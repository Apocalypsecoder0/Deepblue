
import Foundation

// MARK: - Project Management

class ProjectManager {
    private var currentProject: Project?
    private var recentProjects: [String] = []
    
    func createProject(name: String, template: ProjectTemplate) -> Project {
        let project = Project(name: name, path: "/projects/\(name)", template: template)
        currentProject = project
        addToRecentProjects(project.path)
        
        print("📁 Created new project: \(name)")
        setupProjectStructure(project)
        
        return project
    }
    
    func openProject(path: String) -> Project? {
        let project = Project(name: "Loaded Project", path: path, template: .empty)
        currentProject = project
        addToRecentProjects(path)
        
        print("📂 Opened project: \(project.name)")
        return project
    }
    
    func getCurrentProject() -> Project? {
        return currentProject
    }
    
    func getRecentProjects() -> [String] {
        return recentProjects
    }
    
    private func addToRecentProjects(_ path: String) {
        recentProjects.removeAll { $0 == path }
        recentProjects.insert(path, at: 0)
        if recentProjects.count > 10 {
            recentProjects.removeLast()
        }
    }
    
    private func setupProjectStructure(_ project: Project) {
        print("🏗️ Setting up project structure for \(project.template.rawValue) template")
        
        switch project.template {
        case .swiftApp:
            print("  📁 Sources/")
            print("  📁 Tests/")
            print("  📄 Package.swift")
        case .webApp:
            print("  📁 src/")
            print("  📁 public/")
            print("  📁 assets/")
            print("  📄 index.html")
        case .mobileApp:
            print("  📁 src/")
            print("  📁 assets/")
            print("  📁 platforms/")
            print("  📄 config.xml")
        case .empty:
            print("  📄 README.md")
        }
    }
}

struct Project {
    let id: String
    let name: String
    let path: String
    let template: ProjectTemplate
    let createdDate: Date
    
    init(name: String, path: String, template: ProjectTemplate) {
        self.id = UUID().uuidString
        self.name = name
        self.path = path
        self.template = template
        self.createdDate = Date()
    }
}

enum ProjectTemplate: String, CaseIterable {
    case empty = "Empty Project"
    case swiftApp = "Swift Application"
    case webApp = "Web Application"
    case mobileApp = "Mobile Application"
    
    var description: String {
        switch self {
        case .empty: return "A basic empty project"
        case .swiftApp: return "Swift application with Package.swift"
        case .webApp: return "Web application with HTML/CSS/JS"
        case .mobileApp: return "Cross-platform mobile application"
        }
    }
}
