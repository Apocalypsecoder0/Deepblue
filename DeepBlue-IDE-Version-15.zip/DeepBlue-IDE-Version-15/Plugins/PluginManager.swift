
import Foundation

// MARK: - Plugin System

protocol IDEPlugin {
    var name: String { get }
    var version: String { get }
    var author: String { get }
    var description: String { get }
    var dependencies: [String] { get }
    
    func initialize()
    func activate()
    func deactivate()
    func onFileOpen(_ file: File)
    func onFileSave(_ file: File)
    func getMenuItems() -> [PluginMenuItem]
}

struct PluginMenuItem {
    let title: String
    let action: () -> Void
}

class PluginManager {
    private var plugins: [String: IDEPlugin] = [:]
    private var activePlugins: Set<String> = []
    
    func registerPlugin(_ plugin: IDEPlugin) {
        plugins[plugin.name] = plugin
        plugin.initialize()
        print("🔌 Registered plugin: \(plugin.name) v\(plugin.version)")
    }
    
    func activatePlugin(_ name: String) -> Bool {
        guard let plugin = plugins[name] else {
            print("❌ Plugin '\(name)' not found")
            return false
        }
        
        if activePlugins.contains(name) {
            print("⚠️ Plugin '\(name)' is already active")
            return true
        }
        
        plugin.activate()
        activePlugins.insert(name)
        print("✅ Activated plugin: \(name)")
        return true
    }
    
    func deactivatePlugin(_ name: String) -> Bool {
        guard let plugin = plugins[name] else {
            print("❌ Plugin '\(name)' not found")
            return false
        }
        
        if !activePlugins.contains(name) {
            print("⚠️ Plugin '\(name)' is not active")
            return true
        }
        
        plugin.deactivate()
        activePlugins.remove(name)
        print("🔴 Deactivated plugin: \(name)")
        return true
    }
    
    func getActivePlugins() -> [IDEPlugin] {
        return activePlugins.compactMap { plugins[$0] }
    }
    
    func getAllPlugins() -> [IDEPlugin] {
        return Array(plugins.values)
    }
    
    func notifyFileOpen(_ file: File) {
        for plugin in getActivePlugins() {
            plugin.onFileOpen(file)
        }
    }
    
    func notifyFileSave(_ file: File) {
        for plugin in getActivePlugins() {
            plugin.onFileSave(file)
        }
    }
}
