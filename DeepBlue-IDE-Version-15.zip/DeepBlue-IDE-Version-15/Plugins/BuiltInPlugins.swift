
import Foundation

// MARK: - Built-in Plugins

class GitPlugin: IDEPlugin {
    let name = "Git Integration"
    let version = "1.0.0"
    let author = "DeepBlue IDE Team"
    let description = "Enhanced Git integration with visual diff and branch management"
    let dependencies: [String] = []
    
    func initialize() {
        print("🔧 Git plugin initialized")
    }
    
    func activate() {
        print("🟢 Git plugin activated")
    }
    
    func deactivate() {
        print("🔴 Git plugin deactivated")
    }
    
    func onFileOpen(_ file: File) {
        print("📊 Checking Git status for \(file.name)")
    }
    
    func onFileSave(_ file: File) {
        print("💾 Git: File \(file.name) saved - tracking changes")
    }
    
    func getMenuItems() -> [PluginMenuItem] {
        return [
            PluginMenuItem(title: "Git Diff") { print("🔍 Showing Git diff") },
            PluginMenuItem(title: "Git Blame") { print("👤 Showing Git blame") },
            PluginMenuItem(title: "Git Log") { print("📜 Showing Git log") }
        ]
    }
}

class CodeSnippetsPlugin: IDEPlugin {
    let name = "Code Snippets"
    let version = "1.0.0"
    let author = "DeepBlue IDE Team"
    let description = "Code snippet management and insertion"
    let dependencies: [String] = []
    
    private var snippets: [String: String] = [:]
    
    func initialize() {
        loadDefaultSnippets()
        print("📝 Code Snippets plugin initialized")
    }
    
    func activate() {
        print("🟢 Code Snippets plugin activated")
    }
    
    func deactivate() {
        print("🔴 Code Snippets plugin deactivated")
    }
    
    func onFileOpen(_ file: File) {
        print("📝 Loading snippets for \(file.language.rawValue)")
    }
    
    func onFileSave(_ file: File) {
        // Could auto-save custom snippets
    }
    
    func getMenuItems() -> [PluginMenuItem] {
        return [
            PluginMenuItem(title: "Insert Snippet") { self.showSnippets() },
            PluginMenuItem(title: "Create Snippet") { self.createSnippet() }
        ]
    }
    
    private func loadDefaultSnippets() {
        snippets["for_loop_swift"] = """
        for i in 0..<count {
            // code here
        }
        """
        snippets["function_swift"] = """
        func functionName() -> ReturnType {
            // code here
        }
        """
        snippets["class_swift"] = """
        class ClassName {
            init() {
                // initialization
            }
        }
        """
    }
    
    private func showSnippets() {
        print("📝 Available Snippets:")
        for (key, _) in snippets {
            print("  • \(key)")
        }
    }
    
    private func createSnippet() {
        print("✨ Creating new snippet...")
    }
}

class LivePreviewPlugin: IDEPlugin {
    let name = "Live Preview"
    let version = "1.0.0"
    let author = "DeepBlue IDE Team"
    let description = "Live preview for web development"
    let dependencies: [String] = []
    
    func initialize() {
        print("🌐 Live Preview plugin initialized")
    }
    
    func activate() {
        print("🟢 Live Preview plugin activated")
    }
    
    func deactivate() {
        print("🔴 Live Preview plugin deactivated")
    }
    
    func onFileOpen(_ file: File) {
        if file.language == .html || file.language == .css || file.language == .javascript {
            print("🌐 Live preview available for \(file.name)")
        }
    }
    
    func onFileSave(_ file: File) {
        if file.language == .html || file.language == .css || file.language == .javascript {
            print("🔄 Refreshing live preview for \(file.name)")
        }
    }
    
    func getMenuItems() -> [PluginMenuItem] {
        return [
            PluginMenuItem(title: "Start Live Preview") { self.startPreview() },
            PluginMenuItem(title: "Stop Live Preview") { self.stopPreview() }
        ]
    }
    
    private func startPreview() {
        print("🚀 Starting live preview server on port 3000")
    }
    
    private func stopPreview() {
        print("⏹️ Stopping live preview server")
    }
}
