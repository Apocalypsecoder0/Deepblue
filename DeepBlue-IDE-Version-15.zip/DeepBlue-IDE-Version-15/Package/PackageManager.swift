
import Foundation

// MARK: - Package Manager

class PackageManager {
    private var installedPackages: [Package] = []
    
    func searchPackages(_ query: String) -> [Package] {
        let allPackages = [
            Package(name: "SwiftUI", version: "3.0.0", description: "User interface toolkit", language: .swift),
            Package(name: "Alamofire", version: "5.6.0", description: "HTTP networking library", language: .swift),
            Package(name: "React", version: "18.0.0", description: "JavaScript library for building user interfaces", language: .javascript),
            Package(name: "Express", version: "4.18.0", description: "Web application framework for Node.js", language: .javascript),
            Package(name: "NumPy", version: "1.23.0", description: "Scientific computing library", language: .python),
            Package(name: "Django", version: "4.1.0", description: "Web framework for Python", language: .python)
        ]
        
        return allPackages.filter { $0.name.lowercased().contains(query.lowercased()) }
    }
    
    func installPackage(_ package: Package) -> Bool {
        print("📦 Installing package: \(package.name) v\(package.version)")
        
        installedPackages.append(package)
        print("✅ Package \(package.name) installed successfully")
        
        return true
    }
    
    func uninstallPackage(_ packageName: String) -> Bool {
        print("🗑️ Uninstalling package: \(packageName)")
        
        installedPackages.removeAll { $0.name == packageName }
        print("✅ Package \(packageName) uninstalled successfully")
        
        return true
    }
    
    func getInstalledPackages() -> [Package] {
        return installedPackages
    }
    
    func updatePackage(_ packageName: String) -> Bool {
        print("🔄 Updating package: \(packageName)")
        print("✅ Package \(packageName) updated successfully")
        return true
    }
}

struct Package {
    let name: String
    let version: String
    let description: String
    let language: ProgrammingLanguage
    let dependencies: [String]
    
    init(name: String, version: String, description: String, language: ProgrammingLanguage, dependencies: [String] = []) {
        self.name = name
        self.version = version
        self.description = description
        self.language = language
        self.dependencies = dependencies
    }
}
