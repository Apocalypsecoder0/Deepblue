
// IDE State Management
class IDEState {
    constructor() {
        this.openFiles = new Map();
        this.activeFile = null;
        this.currentTheme = 'dark';
        this.settings = {
            fontSize: 14,
            wordWrap: false,
            lineNumbers: true,
            syntaxHighlighting: true
        };
        this.plugins = new Map();
        this.debugSession = null;
    }
}

const ideState = new IDEState();

// Initialize IDE
document.addEventListener('DOMContentLoaded', function() {
    initializeIDE();
    setupEventListeners();
    loadDefaultFiles();
    updateFileTree();
    updateLineNumbers();
});

function initializeIDE() {
    // Set initial theme
    document.documentElement.setAttribute('data-theme', ideState.currentTheme);
    
    // Initialize plugins
    initializePlugins();
    
    // Setup editor
    setupEditor();
    
    console.log('DeepBlue IDE initialized');
}

function setupEventListeners() {
    const codeEditor = document.getElementById('code-editor');
    
    // Editor events
    codeEditor.addEventListener('input', handleCodeChange);
    codeEditor.addEventListener('scroll', syncLineNumbers);
    codeEditor.addEventListener('keydown', handleKeyDown);
    
    // Cursor position tracking
    codeEditor.addEventListener('click', updateCursorPosition);
    codeEditor.addEventListener('keyup', updateCursorPosition);
    
    // Window resize
    window.addEventListener('resize', handleResize);
}

function setupEditor() {
    const editor = document.getElementById('code-editor');
    editor.style.fontSize = ideState.settings.fontSize + 'px';
    editor.style.lineHeight = (ideState.settings.fontSize * 1.4) + 'px';
}

// File Management
function createNewFile() {
    showModal('file-modal');
}

function createFileFromModal() {
    const fileName = document.getElementById('file-name').value;
    const template = document.getElementById('file-template').value;
    
    if (!fileName) {
        alert('Please enter a file name');
        return;
    }
    
    const file = {
        id: generateId(),
        name: fileName,
        content: getTemplateContent(template),
        language: detectLanguage(fileName),
        isModified: false,
        path: `./${fileName}`
    };
    
    ideState.openFiles.set(file.id, file);
    ideState.activeFile = file.id;
    
    updateFileTree();
    updateTabBar();
    loadFileContent(file);
    closeModal('file-modal');
    
    // Clear form
    document.getElementById('file-name').value = '';
    document.getElementById('file-template').value = 'empty';
    
    addOutput(`Created file: ${fileName}`);
}

function openFile() {
    // Simulate file opening dialog
    const fileName = prompt('Enter file name to open:');
    if (!fileName) return;
    
    // Check if file is already open
    for (let [id, file] of ideState.openFiles) {
        if (file.name === fileName) {
            ideState.activeFile = id;
            updateTabBar();
            loadFileContent(file);
            return;
        }
    }
    
    // Create new file if not exists
    const file = {
        id: generateId(),
        name: fileName,
        content: '// File content would be loaded here\n',
        language: detectLanguage(fileName),
        isModified: false,
        path: `./${fileName}`
    };
    
    ideState.openFiles.set(file.id, file);
    ideState.activeFile = file.id;
    
    updateFileTree();
    updateTabBar();
    loadFileContent(file);
    
    addOutput(`Opened file: ${fileName}`);
}

function saveFile() {
    if (!ideState.activeFile) {
        addOutput('No active file to save');
        return;
    }
    
    const file = ideState.openFiles.get(ideState.activeFile);
    const editor = document.getElementById('code-editor');
    file.content = editor.value;
    file.isModified = false;
    
    updateTabBar();
    addOutput(`Saved file: ${file.name}`);
    
    // Simulate backend save
    setTimeout(() => {
        addOutput(`✅ ${file.name} saved successfully`);
    }, 500);
}

function closeFile(fileId) {
    const file = ideState.openFiles.get(fileId);
    if (!file) return;
    
    if (file.isModified) {
        if (!confirm(`${file.name} has unsaved changes. Close anyway?`)) {
            return;
        }
    }
    
    ideState.openFiles.delete(fileId);
    
    if (ideState.activeFile === fileId) {
        // Switch to another open file or clear editor
        const remainingFiles = Array.from(ideState.openFiles.keys());
        if (remainingFiles.length > 0) {
            ideState.activeFile = remainingFiles[0];
            loadFileContent(ideState.openFiles.get(ideState.activeFile));
        } else {
            ideState.activeFile = null;
            clearEditor();
        }
    }
    
    updateTabBar();
    updateFileTree();
    addOutput(`Closed file: ${file.name}`);
}

function loadFileContent(file) {
    const editor = document.getElementById('code-editor');
    editor.value = file.content;
    
    // Update language indicator
    document.getElementById('file-language').textContent = file.language;
    
    // Apply syntax highlighting
    if (ideState.settings.syntaxHighlighting) {
        applySyntaxHighlighting();
    }
    
    updateLineNumbers();
    updateCursorPosition();
}

function clearEditor() {
    const editor = document.getElementById('code-editor');
    editor.value = '';
    document.getElementById('file-language').textContent = 'Plain Text';
    updateLineNumbers();
    updateCursorPosition();
}

// Code Editor Functions
function handleCodeChange(event) {
    if (!ideState.activeFile) return;
    
    const file = ideState.openFiles.get(ideState.activeFile);
    file.content = event.target.value;
    file.isModified = true;
    
    updateTabBar();
    updateLineNumbers();
    
    // Apply syntax highlighting with debounce
    clearTimeout(ideState.syntaxTimeout);
    ideState.syntaxTimeout = setTimeout(() => {
        if (ideState.settings.syntaxHighlighting) {
            applySyntaxHighlighting();
        }
    }, 300);
}

function handleKeyDown(event) {
    // Handle common IDE shortcuts
    if (event.ctrlKey || event.metaKey) {
        switch (event.key) {
            case 's':
                event.preventDefault();
                saveFile();
                break;
            case 'n':
                event.preventDefault();
                createNewFile();
                break;
            case 'o':
                event.preventDefault();
                openFile();
                break;
            case 'f':
                event.preventDefault();
                findInFiles();
                break;
            case 'w':
                event.preventDefault();
                if (ideState.activeFile) {
                    closeFile(ideState.activeFile);
                }
                break;
        }
    }
    
    // Handle Tab key for indentation
    if (event.key === 'Tab') {
        event.preventDefault();
        const editor = event.target;
        const start = editor.selectionStart;
        const end = editor.selectionEnd;
        
        editor.value = editor.value.substring(0, start) + '    ' + editor.value.substring(end);
        editor.selectionStart = editor.selectionEnd = start + 4;
        
        handleCodeChange(event);
    }
}

function updateCursorPosition() {
    const editor = document.getElementById('code-editor');
    const lines = editor.value.substr(0, editor.selectionStart).split('\n');
    const line = lines.length;
    const col = lines[lines.length - 1].length + 1;
    
    document.getElementById('cursor-position').textContent = `Ln ${line}, Col ${col}`;
}

function updateLineNumbers() {
    const editor = document.getElementById('code-editor');
    const lineNumbers = document.getElementById('line-numbers');
    
    if (!ideState.settings.lineNumbers) {
        lineNumbers.style.display = 'none';
        return;
    } else {
        lineNumbers.style.display = 'block';
    }
    
    const lines = editor.value.split('\n');
    const lineCount = lines.length;
    
    let numbersHTML = '';
    for (let i = 1; i <= lineCount; i++) {
        numbersHTML += i + '\n';
    }
    
    lineNumbers.textContent = numbersHTML;
}

function syncLineNumbers() {
    const editor = document.getElementById('code-editor');
    const lineNumbers = document.getElementById('line-numbers');
    lineNumbers.scrollTop = editor.scrollTop;
}

// Compilation and Execution
function compileCode() {
    if (!ideState.activeFile) {
        addOutput('No active file to compile');
        return;
    }
    
    const file = ideState.openFiles.get(ideState.activeFile);
    document.getElementById('compilation-status').textContent = 'Compiling...';
    
    addOutput(`🏗️ Compiling ${file.name}...`);
    
    // Simulate compilation
    setTimeout(() => {
        const success = Math.random() > 0.3; // 70% success rate
        
        if (success) {
            document.getElementById('compilation-status').textContent = 'Compiled';
            addOutput(`✅ Compilation successful for ${file.name}`);
            
            if (file.language === 'swift') {
                addOutput('Swift compilation completed with no errors');
            } else if (file.language === 'python') {
                addOutput('Python syntax check passed');
            } else if (file.language === 'javascript') {
                addOutput('JavaScript validation completed');
            }
        } else {
            document.getElementById('compilation-status').textContent = 'Error';
            addOutput(`❌ Compilation failed for ${file.name}`);
            addOutput('Error: Syntax error on line 5: unexpected token');
        }
    }, 2000);
}

function runCode() {
    if (!ideState.activeFile) {
        addOutput('No active file to run');
        return;
    }
    
    const file = ideState.openFiles.get(ideState.activeFile);
    addOutput(`▶️ Running ${file.name}...`);
    
    // Simulate code execution
    setTimeout(() => {
        if (file.language === 'swift') {
            addOutput('Hello, World!');
        } else if (file.language === 'python') {
            addOutput('55');
        } else if (file.language === 'javascript') {
            addOutput('15');
        } else {
            addOutput('Program output...');
        }
        addOutput(`✅ Execution completed`);
    }, 1500);
}

function formatCode() {
    if (!ideState.activeFile) {
        addOutput('No active file to format');
        return;
    }
    
    const file = ideState.openFiles.get(ideState.activeFile);
    const editor = document.getElementById('code-editor');
    
    // Simple formatting - in a real IDE this would use proper formatters
    let formatted = editor.value;
    
    // Add spaces around operators
    formatted = formatted.replace(/([a-zA-Z0-9])(=)([a-zA-Z0-9])/g, '$1 $2 $3');
    formatted = formatted.replace(/([a-zA-Z0-9])(\+)([a-zA-Z0-9])/g, '$1 $2 $3');
    formatted = formatted.replace(/([a-zA-Z0-9])(-)([a-zA-Z0-9])/g, '$1 $2 $3');
    
    editor.value = formatted;
    file.content = formatted;
    file.isModified = true;
    
    updateTabBar();
    addOutput(`🎨 Formatted ${file.name}`);
}

// Debug Functions
function startDebugging() {
    if (!ideState.activeFile) {
        addOutput('No active file to debug');
        return;
    }
    
    const file = ideState.openFiles.get(ideState.activeFile);
    ideState.debugSession = {
        file: file,
        currentLine: 1,
        breakpoints: new Set([5, 10, 15]), // Simulate some breakpoints
        variables: new Map([
            ['name', '"World"'],
            ['count', '42'],
            ['isValid', 'true']
        ])
    };
    
    updateDebugPanel();
    addOutput(`🐛 Started debugging ${file.name}`);
    addOutput(`⏸️ Paused at breakpoint on line 5`);
}

function stepOver() {
    if (!ideState.debugSession) {
        addOutput('No active debug session');
        return;
    }
    
    ideState.debugSession.currentLine++;
    updateDebugPanel();
    addOutput(`⏭️ Step over - Line ${ideState.debugSession.currentLine}`);
}

function stepInto() {
    if (!ideState.debugSession) {
        addOutput('No active debug session');
        return;
    }
    
    ideState.debugSession.currentLine++;
    updateDebugPanel();
    addOutput(`⬇️ Step into - Line ${ideState.debugSession.currentLine}`);
}

function stepOut() {
    if (!ideState.debugSession) {
        addOutput('No active debug session');
        return;
    }
    
    ideState.debugSession.currentLine++;
    updateDebugPanel();
    addOutput(`⬆️ Step out - Line ${ideState.debugSession.currentLine}`);
}

function stopDebugging() {
    if (!ideState.debugSession) {
        addOutput('No active debug session');
        return;
    }
    
    ideState.debugSession = null;
    updateDebugPanel();
    addOutput(`⏹️ Debug session stopped`);
}

function updateDebugPanel() {
    const breakpointsList = document.getElementById('breakpoints-list');
    const variablesList = document.getElementById('variables-list');
    const callStack = document.getElementById('call-stack');
    
    if (ideState.debugSession) {
        // Update breakpoints
        breakpointsList.innerHTML = '';
        ideState.debugSession.breakpoints.forEach(line => {
            const div = document.createElement('div');
            div.textContent = `Line ${line}`;
            div.className = 'debug-item';
            breakpointsList.appendChild(div);
        });
        
        // Update variables
        variablesList.innerHTML = '';
        ideState.debugSession.variables.forEach((value, name) => {
            const div = document.createElement('div');
            div.textContent = `${name}: ${value}`;
            div.className = 'debug-item';
            variablesList.appendChild(div);
        });
        
        // Update call stack
        callStack.innerHTML = '<div class="debug-item">main()</div>';
    } else {
        breakpointsList.innerHTML = '<div class="debug-item">No breakpoints</div>';
        variablesList.innerHTML = '<div class="debug-item">No variables</div>';
        callStack.innerHTML = '<div class="debug-item">No call stack</div>';
    }
}

// Search and Replace
function findInFiles() {
    showModal('search-modal');
}

function findNext() {
    const query = document.getElementById('search-query').value;
    if (!query) return;
    
    const editor = document.getElementById('code-editor');
    const content = editor.value;
    const currentPos = editor.selectionStart;
    const index = content.indexOf(query, currentPos + 1);
    
    if (index !== -1) {
        editor.setSelectionRange(index, index + query.length);
        editor.focus();
        addOutput(`Found "${query}" at position ${index}`);
    } else {
        addOutput(`"${query}" not found`);
    }
}

function replaceNext() {
    const query = document.getElementById('search-query').value;
    const replacement = document.getElementById('replace-query').value;
    
    if (!query || !ideState.activeFile) return;
    
    const file = ideState.openFiles.get(ideState.activeFile);
    const editor = document.getElementById('code-editor');
    
    if (editor.selectionStart !== editor.selectionEnd) {
        const selectedText = editor.value.substring(editor.selectionStart, editor.selectionEnd);
        if (selectedText === query) {
            editor.setRangeText(replacement, editor.selectionStart, editor.selectionEnd, 'end');
            file.content = editor.value;
            file.isModified = true;
            updateTabBar();
            addOutput(`Replaced "${query}" with "${replacement}"`);
        }
    }
}

function replaceAll() {
    const query = document.getElementById('search-query').value;
    const replacement = document.getElementById('replace-query').value;
    
    if (!query || !ideState.activeFile) return;
    
    const file = ideState.openFiles.get(ideState.activeFile);
    const editor = document.getElementById('code-editor');
    
    const newContent = editor.value.replaceAll(query, replacement);
    const count = (editor.value.match(new RegExp(query, 'g')) || []).length;
    
    editor.value = newContent;
    file.content = newContent;
    file.isModified = true;
    
    updateTabBar();
    updateLineNumbers();
    addOutput(`Replaced ${count} occurrences of "${query}" with "${replacement}"`);
}

// UI Management
function showPanel(panelId) {
    // Hide all panels
    const panels = document.querySelectorAll('.sidebar .panel');
    panels.forEach(panel => panel.style.display = 'none');
    
    // Show selected panel
    const targetPanel = document.getElementById(panelId);
    if (targetPanel) {
        targetPanel.style.display = 'block';
    }
}

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'flex';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

function updateTabBar() {
    const tabBar = document.getElementById('tab-bar');
    tabBar.innerHTML = '';
    
    ideState.openFiles.forEach((file, id) => {
        const tab = document.createElement('div');
        tab.className = 'tab';
        if (id === ideState.activeFile) {
            tab.classList.add('active');
        }
        
        const modifiedIndicator = file.isModified ? ' •' : '';
        tab.innerHTML = `
            <i class="fas fa-file-code"></i>
            <span>${file.name}${modifiedIndicator}</span>
            <button class="tab-close" onclick="closeFile('${id}')" title="Close">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        tab.addEventListener('click', (e) => {
            if (!e.target.closest('.tab-close')) {
                ideState.activeFile = id;
                updateTabBar();
                loadFileContent(file);
            }
        });
        
        tabBar.appendChild(tab);
    });
}

function updateFileTree() {
    const fileTree = document.getElementById('file-tree');
    fileTree.innerHTML = '';
    
    ideState.openFiles.forEach((file, id) => {
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        if (id === ideState.activeFile) {
            fileItem.classList.add('active');
        }
        
        const icon = getFileIcon(file.language);
        fileItem.innerHTML = `
            <i class="${icon}"></i>
            <span>${file.name}</span>
        `;
        
        fileItem.addEventListener('click', () => {
            ideState.activeFile = id;
            updateTabBar();
            updateFileTree();
            loadFileContent(file);
        });
        
        fileTree.appendChild(fileItem);
    });
}

function refreshExplorer() {
    updateFileTree();
    addOutput('File explorer refreshed');
}

// Terminal Functions
function handleTerminalInput(event) {
    if (event.key === 'Enter') {
        const input = event.target;
        const command = input.value.trim();
        
        if (command) {
            addTerminalLine(`$ ${command}`);
            executeTerminalCommand(command);
            input.value = '';
        }
    }
}

function executeTerminalCommand(command) {
    const args = command.split(' ');
    const cmd = args[0].toLowerCase();
    
    switch (cmd) {
        case 'ls':
            const files = Array.from(ideState.openFiles.values()).map(f => f.name);
            addTerminalLine(files.join('  ') || 'No files open');
            break;
        case 'pwd':
            addTerminalLine('/workspace/deepblue-ide');
            break;
        case 'clear':
            clearTerminal();
            break;
        case 'help':
            addTerminalLine('Available commands: ls, pwd, clear, help, git, npm, swift, python');
            break;
        case 'git':
            if (args[1] === 'status') {
                addTerminalLine('On branch main');
                addTerminalLine('Changes not staged for commit:');
                addTerminalLine('  modified: main.swift');
            } else {
                addTerminalLine('Git command executed');
            }
            break;
        default:
            addTerminalLine(`Command '${command}' executed`);
    }
}

function addTerminalLine(text) {
    const container = document.getElementById('terminal-container');
    const line = document.createElement('div');
    line.className = 'terminal-line';
    line.textContent = text;
    container.appendChild(line);
    container.scrollTop = container.scrollHeight;
}

function clearTerminal() {
    const container = document.getElementById('terminal-container');
    container.innerHTML = '<div class="terminal-line">$ Terminal cleared</div>';
}

// Output Functions
function addOutput(text) {
    const container = document.getElementById('output-container');
    const line = document.createElement('div');
    line.className = 'output-line';
    line.textContent = text;
    container.appendChild(line);
    container.scrollTop = container.scrollHeight;
}

function clearOutput() {
    const container = document.getElementById('output-container');
    container.innerHTML = '<div class="output-line">Output cleared</div>';
}

// Theme and Settings
function toggleTheme() {
    const themes = ['dark', 'light', 'high-contrast'];
    const currentIndex = themes.indexOf(ideState.currentTheme);
    const nextIndex = (currentIndex + 1) % themes.length;
    
    ideState.currentTheme = themes[nextIndex];
    document.documentElement.setAttribute('data-theme', ideState.currentTheme);
    document.getElementById('theme-select').value = ideState.currentTheme;
    
    addOutput(`Theme changed to: ${ideState.currentTheme}`);
}

function changeTheme(theme) {
    ideState.currentTheme = theme;
    document.documentElement.setAttribute('data-theme', theme);
    addOutput(`Theme changed to: ${theme}`);
}

function changeFontSize(size) {
    ideState.settings.fontSize = parseInt(size);
    document.getElementById('font-size-value').textContent = size + 'px';
    setupEditor();
    updateLineNumbers();
    addOutput(`Font size changed to: ${size}px`);
}

function toggleWordWrap(enabled) {
    ideState.settings.wordWrap = enabled;
    const editor = document.getElementById('code-editor');
    editor.style.whiteSpace = enabled ? 'pre-wrap' : 'pre';
    addOutput(`Word wrap: ${enabled ? 'enabled' : 'disabled'}`);
}

function toggleLineNumbers(enabled) {
    ideState.settings.lineNumbers = enabled;
    updateLineNumbers();
    addOutput(`Line numbers: ${enabled ? 'enabled' : 'disabled'}`);
}

function toggleSyntaxHighlighting(enabled) {
    ideState.settings.syntaxHighlighting = enabled;
    if (enabled) {
        applySyntaxHighlighting();
    }
    addOutput(`Syntax highlighting: ${enabled ? 'enabled' : 'disabled'}`);
}

// Plugin Management
function initializePlugins() {
    const plugins = [
        { name: 'Git Integration', version: '1.0.0', active: true },
        { name: 'Code Snippets', version: '1.0.0', active: true },
        { name: 'Live Preview', version: '1.0.0', active: false },
        { name: 'Bracket Pair Colorizer', version: '2.0.0', active: false },
        { name: 'REST Client', version: '0.25.0', active: false }
    ];
    
    plugins.forEach(plugin => {
        ideState.plugins.set(plugin.name, plugin);
    });
    
    updatePluginPanel();
}

function updatePluginPanel() {
    const installedPlugins = document.getElementById('installed-plugins');
    const availablePlugins = document.getElementById('available-plugins');
    
    installedPlugins.innerHTML = '';
    availablePlugins.innerHTML = '';
    
    ideState.plugins.forEach(plugin => {
        const pluginItem = document.createElement('div');
        pluginItem.className = 'plugin-item';
        
        pluginItem.innerHTML = `
            <div class="plugin-info">
                <h5>${plugin.name}</h5>
                <p>Version ${plugin.version}</p>
            </div>
            <button class="plugin-btn" onclick="togglePlugin('${plugin.name}')">
                ${plugin.active ? 'Deactivate' : 'Activate'}
            </button>
        `;
        
        if (plugin.active) {
            installedPlugins.appendChild(pluginItem);
        } else {
            availablePlugins.appendChild(pluginItem);
        }
    });
}

function togglePlugin(pluginName) {
    const plugin = ideState.plugins.get(pluginName);
    if (plugin) {
        plugin.active = !plugin.active;
        updatePluginPanel();
        addOutput(`Plugin ${pluginName}: ${plugin.active ? 'activated' : 'deactivated'}`);
    }
}

// Utility Functions
function generateId() {
    return Math.random().toString(36).substr(2, 9);
}

function detectLanguage(fileName) {
    const ext = fileName.split('.').pop().toLowerCase();
    const languageMap = {
        'swift': 'swift',
        'py': 'python',
        'js': 'javascript',
        'ts': 'typescript',
        'java': 'java',
        'cpp': 'cpp',
        'c': 'c',
        'cs': 'csharp',
        'go': 'go',
        'rs': 'rust',
        'php': 'php',
        'rb': 'ruby',
        'html': 'html',
        'css': 'css',
        'json': 'json',
        'xml': 'xml',
        'sql': 'sql',
        'sh': 'bash',
        'ps1': 'powershell',
        'yaml': 'yaml',
        'yml': 'yaml',
        'md': 'markdown'
    };
    
    return languageMap[ext] || 'text';
}

function getFileIcon(language) {
    const iconMap = {
        'swift': 'fab fa-swift',
        'python': 'fab fa-python',
        'javascript': 'fab fa-js-square',
        'typescript': 'fas fa-code',
        'java': 'fab fa-java',
        'cpp': 'fas fa-code',
        'c': 'fas fa-code',
        'html': 'fab fa-html5',
        'css': 'fab fa-css3-alt',
        'json': 'fas fa-brackets-curly',
        'markdown': 'fab fa-markdown'
    };
    
    return iconMap[language] || 'fas fa-file-code';
}

function getTemplateContent(template) {
    const templates = {
        'swift': `import Foundation

func main() {
    print("Hello, World!")
}

main()`,
        'python': `def main():
    print("Hello, World!")

if __name__ == "__main__":
    main()`,
        'javascript': `function main() {
    console.log("Hello, World!");
}

main();`,
        'html': `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Hello, World!</h1>
</body>
</html>`,
        'css': `body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background-color: #f0f0f0;
}`
    };
    
    return templates[template] || '';
}

function applySyntaxHighlighting() {
    // This is a simple syntax highlighting implementation
    // In a real IDE, you would use a proper syntax highlighting library
    const editor = document.getElementById('code-editor');
    if (!editor.value) return;
    
    // For now, just update the display - actual highlighting would require more complex implementation
    addOutput('Syntax highlighting applied');
}

function loadDefaultFiles() {
    // Load some default files to showcase the IDE
    const files = [
        {
            name: 'main.swift',
            content: `import Foundation

func greet(name: String) -> String {
    return "Hello, \\(name)!"
}

let message = greet(name: "World")
print(message)`,
            language: 'swift'
        },
        {
            name: 'script.py',
            content: `def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

print(fibonacci(10))`,
            language: 'python'
        },
        {
            name: 'app.js',
            content: `function calculateSum(numbers) {
    return numbers.reduce((sum, num) => sum + num, 0);
}

const result = calculateSum([1, 2, 3, 4, 5]);
console.log(result);`,
            language: 'javascript'
        }
    ];
    
    files.forEach(fileData => {
        const file = {
            id: generateId(),
            name: fileData.name,
            content: fileData.content,
            language: fileData.language,
            isModified: false,
            path: `./${fileData.name}`
        };
        
        ideState.openFiles.set(file.id, file);
    });
    
    // Set first file as active
    const firstFile = Array.from(ideState.openFiles.keys())[0];
    if (firstFile) {
        ideState.activeFile = firstFile;
        loadFileContent(ideState.openFiles.get(firstFile));
    }
}

function handleResize() {
    updateLineNumbers();
}

// Export for external use
window.ideState = ideState;
