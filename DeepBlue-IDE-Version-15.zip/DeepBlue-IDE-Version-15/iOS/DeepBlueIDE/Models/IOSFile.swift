
import Foundation

class IOSFile {
    let id: UUID
    let name: String
    let path: String
    let language: ProgrammingLanguage
    var content: String
    let createdDate: Date
    var modifiedDate: Date
    
    init(name: String, path: String, language: ProgrammingLanguage, content: String) {
        self.id = UUID()
        self.name = name
        self.path = path
        self.language = language
        self.content = content
        self.createdDate = Date()
        self.modifiedDate = Date()
    }
    
    func updateContent(_ newContent: String) {
        content = newContent
        modifiedDate = Date()
    }
    
    var fileExtension: String {
        return (name as NSString).pathExtension
    }
    
    var isModified: Bool {
        return modifiedDate > createdDate
    }
}

class IOSFileManager {
    private var files: [IOSFile] = []
    private var currentProject: IOSProject?
    
    func startMonitoring() {
        print("📁 iOS File Manager: Started monitoring file system")
    }
    
    func createFile(name: String, content: String = "") -> IOSFile {
        let language = detectLanguage(from: name)
        let file = IOSFile(name: name, path: "/project/\(name)", language: language, content: content)
        files.append(file)
        return file
    }
    
    func openFile(at path: String) -> IOSFile? {
        return files.first { $0.path == path }
    }
    
    func saveFile(_ file: IOSFile) {
        // In a real implementation, this would save to the file system
        file.modifiedDate = Date()
        print("💾 Saved file: \(file.name)")
    }
    
    func deleteFile(_ file: IOSFile) {
        files.removeAll { $0.id == file.id }
        print("🗑️ Deleted file: \(file.name)")
    }
    
    func getAllFiles() -> [IOSFile] {
        return files
    }
    
    private func detectLanguage(from filename: String) -> ProgrammingLanguage {
        let extension = (filename as NSString).pathExtension.lowercased()
        
        switch extension {
        case "swift": return .swift
        case "py": return .python
        case "js": return .javascript
        case "ts": return .typescript
        case "java": return .java
        case "cpp", "cc", "cxx": return .cpp
        case "cs": return .csharp
        case "go": return .go
        case "rs": return .rust
        case "php": return .php
        case "rb": return .ruby
        case "html", "htm": return .html
        case "css": return .css
        case "json": return .json
        case "xml": return .xml
        case "sql": return .sql
        case "sh": return .bash
        case "ps1": return .powershell
        case "yml", "yaml": return .yaml
        case "md": return .markdown
        default: return .swift
        }
    }
}

struct IOSProject {
    let id: UUID
    let name: String
    let path: String
    let files: [IOSFile]
    let createdDate: Date
    
    init(name: String, path: String, files: [IOSFile] = []) {
        self.id = UUID()
        self.name = name
        self.path = path
        self.files = files
        self.createdDate = Date()
    }
}
