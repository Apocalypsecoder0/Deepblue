
import UIKit

class LineNumberView: UIView {
    
    // MARK: - Properties
    private var lineNumbers: [String] = []
    private var font: UIFont = UIFont.monospacedSystemFont(ofSize: 12, weight: .regular)
    
    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupUI()
    }
    
    // MARK: - Setup
    private func setupUI() {
        backgroundColor = .systemGray6
        layer.borderWidth = 0.5
        layer.borderColor = UIColor.systemGray4.cgColor
    }
    
    // MARK: - Drawing
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        
        guard let context = UIGraphicsGetCurrentContext() else { return }
        
        // Clear background
        context.setFillColor(UIColor.systemGray6.cgColor)
        context.fill(rect)
        
        // Draw line numbers
        let lineHeight: CGFloat = font.lineHeight
        let startY: CGFloat = 2
        
        for (index, lineNumber) in lineNumbers.enumerated() {
            let y = startY + (CGFloat(index) * lineHeight)
            let textRect = CGRect(x: 4, y: y, width: rect.width - 8, height: lineHeight)
            
            let attributes: [NSAttributedString.Key: Any] = [
                .font: font,
                .foregroundColor: UIColor.systemGray
            ]
            
            let attributedString = NSAttributedString(string: lineNumber, attributes: attributes)
            attributedString.draw(in: textRect)
        }
    }
    
    // MARK: - Public Methods
    func updateLineNumbers(for text: String) {
        let lines = text.components(separatedBy: .newlines)
        lineNumbers = []
        
        for i in 1...max(lines.count, 1) {
            lineNumbers.append("\(i)")
        }
        
        setNeedsDisplay()
    }
    
    func setFont(_ font: UIFont) {
        self.font = font
        setNeedsDisplay()
    }
}
