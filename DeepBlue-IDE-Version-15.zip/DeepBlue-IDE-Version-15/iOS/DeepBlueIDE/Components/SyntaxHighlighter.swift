
import UIKit

class SyntaxHighlighter {
    
    // MARK: - Color Themes
    struct ColorTheme {
        let keyword: UIColor
        let string: UIColor
        let comment: UIColor
        let number: UIColor
        let type: UIColor
        let function: UIColor
        let variable: UIColor
        let background: UIColor
        let text: UIColor
    }
    
    private let darkTheme = ColorTheme(
        keyword: UIColor.systemPurple,
        string: UIColor.systemRed,
        comment: UIColor.systemGray,
        number: UIColor.systemBlue,
        type: UIColor.systemTeal,
        function: UIColor.systemGreen,
        variable: UIColor.systemOrange,
        background: UIColor.systemBackground,
        text: UIColor.label
    )
    
    // MARK: - Public Methods
    func highlightSyntax(for language: ProgrammingLanguage, in textView: UITextView) {
        let text = textView.text ?? ""
        let attributedString = NSMutableAttributedString(string: text)
        
        // Reset to default color
        attributedString.addAttribute(.foregroundColor, value: darkTheme.text, range: NSRange(location: 0, length: text.count))
        
        // Apply syntax highlighting based on language
        switch language {
        case .swift:
            highlightSwift(in: attributedString)
        case .python:
            highlightPython(in: attributedString)
        case .javascript:
            highlightJavaScript(in: attributedString)
        case .html:
            highlightHTML(in: attributedString)
        case .css:
            highlightCSS(in: attributedString)
        case .json:
            highlightJSON(in: attributedString)
        default:
            highlightGeneric(in: attributedString)
        }
        
        textView.attributedText = attributedString
    }
    
    // MARK: - Language-Specific Highlighting
    private func highlightSwift(in attributedString: NSMutableAttributedString) {
        let keywords = [
            "func", "var", "let", "class", "struct", "enum", "protocol", "extension",
            "import", "if", "else", "switch", "case", "default", "for", "while",
            "repeat", "break", "continue", "return", "true", "false", "nil",
            "public", "private", "internal", "fileprivate", "open", "static",
            "override", "init", "deinit", "self", "super", "throws", "try", "catch"
        ]
        
        let types = [
            "String", "Int", "Double", "Float", "Bool", "Array", "Dictionary",
            "Optional", "Any", "AnyObject", "Void", "UIViewController", "UIView"
        ]
        
        highlightKeywords(keywords, in: attributedString, color: darkTheme.keyword)
        highlightKeywords(types, in: attributedString, color: darkTheme.type)
        highlightStrings(in: attributedString)
        highlightComments(in: attributedString)
        highlightNumbers(in: attributedString)
    }
    
    private func highlightPython(in attributedString: NSMutableAttributedString) {
        let keywords = [
            "def", "class", "if", "else", "elif", "for", "while", "break", "continue",
            "return", "import", "from", "as", "try", "except", "finally", "with",
            "lambda", "global", "nonlocal", "True", "False", "None", "and", "or", "not"
        ]
        
        highlightKeywords(keywords, in: attributedString, color: darkTheme.keyword)
        highlightStrings(in: attributedString)
        highlightComments(in: attributedString, commentSymbol: "#")
        highlightNumbers(in: attributedString)
    }
    
    private func highlightJavaScript(in attributedString: NSMutableAttributedString) {
        let keywords = [
            "function", "var", "let", "const", "if", "else", "for", "while", "do",
            "break", "continue", "return", "switch", "case", "default", "try",
            "catch", "finally", "throw", "new", "this", "typeof", "instanceof",
            "true", "false", "null", "undefined"
        ]
        
        highlightKeywords(keywords, in: attributedString, color: darkTheme.keyword)
        highlightStrings(in: attributedString)
        highlightComments(in: attributedString, commentSymbol: "//")
        highlightNumbers(in: attributedString)
    }
    
    private func highlightHTML(in attributedString: NSMutableAttributedString) {
        let text = attributedString.string
        
        // Highlight HTML tags
        let tagPattern = "<[^>]+>"
        highlightPattern(tagPattern, in: attributedString, color: darkTheme.keyword)
        
        // Highlight attributes
        let attributePattern = "\\b\\w+(?=\\s*=)"
        highlightPattern(attributePattern, in: attributedString, color: darkTheme.type)
        
        // Highlight attribute values
        let valuePattern = "\"[^\"]*\""
        highlightPattern(valuePattern, in: attributedString, color: darkTheme.string)
        
        // Highlight comments
        let commentPattern = "<!--[\\s\\S]*?-->"
        highlightPattern(commentPattern, in: attributedString, color: darkTheme.comment)
    }
    
    private func highlightCSS(in attributedString: NSMutableAttributedString) {
        // Highlight CSS selectors
        let selectorPattern = "^\\s*[.#]?[a-zA-Z][\\w-]*\\s*(?=\\{)"
        highlightPattern(selectorPattern, in: attributedString, color: darkTheme.keyword)
        
        // Highlight CSS properties
        let propertyPattern = "\\b[a-zA-Z-]+(?=\\s*:)"
        highlightPattern(propertyPattern, in: attributedString, color: darkTheme.type)
        
        // Highlight CSS values
        let valuePattern = ":\\s*[^;]+;"
        highlightPattern(valuePattern, in: attributedString, color: darkTheme.string)
        
        // Highlight comments
        let commentPattern = "/\\*[\\s\\S]*?\\*/"
        highlightPattern(commentPattern, in: attributedString, color: darkTheme.comment)
    }
    
    private func highlightJSON(in attributedString: NSMutableAttributedString) {
        // Highlight JSON keys
        let keyPattern = "\"[^\"]+\"\\s*:"
        highlightPattern(keyPattern, in: attributedString, color: darkTheme.keyword)
        
        // Highlight JSON strings
        let stringPattern = "\"[^\"]*\""
        highlightPattern(stringPattern, in: attributedString, color: darkTheme.string)
        
        // Highlight JSON numbers
        highlightNumbers(in: attributedString)
        
        // Highlight JSON literals
        let literalPattern = "\\b(true|false|null)\\b"
        highlightPattern(literalPattern, in: attributedString, color: darkTheme.type)
    }
    
    private func highlightGeneric(in attributedString: NSMutableAttributedString) {
        highlightStrings(in: attributedString)
        highlightComments(in: attributedString)
        highlightNumbers(in: attributedString)
    }
    
    // MARK: - Helper Methods
    private func highlightKeywords(_ keywords: [String], in attributedString: NSMutableAttributedString, color: UIColor) {
        let text = attributedString.string
        for keyword in keywords {
            let pattern = "\\b\(keyword)\\b"
            highlightPattern(pattern, in: attributedString, color: color)
        }
    }
    
    private func highlightStrings(in attributedString: NSMutableAttributedString) {
        let stringPattern = "\"[^\"\\n]*\""
        highlightPattern(stringPattern, in: attributedString, color: darkTheme.string)
        
        let singleQuotePattern = "'[^'\\n]*'"
        highlightPattern(singleQuotePattern, in: attributedString, color: darkTheme.string)
    }
    
    private func highlightComments(in attributedString: NSMutableAttributedString, commentSymbol: String = "//") {
        let commentPattern = "\(commentSymbol).*$"
        highlightPattern(commentPattern, in: attributedString, color: darkTheme.comment, options: [.anchorsMatchLines])
    }
    
    private func highlightNumbers(in attributedString: NSMutableAttributedString) {
        let numberPattern = "\\b\\d+(\\.\\d+)?\\b"
        highlightPattern(numberPattern, in: attributedString, color: darkTheme.number)
    }
    
    private func highlightPattern(_ pattern: String, in attributedString: NSMutableAttributedString, color: UIColor, options: NSRegularExpression.Options = []) {
        do {
            let regex = try NSRegularExpression(pattern: pattern, options: options)
            let range = NSRange(location: 0, length: attributedString.length)
            let matches = regex.matches(in: attributedString.string, options: [], range: range)
            
            for match in matches {
                attributedString.addAttribute(.foregroundColor, value: color, range: match.range)
            }
        } catch {
            print("Error highlighting pattern: \(pattern)")
        }
    }
}
