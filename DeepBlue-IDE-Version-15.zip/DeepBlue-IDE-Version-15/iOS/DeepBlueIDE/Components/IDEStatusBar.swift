
import UIKit

class IDEStatusBar: UIView {
    
    // MARK: - Properties
    private var statusLabel: UILabel!
    private var lineColumnLabel: UILabel!
    private var languageLabel: UILabel!
    private var encodingLabel: UILabel!
    
    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupUI()
    }
    
    // MARK: - Setup
    private func setupUI() {
        backgroundColor = .systemGray6
        layer.borderWidth = 0.5
        layer.borderColor = UIColor.systemGray4.cgColor
        
        // Create labels
        statusLabel = createLabel(text: "Ready", alignment: .left)
        lineColumnLabel = createLabel(text: "Ln 1, Col 1", alignment: .right)
        languageLabel = createLabel(text: "Swift", alignment: .right)
        encodingLabel = createLabel(text: "UTF-8", alignment: .right)
        
        // Add subviews
        addSubview(statusLabel)
        addSubview(lineColumnLabel)
        addSubview(languageLabel)
        addSubview(encodingLabel)
        
        // Setup constraints
        setupConstraints()
    }
    
    private func createLabel(text: String, alignment: NSTextAlignment) -> UILabel {
        let label = UILabel()
        label.text = text
        label.font = UIFont.systemFont(ofSize: 11)
        label.textColor = .secondaryLabel
        label.textAlignment = alignment
        return label
    }
    
    private func setupConstraints() {
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        lineColumnLabel.translatesAutoresizingMaskIntoConstraints = false
        languageLabel.translatesAutoresizingMaskIntoConstraints = false
        encodingLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            // Status label (left side)
            statusLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 8),
            statusLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            statusLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 100),
            
            // Encoding label (right side)
            encodingLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8),
            encodingLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            encodingLabel.widthAnchor.constraint(equalToConstant: 50),
            
            // Language label
            languageLabel.trailingAnchor.constraint(equalTo: encodingLabel.leadingAnchor, constant: -8),
            languageLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            languageLabel.widthAnchor.constraint(equalToConstant: 60),
            
            // Line/Column label
            lineColumnLabel.trailingAnchor.constraint(equalTo: languageLabel.leadingAnchor, constant: -8),
            lineColumnLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            lineColumnLabel.widthAnchor.constraint(equalToConstant: 80)
        ])
    }
    
    // MARK: - Public Methods
    func updateStatus(_ status: String) {
        statusLabel.text = status
    }
    
    func updateLineColumn(line: Int, column: Int) {
        lineColumnLabel.text = "Ln \(line), Col \(column)"
    }
    
    func updateLanguage(_ language: String) {
        languageLabel.text = language
    }
    
    func updateEncoding(_ encoding: String) {
        encodingLabel.text = encoding
    }
}
