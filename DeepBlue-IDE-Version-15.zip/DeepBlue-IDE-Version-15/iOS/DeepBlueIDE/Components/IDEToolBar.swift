
import UIKit

protocol IDEToolBarDelegate: AnyObject {
    func toolBarDidTapRun(_ toolBar: IDEToolBar)
    func toolBarDidTapDebug(_ toolBar: IDEToolBar)
    func toolBarDidTapBuild(_ toolBar: IDEToolBar)
}

class IDEToolBar: UIView {
    
    // MARK: - Properties
    weak var delegate: IDEToolBarDelegate?
    private var stackView: UIStackView!
    private var runButton: UIButton!
    private var debugButton: UIButton!
    private var buildButton: UIButton!
    private var stopButton: UIButton!
    
    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupUI()
    }
    
    // MARK: - Setup
    private func setupUI() {
        backgroundColor = .systemBackground
        layer.borderWidth = 0.5
        layer.borderColor = UIColor.systemGray4.cgColor
        
        // Create buttons
        runButton = createButton(title: "Run", systemImage: "play.fill", color: .systemGreen)
        debugButton = createButton(title: "Debug", systemImage: "ladybug.fill", color: .systemOrange)
        buildButton = createButton(title: "Build", systemImage: "hammer.fill", color: .systemBlue)
        stopButton = createButton(title: "Stop", systemImage: "stop.fill", color: .systemRed)
        
        // Add targets
        runButton.addTarget(self, action: #selector(runButtonTapped), for: .touchUpInside)
        debugButton.addTarget(self, action: #selector(debugButtonTapped), for: .touchUpInside)
        buildButton.addTarget(self, action: #selector(buildButtonTapped), for: .touchUpInside)
        stopButton.addTarget(self, action: #selector(stopButtonTapped), for: .touchUpInside)
        
        // Create stack view
        stackView = UIStackView(arrangedSubviews: [runButton, debugButton, buildButton, stopButton])
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        stackView.spacing = 8
        
        // Add spacer
        let spacer = UIView()
        stackView.addArrangedSubview(spacer)
        
        // Add subview
        addSubview(stackView)
        
        // Setup constraints
        setupConstraints()
    }
    
    private func createButton(title: String, systemImage: String, color: UIColor) -> UIButton {
        let button = UIButton(type: .system)
        button.setTitle(title, for: .normal)
        button.setImage(UIImage(systemName: systemImage), for: .normal)
        button.tintColor = color
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12, weight: .medium)
        button.imageView?.contentMode = .scaleAspectFit
        
        // Configure button layout
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 4, bottom: 0, right: 0)
        button.imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 4)
        
        return button
    }
    
    private func setupConstraints() {
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            stackView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(lessThanOrEqualTo: trailingAnchor, constant: -16),
            stackView.centerYAnchor.constraint(equalTo: centerYAnchor),
            stackView.heightAnchor.constraint(equalToConstant: 32)
        ])
    }
    
    // MARK: - Actions
    @objc private func runButtonTapped() {
        delegate?.toolBarDidTapRun(self)
        animateButtonPress(runButton)
    }
    
    @objc private func debugButtonTapped() {
        delegate?.toolBarDidTapDebug(self)
        animateButtonPress(debugButton)
    }
    
    @objc private func buildButtonTapped() {
        delegate?.toolBarDidTapBuild(self)
        animateButtonPress(buildButton)
    }
    
    @objc private func stopButtonTapped() {
        // Stop current operation
        animateButtonPress(stopButton)
    }
    
    private func animateButtonPress(_ button: UIButton) {
        UIView.animate(withDuration: 0.1, animations: {
            button.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
        }) { _ in
            UIView.animate(withDuration: 0.1) {
                button.transform = .identity
            }
        }
    }
    
    // MARK: - Public Methods
    func setRunning(_ isRunning: Bool) {
        runButton.isEnabled = !isRunning
        debugButton.isEnabled = !isRunning
        buildButton.isEnabled = !isRunning
        stopButton.isEnabled = isRunning
    }
}
