
import UIKit

class FileTableViewCell: UITableViewCell {
    
    // MARK: - Properties
    private var fileIconImageView: UIImageView!
    private var fileNameLabel: UILabel!
    private var filePathLabel: UILabel!
    
    // MARK: - Initialization
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupUI()
    }
    
    // MARK: - Setup
    private func setupUI() {
        // Create UI elements
        fileIconImageView = UIImageView()
        fileIconImageView.contentMode = .scaleAspectFit
        fileIconImageView.tintColor = .systemBlue
        
        fileNameLabel = UILabel()
        fileNameLabel.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        fileNameLabel.textColor = .label
        
        filePathLabel = UILabel()
        filePathLabel.font = UIFont.systemFont(ofSize: 12)
        filePathLabel.textColor = .secondaryLabel
        
        // Add subviews
        contentView.addSubview(fileIconImageView)
        contentView.addSubview(fileNameLabel)
        contentView.addSubview(filePathLabel)
        
        // Setup constraints
        setupConstraints()
    }
    
    private func setupConstraints() {
        fileIconImageView.translatesAutoresizingMaskIntoConstraints = false
        fileNameLabel.translatesAutoresizingMaskIntoConstraints = false
        filePathLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            // File icon
            fileIconImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            fileIconImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            fileIconImageView.widthAnchor.constraint(equalToConstant: 24),
            fileIconImageView.heightAnchor.constraint(equalToConstant: 24),
            
            // File name
            fileNameLabel.leadingAnchor.constraint(equalTo: fileIconImageView.trailingAnchor, constant: 12),
            fileNameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            fileNameLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            
            // File path
            filePathLabel.leadingAnchor.constraint(equalTo: fileIconImageView.trailingAnchor, constant: 12),
            filePathLabel.topAnchor.constraint(equalTo: fileNameLabel.bottomAnchor, constant: 2),
            filePathLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            filePathLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8)
        ])
    }
    
    // MARK: - Public Methods
    func configure(with file: IOSFile) {
        fileNameLabel.text = file.name
        filePathLabel.text = file.path
        fileIconImageView.image = getIcon(for: file.language)
    }
    
    private func getIcon(for language: ProgrammingLanguage) -> UIImage? {
        switch language {
        case .swift:
            return UIImage(systemName: "swift")
        case .javascript:
            return UIImage(systemName: "doc.text")
        case .python:
            return UIImage(systemName: "doc.text")
        case .html:
            return UIImage(systemName: "globe")
        case .css:
            return UIImage(systemName: "paintbrush")
        case .json:
            return UIImage(systemName: "doc.text")
        case .markdown:
            return UIImage(systemName: "doc.richtext")
        default:
            return UIImage(systemName: "doc")
        }
    }
}
