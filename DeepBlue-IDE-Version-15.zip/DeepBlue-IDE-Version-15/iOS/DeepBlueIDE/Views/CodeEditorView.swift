
import UIKit

protocol CodeEditorViewDelegate: AnyObject {
    func codeEditorDidChange(_ editor: CodeEditorView, text: String)
    func codeEditorDidSave(_ editor: CodeEditorView)
}

class CodeEditorView: UIView {
    
    // MARK: - Properties
    weak var delegate: CodeEditorViewDelegate?
    private var textView: UITextView!
    private var lineNumberView: LineNumberView!
    private var currentFile: IOSFile?
    private var syntaxHighlighter: SyntaxHighlighter!
    
    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupUI()
    }
    
    // MARK: - Setup
    private func setupUI() {
        backgroundColor = .systemBackground
        
        // Initialize components
        lineNumberView = LineNumberView()
        textView = UITextView()
        syntaxHighlighter = SyntaxHighlighter()
        
        // Configure text view
        textView.font = UIFont.monospacedSystemFont(ofSize: 14, weight: .regular)
        textView.backgroundColor = .systemBackground
        textView.textColor = .label
        textView.delegate = self
        textView.autocorrectionType = .no
        textView.autocapitalizationType = .none
        textView.smartDashesType = .no
        textView.smartQuotesType = .no
        textView.smartInsertDeleteType = .no
        
        // Add subviews
        addSubview(lineNumberView)
        addSubview(textView)
        
        // Setup constraints
        setupConstraints()
        
        // Setup keyboard shortcuts
        setupKeyboardShortcuts()
    }
    
    private func setupConstraints() {
        lineNumberView.translatesAutoresizingMaskIntoConstraints = false
        textView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            // Line number view
            lineNumberView.topAnchor.constraint(equalTo: topAnchor),
            lineNumberView.leadingAnchor.constraint(equalTo: leadingAnchor),
            lineNumberView.widthAnchor.constraint(equalToConstant: 50),
            lineNumberView.bottomAnchor.constraint(equalTo: bottomAnchor),
            
            // Text view
            textView.topAnchor.constraint(equalTo: topAnchor),
            textView.leadingAnchor.constraint(equalTo: lineNumberView.trailingAnchor),
            textView.trailingAnchor.constraint(equalTo: trailingAnchor),
            textView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }
    
    private func setupKeyboardShortcuts() {
        // Command+S for save
        let saveCommand = UIKeyCommand(
            title: "Save",
            action: #selector(saveFile),
            input: "s",
            modifierFlags: .command
        )
        
        // Command+Z for undo
        let undoCommand = UIKeyCommand(
            title: "Undo",
            action: #selector(undoAction),
            input: "z",
            modifierFlags: .command
        )
        
        // Command+Shift+Z for redo
        let redoCommand = UIKeyCommand(
            title: "Redo",
            action: #selector(redoAction),
            input: "z",
            modifierFlags: [.command, .shift]
        )
        
        if let window = UIApplication.shared.windows.first {
            window.addGestureRecognizer(UITapGestureRecognizer())
        }
    }
    
    // MARK: - Public Methods
    func loadFile(_ file: IOSFile) {
        currentFile = file
        textView.text = file.content
        syntaxHighlighter.highlightSyntax(for: file.language, in: textView)
        lineNumberView.updateLineNumbers(for: textView.text)
    }
    
    func getCurrentText() -> String {
        return textView.text ?? ""
    }
    
    // MARK: - Actions
    @objc private func saveFile() {
        guard let file = currentFile else { return }
        
        file.content = textView.text
        // Here you would save to file system
        delegate?.codeEditorDidSave(self)
    }
    
    @objc private func undoAction() {
        textView.undoManager?.undo()
    }
    
    @objc private func redoAction() {
        textView.undoManager?.redo()
    }
}

// MARK: - UITextViewDelegate
extension CodeEditorView: UITextViewDelegate {
    func textViewDidChange(_ textView: UITextView) {
        delegate?.codeEditorDidChange(self, text: textView.text)
        lineNumberView.updateLineNumbers(for: textView.text)
        
        // Apply syntax highlighting
        if let file = currentFile {
            syntaxHighlighter.highlightSyntax(for: file.language, in: textView)
        }
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        // Auto-indentation
        if text == "\n" {
            let currentLine = getCurrentLine(in: textView, at: range.location)
            let indentation = getIndentation(from: currentLine)
            
            DispatchQueue.main.async {
                textView.insertText("\n\(indentation)")
            }
            return false
        }
        
        return true
    }
    
    private func getCurrentLine(in textView: UITextView, at location: Int) -> String {
        let text = textView.text as NSString
        let lineRange = text.lineRange(for: NSRange(location: location, length: 0))
        return text.substring(with: lineRange)
    }
    
    private func getIndentation(from line: String) -> String {
        var indentation = ""
        for char in line {
            if char == " " || char == "\t" {
                indentation += String(char)
            } else {
                break
            }
        }
        return indentation
    }
}
