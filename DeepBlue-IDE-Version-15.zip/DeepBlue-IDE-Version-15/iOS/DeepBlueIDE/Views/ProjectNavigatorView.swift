
import UIKit

protocol ProjectNavigatorViewDelegate: AnyObject {
    func projectNavigator(_ navigator: ProjectNavigatorView, didSelectFile file: IOSFile)
    func projectNavigator(_ navigator: ProjectNavigatorView, didCreateFile file: IOSFile)
}

class ProjectNavigatorView: UIView {
    
    // MARK: - Properties
    weak var delegate: ProjectNavigatorViewDelegate?
    private var tableView: UITableView!
    private var files: [IOSFile] = []
    private var searchBar: UISearchBar!
    
    // MARK: - Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
        loadFiles()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupUI()
        loadFiles()
    }
    
    // MARK: - Setup
    private func setupUI() {
        backgroundColor = .systemGroupedBackground
        
        // Create search bar
        searchBar = UISearchBar()
        searchBar.placeholder = "Search files..."
        searchBar.delegate = self
        searchBar.searchBarStyle = .minimal
        
        // Create table view
        tableView = UITableView()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(FileTableViewCell.self, forCellReuseIdentifier: "FileCell")
        tableView.backgroundColor = .systemGroupedBackground
        
        // Add subviews
        addSubview(searchBar)
        addSubview(tableView)
        
        // Setup constraints
        setupConstraints()
        
        // Add toolbar
        setupToolbar()
    }
    
    private func setupConstraints() {
        searchBar.translatesAutoresizingMaskIntoConstraints = false
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            // Search bar
            searchBar.topAnchor.constraint(equalTo: topAnchor),
            searchBar.leadingAnchor.constraint(equalTo: leadingAnchor),
            searchBar.trailingAnchor.constraint(equalTo: trailingAnchor),
            searchBar.heightAnchor.constraint(equalToConstant: 44),
            
            // Table view
            tableView.topAnchor.constraint(equalTo: searchBar.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }
    
    private func setupToolbar() {
        // Add context menu for creating new files
        let longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress))
        tableView.addGestureRecognizer(longPressGesture)
    }
    
    // MARK: - Data Loading
    private func loadFiles() {
        // Create sample files for demonstration
        files = [
            IOSFile(name: "main.swift", path: "/project/main.swift", language: .swift, content: "import Foundation\n\nprint(\"Hello, World!\")"),
            IOSFile(name: "ViewController.swift", path: "/project/ViewController.swift", language: .swift, content: "import UIKit\n\nclass ViewController: UIViewController {\n    override func viewDidLoad() {\n        super.viewDidLoad()\n    }\n}"),
            IOSFile(name: "AppDelegate.swift", path: "/project/AppDelegate.swift", language: .swift, content: "import UIKit\n\n@main\nclass AppDelegate: UIResponder, UIApplicationDelegate {\n    // App delegate code\n}"),
            IOSFile(name: "index.html", path: "/project/web/index.html", language: .html, content: "<!DOCTYPE html>\n<html>\n<head>\n    <title>DeepBlue IDE</title>\n</head>\n<body>\n    <h1>Welcome to DeepBlue IDE</h1>\n</body>\n</html>"),
            IOSFile(name: "style.css", path: "/project/web/style.css", language: .css, content: "body {\n    font-family: Arial, sans-serif;\n    margin: 0;\n    padding: 20px;\n}"),
            IOSFile(name: "script.js", path: "/project/web/script.js", language: .javascript, content: "console.log('DeepBlue IDE loaded');\n\nfunction initializeIDE() {\n    // IDE initialization code\n}"),
            IOSFile(name: "README.md", path: "/project/README.md", language: .markdown, content: "# DeepBlue IDE\n\nA comprehensive IDE for iOS development.\n\n## Features\n- Multi-language support\n- Syntax highlighting\n- Code completion")
        ]
        
        tableView.reloadData()
    }
    
    // MARK: - Actions
    @objc private func handleLongPress(_ gesture: UILongPressGestureRecognizer) {
        if gesture.state == .began {
            let point = gesture.location(in: tableView)
            showContextMenu(at: point)
        }
    }
    
    private func showContextMenu(at point: CGPoint) {
        let alertController = UIAlertController(title: "File Actions", message: nil, preferredStyle: .actionSheet)
        
        // Create new file
        let newFileAction = UIAlertAction(title: "New File", style: .default) { _ in
            self.createNewFile()
        }
        
        // Create new folder
        let newFolderAction = UIAlertAction(title: "New Folder", style: .default) { _ in
            self.createNewFolder()
        }
        
        // Cancel
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        
        alertController.addAction(newFileAction)
        alertController.addAction(newFolderAction)
        alertController.addAction(cancelAction)
        
        // Present from the view controller
        if let viewController = self.findViewController() {
            viewController.present(alertController, animated: true)
        }
    }
    
    private func createNewFile() {
        let alertController = UIAlertController(title: "New File", message: "Enter file name", preferredStyle: .alert)
        
        alertController.addTextField { textField in
            textField.placeholder = "filename.swift"
        }
        
        let createAction = UIAlertAction(title: "Create", style: .default) { _ in
            guard let fileName = alertController.textFields?.first?.text, !fileName.isEmpty else { return }
            
            let newFile = IOSFile(name: fileName, path: "/project/\(fileName)", language: .swift, content: "")
            self.files.append(newFile)
            self.tableView.reloadData()
            
            self.delegate?.projectNavigator(self, didCreateFile: newFile)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        
        alertController.addAction(createAction)
        alertController.addAction(cancelAction)
        
        if let viewController = self.findViewController() {
            viewController.present(alertController, animated: true)
        }
    }
    
    private func createNewFolder() {
        // Implementation for creating new folder
        print("Creating new folder...")
    }
}

// MARK: - UITableViewDataSource
extension ProjectNavigatorView: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return files.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FileCell", for: indexPath) as! FileTableViewCell
        let file = files[indexPath.row]
        cell.configure(with: file)
        return cell
    }
}

// MARK: - UITableViewDelegate
extension ProjectNavigatorView: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let file = files[indexPath.row]
        delegate?.projectNavigator(self, didSelectFile: file)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44
    }
}

// MARK: - UISearchBarDelegate
extension ProjectNavigatorView: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        // Implement file search functionality
        print("Searching for: \(searchText)")
    }
}

// MARK: - Helper Extensions
extension UIView {
    func findViewController() -> UIViewController? {
        if let nextResponder = self.next as? UIViewController {
            return nextResponder
        } else if let nextResponder = self.next as? UIView {
            return nextResponder.findViewController()
        } else {
            return nil
        }
    }
}
