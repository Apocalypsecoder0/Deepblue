
import UIKit

class IDEViewController: UIViewController {
    
    // MARK: - Properties
    private var fileManager: IOSFileManager!
    private var codeEditor: CodeEditorView!
    private var projectNavigator: ProjectNavigatorView!
    private var toolBar: IDEToolBar!
    private var statusBar: IDEStatusBar!
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
        setupConstraints()
        initializeIDEComponents()
        
        print("📱 DeepBlue IDE main view controller loaded")
    }
    
    // MARK: - Setup
    private func setupUI() {
        view.backgroundColor = .systemBackground
        title = "DeepBlue IDE"
        
        // Initialize components
        fileManager = IOSFileManager()
        codeEditor = CodeEditorView()
        projectNavigator = ProjectNavigatorView()
        toolBar = IDEToolBar()
        statusBar = IDEStatusBar()
        
        // Add subviews
        view.addSubview(toolBar)
        view.addSubview(projectNavigator)
        view.addSubview(codeEditor)
        view.addSubview(statusBar)
        
        // Setup delegates
        codeEditor.delegate = self
        projectNavigator.delegate = self
        toolBar.delegate = self
    }
    
    private func setupConstraints() {
        toolBar.translatesAutoresizingMaskIntoConstraints = false
        projectNavigator.translatesAutoresizingMaskIntoConstraints = false
        codeEditor.translatesAutoresizingMaskIntoConstraints = false
        statusBar.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            // Tool bar
            toolBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            toolBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            toolBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            toolBar.heightAnchor.constraint(equalToConstant: 44),
            
            // Project navigator
            projectNavigator.topAnchor.constraint(equalTo: toolBar.bottomAnchor),
            projectNavigator.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            projectNavigator.widthAnchor.constraint(equalToConstant: 250),
            projectNavigator.bottomAnchor.constraint(equalTo: statusBar.topAnchor),
            
            // Code editor
            codeEditor.topAnchor.constraint(equalTo: toolBar.bottomAnchor),
            codeEditor.leadingAnchor.constraint(equalTo: projectNavigator.trailingAnchor),
            codeEditor.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            codeEditor.bottomAnchor.constraint(equalTo: statusBar.topAnchor),
            
            // Status bar
            statusBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            statusBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            statusBar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            statusBar.heightAnchor.constraint(equalToConstant: 24)
        ])
    }
    
    private func initializeIDEComponents() {
        // Initialize the IDE backend
        let ideCore = IDECore()
        
        // Load initial project or create new one
        statusBar.updateStatus("Ready - DeepBlue IDE")
        
        // Set up file system monitoring
        fileManager.startMonitoring()
    }
}

// MARK: - Code Editor Delegate
extension IDEViewController: CodeEditorViewDelegate {
    func codeEditorDidChange(_ editor: CodeEditorView, text: String) {
        statusBar.updateStatus("Editing...")
    }
    
    func codeEditorDidSave(_ editor: CodeEditorView) {
        statusBar.updateStatus("File saved")
    }
}

// MARK: - Project Navigator Delegate
extension IDEViewController: ProjectNavigatorViewDelegate {
    func projectNavigator(_ navigator: ProjectNavigatorView, didSelectFile file: IOSFile) {
        codeEditor.loadFile(file)
        statusBar.updateStatus("Opened: \(file.name)")
    }
    
    func projectNavigator(_ navigator: ProjectNavigatorView, didCreateFile file: IOSFile) {
        statusBar.updateStatus("Created: \(file.name)")
    }
}

// MARK: - Tool Bar Delegate
extension IDEViewController: IDEToolBarDelegate {
    func toolBarDidTapRun(_ toolBar: IDEToolBar) {
        statusBar.updateStatus("Running...")
        // Implement run functionality
    }
    
    func toolBarDidTapDebug(_ toolBar: IDEToolBar) {
        statusBar.updateStatus("Starting debugger...")
        // Implement debug functionality
    }
    
    func toolBarDidTapBuild(_ toolBar: IDEToolBar) {
        statusBar.updateStatus("Building...")
        // Implement build functionality
    }
}
