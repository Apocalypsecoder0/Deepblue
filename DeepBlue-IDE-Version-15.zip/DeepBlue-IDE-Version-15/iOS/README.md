
# DeepBlue IDE - iOS Application

A comprehensive IDE for iOS devices, bringing the full development environment to your iPhone and iPad.

## Overview

DeepBlue IDE for iOS is a native iOS application that provides a complete development environment with:

- **Multi-language Support**: Swift, Python, JavaScript, HTML, CSS, and more
- **Code Editor**: Syntax highlighting, auto-completion, and intelligent code assistance
- **Project Management**: Create, organize, and manage development projects
- **File System**: Full file management with import/export capabilities
- **Build & Run**: Compile and execute code directly on your device
- **Debugging**: Built-in debugging tools with breakpoints and variable inspection

## Project Structure

```
iOS/
├── DeepBlueIDE.xcodeproj/          # Xcode project file
├── DeepBlueIDE/                    # Main application folder
│   ├── AppDelegate.swift           # App delegate
│   ├── SceneDelegate.swift         # Scene delegate
│   ├── IDEViewController.swift     # Main IDE interface
│   ├── Views/                      # UI components
│   │   ├── CodeEditorView.swift    # Code editor with syntax highlighting
│   │   ├── ProjectNavigatorView.swift # File browser and project navigator
│   │   └── FileTableViewCell.swift # File list cell
│   ├── Models/                     # Data models
│   │   └── IOSFile.swift          # File and project models
│   ├── Components/                 # Reusable UI components
│   │   ├── SyntaxHighlighter.swift # Syntax highlighting engine
│   │   ├── LineNumberView.swift    # Line number display
│   │   ├── IDEToolBar.swift        # IDE toolbar
│   │   └── IDEStatusBar.swift      # Status bar
│   ├── Core/                       # Core functionality
│   │   └── IDECore.swift          # Main IDE engine
│   ├── Assets.xcassets/            # App icons and images
│   ├── Base.lproj/                 # Storyboards and UI resources
│   │   ├── Main.storyboard        # Main interface
│   │   └── LaunchScreen.storyboard # Launch screen
│   └── Info.plist                  # App configuration
└── README.md                       # This documentation
```

## Features

### Code Editor
- **Syntax Highlighting**: Color-coded syntax for multiple programming languages
- **Auto-Completion**: Intelligent code completion and suggestions
- **Line Numbers**: Visible line numbers for easy navigation
- **Auto-Indentation**: Automatic code indentation
- **Keyboard Shortcuts**: Common shortcuts like Cmd+S for save, Cmd+Z for undo

### Project Navigator
- **File Browser**: Hierarchical view of project files and folders
- **File Operations**: Create, rename, delete files and folders
- **Search**: Quick file search functionality
- **File Types**: Support for various file types with appropriate icons

### Build System
- **Multi-Language Compilation**: Support for Swift, Python, JavaScript, and more
- **Error Reporting**: Detailed compilation errors and warnings
- **Execution Environment**: Run compiled applications directly on iOS

### User Interface
- **Native iOS Design**: Follows iOS Human Interface Guidelines
- **Split View**: Side-by-side file navigator and code editor
- **Responsive Layout**: Optimized for both iPhone and iPad
- **Dark Mode**: Full support for iOS Dark Mode

## Getting Started

### Prerequisites
- iOS 15.0 or later
- Xcode 14.0 or later (for development)

### Installation
1. Clone the repository
2. Open `DeepBlueIDE.xcodeproj` in Xcode
3. Select your target device or simulator
4. Build and run the project

### Usage
1. Launch the app
2. Create a new project or open an existing one
3. Use the project navigator to browse files
4. Select a file to open it in the code editor
5. Use the toolbar to run, debug, or build your code

## Architecture

### Model-View-Controller (MVC)
The app follows the MVC pattern:
- **Models**: `IOSFile`, `IOSProject`, `IOSFileManager`
- **Views**: `CodeEditorView`, `ProjectNavigatorView`, custom UI components
- **Controllers**: `IDEViewController`, `AppDelegate`, `SceneDelegate`

### Core Components
- **IDECore**: Central coordination of all IDE features
- **SyntaxHighlighter**: Language-specific syntax highlighting
- **FileManager**: File system operations and monitoring
- **CompilerManager**: Code compilation and execution

## Customization

### Adding New Languages
1. Extend the `ProgrammingLanguage` enum in `Core/File.swift`
2. Add syntax highlighting rules in `SyntaxHighlighter.swift`
3. Update file type detection in `IOSFileManager`

### Themes
The syntax highlighter supports customizable color themes. Modify the `ColorTheme` struct in `SyntaxHighlighter.swift` to create new themes.

### Extensions
The architecture supports plugins and extensions through the existing plugin system inherited from the main IDE core.

## Performance Considerations

- **Efficient Rendering**: The code editor uses optimized text rendering
- **Memory Management**: Proper memory management for large files
- **Background Processing**: File operations performed on background queues
- **Responsive UI**: UI updates on main thread with proper async handling

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly on both iPhone and iPad
5. Submit a pull request

## License

This project is part of the DeepBlue IDE suite and follows the same licensing terms as the main project.

## Support

For iOS-specific issues:
- Check the iOS simulator logs
- Test on physical devices when possible
- Use Xcode's debugging tools
- Report issues with device specifications and iOS version

## Roadmap

- [ ] iPad multi-window support
- [ ] External keyboard shortcuts
- [ ] iCloud sync for projects
- [ ] Git integration
- [ ] Plugin system for iOS
- [ ] Apple Pencil support for iPad
- [ ] Split-screen multitasking
- [ ] Shortcuts app integration
