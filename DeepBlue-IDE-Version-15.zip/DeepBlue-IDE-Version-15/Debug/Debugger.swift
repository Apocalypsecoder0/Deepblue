
import Foundation

// MARK: - Debugger System

struct Breakpoint {
    let line: Int
    let condition: String?
    let isEnabled: Bool
    
    init(line: Int, condition: String? = nil, isEnabled: Bool = true) {
        self.line = line
        self.condition = condition
        self.isEnabled = isEnabled
    }
}

class Debugger {
    private var breakpoints: [Int: Breakpoint] = [:]
    private var isRunning = false
    private var currentLine = 0
    private var callStack: [String] = []
    private var variables: [String: Any] = [:]
    
    func addBreakpoint(at line: Int, condition: String? = nil) {
        let breakpoint = Breakpoint(line: line, condition: condition)
        breakpoints[line] = breakpoint
        
        if let condition = condition {
            print("🔴 Conditional breakpoint added at line \(line): \(condition)")
        } else {
            print("🔴 Breakpoint added at line \(line)")
        }
    }
    
    func removeBreakpoint(at line: Int) {
        breakpoints.removeValue(forKey: line)
        print("⚪ Breakpoint removed at line \(line)")
    }
    
    func toggleBreakpoint(at line: Int) {
        if var breakpoint = breakpoints[line] {
            breakpoint = Breakpoint(line: line, condition: breakpoint.condition, isEnabled: !breakpoint.isEnabled)
            breakpoints[line] = breakpoint
            print("\(breakpoint.isEnabled ? "🔴" : "⚪") Breakpoint \(breakpoint.isEnabled ? "enabled" : "disabled") at line \(line)")
        }
    }
    
    func listBreakpoints() {
        if breakpoints.isEmpty {
            print("📭 No breakpoints set")
            return
        }
        
        print("🔴 Active Breakpoints:")
        for (line, breakpoint) in breakpoints.sorted(by: { $0.key < $1.key }) {
            let status = breakpoint.isEnabled ? "🔴" : "⚪"
            let condition = breakpoint.condition != nil ? " [Condition: \(breakpoint.condition!)]" : ""
            print("  \(status) Line \(line)\(condition)")
        }
    }
    
    func startDebugging(file: File) {
        print("🐛 Starting debugger for \(file.name)")
        isRunning = true
        currentLine = 1
        callStack = ["main()"]
        
        setupSimulatedVariables(for: file)
        
        print("Debugger started. Breakpoints: \(breakpoints.keys.sorted())")
        
        if !breakpoints.isEmpty {
            let firstBreakpoint = breakpoints.keys.min()!
            currentLine = firstBreakpoint
            print("⏸️ Paused at breakpoint on line \(firstBreakpoint)")
            showCurrentState()
        }
    }
    
    func stepOver() {
        guard isRunning else {
            print("❌ Debugger is not running")
            return
        }
        
        currentLine += 1
        print("⏭️ Step over - Line \(currentLine)")
        showCurrentState()
    }
    
    func stepInto() {
        guard isRunning else {
            print("❌ Debugger is not running")
            return
        }
        
        currentLine += 1
        callStack.append("function_\(currentLine)()")
        print("⬇️ Step into - Line \(currentLine)")
        showCurrentState()
    }
    
    func stepOut() {
        guard isRunning else {
            print("❌ Debugger is not running")
            return
        }
        
        if callStack.count > 1 {
            let function = callStack.removeLast()
            print("⬆️ Step out of \(function)")
        }
        currentLine += 1
        showCurrentState()
    }
    
    func continueExecution() {
        guard isRunning else {
            print("❌ Debugger is not running")
            return
        }
        
        print("▶️ Continue execution")
        
        let nextBreakpoint = breakpoints.keys.filter { $0 > currentLine }.min()
        if let nextLine = nextBreakpoint {
            currentLine = nextLine
            print("⏸️ Paused at breakpoint on line \(currentLine)")
            showCurrentState()
        } else {
            print("✅ Program finished execution")
            stop()
        }
    }
    
    func stop() {
        isRunning = false
        currentLine = 0
        callStack.removeAll()
        variables.removeAll()
        print("⏹️ Debugger stopped")
    }
    
    func evaluateExpression(_ expression: String) {
        print("🔍 Evaluating: \(expression)")
        
        if variables.keys.contains(expression) {
            print("  Result: \(variables[expression] ?? "undefined")")
        } else if expression.contains("+") {
            print("  Result: 42 (simulated calculation)")
        } else {
            print("  Error: Unknown variable or expression")
        }
    }
    
    func showCurrentState() {
        print("\n📍 Current State:")
        print("  Line: \(currentLine)")
        print("  Call Stack: \(callStack.joined(separator: " → "))")
        showVariables()
        showWatchExpressions()
    }
    
    private func setupSimulatedVariables(for file: File) {
        switch file.language {
        case .swift:
            variables = [
                "name": "\"World\"",
                "count": 42,
                "isValid": true,
                "items": "[1, 2, 3, 4, 5]",
                "greeting": "\"Hello, World!\""
            ]
        case .python:
            variables = [
                "n": 10,
                "result": 55,
                "numbers": "[0, 1, 1, 2, 3, 5, 8]",
                "message": "\"Fibonacci complete\""
            ]
        case .javascript:
            variables = [
                "numbers": "[1, 2, 3, 4, 5]",
                "sum": 15,
                "index": 0,
                "temp": "undefined"
            ]
        default:
            variables = [
                "variable1": "value1",
                "variable2": 123,
                "variable3": true
            ]
        }
    }
    
    private func showVariables() {
        print("📊 Variables in Scope:")
        if variables.isEmpty {
            print("  No variables in current scope")
        } else {
            for (name, value) in variables.sorted(by: { $0.key < $1.key }) {
                print("  • \(name): \(value)")
            }
        }
    }
    
    private func showWatchExpressions() {
        print("👁️ Watch Expressions:")
        if let count = variables["count"] as? Int {
            print("  • count * 2: \(count * 2)")
        } else {
            print("  • count * 2: N/A")
        }
        print("  • items.length: 5")
    }
    
    func getBreakpoints() -> [Breakpoint] {
        return Array(breakpoints.values)
    }
    
    func getCurrentLine() -> Int {
        return currentLine
    }
    
    func isDebugging() -> Bool {
        return isRunning
    }
}
