
import Foundation

// MARK: - Editor Components

class SyntaxHighlighter {
    func highlight(_ code: String, language: ProgrammingLanguage) -> String {
        print("🎨 Highlighting \(language.rawValue) code...")
        
        let keywords = getKeywords(for: language)
        var highlightedCode = code
        
        for keyword in keywords {
            highlightedCode = highlightedCode.replacingOccurrences(
                of: keyword,
                with: "[\(keyword)]"
            )
        }
        
        return highlightedCode
    }
    
    private func getKeywords(for language: ProgrammingLanguage) -> [String] {
        switch language {
        case .swift:
            return ["func", "var", "let", "class", "struct", "enum", "import", "if", "else", "for", "while", "return"]
        case .python:
            return ["def", "class", "import", "from", "if", "else", "elif", "for", "while", "return", "try", "except"]
        case .javascript:
            return ["function", "var", "let", "const", "class", "if", "else", "for", "while", "return", "import", "export"]
        case .typescript:
            return ["function", "var", "let", "const", "class", "interface", "type", "if", "else", "for", "while", "return"]
        case .java:
            return ["public", "private", "protected", "class", "interface", "if", "else", "for", "while", "return", "import"]
        case .cpp:
            return ["#include", "class", "struct", "if", "else", "for", "while", "return", "public", "private", "protected"]
        default:
            return []
        }
    }
}

class IntelliSense {
    func getCompletions(for code: String, language: ProgrammingLanguage, position: Int) -> [String] {
        print("💡 Generating IntelliSense completions for \(language.rawValue)...")
        
        switch language {
        case .swift:
            return ["print()", "String", "Int", "Double", "Array", "Dictionary", "func", "var", "let"]
        case .python:
            return ["print()", "str", "int", "float", "list", "dict", "def", "class", "import"]
        case .javascript:
            return ["console.log()", "function", "var", "let", "const", "Array", "Object", "String"]
        case .typescript:
            return ["console.log()", "function", "interface", "type", "string", "number", "boolean"]
        case .java:
            return ["System.out.println()", "public", "private", "class", "interface", "String", "int"]
        default:
            return ["// No completions available"]
        }
    }
    
    func findDefinition(for symbol: String, in files: [File]) -> String? {
        print("🔍 Finding definition for: \(symbol)")
        return "Found definition in file: example.swift:15"
    }
}

class SearchAndReplace {
    func search(query: String, in files: [File]) -> [(file: File, line: Int, match: String)] {
        print("🔍 Searching for: \(query)")
        var results: [(file: File, line: Int, match: String)] = []
        
        for file in files {
            let lines = file.content.components(separatedBy: .newlines)
            for (index, line) in lines.enumerated() {
                if line.lowercased().contains(query.lowercased()) {
                    results.append((file: file, line: index + 1, match: line))
                }
            }
        }
        
        print("Found \(results.count) matches")
        return results
    }
    
    func replace(query: String, with replacement: String, in file: File) -> File {
        print("🔄 Replacing '\(query)' with '\(replacement)' in \(file.name)")
        let newContent = file.content.replacingOccurrences(of: query, with: replacement)
        return File(
            id: file.id,
            name: file.name,
            path: file.path,
            content: newContent,
            language: file.language,
            isModified: true
        )
    }
}
