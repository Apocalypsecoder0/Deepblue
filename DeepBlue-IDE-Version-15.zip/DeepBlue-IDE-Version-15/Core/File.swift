
import Foundation

// MARK: - Core IDE Types and Structures

struct File {
    let id: String
    let name: String
    let path: String
    let content: String
    let language: ProgrammingLanguage
    var isModified: Bool = false
}

enum ProgrammingLanguage: String, CaseIterable {
    case swift = "swift"
    case python = "python"
    case javascript = "javascript"
    case typescript = "typescript"
    case java = "java"
    case cpp = "cpp"
    case c = "c"
    case csharp = "csharp"
    case go = "go"
    case rust = "rust"
    case php = "php"
    case ruby = "ruby"
    case html = "html"
    case css = "css"
    case json = "json"
    case xml = "xml"
    case sql = "sql"
    case bash = "bash"
    case powershell = "powershell"
    case yaml = "yaml"
    case markdown = "markdown"
    
    var fileExtensions: [String] {
        switch self {
        case .swift: return [".swift"]
        case .python: return [".py", ".pyw"]
        case .javascript: return [".js", ".jsx", ".mjs"]
        case .typescript: return [".ts", ".tsx"]
        case .java: return [".java"]
        case .cpp: return [".cpp", ".cc", ".cxx", ".hpp", ".h"]
        case .c: return [".c", ".h"]
        case .csharp: return [".cs"]
        case .go: return [".go"]
        case .rust: return [".rs"]
        case .php: return [".php"]
        case .ruby: return [".rb"]
        case .html: return [".html", ".htm"]
        case .css: return [".css", ".scss", ".sass", ".less"]
        case .json: return [".json"]
        case .xml: return [".xml"]
        case .sql: return [".sql"]
        case .bash: return [".sh", ".bash"]
        case .powershell: return [".ps1"]
        case .yaml: return [".yaml", ".yml"]
        case .markdown: return [".md", ".markdown"]
        }
    }
}
