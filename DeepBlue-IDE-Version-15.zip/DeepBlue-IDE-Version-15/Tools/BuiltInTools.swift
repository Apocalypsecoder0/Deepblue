
import Foundation

// MARK: - Built-in Tools

class CompilerTool: IDETool {
    let name = "Compiler"
    let version = "1.0.0"
    let description = "Multi-language compiler and interpreter"
    
    func execute(with parameters: [String: Any]) -> ToolResult {
        guard let language = parameters["language"] as? ProgrammingLanguage,
              let code = parameters["code"] as? String else {
            return ToolResult(success: false, output: "", errorMessage: "Missing language or code", data: nil)
        }
        
        return compileAndRun(code: code, language: language)
    }
    
    func isAvailable() -> Bool {
        return true
    }
    
    private func compileAndRun(code: String, language: ProgrammingLanguage) -> ToolResult {
        print("🏗️ Compiling \(language.rawValue) code...")
        
        switch language {
        case .swift:
            return ToolResult(success: true, output: "Swift compilation successful\nHello, World!", errorMessage: nil, data: ["exitCode": 0])
        case .python:
            return ToolResult(success: true, output: "Python execution successful\n55", errorMessage: nil, data: ["exitCode": 0])
        case .javascript:
            return ToolResult(success: true, output: "JavaScript execution successful\n15", errorMessage: nil, data: ["exitCode": 0])
        case .java:
            return ToolResult(success: true, output: "Java compilation and execution successful\nHello World", errorMessage: nil, data: ["exitCode": 0])
        case .cpp:
            return ToolResult(success: true, output: "C++ compilation and execution successful\nHello World", errorMessage: nil, data: ["exitCode": 0])
        case .rust:
            return ToolResult(success: true, output: "Rust compilation and execution successful\nHello, world!", errorMessage: nil, data: ["exitCode": 0])
        default:
            return ToolResult(success: false, output: "", errorMessage: "Language not supported by compiler", data: nil)
        }
    }
}

class LinterTool: IDETool {
    let name = "Linter"
    let version = "1.0.0"
    let description = "Code linting and style checking"
    
    func execute(with parameters: [String: Any]) -> ToolResult {
        guard let language = parameters["language"] as? ProgrammingLanguage,
              let code = parameters["code"] as? String else {
            return ToolResult(success: false, output: "", errorMessage: "Missing parameters", data: nil)
        }
        
        let issues = lintCode(code: code, language: language)
        let output = issues.joined(separator: "\n")
        
        return ToolResult(success: true, output: output, errorMessage: nil, data: ["issueCount": issues.count])
    }
    
    func isAvailable() -> Bool {
        return true
    }
    
    private func lintCode(code: String, language: ProgrammingLanguage) -> [String] {
        var issues: [String] = []
        
        let lines = code.components(separatedBy: .newlines)
        for (index, line) in lines.enumerated() {
            if line.count > 100 {
                issues.append("Line \(index + 1): Line too long (\(line.count) characters)")
            }
            if line.hasPrefix(" ") && language == .python {
                issues.append("Line \(index + 1): Use tabs instead of spaces for indentation")
            }
            if line.trimmingCharacters(in: .whitespaces).isEmpty && line.count > 0 {
                issues.append("Line \(index + 1): Line contains only whitespace")
            }
        }
        
        if issues.isEmpty {
            issues.append("✅ No linting issues found")
        }
        
        return issues
    }
}

class FormatterTool: IDETool {
    let name = "Formatter"
    let version = "1.0.0"
    let description = "Code formatting and beautification"
    
    func execute(with parameters: [String: Any]) -> ToolResult {
        guard let language = parameters["language"] as? ProgrammingLanguage,
              let code = parameters["code"] as? String else {
            return ToolResult(success: false, output: "", errorMessage: "Missing parameters", data: nil)
        }
        
        let formattedCode = formatCode(code: code, language: language)
        return ToolResult(success: true, output: formattedCode, errorMessage: nil, data: nil)
    }
    
    func isAvailable() -> Bool {
        return true
    }
    
    private func formatCode(code: String, language: ProgrammingLanguage) -> String {
        var formatted = code
        
        formatted = formatted.replacingOccurrences(of: "  +", with: " ", options: .regularExpression)
        formatted = formatted.replacingOccurrences(of: "=", with: " = ")
        formatted = formatted.replacingOccurrences(of: "  =  ", with: " = ")
        
        return formatted
    }
}

class TestRunnerTool: IDETool {
    let name = "TestRunner"
    let version = "1.0.0"
    let description = "Unit test execution and reporting"
    
    func execute(with parameters: [String: Any]) -> ToolResult {
        guard let testFiles = parameters["testFiles"] as? [File] else {
            return ToolResult(success: false, output: "", errorMessage: "No test files provided", data: nil)
        }
        
        let results = runTests(files: testFiles)
        return ToolResult(success: true, output: results.output, errorMessage: nil, data: results.data)
    }
    
    func isAvailable() -> Bool {
        return true
    }
    
    private func runTests(files: [File]) -> (output: String, data: [String: Any]) {
        var output = "🧪 Running Tests...\n"
        var passed = 0
        var failed = 0
        
        for file in files {
            output += "\n📝 Running tests in \(file.name):\n"
            
            let testCount = Int.random(in: 3...8)
            for i in 1...testCount {
                let success = Bool.random()
                if success {
                    output += "  ✅ Test \(i): PASSED\n"
                    passed += 1
                } else {
                    output += "  ❌ Test \(i): FAILED - Assertion error\n"
                    failed += 1
                }
            }
        }
        
        output += "\n📊 Test Summary: \(passed) passed, \(failed) failed"
        
        return (output, ["passed": passed, "failed": failed, "total": passed + failed])
    }
}
