
import Foundation

// MARK: - Tool System

protocol IDETool {
    var name: String { get }
    var version: String { get }
    var description: String { get }
    func execute(with parameters: [String: Any]) -> ToolResult
    func isAvailable() -> Bool
}

struct ToolResult {
    let success: Bool
    let output: String
    let errorMessage: String?
    let data: [String: Any]?
}

class ToolManager {
    private var tools: [String: IDETool] = [:]
    
    func registerTool(_ tool: IDETool) {
        tools[tool.name] = tool
        print("🔧 Registered tool: \(tool.name) v\(tool.version)")
    }
    
    func executeTool(_ name: String, parameters: [String: Any] = [:]) -> ToolResult? {
        guard let tool = tools[name] else {
            print("❌ Tool '\(name)' not found")
            return nil
        }
        
        if !tool.isAvailable() {
            print("❌ Tool '\(name)' is not available")
            return ToolResult(success: false, output: "", errorMessage: "Tool not available", data: nil)
        }
        
        print("🔧 Executing tool: \(name)")
        return tool.execute(with: parameters)
    }
    
    func getAvailableTools() -> [IDETool] {
        return Array(tools.values.filter { $0.isAvailable() })
    }
    
    func getAllTools() -> [IDETool] {
        return Array(tools.values)
    }
}
