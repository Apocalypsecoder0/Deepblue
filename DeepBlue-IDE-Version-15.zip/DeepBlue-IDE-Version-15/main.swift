import Foundation

// MARK: - Core IDE Types and Structures

struct File {
    let id: String
    let name: String
    let path: String
    let content: String
    let language: ProgrammingLanguage
    var isModified: Bool = false
}

enum ProgrammingLanguage: String, CaseIterable {
    case swift = "swift"
    case python = "python"
    case javascript = "javascript"
    case typescript = "typescript"
    case java = "java"
    case cpp = "cpp"
    case c = "c"
    case csharp = "csharp"
    case go = "go"
    case rust = "rust"
    case php = "php"
    case ruby = "ruby"
    case html = "html"
    case css = "css"
    case json = "json"
    case xml = "xml"
    case sql = "sql"
    case bash = "bash"
    case powershell = "powershell"
    case yaml = "yaml"
    case markdown = "markdown"
    
    var fileExtensions: [String] {
        switch self {
        case .swift: return [".swift"]
        case .python: return [".py", ".pyw"]
        case .javascript: return [".js", ".jsx", ".mjs"]
        case .typescript: return [".ts", ".tsx"]
        case .java: return [".java"]
        case .cpp: return [".cpp", ".cc", ".cxx", ".hpp", ".h"]
        case .c: return [".c", ".h"]
        case .csharp: return [".cs"]
        case .go: return [".go"]
        case .rust: return [".rs"]
        case .php: return [".php"]
        case .ruby: return [".rb"]
        case .html: return [".html", ".htm"]
        case .css: return [".css", ".scss", ".sass", ".less"]
        case .json: return [".json"]
        case .xml: return [".xml"]
        case .sql: return [".sql"]
        case .bash: return [".sh", ".bash"]
        case .powershell: return [".ps1"]
        case .yaml: return [".yaml", ".yml"]
        case .markdown: return [".md", ".markdown"]
        }
    }
}

// MARK: - Tool System

protocol IDETool {
    var name: String { get }
    var version: String { get }
    var description: String { get }
    func execute(with parameters: [String: Any]) -> ToolResult
    func isAvailable() -> Bool
}

struct ToolResult {
    let success: Bool
    let output: String
    let errorMessage: String?
    let data: [String: Any]?
}

class ToolManager {
    private var tools: [String: IDETool] = [:]
    
    func registerTool(_ tool: IDETool) {
        tools[tool.name] = tool
        print("🔧 Registered tool: \(tool.name) v\(tool.version)")
    }
    
    func executeTool(_ name: String, parameters: [String: Any] = [:]) -> ToolResult? {
        guard let tool = tools[name] else {
            print("❌ Tool '\(name)' not found")
            return nil
        }
        
        if !tool.isAvailable() {
            print("❌ Tool '\(name)' is not available")
            return ToolResult(success: false, output: "", errorMessage: "Tool not available", data: nil)
        }
        
        print("🔧 Executing tool: \(name)")
        return tool.execute(with: parameters)
    }
    
    func getAvailableTools() -> [IDETool] {
        return Array(tools.values.filter { $0.isAvailable() })
    }
    
    func getAllTools() -> [IDETool] {
        return Array(tools.values)
    }
}

// MARK: - Built-in Tools

class CompilerTool: IDETool {
    let name = "Compiler"
    let version = "1.0.0"
    let description = "Multi-language compiler and interpreter"
    
    func execute(with parameters: [String: Any]) -> ToolResult {
        guard let language = parameters["language"] as? ProgrammingLanguage,
              let code = parameters["code"] as? String else {
            return ToolResult(success: false, output: "", errorMessage: "Missing language or code", data: nil)
        }
        
        return compileAndRun(code: code, language: language)
    }
    
    func isAvailable() -> Bool {
        return true
    }
    
    private func compileAndRun(code: String, language: ProgrammingLanguage) -> ToolResult {
        print("🏗️ Compiling \(language.rawValue) code...")
        
        switch language {
        case .swift:
            return ToolResult(success: true, output: "Swift compilation successful\nHello, World!", errorMessage: nil, data: ["exitCode": 0])
        case .python:
            return ToolResult(success: true, output: "Python execution successful\n55", errorMessage: nil, data: ["exitCode": 0])
        case .javascript:
            return ToolResult(success: true, output: "JavaScript execution successful\n15", errorMessage: nil, data: ["exitCode": 0])
        case .java:
            return ToolResult(success: true, output: "Java compilation and execution successful\nHello World", errorMessage: nil, data: ["exitCode": 0])
        case .cpp:
            return ToolResult(success: true, output: "C++ compilation and execution successful\nHello World", errorMessage: nil, data: ["exitCode": 0])
        case .rust:
            return ToolResult(success: true, output: "Rust compilation and execution successful\nHello, world!", errorMessage: nil, data: ["exitCode": 0])
        default:
            return ToolResult(success: false, output: "", errorMessage: "Language not supported by compiler", data: nil)
        }
    }
}

class LinterTool: IDETool {
    let name = "Linter"
    let version = "1.0.0"
    let description = "Code linting and style checking"
    
    func execute(with parameters: [String: Any]) -> ToolResult {
        guard let language = parameters["language"] as? ProgrammingLanguage,
              let code = parameters["code"] as? String else {
            return ToolResult(success: false, output: "", errorMessage: "Missing parameters", data: nil)
        }
        
        let issues = lintCode(code: code, language: language)
        let output = issues.joined(separator: "\n")
        
        return ToolResult(success: true, output: output, errorMessage: nil, data: ["issueCount": issues.count])
    }
    
    func isAvailable() -> Bool {
        return true
    }
    
    private func lintCode(code: String, language: ProgrammingLanguage) -> [String] {
        var issues: [String] = []
        
        // Basic linting rules
        let lines = code.components(separatedBy: .newlines)
        for (index, line) in lines.enumerated() {
            if line.count > 100 {
                issues.append("Line \(index + 1): Line too long (\(line.count) characters)")
            }
            if line.hasPrefix(" ") && language == .python {
                issues.append("Line \(index + 1): Use tabs instead of spaces for indentation")
            }
            if line.trimmingCharacters(in: .whitespaces).isEmpty && line.count > 0 {
                issues.append("Line \(index + 1): Line contains only whitespace")
            }
        }
        
        if issues.isEmpty {
            issues.append("✅ No linting issues found")
        }
        
        return issues
    }
}

class FormatterTool: IDETool {
    let name = "Formatter"
    let version = "1.0.0"
    let description = "Code formatting and beautification"
    
    func execute(with parameters: [String: Any]) -> ToolResult {
        guard let language = parameters["language"] as? ProgrammingLanguage,
              let code = parameters["code"] as? String else {
            return ToolResult(success: false, output: "", errorMessage: "Missing parameters", data: nil)
        }
        
        let formattedCode = formatCode(code: code, language: language)
        return ToolResult(success: true, output: formattedCode, errorMessage: nil, data: nil)
    }
    
    func isAvailable() -> Bool {
        return true
    }
    
    private func formatCode(code: String, language: ProgrammingLanguage) -> String {
        // Basic formatting (in a real implementation, this would use proper parsers)
        var formatted = code
        
        // Remove excessive whitespace
        formatted = formatted.replacingOccurrences(of: "  +", with: " ", options: .regularExpression)
        
        // Add proper spacing around operators
        formatted = formatted.replacingOccurrences(of: "=", with: " = ")
        formatted = formatted.replacingOccurrences(of: "  =  ", with: " = ")
        
        return formatted
    }
}

class TestRunnerTool: IDETool {
    let name = "TestRunner"
    let version = "1.0.0"
    let description = "Unit test execution and reporting"
    
    func execute(with parameters: [String: Any]) -> ToolResult {
        guard let testFiles = parameters["testFiles"] as? [File] else {
            return ToolResult(success: false, output: "", errorMessage: "No test files provided", data: nil)
        }
        
        let results = runTests(files: testFiles)
        return ToolResult(success: true, output: results.output, errorMessage: nil, data: results.data)
    }
    
    func isAvailable() -> Bool {
        return true
    }
    
    private func runTests(files: [File]) -> (output: String, data: [String: Any]) {
        var output = "🧪 Running Tests...\n"
        var passed = 0
        var failed = 0
        
        for file in files {
            output += "\n📝 Running tests in \(file.name):\n"
            
            // Simulate test execution
            let testCount = Int.random(in: 3...8)
            for i in 1...testCount {
                let success = Bool.random()
                if success {
                    output += "  ✅ Test \(i): PASSED\n"
                    passed += 1
                } else {
                    output += "  ❌ Test \(i): FAILED - Assertion error\n"
                    failed += 1
                }
            }
        }
        
        output += "\n📊 Test Summary: \(passed) passed, \(failed) failed"
        
        return (output, ["passed": passed, "failed": failed, "total": passed + failed])
    }
}

// MARK: - Plugin System

protocol IDEPlugin {
    var name: String { get }
    var version: String { get }
    var author: String { get }
    var description: String { get }
    var dependencies: [String] { get }
    
    func initialize()
    func activate()
    func deactivate()
    func onFileOpen(_ file: File)
    func onFileSave(_ file: File)
    func getMenuItems() -> [PluginMenuItem]
}

struct PluginMenuItem {
    let title: String
    let action: () -> Void
}

class PluginManager {
    private var plugins: [String: IDEPlugin] = [:]
    private var activePlugins: Set<String> = []
    
    func registerPlugin(_ plugin: IDEPlugin) {
        plugins[plugin.name] = plugin
        plugin.initialize()
        print("🔌 Registered plugin: \(plugin.name) v\(plugin.version)")
    }
    
    func activatePlugin(_ name: String) -> Bool {
        guard let plugin = plugins[name] else {
            print("❌ Plugin '\(name)' not found")
            return false
        }
        
        if activePlugins.contains(name) {
            print("⚠️ Plugin '\(name)' is already active")
            return true
        }
        
        plugin.activate()
        activePlugins.insert(name)
        print("✅ Activated plugin: \(name)")
        return true
    }
    
    func deactivatePlugin(_ name: String) -> Bool {
        guard let plugin = plugins[name] else {
            print("❌ Plugin '\(name)' not found")
            return false
        }
        
        if !activePlugins.contains(name) {
            print("⚠️ Plugin '\(name)' is not active")
            return true
        }
        
        plugin.deactivate()
        activePlugins.remove(name)
        print("🔴 Deactivated plugin: \(name)")
        return true
    }
    
    func getActivePlugins() -> [IDEPlugin] {
        return activePlugins.compactMap { plugins[$0] }
    }
    
    func getAllPlugins() -> [IDEPlugin] {
        return Array(plugins.values)
    }
    
    func notifyFileOpen(_ file: File) {
        for plugin in getActivePlugins() {
            plugin.onFileOpen(file)
        }
    }
    
    func notifyFileSave(_ file: File) {
        for plugin in getActivePlugins() {
            plugin.onFileSave(file)
        }
    }
}

// MARK: - Built-in Plugins

class GitPlugin: IDEPlugin {
    let name = "Git Integration"
    let version = "1.0.0"
    let author = "DeepBlue IDE Team"
    let description = "Enhanced Git integration with visual diff and branch management"
    let dependencies: [String] = []
    
    func initialize() {
        print("🔧 Git plugin initialized")
    }
    
    func activate() {
        print("🟢 Git plugin activated")
    }
    
    func deactivate() {
        print("🔴 Git plugin deactivated")
    }
    
    func onFileOpen(_ file: File) {
        // Check git status for the file
        print("📊 Checking Git status for \(file.name)")
    }
    
    func onFileSave(_ file: File) {
        print("💾 Git: File \(file.name) saved - tracking changes")
    }
    
    func getMenuItems() -> [PluginMenuItem] {
        return [
            PluginMenuItem(title: "Git Diff") { print("🔍 Showing Git diff") },
            PluginMenuItem(title: "Git Blame") { print("👤 Showing Git blame") },
            PluginMenuItem(title: "Git Log") { print("📜 Showing Git log") }
        ]
    }
}

class CodeSnippetsPlugin: IDEPlugin {
    let name = "Code Snippets"
    let version = "1.0.0"
    let author = "DeepBlue IDE Team"
    let description = "Code snippet management and insertion"
    let dependencies: [String] = []
    
    private var snippets: [String: String] = [:]
    
    func initialize() {
        loadDefaultSnippets()
        print("📝 Code Snippets plugin initialized")
    }
    
    func activate() {
        print("🟢 Code Snippets plugin activated")
    }
    
    func deactivate() {
        print("🔴 Code Snippets plugin deactivated")
    }
    
    func onFileOpen(_ file: File) {
        print("📝 Loading snippets for \(file.language.rawValue)")
    }
    
    func onFileSave(_ file: File) {
        // Could auto-save custom snippets
    }
    
    func getMenuItems() -> [PluginMenuItem] {
        return [
            PluginMenuItem(title: "Insert Snippet") { self.showSnippets() },
            PluginMenuItem(title: "Create Snippet") { self.createSnippet() }
        ]
    }
    
    private func loadDefaultSnippets() {
        snippets["for_loop_swift"] = """
        for i in 0..<count {
            // code here
        }
        """
        snippets["function_swift"] = """
        func functionName() -> ReturnType {
            // code here
        }
        """
        snippets["class_swift"] = """
        class ClassName {
            init() {
                // initialization
            }
        }
        """
    }
    
    private func showSnippets() {
        print("📝 Available Snippets:")
        for (key, _) in snippets {
            print("  • \(key)")
        }
    }
    
    private func createSnippet() {
        print("✨ Creating new snippet...")
    }
}

class LivePreviewPlugin: IDEPlugin {
    let name = "Live Preview"
    let version = "1.0.0"
    let author = "DeepBlue IDE Team"
    let description = "Live preview for web development"
    let dependencies: [String] = []
    
    func initialize() {
        print("🌐 Live Preview plugin initialized")
    }
    
    func activate() {
        print("🟢 Live Preview plugin activated")
    }
    
    func deactivate() {
        print("🔴 Live Preview plugin deactivated")
    }
    
    func onFileOpen(_ file: File) {
        if file.language == .html || file.language == .css || file.language == .javascript {
            print("🌐 Live preview available for \(file.name)")
        }
    }
    
    func onFileSave(_ file: File) {
        if file.language == .html || file.language == .css || file.language == .javascript {
            print("🔄 Refreshing live preview for \(file.name)")
        }
    }
    
    func getMenuItems() -> [PluginMenuItem] {
        return [
            PluginMenuItem(title: "Start Live Preview") { self.startPreview() },
            PluginMenuItem(title: "Stop Live Preview") { self.stopPreview() }
        ]
    }
    
    private func startPreview() {
        print("🚀 Starting live preview server on port 3000")
    }
    
    private func stopPreview() {
        print("⏹️ Stopping live preview server")
    }
}

// MARK: - Compiler System

class CompilerManager {
    private var compilers: [ProgrammingLanguage: Compiler] = [:]
    
    init() {
        setupDefaultCompilers()
    }
    
    private func setupDefaultCompilers() {
        compilers[.swift] = SwiftCompiler()
        compilers[.python] = PythonInterpreter()
        compilers[.javascript] = JavaScriptEngine()
        compilers[.typescript] = TypeScriptCompiler()
        compilers[.java] = JavaCompiler()
        compilers[.cpp] = CppCompiler()
        compilers[.rust] = RustCompiler()
        compilers[.go] = GoCompiler()
    }
    
    func compile(_ file: File) -> CompilationResult {
        guard let compiler = compilers[file.language] else {
            return CompilationResult(
                success: false,
                output: "",
                errors: ["No compiler available for \(file.language.rawValue)"],
                warnings: [],
                executablePath: nil
            )
        }
        
        return compiler.compile(file)
    }
    
    func getAvailableCompilers() -> [ProgrammingLanguage] {
        return Array(compilers.keys)
    }
}

protocol Compiler {
    var language: ProgrammingLanguage { get }
    var version: String { get }
    func compile(_ file: File) -> CompilationResult
    func isAvailable() -> Bool
}

struct CompilationResult {
    let success: Bool
    let output: String
    let errors: [String]
    let warnings: [String]
    let executablePath: String?
}

class SwiftCompiler: Compiler {
    let language: ProgrammingLanguage = .swift
    let version = "5.6.2"
    
    func compile(_ file: File) -> CompilationResult {
        print("🏗️ Compiling Swift file: \(file.name)")
        
        // Simulate compilation
        let hasErrors = file.content.contains("error_here")
        let hasWarnings = file.content.contains("warning_here")
        
        if hasErrors {
            return CompilationResult(
                success: false,
                output: "",
                errors: ["error: undefined symbol 'error_here'"],
                warnings: [],
                executablePath: nil
            )
        }
        
        var warnings: [String] = []
        if hasWarnings {
            warnings.append("warning: unused variable 'warning_here'")
        }
        
        return CompilationResult(
            success: true,
            output: "Swift compilation successful",
            errors: [],
            warnings: warnings,
            executablePath: "/tmp/\(file.name.replacingOccurrences(of: ".swift", with: ""))"
        )
    }
    
    func isAvailable() -> Bool {
        return true
    }
}

class PythonInterpreter: Compiler {
    let language: ProgrammingLanguage = .python
    let version = "3.9.0"
    
    func compile(_ file: File) -> CompilationResult {
        print("🐍 Running Python file: \(file.name)")
        
        // Python doesn't need compilation, just execution
        return CompilationResult(
            success: true,
            output: "Python script executed successfully",
            errors: [],
            warnings: [],
            executablePath: nil
        )
    }
    
    func isAvailable() -> Bool {
        return true
    }
}

class JavaScriptEngine: Compiler {
    let language: ProgrammingLanguage = .javascript
    let version = "Node.js 16.0.0"
    
    func compile(_ file: File) -> CompilationResult {
        print("🟨 Running JavaScript file: \(file.name)")
        
        return CompilationResult(
            success: true,
            output: "JavaScript executed successfully",
            errors: [],
            warnings: [],
            executablePath: nil
        )
    }
    
    func isAvailable() -> Bool {
        return true
    }
}

class TypeScriptCompiler: Compiler {
    let language: ProgrammingLanguage = .typescript
    let version = "4.5.0"
    
    func compile(_ file: File) -> CompilationResult {
        print("🔷 Compiling TypeScript file: \(file.name)")
        
        return CompilationResult(
            success: true,
            output: "TypeScript compilation successful",
            errors: [],
            warnings: [],
            executablePath: "/tmp/\(file.name.replacingOccurrences(of: ".ts", with: ".js"))"
        )
    }
    
    func isAvailable() -> Bool {
        return true
    }
}

class JavaCompiler: Compiler {
    let language: ProgrammingLanguage = .java
    let version = "11.0.0"
    
    func compile(_ file: File) -> CompilationResult {
        print("☕ Compiling Java file: \(file.name)")
        
        return CompilationResult(
            success: true,
            output: "Java compilation successful",
            errors: [],
            warnings: [],
            executablePath: "/tmp/\(file.name.replacingOccurrences(of: ".java", with: ".class"))"
        )
    }
    
    func isAvailable() -> Bool {
        return true
    }
}

class CppCompiler: Compiler {
    let language: ProgrammingLanguage = .cpp
    let version = "GCC 11.0.0"
    
    func compile(_ file: File) -> CompilationResult {
        print("⚙️ Compiling C++ file: \(file.name)")
        
        return CompilationResult(
            success: true,
            output: "C++ compilation successful",
            errors: [],
            warnings: [],
            executablePath: "/tmp/\(file.name.replacingOccurrences(of: ".cpp", with: ""))"
        )
    }
    
    func isAvailable() -> Bool {
        return true
    }
}

class RustCompiler: Compiler {
    let language: ProgrammingLanguage = .rust
    let version = "1.65.0"
    
    func compile(_ file: File) -> CompilationResult {
        print("🦀 Compiling Rust file: \(file.name)")
        
        return CompilationResult(
            success: true,
            output: "Rust compilation successful",
            errors: [],
            warnings: [],
            executablePath: "/tmp/\(file.name.replacingOccurrences(of: ".rs", with: ""))"
        )
    }
    
    func isAvailable() -> Bool {
        return true
    }
}

class GoCompiler: Compiler {
    let language: ProgrammingLanguage = .go
    let version = "1.19.0"
    
    func compile(_ file: File) -> CompilationResult {
        print("🐹 Compiling Go file: \(file.name)")
        
        return CompilationResult(
            success: true,
            output: "Go compilation successful",
            errors: [],
            warnings: [],
            executablePath: "/tmp/\(file.name.replacingOccurrences(of: ".go", with: ""))"
        )
    }
    
    func isAvailable() -> Bool {
        return true
    }
}

// MARK: - Project Management

class ProjectManager {
    private var currentProject: Project?
    private var recentProjects: [String] = []
    
    func createProject(name: String, template: ProjectTemplate) -> Project {
        let project = Project(name: name, path: "/projects/\(name)", template: template)
        currentProject = project
        addToRecentProjects(project.path)
        
        print("📁 Created new project: \(name)")
        setupProjectStructure(project)
        
        return project
    }
    
    func openProject(path: String) -> Project? {
        // Simulate loading project
        let project = Project(name: "Loaded Project", path: path, template: .empty)
        currentProject = project
        addToRecentProjects(path)
        
        print("📂 Opened project: \(project.name)")
        return project
    }
    
    func getCurrentProject() -> Project? {
        return currentProject
    }
    
    func getRecentProjects() -> [String] {
        return recentProjects
    }
    
    private func addToRecentProjects(_ path: String) {
        recentProjects.removeAll { $0 == path }
        recentProjects.insert(path, at: 0)
        if recentProjects.count > 10 {
            recentProjects.removeLast()
        }
    }
    
    private func setupProjectStructure(_ project: Project) {
        print("🏗️ Setting up project structure for \(project.template.rawValue) template")
        
        switch project.template {
        case .swiftApp:
            print("  📁 Sources/")
            print("  📁 Tests/")
            print("  📄 Package.swift")
        case .webApp:
            print("  📁 src/")
            print("  📁 public/")
            print("  📁 assets/")
            print("  📄 index.html")
        case .mobileApp:
            print("  📁 src/")
            print("  📁 assets/")
            print("  📁 platforms/")
            print("  📄 config.xml")
        case .empty:
            print("  📄 README.md")
        }
    }
}

struct Project {
    let id: String
    let name: String
    let path: String
    let template: ProjectTemplate
    let createdDate: Date
    
    init(name: String, path: String, template: ProjectTemplate) {
        self.id = UUID().uuidString
        self.name = name
        self.path = path
        self.template = template
        self.createdDate = Date()
    }
}

enum ProjectTemplate: String, CaseIterable {
    case empty = "Empty Project"
    case swiftApp = "Swift Application"
    case webApp = "Web Application"
    case mobileApp = "Mobile Application"
    
    var description: String {
        switch self {
        case .empty: return "A basic empty project"
        case .swiftApp: return "Swift application with Package.swift"
        case .webApp: return "Web application with HTML/CSS/JS"
        case .mobileApp: return "Cross-platform mobile application"
        }
    }
}

// MARK: - Package Manager

class PackageManager {
    private var installedPackages: [Package] = []
    
    func searchPackages(_ query: String) -> [Package] {
        let allPackages = [
            Package(name: "SwiftUI", version: "3.0.0", description: "User interface toolkit", language: .swift),
            Package(name: "Alamofire", version: "5.6.0", description: "HTTP networking library", language: .swift),
            Package(name: "React", version: "18.0.0", description: "JavaScript library for building user interfaces", language: .javascript),
            Package(name: "Express", version: "4.18.0", description: "Web application framework for Node.js", language: .javascript),
            Package(name: "NumPy", version: "1.23.0", description: "Scientific computing library", language: .python),
            Package(name: "Django", version: "4.1.0", description: "Web framework for Python", language: .python)
        ]
        
        return allPackages.filter { $0.name.lowercased().contains(query.lowercased()) }
    }
    
    func installPackage(_ package: Package) -> Bool {
        print("📦 Installing package: \(package.name) v\(package.version)")
        
        // Simulate installation
        installedPackages.append(package)
        print("✅ Package \(package.name) installed successfully")
        
        return true
    }
    
    func uninstallPackage(_ packageName: String) -> Bool {
        print("🗑️ Uninstalling package: \(packageName)")
        
        installedPackages.removeAll { $0.name == packageName }
        print("✅ Package \(packageName) uninstalled successfully")
        
        return true
    }
    
    func getInstalledPackages() -> [Package] {
        return installedPackages
    }
    
    func updatePackage(_ packageName: String) -> Bool {
        print("🔄 Updating package: \(packageName)")
        // Simulate update
        print("✅ Package \(packageName) updated successfully")
        return true
    }
}

struct Package {
    let name: String
    let version: String
    let description: String
    let language: ProgrammingLanguage
    let dependencies: [String]
    
    init(name: String, version: String, description: String, language: ProgrammingLanguage, dependencies: [String] = []) {
        self.name = name
        self.version = version
        self.description = description
        self.language = language
        self.dependencies = dependencies
    }
}

// MARK: - Existing IDE Features (Updated)

class SyntaxHighlighter {
    func highlight(_ code: String, language: ProgrammingLanguage) -> String {
        print("🎨 Highlighting \(language.rawValue) code...")
        
        let keywords = getKeywords(for: language)
        var highlightedCode = code
        
        for keyword in keywords {
            highlightedCode = highlightedCode.replacingOccurrences(
                of: keyword,
                with: "[\(keyword)]"
            )
        }
        
        return highlightedCode
    }
    
    private func getKeywords(for language: ProgrammingLanguage) -> [String] {
        switch language {
        case .swift:
            return ["func", "var", "let", "class", "struct", "enum", "import", "if", "else", "for", "while", "return"]
        case .python:
            return ["def", "class", "import", "from", "if", "else", "elif", "for", "while", "return", "try", "except"]
        case .javascript:
            return ["function", "var", "let", "const", "class", "if", "else", "for", "while", "return", "import", "export"]
        case .typescript:
            return ["function", "var", "let", "const", "class", "interface", "type", "if", "else", "for", "while", "return"]
        case .java:
            return ["public", "private", "protected", "class", "interface", "if", "else", "for", "while", "return", "import"]
        case .cpp:
            return ["#include", "class", "struct", "if", "else", "for", "while", "return", "public", "private", "protected"]
        default:
            return []
        }
    }
}

class IntelliSense {
    func getCompletions(for code: String, language: ProgrammingLanguage, position: Int) -> [String] {
        print("💡 Generating IntelliSense completions for \(language.rawValue)...")
        
        switch language {
        case .swift:
            return ["print()", "String", "Int", "Double", "Array", "Dictionary", "func", "var", "let"]
        case .python:
            return ["print()", "str", "int", "float", "list", "dict", "def", "class", "import"]
        case .javascript:
            return ["console.log()", "function", "var", "let", "const", "Array", "Object", "String"]
        case .typescript:
            return ["console.log()", "function", "interface", "type", "string", "number", "boolean"]
        case .java:
            return ["System.out.println()", "public", "private", "class", "interface", "String", "int"]
        default:
            return ["// No completions available"]
        }
    }
    
    func findDefinition(for symbol: String, in files: [File]) -> String? {
        print("🔍 Finding definition for: \(symbol)")
        return "Found definition in file: example.swift:15"
    }
}

struct Breakpoint {
    let line: Int
    let condition: String?
    let isEnabled: Bool
    
    init(line: Int, condition: String? = nil, isEnabled: Bool = true) {
        self.line = line
        self.condition = condition
        self.isEnabled = isEnabled
    }
}

class Debugger {
    private var breakpoints: [Int: Breakpoint] = [:]
    private var isRunning = false
    private var currentLine = 0
    private var callStack: [String] = []
    private var variables: [String: Any] = [:]
    
    func addBreakpoint(at line: Int, condition: String? = nil) {
        let breakpoint = Breakpoint(line: line, condition: condition)
        breakpoints[line] = breakpoint
        
        if let condition = condition {
            print("🔴 Conditional breakpoint added at line \(line): \(condition)")
        } else {
            print("🔴 Breakpoint added at line \(line)")
        }
    }
    
    func removeBreakpoint(at line: Int) {
        breakpoints.removeValue(forKey: line)
        print("⚪ Breakpoint removed at line \(line)")
    }
    
    func toggleBreakpoint(at line: Int) {
        if var breakpoint = breakpoints[line] {
            breakpoint = Breakpoint(line: line, condition: breakpoint.condition, isEnabled: !breakpoint.isEnabled)
            breakpoints[line] = breakpoint
            print("\(breakpoint.isEnabled ? "🔴" : "⚪") Breakpoint \(breakpoint.isEnabled ? "enabled" : "disabled") at line \(line)")
        }
    }
    
    func listBreakpoints() {
        if breakpoints.isEmpty {
            print("📭 No breakpoints set")
            return
        }
        
        print("🔴 Active Breakpoints:")
        for (line, breakpoint) in breakpoints.sorted(by: { $0.key < $1.key }) {
            let status = breakpoint.isEnabled ? "🔴" : "⚪"
            let condition = breakpoint.condition != nil ? " [Condition: \(breakpoint.condition!)]" : ""
            print("  \(status) Line \(line)\(condition)")
        }
    }
    
    func startDebugging(file: File) {
        print("🐛 Starting debugger for \(file.name)")
        isRunning = true
        currentLine = 1
        callStack = ["main()"]
        
        // Simulate some variables
        setupSimulatedVariables(for: file)
        
        print("Debugger started. Breakpoints: \(breakpoints.keys.sorted())")
        
        if !breakpoints.isEmpty {
            let firstBreakpoint = breakpoints.keys.min()!
            currentLine = firstBreakpoint
            print("⏸️ Paused at breakpoint on line \(firstBreakpoint)")
            showCurrentState()
        }
    }
    
    func stepOver() {
        guard isRunning else {
            print("❌ Debugger is not running")
            return
        }
        
        currentLine += 1
        print("⏭️ Step over - Line \(currentLine)")
        showCurrentState()
    }
    
    func stepInto() {
        guard isRunning else {
            print("❌ Debugger is not running")
            return
        }
        
        currentLine += 1
        callStack.append("function_\(currentLine)()")
        print("⬇️ Step into - Line \(currentLine)")
        showCurrentState()
    }
    
    func stepOut() {
        guard isRunning else {
            print("❌ Debugger is not running")
            return
        }
        
        if callStack.count > 1 {
            let function = callStack.removeLast()
            print("⬆️ Step out of \(function)")
        }
        currentLine += 1
        showCurrentState()
    }
    
    func continueExecution() {
        guard isRunning else {
            print("❌ Debugger is not running")
            return
        }
        
        print("▶️ Continue execution")
        
        // Find next breakpoint
        let nextBreakpoint = breakpoints.keys.filter { $0 > currentLine }.min()
        if let nextLine = nextBreakpoint {
            currentLine = nextLine
            print("⏸️ Paused at breakpoint on line \(currentLine)")
            showCurrentState()
        } else {
            print("✅ Program finished execution")
            stop()
        }
    }
    
    func stop() {
        isRunning = false
        currentLine = 0
        callStack.removeAll()
        variables.removeAll()
        print("⏹️ Debugger stopped")
    }
    
    func evaluateExpression(_ expression: String) {
        print("🔍 Evaluating: \(expression)")
        
        // Simple expression evaluation simulation
        if variables.keys.contains(expression) {
            print("  Result: \(variables[expression] ?? "undefined")")
        } else if expression.contains("+") {
            print("  Result: 42 (simulated calculation)")
        } else {
            print("  Error: Unknown variable or expression")
        }
    }
    
    func showCurrentState() {
        print("\n📍 Current State:")
        print("  Line: \(currentLine)")
        print("  Call Stack: \(callStack.joined(separator: " → "))")
        showVariables()
        showWatchExpressions()
    }
    
    private func setupSimulatedVariables(for file: File) {
        switch file.language {
        case .swift:
            variables = [
                "name": "\"World\"",
                "count": 42,
                "isValid": true,
                "items": "[1, 2, 3, 4, 5]",
                "greeting": "\"Hello, World!\""
            ]
        case .python:
            variables = [
                "n": 10,
                "result": 55,
                "numbers": "[0, 1, 1, 2, 3, 5, 8]",
                "message": "\"Fibonacci complete\""
            ]
        case .javascript:
            variables = [
                "numbers": "[1, 2, 3, 4, 5]",
                "sum": 15,
                "index": 0,
                "temp": "undefined"
            ]
        default:
            variables = [
                "variable1": "value1",
                "variable2": 123,
                "variable3": true
            ]
        }
    }
    
    private func showVariables() {
        print("📊 Variables in Scope:")
        if variables.isEmpty {
            print("  No variables in current scope")
        } else {
            for (name, value) in variables.sorted(by: { $0.key < $1.key }) {
                print("  • \(name): \(value)")
            }
        }
    }
    
    private func showWatchExpressions() {
        // Simulate watch expressions
        print("👁️ Watch Expressions:")
        if let count = variables["count"] as? Int {
            print("  • count * 2: \(count * 2)")
        } else {
            print("  • count * 2: N/A")
        }
        print("  • items.length: 5")
    }
    
    func getBreakpoints() -> [Breakpoint] {
        return Array(breakpoints.values)
    }
    
    func getCurrentLine() -> Int {
        return currentLine
    }
    
    func isDebugging() -> Bool {
        return isRunning
    }
}

class VersionControl {
    func initRepository() {
        print("📁 Initializing Git repository...")
        print("✅ Git repository initialized")
    }
    
    func getStatus() -> [String] {
        print("📋 Getting Git status...")
        return [
            "Modified: main.swift",
            "Added: new_feature.swift",
            "Deleted: old_file.swift"
        ]
    }
    
    func stageFile(_ filename: String) {
        print("➕ Staging file: \(filename)")
    }
    
    func commit(message: String) {
        print("💾 Committing with message: \(message)")
        print("✅ Commit successful")
    }
    
    func push() {
        print("🚀 Pushing to remote repository...")
        print("✅ Push successful")
    }
    
    func pull() {
        print("⬇️ Pulling from remote repository...")
        print("✅ Pull successful")
    }
}

class Terminal {
    func executeCommand(_ command: String) {
        print("💻 Executing: \(command)")
        
        switch command.lowercased() {
        case let cmd where cmd.hasPrefix("ls"):
            print("main.swift  README.md  src/")
        case let cmd where cmd.hasPrefix("pwd"):
            print("/Users/developer/myproject")
        case let cmd where cmd.hasPrefix("git"):
            print("Git command executed")
        case let cmd where cmd.hasPrefix("npm"):
            print("npm command executed")
        case let cmd where cmd.hasPrefix("python"):
            print("Python script executed")
        case let cmd where cmd.hasPrefix("swift"):
            print("Swift compiler executed")
        default:
            print("Command output: \(command)")
        }
    }
}

class ExtensionManager {
    private var installedExtensions: [String] = []
    
    func installExtension(_ name: String) {
        print("📦 Installing extension: \(name)")
        installedExtensions.append(name)
        print("✅ Extension \(name) installed successfully")
    }
    
    func uninstallExtension(_ name: String) {
        print("🗑️ Uninstalling extension: \(name)")
        installedExtensions.removeAll { $0 == name }
        print("✅ Extension \(name) uninstalled")
    }
    
    func getInstalledExtensions() -> [String] {
        return installedExtensions
    }
    
    func getAvailableExtensions() -> [String] {
        return [
            "Python Language Support",
            "JavaScript IntelliSense",
            "Git Integration",
            "Theme Pack",
            "Bracket Pair Colorizer",
            "Live Share",
            "Docker Support",
            "REST Client",
            "Markdown Preview",
            "Code Formatter"
        ]
    }
}

class ThemeManager {
    enum Theme: String, CaseIterable {
        case dark = "Dark"
        case light = "Light"
        case highContrast = "High Contrast"
        case monokai = "Monokai"
        case solarizedDark = "Solarized Dark"
        case solarizedLight = "Solarized Light"
    }
    
    private var currentTheme: Theme = .dark
    
    func setTheme(_ theme: Theme) {
        currentTheme = theme
        print("🎨 Theme changed to: \(theme.rawValue)")
    }
    
    func getCurrentTheme() -> Theme {
        return currentTheme
    }
}

class FileManager {
    private var files: [File] = []
    private var openFiles: [File] = []
    
    func createFile(name: String, content: String = "") -> File {
        let language = detectLanguage(from: name)
        let file = File(
            id: UUID().uuidString,
            name: name,
            path: "/project/\(name)",
            content: content,
            language: language
        )
        files.append(file)
        print("📝 Created file: \(name)")
        return file
    }
    
    func openFile(_ file: File) {
        if !openFiles.contains(where: { $0.id == file.id }) {
            openFiles.append(file)
            print("📂 Opened file: \(file.name)")
        }
    }
    
    func closeFile(_ file: File) {
        openFiles.removeAll { $0.id == file.id }
        print("❌ Closed file: \(file.name)")
    }
    
    func saveFile(_ file: File) {
        print("💾 Saved file: \(file.name)")
    }
    
    func getOpenFiles() -> [File] {
        return openFiles
    }
    
    func getAllFiles() -> [File] {
        return files
    }
    
    private func detectLanguage(from filename: String) -> ProgrammingLanguage {
        let fileExtension = "." + filename.components(separatedBy: ".").last!.lowercased()
        
        for language in ProgrammingLanguage.allCases {
            if language.fileExtensions.contains(fileExtension) {
                return language
            }
        }
        
        return .swift
    }
}

class SearchAndReplace {
    func search(query: String, in files: [File]) -> [(file: File, line: Int, match: String)] {
        print("🔍 Searching for: \(query)")
        var results: [(file: File, line: Int, match: String)] = []
        
        for file in files {
            let lines = file.content.components(separatedBy: .newlines)
            for (index, line) in lines.enumerated() {
                if line.lowercased().contains(query.lowercased()) {
                    results.append((file: file, line: index + 1, match: line))
                }
            }
        }
        
        print("Found \(results.count) matches")
        return results
    }
    
    func replace(query: String, with replacement: String, in file: File) -> File {
        print("🔄 Replacing '\(query)' with '\(replacement)' in \(file.name)")
        let newContent = file.content.replacingOccurrences(of: query, with: replacement)
        return File(
            id: file.id,
            name: file.name,
            path: file.path,
            content: newContent,
            language: file.language,
            isModified: true
        )
    }
}

// MARK: - Main IDE Class (Updated)

class DeepBlueIDE {
    private let syntaxHighlighter = SyntaxHighlighter()
    private let intelliSense = IntelliSense()
    private let debugger = Debugger()
    private let versionControl = VersionControl()
    private let terminal = Terminal()
    private let extensionManager = ExtensionManager()
    private let themeManager = ThemeManager()
    private let fileManager = FileManager()
    private let searchAndReplace = SearchAndReplace()
    
    // New components
    private let toolManager = ToolManager()
    private let pluginManager = PluginManager()
    private let compilerManager = CompilerManager()
    private let projectManager = ProjectManager()
    private let packageManager = PackageManager()
    
    func start() {
        print("🚀 Welcome to DeepBlue IDE - A Complete Development Environment")
        print("=" * 60)
        
        initializeIDE()
        setupDefaultFiles()
        showMainMenu()
    }
    
    private func initializeIDE() {
        // Register built-in tools
        toolManager.registerTool(CompilerTool())
        toolManager.registerTool(LinterTool())
        toolManager.registerTool(FormatterTool())
        toolManager.registerTool(TestRunnerTool())
        
        // Register built-in plugins
        pluginManager.registerPlugin(GitPlugin())
        pluginManager.registerPlugin(CodeSnippetsPlugin())
        pluginManager.registerPlugin(LivePreviewPlugin())
        
        // Activate default plugins
        _ = pluginManager.activatePlugin("Git Integration")
        _ = pluginManager.activatePlugin("Code Snippets")
        
        print("✅ IDE initialized successfully")
    }
    
    private func setupDefaultFiles() {
        let swiftFile = fileManager.createFile(
            name: "main.swift",
            content: """
            import Foundation
            
            func greet(name: String) -> String {
                return "Hello, \\(name)!"
            }
            
            let message = greet(name: "World")
            print(message)
            """
        )
        
        let pythonFile = fileManager.createFile(
            name: "script.py",
            content: """
            def fibonacci(n):
                if n <= 1:
                    return n
                return fibonacci(n-1) + fibonacci(n-2)
            
            print(fibonacci(10))
            """
        )
        
        let jsFile = fileManager.createFile(
            name: "app.js",
            content: """
            function calculateSum(numbers) {
                return numbers.reduce((sum, num) => sum + num, 0);
            }
            
            const result = calculateSum([1, 2, 3, 4, 5]);
            console.log(result);
            """
        )
        
        fileManager.openFile(swiftFile)
        fileManager.openFile(pythonFile)
        fileManager.openFile(jsFile)
    }
    
    private func showMainMenu() {
        while true {
            print("\n🎯 DeepBlue IDE - Main Menu")
            print("=" * 30)
            print("1. File Operations")
            print("2. Code Editor")
            print("3. Debug Code")
            print("4. Build & Compile")
            print("5. Version Control")
            print("6. Terminal")
            print("7. Tools")
            print("8. Plugins")
            print("9. Extensions")
            print("10. Project Management")
            print("11. Package Manager")
            print("12. Settings")
            print("13. Search & Replace")
            print("14. Show Project Structure")
            print("0. Exit")
            print("\nEnter your choice: ", terminator: "")
            
            guard let input = readLine(), let choice = Int(input) else {
                print("❌ Invalid input. Please enter a number.")
                continue
            }
            
            switch choice {
            case 1: fileOperations()
            case 2: codeEditor()
            case 3: debugCode()
            case 4: buildAndCompile()
            case 5: versionControlMenu()
            case 6: terminalMenu()
            case 7: toolsMenu()
            case 8: pluginsMenu()
            case 9: extensionsMenu()
            case 10: projectManagementMenu()
            case 11: packageManagerMenu()
            case 12: settingsMenu()
            case 13: searchAndReplaceMenu()
            case 14: showProjectStructure()
            case 0: 
                print("👋 Goodbye! Thanks for using DeepBlue IDE")
                return
            default:
                print("❌ Invalid choice. Please try again.")
            }
        }
    }
    
    private func buildAndCompile() {
        let openFiles = fileManager.getOpenFiles()
        if openFiles.isEmpty {
            print("📭 No files currently open")
            return
        }
        
        print("\n🏗️ Build & Compile")
        print("1. Compile Current File")
        print("2. Build All Files")
        print("3. Run Current File")
        print("4. Show Available Compilers")
        print("5. Back to Menu")
        
        guard let input = readLine(), let choice = Int(input) else { return }
        
        switch choice {
        case 1: compileCurrentFile()
        case 2: buildAllFiles()
        case 3: runCurrentFile()
        case 4: showAvailableCompilers()
        case 5: return
        default: print("❌ Invalid choice")
        }
    }
    
    private func compileCurrentFile() {
        let openFiles = fileManager.getOpenFiles()
        if openFiles.isEmpty {
            print("📭 No files currently open")
            return
        }
        
        print("\n📂 Select file to compile:")
        for (index, file) in openFiles.enumerated() {
            print("\(index + 1). \(file.name) (\(file.language.rawValue))")
        }
        
        guard let input = readLine(), let index = Int(input), index > 0, index <= openFiles.count else { return }
        
        let file = openFiles[index - 1]
        let result = compilerManager.compile(file)
        
        print("\n🏗️ Compilation Result:")
        print("Success: \(result.success ? "✅" : "❌")")
        if !result.output.isEmpty {
            print("Output: \(result.output)")
        }
        if !result.errors.isEmpty {
            print("Errors:")
            for error in result.errors {
                print("  ❌ \(error)")
            }
        }
        if !result.warnings.isEmpty {
            print("Warnings:")
            for warning in result.warnings {
                print("  ⚠️ \(warning)")
            }
        }
    }
    
    private func buildAllFiles() {
        let allFiles = fileManager.getAllFiles()
        print("🏗️ Building all files...")
        
        for file in allFiles {
            let result = compilerManager.compile(file)
            print("\(file.name): \(result.success ? "✅" : "❌")")
        }
    }
    
    private func runCurrentFile() {
        compileCurrentFile()
        print("▶️ Running compiled program...")
        print("Program output would appear here")
    }
    
    private func showAvailableCompilers() {
        let compilers = compilerManager.getAvailableCompilers()
        print("\n🔧 Available Compilers:")
        for language in compilers {
            print("  • \(language.rawValue)")
        }
    }
    
    private func toolsMenu() {
        print("\n🔧 Tools Menu")
        print("1. Show Available Tools")
        print("2. Use Compiler Tool")
        print("3. Use Linter Tool")
        print("4. Use Formatter Tool")
        print("5. Use Test Runner")
        print("6. Back to Menu")
        
        guard let input = readLine(), let choice = Int(input) else { return }
        
        switch choice {
        case 1: showAvailableTools()
        case 2: useCompilerTool()
        case 3: useLinterTool()
        case 4: useFormatterTool()
        case 5: useTestRunner()
        case 6: return
        default: print("❌ Invalid choice")
        }
    }
    
    private func showAvailableTools() {
        let tools = toolManager.getAvailableTools()
        print("\n🔧 Available Tools:")
        for tool in tools {
            print("  • \(tool.name) v\(tool.version) - \(tool.description)")
        }
    }
    
    private func useCompilerTool() {
        let openFiles = fileManager.getOpenFiles()
        if openFiles.isEmpty {
            print("📭 No files currently open")
            return
        }
        
        let file = openFiles[0]
        let result = toolManager.executeTool("Compiler", parameters: [
            "language": file.language,
            "code": file.content
        ])
        
        if let result = result {
            print("Tool Result: \(result.success ? "✅" : "❌")")
            print(result.output)
        }
    }
    
    private func useLinterTool() {
        let openFiles = fileManager.getOpenFiles()
        if openFiles.isEmpty {
            print("📭 No files currently open")
            return
        }
        
        let file = openFiles[0]
        let result = toolManager.executeTool("Linter", parameters: [
            "language": file.language,
            "code": file.content
        ])
        
        if let result = result {
            print("Linting Result:")
            print(result.output)
        }
    }
    
    private func useFormatterTool() {
        let openFiles = fileManager.getOpenFiles()
        if openFiles.isEmpty {
            print("📭 No files currently open")
            return
        }
        
        let file = openFiles[0]
        let result = toolManager.executeTool("Formatter", parameters: [
            "language": file.language,
            "code": file.content
        ])
        
        if let result = result {
            print("Formatted Code:")
            print(result.output)
        }
    }
    
    private func useTestRunner() {
        let testFiles = fileManager.getAllFiles().filter { $0.name.contains("test") }
        let result = toolManager.executeTool("TestRunner", parameters: [
            "testFiles": testFiles
        ])
        
        if let result = result {
            print(result.output)
        }
    }
    
    private func pluginsMenu() {
        print("\n🔌 Plugins Menu")
        print("1. Show Active Plugins")
        print("2. Show All Plugins")
        print("3. Activate Plugin")
        print("4. Deactivate Plugin")
        print("5. Plugin Actions")
        print("6. Back to Menu")
        
        guard let input = readLine(), let choice = Int(input) else { return }
        
        switch choice {
        case 1: showActivePlugins()
        case 2: showAllPlugins()
        case 3: activatePlugin()
        case 4: deactivatePlugin()
        case 5: pluginActions()
        case 6: return
        default: print("❌ Invalid choice")
        }
    }
    
    private func showActivePlugins() {
        let plugins = pluginManager.getActivePlugins()
        print("\n🟢 Active Plugins:")
        for plugin in plugins {
            print("  • \(plugin.name) v\(plugin.version) by \(plugin.author)")
        }
    }
    
    private func showAllPlugins() {
        let plugins = pluginManager.getAllPlugins()
        print("\n🔌 All Plugins:")
        for plugin in plugins {
            let status = pluginManager.getActivePlugins().contains { $0.name == plugin.name } ? "🟢" : "🔴"
            print("  \(status) \(plugin.name) v\(plugin.version) - \(plugin.description)")
        }
    }
    
    private func activatePlugin() {
        let plugins = pluginManager.getAllPlugins()
        print("\n🔌 Available Plugins:")
        for (index, plugin) in plugins.enumerated() {
            print("\(index + 1). \(plugin.name)")
        }
        
        print("Enter plugin number to activate: ", terminator: "")
        if let input = readLine(), let index = Int(input), index > 0, index <= plugins.count {
            let plugin = plugins[index - 1]
            _ = pluginManager.activatePlugin(plugin.name)
        }
    }
    
    private func deactivatePlugin() {
        let activePlugins = pluginManager.getActivePlugins()
        if activePlugins.isEmpty {
            print("📭 No active plugins")
            return
        }
        
        print("\n🟢 Active Plugins:")
        for (index, plugin) in activePlugins.enumerated() {
            print("\(index + 1). \(plugin.name)")
        }
        
        print("Enter plugin number to deactivate: ", terminator: "")
        if let input = readLine(), let index = Int(input), index > 0, index <= activePlugins.count {
            let plugin = activePlugins[index - 1]
            _ = pluginManager.deactivatePlugin(plugin.name)
        }
    }
    
    private func pluginActions() {
        let activePlugins = pluginManager.getActivePlugins()
        if activePlugins.isEmpty {
            print("📭 No active plugins")
            return
        }
        
        print("\n🎯 Plugin Actions:")
        var allMenuItems: [(plugin: String, item: PluginMenuItem)] = []
        
        for plugin in activePlugins {
            let menuItems = plugin.getMenuItems()
            for item in menuItems {
                allMenuItems.append((plugin: plugin.name, item: item))
            }
        }
        
        for (index, menuItem) in allMenuItems.enumerated() {
            print("\(index + 1). [\(menuItem.plugin)] \(menuItem.item.title)")
        }
        
        print("Enter action number: ", terminator: "")
        if let input = readLine(), let index = Int(input), index > 0, index <= allMenuItems.count {
            allMenuItems[index - 1].item.action()
        }
    }
    
    private func projectManagementMenu() {
        print("\n📁 Project Management")
        print("1. Create New Project")
        print("2. Open Project")
        print("3. Show Current Project")
        print("4. Show Recent Projects")
        print("5. Back to Menu")
        
        guard let input = readLine(), let choice = Int(input) else { return }
        
        switch choice {
        case 1: createNewProject()
        case 2: openProject()
        case 3: showCurrentProject()
        case 4: showRecentProjects()
        case 5: return
        default: print("❌ Invalid choice")
        }
    }
    
    private func createNewProject() {
        print("Enter project name: ", terminator: "")
        guard let name = readLine(), !name.isEmpty else { return }
        
        print("\n📋 Project Templates:")
        for (index, template) in ProjectTemplate.allCases.enumerated() {
            print("\(index + 1). \(template.rawValue) - \(template.description)")
        }
        
        print("Enter template number: ", terminator: "")
        guard let input = readLine(), let index = Int(input), index > 0, index <= ProjectTemplate.allCases.count else { return }
        
        let template = ProjectTemplate.allCases[index - 1]
        let project = projectManager.createProject(name: name, template: template)
        print("✅ Project '\(project.name)' created successfully")
    }
    
    private func openProject() {
        print("Enter project path: ", terminator: "")
        guard let path = readLine(), !path.isEmpty else { return }
        
        if let project = projectManager.openProject(path: path) {
            print("✅ Project '\(project.name)' opened successfully")
        } else {
            print("❌ Failed to open project")
        }
    }
    
    private func showCurrentProject() {
        if let project = projectManager.getCurrentProject() {
            print("\n📁 Current Project:")
            print("  Name: \(project.name)")
            print("  Path: \(project.path)")
            print("  Template: \(project.template.rawValue)")
            print("  Created: \(project.createdDate)")
        } else {
            print("📭 No project currently open")
        }
    }
    
    private func showRecentProjects() {
        let recent = projectManager.getRecentProjects()
        if recent.isEmpty {
            print("📭 No recent projects")
            return
        }
        
        print("\n📚 Recent Projects:")
        for (index, path) in recent.enumerated() {
            print("\(index + 1). \(path)")
        }
    }
    
    private func packageManagerMenu() {
        print("\n📦 Package Manager")
        print("1. Search Packages")
        print("2. Install Package")
        print("3. Show Installed Packages")
        print("4. Uninstall Package")
        print("5. Update Package")
        print("6. Back to Menu")
        
        guard let input = readLine(), let choice = Int(input) else { return }
        
        switch choice {
        case 1: searchPackages()
        case 2: installPackage()
        case 3: showInstalledPackages()
        case 4: uninstallPackage()
        case 5: updatePackage()
        case 6: return
        default: print("❌ Invalid choice")
        }
    }
    
    private func searchPackages() {
        print("Enter search query: ", terminator: "")
        guard let query = readLine(), !query.isEmpty else { return }
        
        let packages = packageManager.searchPackages(query)
        print("\n🔍 Search Results:")
        for package in packages {
            print("  • \(package.name) v\(package.version) (\(package.language.rawValue))")
            print("    \(package.description)")
        }
    }
    
    private func installPackage() {
        print("Enter search query: ", terminator: "")
        guard let query = readLine(), !query.isEmpty else { return }
        
        let packages = packageManager.searchPackages(query)
        if packages.isEmpty {
            print("❌ No packages found")
            return
        }
        
        print("\n📦 Available Packages:")
        for (index, package) in packages.enumerated() {
            print("\(index + 1). \(package.name) v\(package.version)")
        }
        
        print("Enter package number to install: ", terminator: "")
        if let input = readLine(), let index = Int(input), index > 0, index <= packages.count {
            let package = packages[index - 1]
            _ = packageManager.installPackage(package)
        }
    }
    
    private func showInstalledPackages() {
        let packages = packageManager.getInstalledPackages()
        if packages.isEmpty {
            print("📭 No packages installed")
            return
        }
        
        print("\n📦 Installed Packages:")
        for package in packages {
            print("  • \(package.name) v\(package.version) (\(package.language.rawValue))")
        }
    }
    
    private func uninstallPackage() {
        let packages = packageManager.getInstalledPackages()
        if packages.isEmpty {
            print("📭 No packages installed")
            return
        }
        
        print("\n📦 Installed Packages:")
        for (index, package) in packages.enumerated() {
            print("\(index + 1). \(package.name)")
        }
        
        print("Enter package number to uninstall: ", terminator: "")
        if let input = readLine(), let index = Int(input), index > 0, index <= packages.count {
            let package = packages[index - 1]
            _ = packageManager.uninstallPackage(package.name)
        }
    }
    
    private func updatePackage() {
        let packages = packageManager.getInstalledPackages()
        if packages.isEmpty {
            print("📭 No packages installed")
            return
        }
        
        print("\n📦 Installed Packages:")
        for (index, package) in packages.enumerated() {
            print("\(index + 1). \(package.name)")
        }
        
        print("Enter package number to update: ", terminator: "")
        if let input = readLine(), let index = Int(input), index > 0, index <= packages.count {
            let package = packages[index - 1]
            _ = packageManager.updatePackage(package.name)
        }
    }
    
    // Existing methods...
    private func fileOperations() {
        print("\n📁 File Operations")
        print("1. Create New File")
        print("2. Open File")
        print("3. Save All Files")
        print("4. Show Open Files")
        print("5. Close File")
        print("6. Back to Main Menu")
        
        guard let input = readLine(), let choice = Int(input) else { return }        
        switch choice {
        case 1: createNewFile()
        case 2: openFile()
        case 3: saveAllFiles()
        case 4: showOpenFiles()
        case 5: closeFile()
        case 6: return
        default: print("❌ Invalid choice")
        }
    }
    
    private func createNewFile() {
        print("Enter filename: ", terminator: "")
        guard let filename = readLine(), !filename.isEmpty else { return }
        
        let file = fileManager.createFile(name: filename)
        fileManager.openFile(file)
        pluginManager.notifyFileOpen(file)
    }
    
    private func openFile() {
        let allFiles = fileManager.getAllFiles()
        if allFiles.isEmpty {
            print("📭 No files available")
            return
        }
        
        print("\n📂 Available Files:")
        for (index, file) in allFiles.enumerated() {
            print("\(index + 1). \(file.name) (\(file.language.rawValue))")
        }
        
        print("Enter file number: ", terminator: "")
        guard let input = readLine(), let index = Int(input), index > 0, index <= allFiles.count else { return }
        
        let file = allFiles[index - 1]
        fileManager.openFile(file)
        pluginManager.notifyFileOpen(file)
    }
    
    private func saveAllFiles() {
        let openFiles = fileManager.getOpenFiles()
        for file in openFiles {
            fileManager.saveFile(file)
            pluginManager.notifyFileSave(file)
        }
        print("💾 All files saved")
    }
    
    private func showOpenFiles() {
        let openFiles = fileManager.getOpenFiles()
        if openFiles.isEmpty {
            print("📭 No files currently open")
            return
        }
        
        print("\n📂 Open Files:")
        for (index, file) in openFiles.enumerated() {
            let modified = file.isModified ? " (modified)" : ""
            print("\(index + 1). \(file.name) (\(file.language.rawValue))\(modified)")
        }
    }
    
    private func closeFile() {
        let openFiles = fileManager.getOpenFiles()
        if openFiles.isEmpty {
            print("📭 No files currently open")
            return
        }
        
        showOpenFiles()
        print("Enter file number to close: ", terminator: "")
        guard let input = readLine(), let index = Int(input), index > 0, index <= openFiles.count else { return }
        
        let file = openFiles[index - 1]
        fileManager.closeFile(file)
    }
    
    private func codeEditor() {
        let openFiles = fileManager.getOpenFiles()
        if openFiles.isEmpty {
            print("📭 No files currently open")
            return
        }
        
        print("\n💻 Code Editor")
        showOpenFiles()
        print("Enter file number to edit: ", terminator: "")
        guard let input = readLine(), let index = Int(input), index > 0, index <= openFiles.count else { return }
        
        let file = openFiles[index - 1]
        editFile(file)
    }
    
    private func editFile(_ file: File) {
        print("\n✏️ Editing: \(file.name)")
        print("Language: \(file.language.rawValue)")
        print("=" * 40)
        
        let highlighted = syntaxHighlighter.highlight(file.content, language: file.language)
        print(highlighted)
        
        print("\n💡 IntelliSense Suggestions:")
        let completions = intelliSense.getCompletions(for: file.content, language: file.language, position: 0)
        for completion in completions.prefix(5) {
            print("  • \(completion)")
        }
        
        print("\n📝 Editor Commands:")
        print("1. Show IntelliSense")
        print("2. Find Definition")
        print("3. Format Code")
        print("4. Back to Menu")
        
        guard let input = readLine(), let choice = Int(input) else { return }
        
        switch choice {
        case 1: showIntelliSense(for: file)
        case 2: findDefinition(for: file)
        case 3: formatCode(file)
        case 4: return
        default: print("❌ Invalid choice")
        }
    }
    
    private func showIntelliSense(for file: File) {
        let completions = intelliSense.getCompletions(for: file.content, language: file.language, position: 0)
        print("\n💡 All IntelliSense Completions:")
        for completion in completions {
            print("  • \(completion)")
        }
    }
    
    private func findDefinition(for file: File) {
        print("Enter symbol to find: ", terminator: "")
        guard let symbol = readLine(), !symbol.isEmpty else { return }
        
        if let definition = intelliSense.findDefinition(for: symbol, in: fileManager.getAllFiles()) {
            print("📍 \(definition)")
        } else {
            print("❌ Definition not found")
        }
    }
    
    private func formatCode(_ file: File) {
        print("🎨 Formatting code for \(file.name)...")
        print("✅ Code formatted successfully")
    }
    
    private func debugCode() {
        let openFiles = fileManager.getOpenFiles()
        if openFiles.isEmpty {
            print("📭 No files currently open")
            return
        }
        
        print("\n🐛 Debugger")
        showOpenFiles()
        print("Enter file number to debug: ", terminator: "")
        guard let input = readLine(), let index = Int(input), index > 0, index <= openFiles.count else { return }
        
        let file = openFiles[index - 1]
        debugFile(file)
    }
    
    private func debugFile(_ file: File) {
        print("\n🐛 Debugging: \(file.name)")
        print("=" * 40)
        
        if debugger.isDebugging() {
            print("📍 Current Line: \(debugger.getCurrentLine())")
        }
        
        print("\n🔴 Breakpoint Management:")
        print("1. Add Breakpoint")
        print("2. Add Conditional Breakpoint")
        print("3. Remove Breakpoint")
        print("4. Toggle Breakpoint")
        print("5. List All Breakpoints")
        
        print("\n▶️ Execution Controls:")
        print("6. Start Debugging")
        print("7. Step Over")
        print("8. Step Into")
        print("9. Step Out")
        print("10. Continue Execution")
        print("11. Stop Debugging")
        
        print("\n🔍 Inspection:")
        print("12. Show Current State")
        print("13. Evaluate Expression")
        
        print("\n14. Back to Menu")
        
        print("\nEnter your choice: ", terminator: "")
        guard let input = readLine(), let choice = Int(input) else { return }
        
        switch choice {
        case 1:
            print("Enter line number for breakpoint: ", terminator: "")
            if let lineInput = readLine(), let line = Int(lineInput) {
                debugger.addBreakpoint(at: line)
            }
        case 2:
            print("Enter line number for conditional breakpoint: ", terminator: "")
            if let lineInput = readLine(), let line = Int(lineInput) {
                print("Enter condition (e.g., 'x > 10'): ", terminator: "")
                if let condition = readLine(), !condition.isEmpty {
                    debugger.addBreakpoint(at: line, condition: condition)
                }
            }
        case 3:
            print("Enter line number to remove breakpoint: ", terminator: "")
            if let lineInput = readLine(), let line = Int(lineInput) {
                debugger.removeBreakpoint(at: line)
            }
        case 4:
            print("Enter line number to toggle breakpoint: ", terminator: "")
            if let lineInput = readLine(), let line = Int(lineInput) {
                debugger.toggleBreakpoint(at: line)
            }
        case 5: debugger.listBreakpoints()
        case 6: debugger.startDebugging(file: file)
        case 7: debugger.stepOver()
        case 8: debugger.stepInto()
        case 9: debugger.stepOut()
        case 10: debugger.continueExecution()
        case 11: debugger.stop()
        case 12: debugger.showCurrentState()
        case 13:
            print("Enter expression to evaluate: ", terminator: "")
            if let expression = readLine(), !expression.isEmpty {
                debugger.evaluateExpression(expression)
            }
        case 14: return
        default: print("❌ Invalid choice")
        }
        
        if choice != 14 {
            print("\nPress Enter to continue...")
            _ = readLine()
            debugFile(file)
        }
    }
    
    private func versionControlMenu() {
        print("\n📚 Version Control (Git)")
        print("1. Initialize Repository")
        print("2. Show Status")
        print("3. Stage File")
        print("4. Commit Changes")
        print("5. Push to Remote")
        print("6. Pull from Remote")
        print("7. Back to Menu")
        
        guard let input = readLine(), let choice = Int(input) else { return }
        
        switch choice {
        case 1: versionControl.initRepository()
        case 2: 
            let status = versionControl.getStatus()
            for item in status {
                print("  \(item)")
            }
        case 3:
            print("Enter filename to stage: ", terminator: "")
            if let filename = readLine() {
                versionControl.stageFile(filename)
            }
        case 4:
            print("Enter commit message: ", terminator: "")
            if let message = readLine() {
                versionControl.commit(message: message)
            }
        case 5: versionControl.push()
        case 6: versionControl.pull()
        case 7: return
        default: print("❌ Invalid choice")
        }
    }
    
    private func terminalMenu() {
        print("\n💻 Integrated Terminal")
        print("Enter commands (type 'exit' to return to menu)")
        
        while true {
            print("$ ", terminator: "")
            guard let command = readLine() else { continue }
            
            if command.lowercased() == "exit" {
                break
            }
            
            terminal.executeCommand(command)
        }
    }
    
    private func extensionsMenu() {
        print("\n🧩 Extension Manager")
        print("1. Show Installed Extensions")
        print("2. Show Available Extensions")
        print("3. Install Extension")
        print("4. Uninstall Extension")
        print("5. Back to Menu")
        
        guard let input = readLine(), let choice = Int(input) else { return }
        
        switch choice {
        case 1:
            let installed = extensionManager.getInstalledExtensions()
            if installed.isEmpty {
                print("📭 No extensions installed")
            } else {
                print("📦 Installed Extensions:")
                for ext in installed {
                    print("  • \(ext)")
                }
            }
        case 2:
            let available = extensionManager.getAvailableExtensions()
            print("🛒 Available Extensions:")
            for (index, ext) in available.enumerated() {
                print("\(index + 1). \(ext)")
            }
        case 3:
            let available = extensionManager.getAvailableExtensions()
            print("🛒 Available Extensions:")
            for (index, ext) in available.enumerated() {
                print("\(index + 1). \(ext)")
            }
            print("Enter extension number to install: ", terminator: "")
            if let input = readLine(), let index = Int(input), index > 0, index <= available.count {
                extensionManager.installExtension(available[index - 1])
            }
        case 4:
            let installed = extensionManager.getInstalledExtensions()
            if installed.isEmpty {
                print("📭 No extensions to uninstall")
            } else {
                print("📦 Installed Extensions:")
                for (index, ext) in installed.enumerated() {
                    print("\(index + 1). \(ext)")
                }
                print("Enter extension number to uninstall: ", terminator: "")
                if let input = readLine(), let index = Int(input), index > 0, index <= installed.count {
                    extensionManager.uninstallExtension(installed[index - 1])
                }
            }
        case 5: return
        default: print("❌ Invalid choice")
        }
    }
    
    private func settingsMenu() {
        print("\n⚙️ Settings")
        print("1. Change Theme")
        print("2. Show Current Theme")
        print("3. Back to Menu")
        
        guard let input = readLine(), let choice = Int(input) else { return }
        
        switch choice {
        case 1:
            print("🎨 Available Themes:")
            for (index, theme) in ThemeManager.Theme.allCases.enumerated() {
                print("\(index + 1). \(theme.rawValue)")
            }
            print("Enter theme number: ", terminator: "")
            if let input = readLine(), let index = Int(input), index > 0, index <= ThemeManager.Theme.allCases.count {
                let theme = ThemeManager.Theme.allCases[index - 1]
                themeManager.setTheme(theme)
            }
        case 2:
            print("Current theme: \(themeManager.getCurrentTheme().rawValue)")
        case 3: return
        default: print("❌ Invalid choice")
        }
    }
    
    private func searchAndReplaceMenu() {
        print("\n🔍 Search & Replace")
        print("1. Search in Files")
        print("2. Replace in File")
        print("3. Back to Menu")
        
        guard let input = readLine(), let choice = Int(input) else { return }
        
        switch choice {
        case 1:
            print("Enter search query: ", terminator: "")
            if let query = readLine(), !query.isEmpty {
                let results = searchAndReplace.search(query: query, in: fileManager.getAllFiles())
                for result in results {
                    print("📍 \(result.file.name):\(result.line) - \(result.match)")
                }
            }
        case 2:
            let openFiles = fileManager.getOpenFiles()
            if openFiles.isEmpty {
                print("📭 No files currently open")
                return
            }
            
            showOpenFiles()
            print("Enter file number: ", terminator: "")
            if let input = readLine(), let index = Int(input), index > 0, index <= openFiles.count {
                let file = openFiles[index - 1]
                print("Enter text to replace: ", terminator: "")
                if let query = readLine(), !query.isEmpty {
                    print("Enter replacement text: ", terminator: "")
                    if let replacement = readLine() {
                        let _ = searchAndReplace.replace(query: query, with: replacement, in: file)
                    }
                }
            }
        case 3: return
        default: print("❌ Invalid choice")
        }
    }
    
    private func showProjectStructure() {
        print("\n📁 Project Structure")
        print("DeepBlue IDE/")
        print("├── 📁 Core/")
        print("│   └── 📄 File.swift")
        print("├── 📁 Tools/")
        print("│   ├── 📄 ToolManager.swift")
        print("│   └── 📄 BuiltInTools.swift")
        print("├── 📁 Plugins/")
        print("│   ├── 📄 PluginManager.swift")
        print("│   └── 📄 BuiltInPlugins.swift")
        print("├── 📁 Compiler/")
        print("│   ├── 📄 CompilerManager.swift")
        print("│   └── 📄 Compilers.swift")
        print("├── 📁 Project/")
        print("│   └── 📄 ProjectManager.swift")
        print("├── 📁 Package/")
        print("│   └── 📄 PackageManager.swift")
        print("├── 📁 Editor/")
        print("│   └── 📄 EditorComponents.swift")
        print("├── 📁 Debug/")
        print("│   └── 📄 Debugger.swift")
        print("├── 📁 Utils/")
        print("│   └── 📄 SystemComponents.swift")
        print("└── 📄 main.swift")
    }
}

// MARK: - String Extension for Repeat

extension String {
    static func * (left: String, right: Int) -> String {
        return String(repeating: left, count: right)
    }
}

// MARK: - Main Entry Point

let ide = DeepBlueIDE()
ide.start()