
import Foundation

// MARK: - Compiler System

class CompilerManager {
    private var compilers: [ProgrammingLanguage: Compiler] = [:]
    
    init() {
        setupDefaultCompilers()
    }
    
    private func setupDefaultCompilers() {
        compilers[.swift] = SwiftCompiler()
        compilers[.python] = PythonInterpreter()
        compilers[.javascript] = JavaScriptEngine()
        compilers[.typescript] = TypeScriptCompiler()
        compilers[.java] = JavaCompiler()
        compilers[.cpp] = CppCompiler()
        compilers[.rust] = RustCompiler()
        compilers[.go] = GoCompiler()
    }
    
    func compile(_ file: File) -> CompilationResult {
        guard let compiler = compilers[file.language] else {
            return CompilationResult(
                success: false,
                output: "",
                errors: ["No compiler available for \(file.language.rawValue)"],
                warnings: [],
                executablePath: nil
            )
        }
        
        return compiler.compile(file)
    }
    
    func getAvailableCompilers() -> [ProgrammingLanguage] {
        return Array(compilers.keys)
    }
}

protocol Compiler {
    var language: ProgrammingLanguage { get }
    var version: String { get }
    func compile(_ file: File) -> CompilationResult
    func isAvailable() -> Bool
}

struct CompilationResult {
    let success: Bool
    let output: String
    let errors: [String]
    let warnings: [String]
    let executablePath: String?
}
