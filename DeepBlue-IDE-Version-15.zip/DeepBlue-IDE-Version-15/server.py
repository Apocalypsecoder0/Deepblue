
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import subprocess
import tempfile
import os
import json

app = Flask(__name__)
CORS(app)

@app.route('/')
def index():
    return send_from_directory('public', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory('public', path)

@app.route('/api/compile', methods=['POST'])
def compile_code():
    data = request.get_json()
    language = data.get('language')
    code = data.get('code')
    filename = data.get('filename', 'temp')
    
    if not language or not code:
        return jsonify({'success': False, 'error': 'Missing language or code'})
    
    try:
        result = compile_and_run(code, language, filename)
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/run', methods=['POST'])
def run_code():
    data = request.get_json()
    language = data.get('language')
    code = data.get('code')
    filename = data.get('filename', 'temp')
    
    if not language or not code:
        return jsonify({'success': False, 'error': 'Missing language or code'})
    
    try:
        result = execute_code(code, language, filename)
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/lint', methods=['POST'])
def lint_code():
    data = request.get_json()
    language = data.get('language')
    code = data.get('code')
    
    if not language or not code:
        return jsonify({'success': False, 'error': 'Missing language or code'})
    
    try:
        result = lint_source_code(code, language)
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/format', methods=['POST'])
def format_code():
    data = request.get_json()
    language = data.get('language')
    code = data.get('code')
    
    if not language or not code:
        return jsonify({'success': False, 'error': 'Missing language or code'})
    
    try:
        result = format_source_code(code, language)
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/files', methods=['GET'])
def list_files():
    try:
        files = []
        for root, dirs, filenames in os.walk('.'):
            for filename in filenames:
                if not filename.startswith('.') and filename.endswith(('.swift', '.py', '.js', '.ts', '.java', '.cpp', '.c', '.html', '.css', '.json')):
                    filepath = os.path.join(root, filename)
                    files.append({
                        'name': filename,
                        'path': filepath,
                        'size': os.path.getsize(filepath)
                    })
        return jsonify({'success': True, 'files': files})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/file', methods=['GET'])
def get_file():
    filepath = request.args.get('path')
    if not filepath:
        return jsonify({'success': False, 'error': 'Missing file path'})
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        return jsonify({'success': True, 'content': content})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/file', methods=['POST'])
def save_file():
    data = request.get_json()
    filepath = data.get('path')
    content = data.get('content')
    
    if not filepath or content is None:
        return jsonify({'success': False, 'error': 'Missing file path or content'})
    
    try:
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return jsonify({'success': True, 'message': 'File saved successfully'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

def compile_and_run(code, language, filename):
    """Compile and run code based on language"""
    
    if language == 'swift':
        with tempfile.NamedTemporaryFile(mode='w', suffix='.swift', delete=False) as f:
            f.write(code)
            f.flush()
            
            try:
                # Compile Swift code
                compile_result = subprocess.run(
                    ['swift', '-parse', f.name],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                
                if compile_result.returncode == 0:
                    # Run Swift code
                    run_result = subprocess.run(
                        ['swift', f.name],
                        capture_output=True,
                        text=True,
                        timeout=10
                    )
                    
                    return {
                        'success': True,
                        'output': run_result.stdout,
                        'errors': run_result.stderr,
                        'exit_code': run_result.returncode
                    }
                else:
                    return {
                        'success': False,
                        'output': '',
                        'errors': compile_result.stderr,
                        'exit_code': compile_result.returncode
                    }
            finally:
                os.unlink(f.name)
    
    elif language == 'python':
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write(code)
            f.flush()
            
            try:
                result = subprocess.run(
                    ['python3', f.name],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                
                return {
                    'success': result.returncode == 0,
                    'output': result.stdout,
                    'errors': result.stderr,
                    'exit_code': result.returncode
                }
            finally:
                os.unlink(f.name)
    
    elif language == 'javascript':
        with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
            f.write(code)
            f.flush()
            
            try:
                result = subprocess.run(
                    ['node', f.name],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                
                return {
                    'success': result.returncode == 0,
                    'output': result.stdout,
                    'errors': result.stderr,
                    'exit_code': result.returncode
                }
            finally:
                os.unlink(f.name)
    
    else:
        return {
            'success': False,
            'output': '',
            'errors': f'Language {language} not supported',
            'exit_code': 1
        }

def execute_code(code, language, filename):
    """Execute code without compilation step"""
    return compile_and_run(code, language, filename)

def lint_source_code(code, language):
    """Perform basic linting on source code"""
    issues = []
    lines = code.split('\n')
    
    for i, line in enumerate(lines, 1):
        # Basic linting rules
        if len(line) > 100:
            issues.append(f"Line {i}: Line too long ({len(line)} characters)")
        
        if line.rstrip() != line:
            issues.append(f"Line {i}: Trailing whitespace")
        
        if line.strip() == '' and len(line) > 0:
            issues.append(f"Line {i}: Line contains only whitespace")
        
        # Language-specific rules
        if language == 'python':
            if line.startswith(' ') and not line.startswith('    '):
                issues.append(f"Line {i}: Inconsistent indentation")
        
        elif language == 'javascript':
            if '==' in line and '===' not in line:
                issues.append(f"Line {i}: Use === instead of ==")
    
    return {
        'success': True,
        'issues': issues,
        'issue_count': len(issues)
    }

def format_source_code(code, language):
    """Perform basic code formatting"""
    lines = code.split('\n')
    formatted_lines = []
    
    for line in lines:
        # Remove trailing whitespace
        line = line.rstrip()
        
        # Basic formatting
        if language in ['javascript', 'swift', 'java']:
            # Add spaces around operators
            line = line.replace('=', ' = ')
            line = line.replace('  =  ', ' = ')  # Fix double spaces
            line = line.replace('+', ' + ')
            line = line.replace('  +  ', ' + ')
            line = line.replace('-', ' - ')
            line = line.replace('  -  ', ' - ')
        
        formatted_lines.append(line)
    
    return {
        'success': True,
        'formatted_code': '\n'.join(formatted_lines)
    }

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
