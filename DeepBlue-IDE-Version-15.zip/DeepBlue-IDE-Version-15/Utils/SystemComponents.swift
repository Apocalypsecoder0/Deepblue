
import Foundation

// MARK: - System Components

class VersionControl {
    func initRepository() {
        print("📁 Initializing Git repository...")
        print("✅ Git repository initialized")
    }
    
    func getStatus() -> [String] {
        print("📋 Getting Git status...")
        return [
            "Modified: main.swift",
            "Added: new_feature.swift",
            "Deleted: old_file.swift"
        ]
    }
    
    func stageFile(_ filename: String) {
        print("➕ Staging file: \(filename)")
    }
    
    func commit(message: String) {
        print("💾 Committing with message: \(message)")
        print("✅ Commit successful")
    }
    
    func push() {
        print("🚀 Pushing to remote repository...")
        print("✅ Push successful")
    }
    
    func pull() {
        print("⬇️ Pulling from remote repository...")
        print("✅ Pull successful")
    }
}

class Terminal {
    func executeCommand(_ command: String) {
        print("💻 Executing: \(command)")
        
        switch command.lowercased() {
        case let cmd where cmd.hasPrefix("ls"):
            print("main.swift  README.md  src/")
        case let cmd where cmd.hasPrefix("pwd"):
            print("/Users/developer/myproject")
        case let cmd where cmd.hasPrefix("git"):
            print("Git command executed")
        case let cmd where cmd.hasPrefix("npm"):
            print("npm command executed")
        case let cmd where cmd.hasPrefix("python"):
            print("Python script executed")
        case let cmd where cmd.hasPrefix("swift"):
            print("Swift compiler executed")
        default:
            print("Command output: \(command)")
        }
    }
}

class ExtensionManager {
    private var installedExtensions: [String] = []
    
    func installExtension(_ name: String) {
        print("📦 Installing extension: \(name)")
        installedExtensions.append(name)
        print("✅ Extension \(name) installed successfully")
    }
    
    func uninstallExtension(_ name: String) {
        print("🗑️ Uninstalling extension: \(name)")
        installedExtensions.removeAll { $0 == name }
        print("✅ Extension \(name) uninstalled")
    }
    
    func getInstalledExtensions() -> [String] {
        return installedExtensions
    }
    
    func getAvailableExtensions() -> [String] {
        return [
            "Python Language Support",
            "JavaScript IntelliSense",
            "Git Integration",
            "Theme Pack",
            "Bracket Pair Colorizer",
            "Live Share",
            "Docker Support",
            "REST Client",
            "Markdown Preview",
            "Code Formatter"
        ]
    }
}

class ThemeManager {
    enum Theme: String, CaseIterable {
        case dark = "Dark"
        case light = "Light"
        case highContrast = "High Contrast"
        case monokai = "Monokai"
        case solarizedDark = "Solarized Dark"
        case solarizedLight = "Solarized Light"
    }
    
    private var currentTheme: Theme = .dark
    
    func setTheme(_ theme: Theme) {
        currentTheme = theme
        print("🎨 Theme changed to: \(theme.rawValue)")
    }
    
    func getCurrentTheme() -> Theme {
        return currentTheme
    }
}

class FileManager {
    private var files: [File] = []
    private var openFiles: [File] = []
    
    func createFile(name: String, content: String = "") -> File {
        let language = detectLanguage(from: name)
        let file = File(
            id: UUID().uuidString,
            name: name,
            path: "/project/\(name)",
            content: content,
            language: language
        )
        files.append(file)
        print("📝 Created file: \(name)")
        return file
    }
    
    func openFile(_ file: File) {
        if !openFiles.contains(where: { $0.id == file.id }) {
            openFiles.append(file)
            print("📂 Opened file: \(file.name)")
        }
    }
    
    func closeFile(_ file: File) {
        openFiles.removeAll { $0.id == file.id }
        print("❌ Closed file: \(file.name)")
    }
    
    func saveFile(_ file: File) {
        print("💾 Saved file: \(file.name)")
    }
    
    func getOpenFiles() -> [File] {
        return openFiles
    }
    
    func getAllFiles() -> [File] {
        return files
    }
    
    private func detectLanguage(from filename: String) -> ProgrammingLanguage {
        let fileExtension = "." + filename.components(separatedBy: ".").last!.lowercased()
        
        for language in ProgrammingLanguage.allCases {
            if language.fileExtensions.contains(fileExtension) {
                return language
            }
        }
        
        return .swift
    }
}
