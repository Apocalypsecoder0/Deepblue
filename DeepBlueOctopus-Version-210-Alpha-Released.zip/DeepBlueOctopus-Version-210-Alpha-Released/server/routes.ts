import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertFileSchema, insertProjectSchema, registerUserSchema, loginUserSchema, updateUserSchema } from "@shared/schema";
import { exec } from "child_process";
import { promisify } from "util";
import bcrypt from "bcrypt";
import crypto from "crypto";
import session from "express-session";

const execAsync = promisify(exec);

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Session middleware configuration
  app.use(session({
    secret: process.env.SESSION_SECRET || 'deepblue-ide-secret-key-2025',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // Set to true in production with HTTPS
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Authentication middleware
  function requireAuth(req: any, res: any, next: any) {
    if (req.session && req.session.userId) {
      return next();
    }
    return res.status(401).json({ message: 'Authentication required' });
  }

  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const result = registerUserSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid input", 
          errors: result.error.issues 
        });
      }

      const { username, email, password, firstName, lastName } = result.data;

      // Check if user already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }

      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(409).json({ message: "Email already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create user
      const user = await storage.registerUser({
        username,
        email,
        password: hashedPassword,
        firstName,
        lastName
      });

      // Log user activity
      await storage.logUserActivity({
        userId: user.id,
        action: "Account created",
        details: `New account registered with email: ${email}`,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      // Create session
      req.session.userId = user.id;
      req.session.username = user.username;

      // Return user data (without password)
      const { password: _, ...userResponse } = user;
      res.status(201).json(userResponse);
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Failed to create account" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const result = loginUserSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid input", 
          errors: result.error.issues 
        });
      }

      const { username, password } = result.data;

      // Find user by username or email
      let user = await storage.getUserByUsername(username);
      if (!user) {
        user = await storage.getUserByEmail(username);
      }

      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Verify password
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Update last login
      await storage.updateLastLogin(user.id);

      // Log user activity
      await storage.logUserActivity({
        userId: user.id,
        action: "User logged in",
        details: `Successful login from ${req.ip}`,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      // Create session
      req.session.userId = user.id;
      req.session.username = user.username;

      // Return user data (without password)
      const { password: _, ...userResponse } = user;
      res.json(userResponse);
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Failed to log in" });
    }
  });

  app.post("/api/auth/logout", requireAuth, async (req: any, res) => {
    try {
      // Log user activity
      await storage.logUserActivity({
        userId: req.session.userId,
        action: "User logged out",
        details: `User logged out from ${req.ip}`,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      // Destroy session
      req.session.destroy((err: any) => {
        if (err) {
          return res.status(500).json({ message: "Failed to log out" });
        }
        res.json({ message: "Logged out successfully" });
      });
    } catch (error) {
      console.error("Logout error:", error);
      res.status(500).json({ message: "Failed to log out" });
    }
  });

  app.get("/api/auth/user", requireAuth, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Return user data (without password)
      const { password: _, ...userResponse } = user;
      res.json(userResponse);
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  // User management routes
  app.put("/api/user/profile", requireAuth, async (req: any, res) => {
    try {
      const result = updateUserSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid input", 
          errors: result.error.issues 
        });
      }

      const updatedUser = await storage.updateUser(req.session.userId, result.data);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }

      // Log user activity
      await storage.logUserActivity({
        userId: req.session.userId,
        action: "Profile updated",
        details: "User profile information updated",
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      // Return updated user data (without password)
      const { password: _, ...userResponse } = updatedUser;
      res.json(userResponse);
    } catch (error) {
      console.error("Update profile error:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.put("/api/user/password", requireAuth, async (req: any, res) => {
    try {
      const { currentPassword, newPassword } = req.body;

      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Current and new passwords are required" });
      }

      // Get current user
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Verify current password
      const isValidPassword = await bcrypt.compare(currentPassword, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Current password is incorrect" });
      }

      // Hash new password
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      // Update password
      const success = await storage.updateUserPassword(user.id, hashedPassword);
      if (!success) {
        return res.status(500).json({ message: "Failed to update password" });
      }

      // Log user activity
      await storage.logUserActivity({
        userId: req.session.userId,
        action: "Password changed",
        details: "User password was changed",
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      res.json({ message: "Password updated successfully" });
    } catch (error) {
      console.error("Update password error:", error);
      res.status(500).json({ message: "Failed to update password" });
    }
  });

  app.get("/api/user/settings", requireAuth, async (req: any, res) => {
    try {
      const settings = await storage.getUserSettings(req.session.userId);
      res.json(settings || {});
    } catch (error) {
      console.error("Get user settings error:", error);
      res.status(500).json({ message: "Failed to get user settings" });
    }
  });

  app.put("/api/user/settings", requireAuth, async (req: any, res) => {
    try {
      const settings = await storage.updateUserSettings(req.session.userId, req.body);
      
      // Log user activity
      await storage.logUserActivity({
        userId: req.session.userId,
        action: "Settings updated",
        details: "User settings were updated",
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      res.json(settings);
    } catch (error) {
      console.error("Update user settings error:", error);
      res.status(500).json({ message: "Failed to update settings" });
    }
  });

  app.get("/api/user/activity", requireAuth, async (req: any, res) => {
    try {
      const activity = await storage.getUserActivity(req.session.userId, 50);
      res.json(activity);
    } catch (error) {
      console.error("Get user activity error:", error);
      res.status(500).json({ message: "Failed to get user activity" });
    }
  });

  app.get("/api/user/sessions", requireAuth, async (req: any, res) => {
    try {
      const sessions = await storage.getUserSessions(req.session.userId);
      res.json(sessions);
    } catch (error) {
      console.error("Get user sessions error:", error);
      res.status(500).json({ message: "Failed to get user sessions" });
    }
  });

  app.delete("/api/user/sessions/:sessionId", requireAuth, async (req: any, res) => {
    try {
      const sessionId = parseInt(req.params.sessionId);
      const success = await storage.deleteUserSession(sessionId);
      
      if (success) {
        // Log user activity
        await storage.logUserActivity({
          userId: req.session.userId,
          action: "Session terminated",
          details: `Session ${sessionId} was terminated`,
          ipAddress: req.ip,
          userAgent: req.get('User-Agent')
        });

        res.json({ message: "Session terminated successfully" });
      } else {
        res.status(404).json({ message: "Session not found" });
      }
    } catch (error) {
      console.error("Delete session error:", error);
      res.status(500).json({ message: "Failed to delete session" });
    }
  });

  app.delete("/api/user/account", requireAuth, async (req: any, res) => {
    try {
      // Log user activity before deletion
      await storage.logUserActivity({
        userId: req.session.userId,
        action: "Account deleted",
        details: "User account was permanently deleted",
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });

      const success = await storage.deleteUser(req.session.userId);
      if (success) {
        // Destroy session
        req.session.destroy(() => {
          res.json({ message: "Account deleted successfully" });
        });
      } else {
        res.status(500).json({ message: "Failed to delete account" });
      }
    } catch (error) {
      console.error("Delete account error:", error);
      res.status(500).json({ message: "Failed to delete account" });
    }
  });

  // Get default project and files
  app.get("/api/project", async (req, res) => {
    try {
      const projects = await storage.getProjectsByUser(1); // Default user
      const project = projects[0];
      if (!project) {
        return res.status(404).json({ message: "No project found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ message: "Failed to get project" });
    }
  });

  // Get files for default project
  app.get("/api/files", async (req, res) => {
    try {
      console.log("Getting files for default project...");
      const projects = await storage.getProjectsByUser(1); // Default user
      console.log("Projects:", projects);
      const project = projects[0];
      if (!project) {
        console.log("No project found");
        return res.status(404).json({ message: "No project found" });
      }
      console.log("Getting files for project:", project.id);
      const files = await storage.getFilesByProject(project.id);
      console.log("Files:", files);
      res.json(files);
    } catch (error) {
      console.error("Error getting files:", error);
      res.status(500).json({ message: "Failed to get files", error: (error as Error).message });
    }
  });

  // Plugin API endpoints
  app.get("/api/plugins/installed", async (req, res) => {
    try {
      // For now, return empty array as no plugins are installed by default
      // In a real implementation, this would query the database
      res.json([]);
    } catch (error) {
      res.status(500).json({ message: "Failed to get installed plugins" });
    }
  });

  app.post("/api/plugins/install", async (req, res) => {
    try {
      const { manifest, code } = req.body;
      
      // Validate plugin manifest
      if (!manifest?.id || !manifest?.name || !manifest?.version) {
        return res.status(400).json({ message: "Invalid plugin manifest" });
      }

      // In a real implementation, this would save to database
      // For now, just return success
      res.json({ success: true, message: `Plugin ${manifest.id} installed successfully` });
    } catch (error) {
      res.status(500).json({ message: "Failed to install plugin" });
    }
  });

  app.delete("/api/plugins/:pluginId", async (req, res) => {
    try {
      const { pluginId } = req.params;
      
      // In a real implementation, this would remove from database
      res.json({ success: true, message: `Plugin ${pluginId} uninstalled successfully` });
    } catch (error) {
      res.status(500).json({ message: "Failed to uninstall plugin" });
    }
  });

  // Compiler API endpoint
  app.post("/api/compile", async (req, res) => {
    try {
      const { command, args, code, fileName, workingDirectory = '/tmp', environment = {} } = req.body;
      
      // Create temporary file with the code
      const fs = require('fs');
      const path = require('path');
      const { exec } = require('child_process');
      const os = require('os');
      
      const tempDir = os.tmpdir();
      const tempFile = path.join(tempDir, fileName);
      
      // Write code to temporary file
      fs.writeFileSync(tempFile, code);
      
      // Build command with arguments
      const fullCommand = `${command} ${args.join(' ')}`.replace(/\${file}/g, tempFile).replace(/\${fileBasenameNoExtension}/g, path.basename(fileName, path.extname(fileName)));
      
      console.log('Executing command:', fullCommand);
      
      // Execute compilation/run command
      exec(fullCommand, { 
        cwd: workingDirectory,
        env: { ...process.env, ...environment },
        timeout: 30000 // 30 second timeout
      }, (error, stdout, stderr) => {
        // Clean up temporary file
        try {
          fs.unlinkSync(tempFile);
        } catch (cleanupError) {
          console.warn('Failed to clean up temp file:', cleanupError);
        }
        
        if (error) {
          return res.json({
            success: false,
            output: stderr || error.message,
            exitCode: error.code || 1
          });
        }
        
        res.json({
          success: true,
          output: stdout + (stderr ? '\nWarnings:\n' + stderr : ''),
          exitCode: 0
        });
      });
      
    } catch (error) {
      res.status(500).json({ 
        success: false,
        message: "Compilation failed", 
        error: (error as Error).message 
      });
    }
  });

  // Get files by project
  app.get("/api/files/:projectId", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const files = await storage.getFilesByProject(projectId);
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: "Failed to get files" });
    }
  });

  // Get file content
  app.get("/api/file/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const file = await storage.getFile(id);
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      res.json(file);
    } catch (error) {
      res.status(500).json({ message: "Failed to get file" });
    }
  });

  // Create new file
  app.post("/api/file", async (req, res) => {
    try {
      const fileData = insertFileSchema.parse(req.body);
      const file = await storage.createFile(fileData);
      res.json(file);
    } catch (error) {
      res.status(400).json({ message: "Invalid file data" });
    }
  });

  // Update file content
  app.put("/api/file/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const file = await storage.updateFile(id, updates);
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      res.json(file);
    } catch (error) {
      res.status(500).json({ message: "Failed to update file" });
    }
  });

  // Delete file
  app.delete("/api/file/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteFile(id);
      if (!success) {
        return res.status(404).json({ message: "File not found" });
      }
      res.json({ message: "File deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete file" });
    }
  });

  // Execute code
  app.post("/api/execute", async (req, res) => {
    try {
      const { code, language, input = "" } = req.body;
      let command = "";
      let tempFile = "";
      let compileCommand = "";

      // Escape code for shell execution
      const escapedCode = code.replace(/'/g, "'\\''");

      switch (language) {
        case "javascript":
          tempFile = "temp.js";
          command = `echo '${escapedCode}' > ${tempFile} && node ${tempFile} && rm ${tempFile}`;
          break;
        
        case "typescript":
          tempFile = "temp.ts";
          command = `echo '${escapedCode}' > ${tempFile} && npx tsx ${tempFile} && rm ${tempFile}`;
          break;
        
        case "python":
          tempFile = "temp.py";
          if (input) {
            command = `echo '${escapedCode}' > ${tempFile} && echo '${input}' | python3 ${tempFile} && rm ${tempFile}`;
          } else {
            command = `echo '${escapedCode}' > ${tempFile} && python3 ${tempFile} && rm ${tempFile}`;
          }
          break;
        
        case "java":
          tempFile = "Main.java";
          compileCommand = `echo '${escapedCode}' > ${tempFile} && javac ${tempFile}`;
          if (input) {
            command = `${compileCommand} && echo '${input}' | java Main && rm ${tempFile} Main.class`;
          } else {
            command = `${compileCommand} && java Main && rm ${tempFile} Main.class`;
          }
          break;
        
        case "cpp":
        case "c++":
          tempFile = "temp.cpp";
          compileCommand = `echo '${escapedCode}' > ${tempFile} && g++ -o temp_exe ${tempFile}`;
          if (input) {
            command = `${compileCommand} && echo '${input}' | ./temp_exe && rm ${tempFile} temp_exe`;
          } else {
            command = `${compileCommand} && ./temp_exe && rm ${tempFile} temp_exe`;
          }
          break;
        
        case "c":
          tempFile = "temp.c";
          compileCommand = `echo '${escapedCode}' > ${tempFile} && gcc -o temp_exe ${tempFile}`;
          if (input) {
            command = `${compileCommand} && echo '${input}' | ./temp_exe && rm ${tempFile} temp_exe`;
          } else {
            command = `${compileCommand} && ./temp_exe && rm ${tempFile} temp_exe`;
          }
          break;
        
        case "rust":
          tempFile = "temp.rs";
          compileCommand = `echo '${escapedCode}' > ${tempFile} && rustc ${tempFile} -o temp_exe`;
          if (input) {
            command = `${compileCommand} && echo '${input}' | ./temp_exe && rm ${tempFile} temp_exe`;
          } else {
            command = `${compileCommand} && ./temp_exe && rm ${tempFile} temp_exe`;
          }
          break;
        
        case "go":
          tempFile = "temp.go";
          if (input) {
            command = `echo '${escapedCode}' > ${tempFile} && echo '${input}' | go run ${tempFile} && rm ${tempFile}`;
          } else {
            command = `echo '${escapedCode}' > ${tempFile} && go run ${tempFile} && rm ${tempFile}`;
          }
          break;
        
        case "php":
          tempFile = "temp.php";
          if (input) {
            command = `echo '${escapedCode}' > ${tempFile} && echo '${input}' | php ${tempFile} && rm ${tempFile}`;
          } else {
            command = `echo '${escapedCode}' > ${tempFile} && php ${tempFile} && rm ${tempFile}`;
          }
          break;
        
        case "ruby":
          tempFile = "temp.rb";
          if (input) {
            command = `echo '${escapedCode}' > ${tempFile} && echo '${input}' | ruby ${tempFile} && rm ${tempFile}`;
          } else {
            command = `echo '${escapedCode}' > ${tempFile} && ruby ${tempFile} && rm ${tempFile}`;
          }
          break;
        
        case "bash":
        case "shell":
          tempFile = "temp.sh";
          command = `echo '${escapedCode}' > ${tempFile} && chmod +x ${tempFile} && ./${tempFile} && rm ${tempFile}`;
          break;
        
        case "swift":
          tempFile = "temp.swift";
          if (input) {
            command = `echo '${escapedCode}' > ${tempFile} && echo '${input}' | swift ${tempFile} && rm ${tempFile}`;
          } else {
            command = `echo '${escapedCode}' > ${tempFile} && swift ${tempFile} && rm ${tempFile}`;
          }
          break;
        
        case "kotlin":
          tempFile = "temp.kt";
          compileCommand = `echo '${escapedCode}' > ${tempFile} && kotlinc ${tempFile} -include-runtime -d temp.jar`;
          if (input) {
            command = `${compileCommand} && echo '${input}' | java -jar temp.jar && rm ${tempFile} temp.jar`;
          } else {
            command = `${compileCommand} && java -jar temp.jar && rm ${tempFile} temp.jar`;
          }
          break;
        
        case "dart":
          tempFile = "temp.dart";
          if (input) {
            command = `echo '${escapedCode}' > ${tempFile} && echo '${input}' | dart ${tempFile} && rm ${tempFile}`;
          } else {
            command = `echo '${escapedCode}' > ${tempFile} && dart ${tempFile} && rm ${tempFile}`;
          }
          break;
        
        case "lua":
          tempFile = "temp.lua";
          if (input) {
            command = `echo '${escapedCode}' > ${tempFile} && echo '${input}' | lua ${tempFile} && rm ${tempFile}`;
          } else {
            command = `echo '${escapedCode}' > ${tempFile} && lua ${tempFile} && rm ${tempFile}`;
          }
          break;
        
        case "scala":
          tempFile = "temp.scala";
          if (input) {
            command = `echo '${escapedCode}' > ${tempFile} && echo '${input}' | scala ${tempFile} && rm ${tempFile}`;
          } else {
            command = `echo '${escapedCode}' > ${tempFile} && scala ${tempFile} && rm ${tempFile}`;
          }
          break;
        
        case "haskell":
          tempFile = "temp.hs";
          compileCommand = `echo '${escapedCode}' > ${tempFile} && ghc -o temp_exe ${tempFile}`;
          if (input) {
            command = `${compileCommand} && echo '${input}' | ./temp_exe && rm ${tempFile} temp_exe temp.hi temp.o`;
          } else {
            command = `${compileCommand} && ./temp_exe && rm ${tempFile} temp_exe temp.hi temp.o`;
          }
          break;
        
        case "elixir":
          tempFile = "temp.exs";
          if (input) {
            command = `echo '${escapedCode}' > ${tempFile} && echo '${input}' | elixir ${tempFile} && rm ${tempFile}`;
          } else {
            command = `echo '${escapedCode}' > ${tempFile} && elixir ${tempFile} && rm ${tempFile}`;
          }
          break;
        
        case "crystal":
          tempFile = "temp.cr";
          if (input) {
            command = `echo '${escapedCode}' > ${tempFile} && echo '${input}' | crystal run ${tempFile} && rm ${tempFile}`;
          } else {
            command = `echo '${escapedCode}' > ${tempFile} && crystal run ${tempFile} && rm ${tempFile}`;
          }
          break;
        
        case "nim":
          tempFile = "temp.nim";
          compileCommand = `echo '${escapedCode}' > ${tempFile} && nim compile --run ${tempFile}`;
          if (input) {
            command = `${compileCommand} && echo '${input}' | ./temp && rm ${tempFile} temp`;
          } else {
            command = `${compileCommand} && rm ${tempFile} temp`;
          }
          break;
        
        case "zig":
          tempFile = "temp.zig";
          if (input) {
            command = `echo '${escapedCode}' > ${tempFile} && echo '${input}' | zig run ${tempFile} && rm ${tempFile}`;
          } else {
            command = `echo '${escapedCode}' > ${tempFile} && zig run ${tempFile} && rm ${tempFile}`;
          }
          break;
        
        case "html":
          return res.json({
            output: "HTML preview would be shown in browser",
            error: "",
            success: true,
            html: code
          });
        
        case "css":
          return res.json({
            output: "CSS styles would be applied to HTML",
            error: "",
            success: true,
            css: code
          });
        
        default:
          return res.status(400).json({ 
            message: `Language '${language}' is not supported yet`,
            supportedLanguages: [
              "javascript", "typescript", "python", "java", "cpp", "c", 
              "rust", "go", "php", "ruby", "bash", "html", "css",
              "swift", "kotlin", "dart", "lua", "scala", "haskell",
              "elixir", "crystal", "nim", "zig"
            ]
          });
      }

      // Set execution timeout
      const timeout = 10000; // 10 seconds
      const { stdout, stderr } = await Promise.race([
        execAsync(command),
        new Promise<never>((_, reject) => 
          setTimeout(() => reject(new Error("Execution timeout")), timeout)
        )
      ]);

      res.json({ 
        output: stdout || "Code executed successfully (no output)",
        error: stderr,
        success: !stderr,
        language: language,
        executionTime: Date.now()
      });
    } catch (error: any) {
      res.json({
        output: "",
        error: error.message || "Execution failed",
        success: false,
        language: req.body.language || "unknown"
      });
    }
  });

  // Get language info
  app.get("/api/languages", async (req, res) => {
    const languages = [
      {
        id: "javascript",
        name: "JavaScript",
        extensions: [".js", ".mjs"],
        hasCompiler: false,
        hasInterpreter: true,
        supportsInput: false
      },
      {
        id: "typescript", 
        name: "TypeScript",
        extensions: [".ts"],
        hasCompiler: true,
        hasInterpreter: true,
        supportsInput: false
      },
      {
        id: "python",
        name: "Python",
        extensions: [".py"],
        hasCompiler: false,
        hasInterpreter: true,
        supportsInput: true
      },
      {
        id: "java",
        name: "Java",
        extensions: [".java"],
        hasCompiler: true,
        hasInterpreter: false,
        supportsInput: true
      },
      {
        id: "cpp",
        name: "C++",
        extensions: [".cpp", ".cxx", ".cc"],
        hasCompiler: true,
        hasInterpreter: false,
        supportsInput: true
      },
      {
        id: "c",
        name: "C",
        extensions: [".c"],
        hasCompiler: true,
        hasInterpreter: false,
        supportsInput: true
      },
      {
        id: "rust",
        name: "Rust",
        extensions: [".rs"],
        hasCompiler: true,
        hasInterpreter: false,
        supportsInput: true
      },
      {
        id: "go",
        name: "Go",
        extensions: [".go"],
        hasCompiler: true,
        hasInterpreter: true,
        supportsInput: true
      },
      {
        id: "php",
        name: "PHP",
        extensions: [".php"],
        hasCompiler: false,
        hasInterpreter: true,
        supportsInput: true
      },
      {
        id: "ruby",
        name: "Ruby",
        extensions: [".rb"],
        hasCompiler: false,
        hasInterpreter: true,
        supportsInput: true
      },
      {
        id: "bash",
        name: "Bash",
        extensions: [".sh", ".bash"],
        hasCompiler: false,
        hasInterpreter: true,
        supportsInput: false
      },
      {
        id: "html",
        name: "HTML",
        extensions: [".html", ".htm"],
        hasCompiler: false,
        hasInterpreter: false,
        supportsInput: false
      },
      {
        id: "css",
        name: "CSS",
        extensions: [".css"],
        hasCompiler: false,
        hasInterpreter: false,
        supportsInput: false
      }
    ];

    res.json(languages);
  });

  // Server Management API endpoints
  app.get("/api/servers", async (req, res) => {
    const servers = [
      {
        name: 'Apache HTTP Server',
        type: 'apache',
        port: 80,
        status: 'stopped',
        version: '2.4.57',
        configPath: '/etc/apache2/apache2.conf',
        logPath: '/var/log/apache2/access.log'
      },
      {
        name: 'MySQL Database',
        type: 'mysql',
        port: 3306,
        status: 'stopped',
        version: '8.0.35',
        configPath: '/etc/mysql/mysql.conf.d/mysqld.cnf',
        logPath: '/var/log/mysql/error.log'
      },
      {
        name: 'phpMyAdmin',
        type: 'phpmyadmin',
        port: 8080,
        status: 'stopped',
        version: '5.2.1',
        configPath: '/etc/phpmyadmin/config.inc.php',
        logPath: '/var/log/apache2/phpmyadmin.log'
      }
    ];
    res.json(servers);
  });

  app.post("/api/servers/:type/toggle", async (req, res) => {
    try {
      const { type } = req.params;
      const { action } = req.body; // 'start' or 'stop'
      
      // Simulate server management
      const mockResult = {
        success: true,
        message: `${type} server ${action}ed successfully`,
        status: action === 'start' ? 'running' : 'stopped',
        timestamp: new Date().toISOString()
      };
      
      res.json(mockResult);
    } catch (error: any) {
      res.status(500).json({
        success: false,
        message: `Failed to ${req.body.action} server: ${error.message}`
      });
    }
  });

  // PHP code execution endpoint
  app.post("/api/execute/php", async (req, res) => {
    try {
      const { code, input } = req.body;
      const escapedCode = code.replace(/'/g, "'\"'\"'");
      const tempFile = "temp.php";
      
      let command;
      if (input) {
        command = `echo '<?php ${escapedCode}' > ${tempFile} && echo '${input}' | php ${tempFile} && rm ${tempFile}`;
      } else {
        command = `echo '<?php ${escapedCode}' > ${tempFile} && php ${tempFile} && rm ${tempFile}`;
      }

      const { exec } = await import("child_process");
      exec(command, { timeout: 10000 }, (error: any, stdout: any, stderr: any) => {
        res.json({
          output: stdout || "PHP code executed successfully",
          error: stderr || error?.message,
          success: !error && !stderr,
          language: "php",
          executionTime: Date.now()
        });
      });
    } catch (error: any) {
      res.json({
        output: "",
        error: error.message || "PHP execution failed",
        success: false,
        language: "php"
      });
    }
  });

  // Database management endpoints
  app.get("/api/databases", async (req, res) => {
    const databases = [
      {
        name: "blog_db",
        tables: 15,
        size: "1.2MB",
        lastModified: new Date(Date.now() - 86400000).toISOString()
      },
      {
        name: "ecommerce_db", 
        tables: 8,
        size: "856KB",
        lastModified: new Date(Date.now() - 172800000).toISOString()
      },
      {
        name: "test_db",
        tables: 3,
        size: "124KB", 
        lastModified: new Date(Date.now() - 3600000).toISOString()
      }
    ];
    res.json(databases);
  });

  app.post("/api/sql/execute", async (req, res) => {
    try {
      const { query } = req.body;
      
      // Mock SQL execution
      const mockResult = {
        success: true,
        message: "Query executed successfully",
        rows: [],
        affectedRows: 0,
        executionTime: Math.random() * 100
      };
      
      res.json(mockResult);
    } catch (error: any) {
      res.status(500).json({
        success: false,
        message: `SQL execution failed: ${error.message}`
      });
    }
  });

  // GitHub Integration endpoints
  app.post('/api/github/push', async (req, res) => {
    try {
      const { repository, branch, commitMessage, files } = req.body;
      
      if (!repository || !branch || !commitMessage) {
        return res.status(400).json({ message: 'Missing required parameters' });
      }

      // Get current project files
      const projects = await storage.getProjectsByUser(1);
      const project = projects[0];
      const projectFiles = project ? await storage.getFilesByProject(project.id) : [];
      
      // Simulate GitHub push operation
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      res.json({
        success: true,
        message: `Successfully pushed to ${repository}/${branch}`,
        commitSha: `abc${Math.random().toString(36).substring(7)}`,
        filesChanged: projectFiles.length
      });
    } catch (error) {
      console.error('Failed to push to GitHub:', error);
      res.status(500).json({ message: 'Failed to push to GitHub' });
    }
  });

  app.post('/api/github/clone', async (req, res) => {
    try {
      const { repositoryUrl, branch = 'main' } = req.body;
      
      if (!repositoryUrl) {
        return res.status(400).json({ message: 'Repository URL is required' });
      }

      // Extract repository name from URL
      const repoName = repositoryUrl.split('/').pop()?.replace('.git', '') || 'cloned-repo';
      
      // Create a new project for the cloned repository
      const newProject = await storage.createProject({
        name: repoName,
        description: `Cloned from ${repositoryUrl}`,
        userId: 1
      });

      // Create sample files for the cloned repository
      const sampleFiles = [
        {
          name: 'README.md',
          path: '/README.md',
          content: `# ${repoName}\n\nCloned from ${repositoryUrl}`,
          language: 'markdown',
          projectId: newProject.id,
          isDirectory: false,
          parentId: null,
          size: 50,
          isReadonly: false,
          encoding: 'utf-8'
        },
        {
          name: 'main.js',
          path: '/main.js',
          content: `// ${repoName} - Main file\nconsole.log("Hello from ${repoName}!");`,
          language: 'javascript',
          projectId: newProject.id,
          isDirectory: false,
          parentId: null,
          size: 80,
          isReadonly: false,
          encoding: 'utf-8'
        }
      ];

      for (const fileData of sampleFiles) {
        await storage.createFile(fileData as any);
      }

      // Simulate clone operation
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      res.json({
        success: true,
        message: `Successfully cloned ${repositoryUrl}`,
        projectId: newProject.id,
        projectName: repoName,
        branch,
        filesCloned: sampleFiles.length
      });
    } catch (error) {
      console.error('Failed to clone repository:', error);
      res.status(500).json({ message: 'Failed to clone repository' });
    }
  });

  app.post('/api/github/pull-request', async (req, res) => {
    try {
      const { repository, title, description, sourceBranch, targetBranch } = req.body;
      
      if (!repository || !title || !sourceBranch || !targetBranch) {
        return res.status(400).json({ message: 'Missing required parameters' });
      }

      // Simulate pull request creation
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const prNumber = Math.floor(Math.random() * 1000) + 1;
      
      res.json({
        success: true,
        message: `Pull request created successfully`,
        pullRequestNumber: prNumber,
        url: `https://github.com/${repository}/pull/${prNumber}`,
        title,
        sourceBranch,
        targetBranch
      });
    } catch (error) {
      console.error('Failed to create pull request:', error);
      res.status(500).json({ message: 'Failed to create pull request' });
    }
  });

  app.get('/api/github/status', async (req, res) => {
    try {
      // Get current project status
      const projects = await storage.getProjectsByUser(1);
      const project = projects[0];
      const files = project ? await storage.getFilesByProject(project.id) : [];
      
      // Simulate git status
      const modifiedFiles = files.filter(f => !f.isDirectory).slice(0, 3);
      const stagedFiles = files.filter(f => !f.isDirectory).slice(0, 2);
      
      res.json({
        currentBranch: 'main',
        ahead: Math.floor(Math.random() * 5),
        behind: Math.floor(Math.random() * 3),
        modifiedFiles: modifiedFiles.map(f => ({
          name: f.name,
          path: f.path,
          status: 'modified'
        })),
        stagedFiles: stagedFiles.map(f => ({
          name: f.name,
          path: f.path,
          status: 'staged'
        })),
        untrackedFiles: [],
        repository: project?.name || 'unknown',
        lastCommit: {
          sha: 'abc123def',
          message: 'Update project files',
          author: 'DeepBlue IDE',
          date: new Date().toISOString()
        }
      });
    } catch (error) {
      console.error('Failed to get git status:', error);
      res.status(500).json({ message: 'Failed to get git status' });
    }
  });

  // Mission System endpoints
  app.get('/api/missions', async (req, res) => {
    try {
      // Sample missions data
      const sampleMissions = [
        {
          id: 'mission-1',
          title: 'Complete First JavaScript Project',
          description: 'Build a simple calculator application using vanilla JavaScript with basic arithmetic operations.',
          category: 'coding',
          difficulty: 'easy',
          status: 'active',
          progress: 3,
          maxProgress: 5,
          reward: {
            points: 100,
            coins: 25,
            badges: ['JavaScript Beginner'],
            unlocks: ['Advanced JS Missions']
          },
          requirements: [
            { description: 'Create HTML structure', completed: true },
            { description: 'Implement basic operations', completed: true },
            { description: 'Add CSS styling', completed: true },
            { description: 'Test all functions', completed: false },
            { description: 'Deploy to GitHub Pages', completed: false }
          ],
          timeLimit: 48,
          createdAt: '2025-01-01T10:00:00Z',
          assignedBy: 'System'
        },
        {
          id: 'mission-2',
          title: 'Master Git Version Control',
          description: 'Learn essential Git commands and workflow by managing a real project with branches, commits, and merges.',
          category: 'learning',
          difficulty: 'medium',
          status: 'pending',
          progress: 0,
          maxProgress: 8,
          reward: {
            points: 200,
            coins: 50,
            badges: ['Git Master'],
            unlocks: ['Collaboration Missions']
          },
          requirements: [
            { description: 'Create repository', completed: false },
            { description: 'Make 10 commits', completed: false },
            { description: 'Create and merge branch', completed: false },
            { description: 'Resolve merge conflict', completed: false },
            { description: 'Use pull requests', completed: false },
            { description: 'Tag a release', completed: false },
            { description: 'Collaborate with team', completed: false },
            { description: 'Write good commit messages', completed: false }
          ],
          timeLimit: 72,
          createdAt: '2025-01-01T12:00:00Z',
          assignedBy: 'System'
        },
        {
          id: 'mission-3',
          title: 'Database Design Challenge',
          description: 'Design and implement a relational database schema for an e-commerce application with proper normalization.',
          category: 'coding',
          difficulty: 'hard',
          status: 'pending',
          progress: 0,
          maxProgress: 6,
          reward: {
            points: 350,
            coins: 100,
            badges: ['Database Architect'],
            unlocks: ['Advanced Database Missions']
          },
          requirements: [
            { description: 'Design ER diagram', completed: false },
            { description: 'Create normalized tables', completed: false },
            { description: 'Implement relationships', completed: false },
            { description: 'Write complex queries', completed: false },
            { description: 'Add indexes and constraints', completed: false },
            { description: 'Test data integrity', completed: false }
          ],
          timeLimit: 96,
          createdAt: '2025-01-01T14:00:00Z',
          assignedBy: 'System'
        },
        {
          id: 'mission-4',
          title: 'Daily Code Review',
          description: 'Review and provide constructive feedback on team member\'s code submissions.',
          category: 'daily',
          difficulty: 'easy',
          status: 'completed',
          progress: 1,
          maxProgress: 1,
          reward: {
            points: 50,
            coins: 10,
            badges: [],
            unlocks: []
          },
          requirements: [
            { description: 'Review 3 pull requests', completed: true }
          ],
          timeLimit: 24,
          createdAt: '2025-01-01T08:00:00Z',
          completedAt: '2025-01-01T16:30:00Z',
          assignedBy: 'System'
        },
        {
          id: 'mission-5',
          title: 'Team Collaboration Sprint',
          description: 'Successfully complete a week-long sprint with your development team, meeting all sprint goals.',
          category: 'collaboration',
          difficulty: 'medium',
          status: 'active',
          progress: 4,
          maxProgress: 7,
          reward: {
            points: 250,
            coins: 75,
            badges: ['Team Player', 'Sprint Champion'],
            unlocks: ['Leadership Missions']
          },
          requirements: [
            { description: 'Attend all daily standups', completed: true },
            { description: 'Complete assigned tasks', completed: true },
            { description: 'Help team members', completed: true },
            { description: 'Participate in retrospective', completed: true },
            { description: 'Meet sprint deadline', completed: false },
            { description: 'Zero critical bugs', completed: false },
            { description: 'Document deliverables', completed: false }
          ],
          timeLimit: 168,
          createdAt: '2024-12-30T09:00:00Z',
          assignedBy: 'Team Lead'
        }
      ];

      res.json(sampleMissions);
    } catch (error) {
      console.error('Failed to get missions:', error);
      res.status(500).json({ message: 'Failed to get missions' });
    }
  });

  app.get('/api/missions/stats', async (req, res) => {
    try {
      const stats = {
        totalMissions: 15,
        completedMissions: 8,
        failedMissions: 2,
        totalPoints: 2450,
        totalCoins: 125,
        currentLevel: 5,
        experiencePoints: 2450,
        nextLevelExp: 3000,
        badges: ['First Steps', 'Code Warrior', 'Team Player', 'Git Master', 'Database Pro'],
        streak: 7,
        rank: 'Advanced Developer'
      };

      res.json(stats);
    } catch (error) {
      console.error('Failed to get mission stats:', error);
      res.status(500).json({ message: 'Failed to get mission stats' });
    }
  });

  app.post('/api/missions/:id/start', async (req, res) => {
    try {
      const { id } = req.params;
      
      // Simulate mission start
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      res.json({
        success: true,
        message: `Mission ${id} started successfully`,
        startedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error('Failed to start mission:', error);
      res.status(500).json({ message: 'Failed to start mission' });
    }
  });

  app.post('/api/missions/:id/complete', async (req, res) => {
    try {
      const { id } = req.params;
      
      // Simulate mission completion with rewards
      const reward = {
        points: Math.floor(Math.random() * 200) + 50,
        coins: Math.floor(Math.random() * 50) + 10,
        badges: Math.random() > 0.7 ? ['Mission Master'] : [],
        unlocks: Math.random() > 0.8 ? ['Advanced Missions'] : []
      };
      
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      res.json({
        success: true,
        message: `Mission ${id} completed successfully`,
        reward,
        completedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error('Failed to complete mission:', error);
      res.status(500).json({ message: 'Failed to complete mission' });
    }
  });

  app.post('/api/missions', async (req, res) => {
    try {
      const { title, description, category, difficulty, timeLimit, requirements } = req.body;
      
      if (!title || !description) {
        return res.status(400).json({ message: 'Title and description are required' });
      }
      
      const newMission = {
        id: `mission-${Date.now()}`,
        title,
        description,
        category: category || 'coding',
        difficulty: difficulty || 'medium',
        status: 'pending',
        progress: 0,
        maxProgress: requirements?.length || 1,
        reward: {
          points: difficulty === 'easy' ? 50 : difficulty === 'medium' ? 100 : difficulty === 'hard' ? 200 : 300,
          coins: Math.floor((difficulty === 'easy' ? 50 : difficulty === 'medium' ? 100 : difficulty === 'hard' ? 200 : 300) / 4),
          badges: [],
          unlocks: []
        },
        requirements: requirements?.map((req: string) => ({
          description: req,
          completed: false
        })) || [{ description: 'Complete the mission', completed: false }],
        timeLimit: timeLimit || 24,
        createdAt: new Date().toISOString(),
        assignedBy: 'User'
      };
      
      // In a real implementation, this would save to database
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      res.json({
        success: true,
        message: 'Mission created successfully',
        mission: newMission
      });
    } catch (error) {
      console.error('Failed to create mission:', error);
      res.status(500).json({ message: 'Failed to create mission' });
    }
  });

  app.delete('/api/missions/:id', async (req, res) => {
    try {
      const { id } = req.params;
      
      // Simulate mission deletion
      await new Promise(resolve => setTimeout(resolve, 500));
      
      res.json({
        success: true,
        message: `Mission ${id} deleted successfully`
      });
    } catch (error) {
      console.error('Failed to delete mission:', error);
      res.status(500).json({ message: 'Failed to delete mission' });
    }
  });

  app.post('/api/missions/:id/progress', async (req, res) => {
    try {
      const { id } = req.params;
      const { requirementIndex, completed } = req.body;
      
      // Simulate progress update
      await new Promise(resolve => setTimeout(resolve, 500));
      
      res.json({
        success: true,
        message: 'Mission progress updated',
        updatedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error('Failed to update mission progress:', error);
      res.status(500).json({ message: 'Failed to update mission progress' });
    }
  });

  app.get('/api/missions/leaderboard', async (req, res) => {
    try {
      const leaderboard = [
        { rank: 1, username: 'CodeMaster', points: 4250, level: 8, badges: 12 },
        { rank: 2, username: 'DevNinja', points: 3890, level: 7, badges: 10 },
        { rank: 3, username: 'BugHunter', points: 3560, level: 6, badges: 9 },
        { rank: 4, username: 'GitGuru', points: 3200, level: 6, badges: 8 },
        { rank: 5, username: 'DataWiz', points: 2890, level: 5, badges: 7 },
        { rank: 6, username: 'You', points: 2450, level: 5, badges: 5 },
        { rank: 7, username: 'ScriptKid', points: 2100, level: 4, badges: 6 },
        { rank: 8, username: 'FullStack', points: 1950, level: 4, badges: 5 },
        { rank: 9, username: 'ReactPro', points: 1750, level: 3, badges: 4 },
        { rank: 10, username: 'NodeJS', points: 1500, level: 3, badges: 3 }
      ];

      res.json(leaderboard);
    } catch (error) {
      console.error('Failed to get leaderboard:', error);
      res.status(500).json({ message: 'Failed to get leaderboard' });
    }
  });

  // GitHub Integration routes
  let githubToken: string | null = null;

  app.post('/api/github/auth', async (req, res) => {
    try {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ error: 'Token is required' });
      }

      // Test the token by making a request to GitHub API
      const response = await fetch('https://api.github.com/user', {
        headers: {
          'Authorization': `token ${token}`,
          'User-Agent': 'DeepBlue-IDE'
        }
      });

      if (!response.ok) {
        return res.status(401).json({ error: 'Invalid GitHub token' });
      }

      githubToken = token;
      const user = await response.json();
      
      res.json({ authenticated: true, user });
    } catch (error) {
      res.status(500).json({ error: 'Authentication failed' });
    }
  });

  app.get('/api/github/status', async (req, res) => {
    res.json({ authenticated: !!githubToken });
  });

  app.get('/api/github/user', async (req, res) => {
    if (!githubToken) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    try {
      const response = await fetch('https://api.github.com/user', {
        headers: {
          'Authorization': `token ${githubToken}`,
          'User-Agent': 'DeepBlue-IDE'
        }
      });

      if (!response.ok) {
        return res.status(401).json({ error: 'Invalid token' });
      }

      const user = await response.json();
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch user info' });
    }
  });

  app.get('/api/github/repositories', async (req, res) => {
    if (!githubToken) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    try {
      const response = await fetch('https://api.github.com/user/repos?sort=updated&per_page=50', {
        headers: {
          'Authorization': `token ${githubToken}`,
          'User-Agent': 'DeepBlue-IDE'
        }
      });

      if (!response.ok) {
        return res.status(401).json({ error: 'Failed to fetch repositories' });
      }

      const repos = await response.json();
      res.json(repos);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch repositories' });
    }
  });

  app.post('/api/github/push', async (req, res) => {
    if (!githubToken) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    try {
      const { repository, commitMessage, branch } = req.body;
      
      // Get all files from current project
      const files = await storage.getFilesByProject(1); // Default project
      
      // Create commit data
      const commitData = {
        message: commitMessage,
        content: files.map(file => ({
          path: file.path.startsWith('/') ? file.path.slice(1) : file.path,
          content: file.content,
          encoding: 'utf-8'
        }))
      };

      // For now, return success - full GitHub push implementation would require more complex API calls
      res.json({ 
        success: true, 
        message: 'Code push initiated',
        repository,
        branch,
        filesCount: files.length
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to push code' });
    }
  });

  app.post('/api/github/clone', async (req, res) => {
    try {
      const { repositoryUrl } = req.body;
      
      // For now, return success - full clone implementation would require git operations
      res.json({ 
        success: true, 
        message: 'Repository clone initiated',
        url: repositoryUrl
      });
    } catch (error) {
      res.status(500).json({ error: 'Failed to clone repository' });
    }
  });

  app.post('/api/github/create-repo', async (req, res) => {
    if (!githubToken) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    try {
      const { name, description, private: isPrivate } = req.body;
      
      const response = await fetch('https://api.github.com/user/repos', {
        method: 'POST',
        headers: {
          'Authorization': `token ${githubToken}`,
          'User-Agent': 'DeepBlue-IDE',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name,
          description,
          private: isPrivate,
          auto_init: true
        })
      });

      if (!response.ok) {
        const error = await response.json();
        return res.status(response.status).json({ error: error.message });
      }

      const repo = await response.json();
      res.json(repo);
    } catch (error) {
      res.status(500).json({ error: 'Failed to create repository' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
