import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  profilePicture: text("profile_picture"),
  bio: text("bio"),
  location: text("location"),
  website: text("website"),
  githubUsername: text("github_username"),
  twitterUsername: text("twitter_username"),
  linkedinUsername: text("linkedin_username"),
  isEmailVerified: boolean("is_email_verified").default(false),
  isActive: boolean("is_active").default(true),
  lastLoginAt: timestamp("last_login_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const userSettings = pgTable("user_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  theme: text("theme").default("deepblue-dark"),
  language: text("language").default("en"),
  timezone: text("timezone").default("UTC"),
  notifications: boolean("notifications").default(true),
  emailNotifications: boolean("email_notifications").default(true),
  twoFactorEnabled: boolean("two_factor_enabled").default(false),
  publicProfile: boolean("public_profile").default(false),
  showEmail: boolean("show_email").default(false),
  showLocation: boolean("show_location").default(false),
  darkMode: boolean("dark_mode").default(true),
  compactMode: boolean("compact_mode").default(false),
  autoSave: boolean("auto_save").default(true),
  codeCompletion: boolean("code_completion").default(true),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const userSessions = pgTable("user_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  sessionToken: text("session_token").notNull().unique(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  isActive: boolean("is_active").default(true),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const passwordResets = pgTable("password_resets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  isUsed: boolean("is_used").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emailVerifications = pgTable("email_verifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  token: text("token").notNull().unique(),
  newEmail: text("new_email"),
  expiresAt: timestamp("expires_at").notNull(),
  isUsed: boolean("is_used").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userActivity = pgTable("user_activity", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  action: text("action").notNull(),
  details: text("details"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  path: text("path").notNull(),
  content: text("content").notNull().default(""),
  language: text("language").notNull().default("javascript"),
  projectId: integer("project_id").references(() => projects.id),
  isDirectory: boolean("is_directory").notNull().default(false),
  parentId: integer("parent_id").references(() => files.id),
  size: integer("size").default(0),
  lastModified: timestamp("last_modified").defaultNow(),
  isReadonly: boolean("is_readonly").default(false),
  encoding: text("encoding").default("utf-8"),
});

export const workspaceSettings = pgTable("workspace_settings", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id),
  theme: text("theme").default("deepblue-dark"),
  fontSize: integer("font_size").default(14),
  fontFamily: text("font_family").default("JetBrains Mono"),
  tabSize: integer("tab_size").default(2),
  wordWrap: boolean("word_wrap").default(true),
  lineNumbers: boolean("line_numbers").default(true),
  minimap: boolean("minimap").default(false),
  autoSave: boolean("auto_save").default(true),
  formatOnSave: boolean("format_on_save").default(false),
  liveShare: boolean("live_share").default(false),
  extensions: text("extensions").array().default([]),
});

export const debugSessions = pgTable("debug_sessions", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id),
  name: text("name").notNull(),
  configuration: text("configuration").notNull(),
  status: text("status").default("stopped"),
  breakpoints: text("breakpoints").array().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

export const snippets = pgTable("snippets", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  prefix: text("prefix").notNull(),
  body: text("body").notNull(),
  description: text("description"),
  language: text("language").notNull(),
  scope: text("scope").default("user"),
  isBuiltIn: boolean("is_built_in").default(false),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  lastLoginAt: true,
  createdAt: true,
  updatedAt: true,
});

export const loginUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const registerUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  firstName: true,
  lastName: true,
});

export const updateUserSchema = createInsertSchema(users).pick({
  firstName: true,
  lastName: true,
  bio: true,
  location: true,
  website: true,
  githubUsername: true,
  twitterUsername: true,
  linkedinUsername: true,
});

export const insertUserSettingsSchema = createInsertSchema(userSettings).omit({
  id: true,
  updatedAt: true,
});

export const insertUserSessionSchema = createInsertSchema(userSessions).omit({
  id: true,
  createdAt: true,
});

export const insertPasswordResetSchema = createInsertSchema(passwordResets).omit({
  id: true,
  createdAt: true,
});

export const insertEmailVerificationSchema = createInsertSchema(emailVerifications).omit({
  id: true,
  createdAt: true,
});

export const insertUserActivitySchema = createInsertSchema(userActivity).omit({
  id: true,
  createdAt: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
});

export const insertFileSchema = createInsertSchema(files).omit({
  id: true,
  lastModified: true,
});

export const insertWorkspaceSettingsSchema = createInsertSchema(workspaceSettings).omit({
  id: true,
});

export const insertDebugSessionSchema = createInsertSchema(debugSessions).omit({
  id: true,
  createdAt: true,
});

export const insertSnippetSchema = createInsertSchema(snippets).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;
export type RegisterUser = z.infer<typeof registerUserSchema>;
export type UpdateUser = z.infer<typeof updateUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;
export type UserSettings = typeof userSettings.$inferSelect;

export type InsertUserSession = z.infer<typeof insertUserSessionSchema>;
export type UserSession = typeof userSessions.$inferSelect;

export type InsertPasswordReset = z.infer<typeof insertPasswordResetSchema>;
export type PasswordReset = typeof passwordResets.$inferSelect;

export type InsertEmailVerification = z.infer<typeof insertEmailVerificationSchema>;
export type EmailVerification = typeof emailVerifications.$inferSelect;

export type InsertUserActivity = z.infer<typeof insertUserActivitySchema>;
export type UserActivity = typeof userActivity.$inferSelect;

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export type InsertFile = z.infer<typeof insertFileSchema>;
export type File = typeof files.$inferSelect;

export type InsertWorkspaceSettings = z.infer<typeof insertWorkspaceSettingsSchema>;
export type WorkspaceSettings = typeof workspaceSettings.$inferSelect;

export type InsertDebugSession = z.infer<typeof insertDebugSessionSchema>;
export type DebugSession = typeof debugSessions.$inferSelect;

export type InsertSnippet = z.infer<typeof insertSnippetSchema>;
export type Snippet = typeof snippets.$inferSelect;
