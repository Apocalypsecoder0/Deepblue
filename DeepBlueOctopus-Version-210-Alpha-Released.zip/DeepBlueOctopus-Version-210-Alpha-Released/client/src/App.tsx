import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip-system";
import { ThemeProvider } from "@/components/ui/theme-system";
import { SoundProvider } from "@/components/ui/sound-system";
import IDE from "@/pages/ide";
import NotFound from "@/pages/not-found";
import SplashScreen from "@/components/ui/splash-screen";

function Router() {
  return (
    <Switch>
      <Route path="/" component={IDE} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [isAppReady, setIsAppReady] = useState(false);

  // Simulate app initialization
  useEffect(() => {
    // Check if the splash has been shown in this session
    const splashShown = sessionStorage.getItem('splashShown');
    
    if (splashShown) {
      // Skip splash if already shown in this session
      setShowSplash(false);
      setIsAppReady(true);
    } else {
      // Show splash screen for new sessions
      setTimeout(() => {
        setIsAppReady(true);
      }, 500); // Small delay to ensure everything is ready
    }
  }, []);

  const handleSplashComplete = () => {
    sessionStorage.setItem('splashShown', 'true');
    setShowSplash(false);
  };

  if (showSplash && !sessionStorage.getItem('splashShown')) {
    return (
      <QueryClientProvider client={queryClient}>
        <ThemeProvider>
          <SoundProvider>
            <TooltipProvider>
              <SplashScreen 
                onComplete={handleSplashComplete}
                duration={3500}
              />
            </TooltipProvider>
          </SoundProvider>
        </ThemeProvider>
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <SoundProvider>
          <TooltipProvider>
            <Toaster />
            {isAppReady && <Router />}
          </TooltipProvider>
        </SoundProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
