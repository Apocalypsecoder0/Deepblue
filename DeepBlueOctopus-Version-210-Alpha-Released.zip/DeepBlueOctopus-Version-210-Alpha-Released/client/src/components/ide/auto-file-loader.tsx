import React, { useEffect } from 'react';
import { useIDEState } from '@/hooks/use-ide-state';
import { useQuery } from '@tanstack/react-query';

interface AutoFileLoaderProps {
  onFileOpen: (file: any) => void;
}

export function AutoFileLoader({ onFileOpen }: AutoFileLoaderProps) {
  const { currentFile } = useIDEState();
  
  const { data: files } = useQuery({
    queryKey: ['/api/files'],
    enabled: !currentFile
  });

  useEffect(() => {
    // Only auto-load if no file is currently open
    if (!currentFile && files && files.length > 0) {
      // Find the first non-directory file to open
      const firstFile = files.find((file: any) => !file.isDirectory);
      if (firstFile) {
        onFileOpen(firstFile);
      }
    }
  }, [currentFile, files, onFileOpen]);

  // This component doesn't render anything visible
  return null;
}