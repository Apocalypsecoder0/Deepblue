import { useState } from "react";
import { X, Server, Database, Globe, Activity, Settings, Play, Square, RotateCcw, FileText, Monitor, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";

interface ServerManagementProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ServerStatus {
  name: string;
  status: 'running' | 'stopped' | 'error';
  port: number;
  uptime: string;
  cpu: number;
  memory: number;
  version: string;
}

interface DatabaseConnection {
  name: string;
  type: 'PostgreSQL' | 'MySQL' | 'MongoDB' | 'Redis';
  status: 'connected' | 'disconnected' | 'error';
  host: string;
  port: number;
  tables?: number;
  size?: string;
}

export default function ServerManagement({ isOpen, onClose }: ServerManagementProps) {
  const [activeTab, setActiveTab] = useState("overview");
  const [serverStatuses, setServerStatuses] = useState<ServerStatus[]>([
    {
      name: "Development Server",
      status: "running",
      port: 3000,
      uptime: "2h 34m",
      cpu: 12,
      memory: 45,
      version: "v18.17.0"
    },
    {
      name: "API Server",
      status: "running",
      port: 8080,
      uptime: "2h 34m",
      cpu: 8,
      memory: 32,
      version: "v1.5.0"
    },
    {
      name: "Database Server",
      status: "running",
      port: 5432,
      uptime: "5h 12m",
      cpu: 5,
      memory: 28,
      version: "v15.4"
    }
  ]);

  const [databases, setDatabases] = useState<DatabaseConnection[]>([
    {
      name: "Main Database",
      type: "PostgreSQL",
      status: "connected",
      host: "localhost",
      port: 5432,
      tables: 15,
      size: "24.5 MB"
    },
    {
      name: "Cache Store",
      type: "Redis",
      status: "connected",
      host: "localhost",
      port: 6379,
      size: "128 KB"
    },
    {
      name: "Analytics DB",
      type: "MongoDB",
      status: "disconnected",
      host: "localhost",
      port: 27017,
      tables: 8,
      size: "12.3 MB"
    }
  ]);

  const [logs] = useState([
    "2025-01-01 05:41:23 [INFO] Development server started successfully",
    "2025-01-01 05:41:25 [INFO] Database connection established",
    "2025-01-01 05:41:26 [INFO] API routes registered",
    "2025-01-01 05:41:28 [WARN] High memory usage detected (45%)",
    "2025-01-01 05:41:30 [INFO] Client connected from 127.0.0.1",
    "2025-01-01 05:41:32 [INFO] File watcher initialized",
    "2025-01-01 05:41:35 [ERROR] Failed to connect to analytics database",
    "2025-01-01 05:41:37 [INFO] Hot reload triggered for main.tsx",
  ]);

  const handleServerAction = (serverName: string, action: 'start' | 'stop' | 'restart') => {
    setServerStatuses(prev => prev.map(server => {
      if (server.name === serverName) {
        switch (action) {
          case 'start':
            return { ...server, status: 'running' as const };
          case 'stop':
            return { ...server, status: 'stopped' as const };
          case 'restart':
            return { ...server, status: 'running' as const, uptime: '0m' };
        }
      }
      return server;
    }));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running':
      case 'connected':
        return 'bg-green-500';
      case 'stopped':
      case 'disconnected':
        return 'bg-orange-500';
      case 'error':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'running':
      case 'connected':
        return 'default';
      case 'stopped':
      case 'disconnected':
        return 'secondary';
      case 'error':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
      <Card className="w-[95%] h-[95%] max-w-7xl bg-background border-2 border-blue-500/30 shadow-2xl">
        <CardHeader className="pb-4 border-b border-blue-500/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Server className="h-6 w-6 text-blue-400" />
              </div>
              <div>
                <CardTitle className="text-2xl font-bold text-blue-300">
                  Server Management Console
                </CardTitle>
                <p className="text-[var(--ide-text-secondary)] text-sm mt-1">
                  Monitor and control your development environment
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-[var(--ide-text-secondary)] hover:text-[var(--ide-text)]"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
            <TabsList className="grid w-full grid-cols-5 mb-6">
              <TabsTrigger value="overview" className="flex items-center space-x-2">
                <Activity className="h-4 w-4" />
                <span>Overview</span>
              </TabsTrigger>
              <TabsTrigger value="servers" className="flex items-center space-x-2">
                <Server className="h-4 w-4" />
                <span>Servers</span>
              </TabsTrigger>
              <TabsTrigger value="databases" className="flex items-center space-x-2">
                <Database className="h-4 w-4" />
                <span>Databases</span>
              </TabsTrigger>
              <TabsTrigger value="deployment" className="flex items-center space-x-2">
                <Globe className="h-4 w-4" />
                <span>Deployment</span>
              </TabsTrigger>
              <TabsTrigger value="logs" className="flex items-center space-x-2">
                <FileText className="h-4 w-4" />
                <span>Logs</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-blue-900/20 border-blue-500/30">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg text-blue-300 flex items-center space-x-2">
                      <Server className="h-5 w-5" />
                      <span>Server Status</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {serverStatuses.map((server, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div className={`w-2 h-2 rounded-full ${getStatusColor(server.status)}`} />
                            <span className="text-sm text-[var(--ide-text)]">{server.name}</span>
                          </div>
                          <Badge variant={getStatusBadgeVariant(server.status)} className="text-xs">
                            {server.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-green-900/20 border-green-500/30">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg text-green-300 flex items-center space-x-2">
                      <Database className="h-5 w-5" />
                      <span>Database Status</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {databases.map((db, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <div className={`w-2 h-2 rounded-full ${getStatusColor(db.status)}`} />
                            <span className="text-sm text-[var(--ide-text)]">{db.name}</span>
                          </div>
                          <Badge variant={getStatusBadgeVariant(db.status)} className="text-xs">
                            {db.type}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-purple-900/20 border-purple-500/30">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg text-purple-300 flex items-center space-x-2">
                      <Monitor className="h-5 w-5" />
                      <span>System Resources</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-[var(--ide-text-secondary)]">CPU Usage</span>
                          <span className="text-[var(--ide-text)]">12%</span>
                        </div>
                        <Progress value={12} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-[var(--ide-text-secondary)]">Memory</span>
                          <span className="text-[var(--ide-text)]">45%</span>
                        </div>
                        <Progress value={45} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-[var(--ide-text-secondary)]">Disk Usage</span>
                          <span className="text-[var(--ide-text)]">68%</span>
                        </div>
                        <Progress value={68} className="h-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-background/50 border-blue-500/20">
                <CardHeader>
                  <CardTitle className="text-blue-300">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                      <Play className="h-4 w-4 mr-2" />
                      Start All
                    </Button>
                    <Button variant="outline" className="border-orange-500 text-orange-400 hover:bg-orange-500/20">
                      <Square className="h-4 w-4 mr-2" />
                      Stop All
                    </Button>
                    <Button variant="outline" className="border-green-500 text-green-400 hover:bg-green-500/20">
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Restart All
                    </Button>
                    <Button variant="outline" className="border-purple-500 text-purple-400 hover:bg-purple-500/20">
                      <Globe className="h-4 w-4 mr-2" />
                      Deploy
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="servers" className="space-y-6">
              <div className="grid gap-6">
                {serverStatuses.map((server, index) => (
                  <Card key={index} className="bg-background/50 border-blue-500/20">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${getStatusColor(server.status)}`} />
                          <CardTitle className="text-lg text-[var(--ide-text)]">{server.name}</CardTitle>
                          <Badge variant={getStatusBadgeVariant(server.status)}>
                            {server.status}
                          </Badge>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleServerAction(server.name, 'start')}
                            className="border-green-500 text-green-400 hover:bg-green-500/20"
                          >
                            <Play className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleServerAction(server.name, 'stop')}
                            className="border-orange-500 text-orange-400 hover:bg-orange-500/20"
                          >
                            <Square className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleServerAction(server.name, 'restart')}
                            className="border-blue-500 text-blue-400 hover:bg-blue-500/20"
                          >
                            <RotateCcw className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                        <div>
                          <p className="text-sm text-[var(--ide-text-secondary)]">Port</p>
                          <p className="text-[var(--ide-text)] font-mono">{server.port}</p>
                        </div>
                        <div>
                          <p className="text-sm text-[var(--ide-text-secondary)]">Uptime</p>
                          <p className="text-[var(--ide-text)]">{server.uptime}</p>
                        </div>
                        <div>
                          <p className="text-sm text-[var(--ide-text-secondary)]">CPU</p>
                          <p className="text-[var(--ide-text)]">{server.cpu}%</p>
                        </div>
                        <div>
                          <p className="text-sm text-[var(--ide-text-secondary)]">Memory</p>
                          <p className="text-[var(--ide-text)]">{server.memory}%</p>
                        </div>
                        <div>
                          <p className="text-sm text-[var(--ide-text-secondary)]">Version</p>
                          <p className="text-[var(--ide-text)] font-mono">{server.version}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="databases" className="space-y-6">
              <div className="grid gap-6">
                {databases.map((db, index) => (
                  <Card key={index} className="bg-background/50 border-blue-500/20">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${getStatusColor(db.status)}`} />
                          <CardTitle className="text-lg text-[var(--ide-text)]">{db.name}</CardTitle>
                          <Badge variant={getStatusBadgeVariant(db.status)}>
                            {db.type}
                          </Badge>
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" className="border-blue-500 text-blue-400 hover:bg-blue-500/20">
                            <Database className="h-3 w-3 mr-1" />
                            Connect
                          </Button>
                          <Button size="sm" variant="outline" className="border-green-500 text-green-400 hover:bg-green-500/20">
                            <Settings className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div>
                          <p className="text-sm text-[var(--ide-text-secondary)]">Host</p>
                          <p className="text-[var(--ide-text)] font-mono">{db.host}:{db.port}</p>
                        </div>
                        <div>
                          <p className="text-sm text-[var(--ide-text-secondary)]">Status</p>
                          <Badge variant={getStatusBadgeVariant(db.status)}>
                            {db.status}
                          </Badge>
                        </div>
                        {db.tables && (
                          <div>
                            <p className="text-sm text-[var(--ide-text-secondary)]">Tables</p>
                            <p className="text-[var(--ide-text)]">{db.tables}</p>
                          </div>
                        )}
                        {db.size && (
                          <div>
                            <p className="text-sm text-[var(--ide-text-secondary)]">Size</p>
                            <p className="text-[var(--ide-text)]">{db.size}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="deployment" className="space-y-6">
              <Card className="bg-background/50 border-blue-500/20">
                <CardHeader>
                  <CardTitle className="text-blue-300 flex items-center space-x-2">
                    <Globe className="h-5 w-5" />
                    <span>Deployment Management</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-[var(--ide-text)]">Development</h3>
                      <div className="space-y-2">
                        <p className="text-[var(--ide-text-secondary)]">Local Environment</p>
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 rounded-full bg-green-500" />
                          <span className="text-[var(--ide-text)]">Running on localhost:3000</span>
                        </div>
                        <Button className="w-full bg-blue-600 hover:bg-blue-700">
                          <Zap className="h-4 w-4 mr-2" />
                          Hot Reload Active
                        </Button>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-[var(--ide-text)]">Production</h3>
                      <div className="space-y-2">
                        <p className="text-[var(--ide-text-secondary)]">Replit Deployment</p>
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 rounded-full bg-orange-500" />
                          <span className="text-[var(--ide-text)]">Not deployed</span>
                        </div>
                        <Button variant="outline" className="w-full border-green-500 text-green-400 hover:bg-green-500/20">
                          <Globe className="h-4 w-4 mr-2" />
                          Deploy to Production
                        </Button>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-[var(--ide-text)]">Environment Variables</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <p className="text-sm text-[var(--ide-text-secondary)]">Development</p>
                        <div className="bg-background/80 p-3 rounded border font-mono text-sm">
                          NODE_ENV=development<br />
                          PORT=3000<br />
                          DATABASE_URL=***<br />
                          VITE_APP_TITLE=DeepBlue:Octopus
                        </div>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm text-[var(--ide-text-secondary)]">Production</p>
                        <div className="bg-background/80 p-3 rounded border font-mono text-sm">
                          NODE_ENV=production<br />
                          PORT=443<br />
                          DATABASE_URL=***<br />
                          SSL_ENABLED=true
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="logs" className="space-y-6">
              <Card className="bg-background/50 border-blue-500/20">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-blue-300 flex items-center space-x-2">
                      <FileText className="h-5 w-5" />
                      <span>System Logs</span>
                    </CardTitle>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline">
                        Clear Logs
                      </Button>
                      <Button size="sm" variant="outline">
                        Export Logs
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96 w-full">
                    <div className="space-y-1 font-mono text-sm">
                      {logs.map((log, index) => (
                        <div key={index} className="p-2 hover:bg-background/50 rounded">
                          <span className={`
                            ${log.includes('[ERROR]') ? 'text-red-400' : ''}
                            ${log.includes('[WARN]') ? 'text-orange-400' : ''}
                            ${log.includes('[INFO]') ? 'text-blue-400' : ''}
                            ${!log.includes('[') ? 'text-[var(--ide-text)]' : ''}
                          `}>
                            {log}
                          </span>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}