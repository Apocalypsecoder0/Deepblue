import { Save, FolderOpen, FilePlus, Undo, Redo, Play, Settings, Palette } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useIDEState } from "@/hooks/use-ide-state";

export default function Toolbar() {
  const { createNewFile, saveCurrentFile, runCurrentFile } = useIDEState();

  return (
    <div className="ide-sidebar border-b ide-border h-12 flex items-center justify-between px-4">
      <div className="flex items-center space-x-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={createNewFile}
          className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
          title="New File"
        >
          <FilePlus className="h-4 w-4" />
        </Button>
        
        <Button
          variant="ghost"
          size="sm"
          className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
          title="Open Folder"
        >
          <FolderOpen className="h-4 w-4" />
        </Button>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={saveCurrentFile}
          className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
          title="Save"
        >
          <Save className="h-4 w-4" />
        </Button>
        
        <Separator orientation="vertical" className="h-6 bg-[var(--ide-border)]" />
        
        <Button
          variant="ghost"
          size="sm"
          className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
          title="Undo"
        >
          <Undo className="h-4 w-4" />
        </Button>
        
        <Button
          variant="ghost"
          size="sm"
          className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
          title="Redo"
        >
          <Redo className="h-4 w-4" />
        </Button>
        
        <Separator orientation="vertical" className="h-6 bg-[var(--ide-border)]" />
        
        <Button
          onClick={runCurrentFile}
          className="bg-[var(--ide-success)] text-[var(--ide-bg)] hover:bg-green-400 px-4 py-2 font-medium"
          title="Run Code"
        >
          <Play className="h-4 w-4 mr-2" />
          Run
        </Button>
      </div>
      
      <div className="flex items-center space-x-3">
        <Button
          variant="ghost"
          size="sm"
          className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
          title="Settings"
        >
          <Settings className="h-4 w-4" />
        </Button>
        
        <Button
          variant="ghost"
          size="sm"
          className="text-[var(--ide-text)] hover:text-white hover:bg-[var(--ide-bg)] p-2"
          title="Theme Toggle"
        >
          <Palette className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
