import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { 
  FolderOpen, 
  File, 
  Search, 
  Clock, 
  Bookmark,
  Upload,
  Download,
  MoreHorizontal,
  Filter,
  Grid,
  List,
  ArrowUpDown,
  Zap,
  Copy,
  Trash2,
  Edit,
  Eye,
  Star,
  RefreshCw,
  Archive,
  FileText,
  Image,
  Play,
  Code,
  Database,
  Settings,
  GitBranch,
  FolderPlus,
  FilePlus,
  Share,
  Lock,
  Unlock,
  ChevronDown,
  ChevronRight
} from "lucide-react";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

interface EnhancedFileExplorerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FileItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  path: string;
  size?: number;
  modified: Date;
  isBookmarked: boolean;
  isReadonly: boolean;
  language?: string;
  parentId?: string;
  isExpanded?: boolean;
  children?: FileItem[];
}

interface RecentFile {
  id: string;
  name: string;
  path: string;
  lastOpened: Date;
  type: string;
}

interface BookmarkedFile {
  id: string;
  name: string;
  path: string;
  type: string;
  bookmarkedAt: Date;
}

export default function EnhancedFileExplorer({ isOpen, onClose }: EnhancedFileExplorerProps) {
  const [files, setFiles] = useState<FileItem[]>([
    {
      id: '1',
      name: 'src',
      type: 'folder',
      path: '/src',
      modified: new Date(),
      isBookmarked: false,
      isReadonly: false,
      isExpanded: true,
      children: [
        {
          id: '1-1',
          name: 'components',
          type: 'folder',
          path: '/src/components',
          modified: new Date(),
          isBookmarked: false,
          isReadonly: false,
          parentId: '1',
          isExpanded: false,
          children: [
            {
              id: '1-1-1',
              name: 'Button.tsx',
              type: 'file',
              path: '/src/components/Button.tsx',
              size: 1024,
              modified: new Date(Date.now() - 1000 * 60 * 30),
              isBookmarked: true,
              isReadonly: false,
              language: 'typescript',
              parentId: '1-1'
            }
          ]
        },
        {
          id: '1-2',
          name: 'main.tsx',
          type: 'file',
          path: '/src/main.tsx',
          size: 2048,
          modified: new Date(Date.now() - 1000 * 60 * 10),
          isBookmarked: false,
          isReadonly: false,
          language: 'typescript',
          parentId: '1'
        }
      ]
    },
    {
      id: '2',
      name: 'public',
      type: 'folder',
      path: '/public',
      modified: new Date(Date.now() - 1000 * 60 * 60),
      isBookmarked: false,
      isReadonly: false,
      isExpanded: false,
      children: [
        {
          id: '2-1',
          name: 'index.html',
          type: 'file',
          path: '/public/index.html',
          size: 512,
          modified: new Date(Date.now() - 1000 * 60 * 60),
          isBookmarked: false,
          isReadonly: false,
          language: 'html',
          parentId: '2'
        }
      ]
    },
    {
      id: '3',
      name: 'README.md',
      type: 'file',
      path: '/README.md',
      size: 1536,
      modified: new Date(Date.now() - 1000 * 60 * 20),
      isBookmarked: true,
      isReadonly: false,
      language: 'markdown'
    }
  ]);

  const [recentFiles, setRecentFiles] = useState<RecentFile[]>([
    {
      id: '1-2',
      name: 'main.tsx',
      path: '/src/main.tsx',
      lastOpened: new Date(Date.now() - 1000 * 60 * 5),
      type: 'typescript'
    },
    {
      id: '1-1-1',
      name: 'Button.tsx',
      path: '/src/components/Button.tsx',
      lastOpened: new Date(Date.now() - 1000 * 60 * 15),
      type: 'typescript'
    },
    {
      id: '3',
      name: 'README.md',
      path: '/README.md',
      lastOpened: new Date(Date.now() - 1000 * 60 * 25),
      type: 'markdown'
    }
  ]);

  const [bookmarkedFiles, setBookmarkedFiles] = useState<BookmarkedFile[]>([
    {
      id: '1-1-1',
      name: 'Button.tsx',
      path: '/src/components/Button.tsx',
      type: 'typescript',
      bookmarkedAt: new Date(Date.now() - 1000 * 60 * 60 * 2)
    },
    {
      id: '3',
      name: 'README.md',
      path: '/README.md',
      type: 'markdown',
      bookmarkedAt: new Date(Date.now() - 1000 * 60 * 60 * 24)
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [sortBy, setSortBy] = useState<'name' | 'modified' | 'size' | 'type'>('name');
  const [filterType, setFilterType] = useState<'all' | 'files' | 'folders'>('all');
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [currentPath, setCurrentPath] = useState('/');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getFileIcon = (item: FileItem) => {
    if (item.type === 'folder') {
      return <FolderOpen className="w-4 h-4 text-blue-400" />;
    }
    
    switch (item.language) {
      case 'typescript':
      case 'javascript':
        return <Code className="w-4 h-4 text-yellow-400" />;
      case 'html':
      case 'css':
        return <FileText className="w-4 h-4 text-green-400" />;
      case 'markdown':
        return <FileText className="w-4 h-4 text-purple-400" />;
      case 'json':
        return <Database className="w-4 h-4 text-orange-400" />;
      default:
        return <File className="w-4 h-4 text-gray-400" />;
    }
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return '';
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${Math.round(bytes / Math.pow(1024, i) * 100) / 100} ${sizes[i]}`;
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const toggleFileExpansion = (fileId: string) => {
    setFiles(prev => prev.map(file => 
      file.id === fileId ? { ...file, isExpanded: !file.isExpanded } : file
    ));
  };

  const toggleBookmark = (fileId: string) => {
    setFiles(prev => prev.map(file => 
      file.id === fileId ? { ...file, isBookmarked: !file.isBookmarked } : file
    ));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    setIsUploading(true);
    
    // Simulate upload process
    setTimeout(() => {
      setIsUploading(false);
      console.log('Files uploaded:', Array.from(files).map(f => f.name));
    }, 2000);
  };

  const handleFileSelection = (fileId: string, isMultiSelect: boolean) => {
    if (isMultiSelect) {
      setSelectedFiles(prev => 
        prev.includes(fileId) 
          ? prev.filter(id => id !== fileId)
          : [...prev, fileId]
      );
    } else {
      setSelectedFiles([fileId]);
    }
  };

  const createNewFile = () => {
    const newFile: FileItem = {
      id: Date.now().toString(),
      name: 'untitled.txt',
      type: 'file',
      path: `${currentPath}/untitled.txt`,
      size: 0,
      modified: new Date(),
      isBookmarked: false,
      isReadonly: false,
      language: 'plaintext'
    };
    setFiles(prev => [...prev, newFile]);
  };

  const createNewFolder = () => {
    const newFolder: FileItem = {
      id: Date.now().toString(),
      name: 'New Folder',
      type: 'folder',
      path: `${currentPath}/New Folder`,
      modified: new Date(),
      isBookmarked: false,
      isReadonly: false,
      isExpanded: false,
      children: []
    };
    setFiles(prev => [...prev, newFolder]);
  };

  const deleteSelectedFiles = () => {
    setFiles(prev => prev.filter(file => !selectedFiles.includes(file.id)));
    setSelectedFiles([]);
  };

  const renderFileItem = (item: FileItem, depth = 0) => {
    const isSelected = selectedFiles.includes(item.id);
    
    return (
      <div key={item.id} className="space-y-1">
        <div 
          className={`flex items-center gap-2 p-2 rounded cursor-pointer transition-colors ${
            isSelected ? 'bg-blue-600/20' : 'hover:bg-gray-700/50'
          }`}
          style={{ paddingLeft: `${depth * 20 + 8}px` }}
          onClick={(e) => handleFileSelection(item.id, e.ctrlKey || e.metaKey)}
        >
          {item.type === 'folder' && (
            <Button
              variant="ghost"
              size="sm"
              className="p-0 h-4 w-4"
              onClick={(e) => {
                e.stopPropagation();
                toggleFileExpansion(item.id);
              }}
            >
              {item.isExpanded ? (
                <ChevronDown className="w-3 h-3" />
              ) : (
                <ChevronRight className="w-3 h-3" />
              )}
            </Button>
          )}
          
          {getFileIcon(item)}
          
          <span className="flex-1 text-sm text-white truncate">
            {item.name}
          </span>
          
          {item.isBookmarked && (
            <Star className="w-3 h-3 text-yellow-400 fill-current" />
          )}
          
          {item.isReadonly && (
            <Lock className="w-3 h-3 text-gray-400" />
          )}
          
          <div className="flex items-center gap-1 text-xs text-gray-400">
            {item.size && <span>{formatFileSize(item.size)}</span>}
            <span>{formatTimeAgo(item.modified)}</span>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="p-0 h-6 w-6">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Eye className="w-4 h-4 mr-2" />
                Open
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Edit className="w-4 h-4 mr-2" />
                Rename
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => toggleBookmark(item.id)}>
                <Star className="w-4 h-4 mr-2" />
                {item.isBookmarked ? 'Remove Bookmark' : 'Add Bookmark'}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Copy className="w-4 h-4 mr-2" />
                Copy
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Share className="w-4 h-4 mr-2" />
                Share
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-400">
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        {item.type === 'folder' && item.isExpanded && item.children && (
          <div>
            {item.children.map(child => renderFileItem(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-900 border border-gray-700 rounded-lg w-[95vw] h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <FolderOpen className="w-6 h-6 text-blue-400" />
            <div>
              <h2 className="text-lg font-semibold text-white">Enhanced File Explorer</h2>
              <p className="text-sm text-gray-400">Advanced file management with professional tools</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant="secondary">{files.length} items</Badge>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onClose}
              className="text-gray-400 hover:text-white"
            >
              ✕
            </Button>
          </div>
        </div>

        {/* Toolbar */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <div className="flex items-center gap-2">
            <Button onClick={createNewFile} size="sm">
              <FilePlus className="w-4 h-4 mr-1" />
              New File
            </Button>
            <Button onClick={createNewFolder} size="sm" variant="outline">
              <FolderPlus className="w-4 h-4 mr-1" />
              New Folder
            </Button>
            <Button
              onClick={() => fileInputRef.current?.click()}
              size="sm"
              variant="outline"
              disabled={isUploading}
            >
              <Upload className="w-4 h-4 mr-1" />
              {isUploading ? 'Uploading...' : 'Upload'}
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              className="hidden"
              onChange={handleFileUpload}
            />
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('list')}
            >
              <List className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('grid')}
            >
              <Grid className="w-4 h-4" />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <ArrowUpDown className="w-4 h-4 mr-1" />
                  Sort
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => setSortBy('name')}>
                  Sort by Name
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy('modified')}>
                  Sort by Modified
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy('size')}>
                  Sort by Size
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setSortBy('type')}>
                  Sort by Type
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Filter className="w-4 h-4 mr-1" />
                  Filter
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => setFilterType('all')}>
                  Show All
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterType('files')}>
                  Files Only
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterType('folders')}>
                  Folders Only
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {selectedFiles.length > 0 && (
          <div className="flex items-center justify-between p-2 bg-blue-600/10 border-b border-gray-700">
            <span className="text-sm text-blue-400">
              {selectedFiles.length} items selected
            </span>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline">
                <Download className="w-4 h-4 mr-1" />
                Download
              </Button>
              <Button size="sm" variant="outline">
                <Archive className="w-4 h-4 mr-1" />
                Archive
              </Button>
              <Button size="sm" variant="destructive" onClick={deleteSelectedFiles}>
                <Trash2 className="w-4 h-4 mr-1" />
                Delete
              </Button>
            </div>
          </div>
        )}

        {/* Main Content */}
        <div className="flex-1 flex">
          <div className="flex-1">
            <Tabs defaultValue="explorer" className="h-full flex flex-col">
              <TabsList className="grid w-full grid-cols-6">
                <TabsTrigger value="explorer">Explorer</TabsTrigger>
                <TabsTrigger value="search">Search</TabsTrigger>
                <TabsTrigger value="recent">Recent</TabsTrigger>
                <TabsTrigger value="bookmarks">Bookmarks</TabsTrigger>
                <TabsTrigger value="operations">Operations</TabsTrigger>
                <TabsTrigger value="compare">Compare</TabsTrigger>
              </TabsList>
              
              <TabsContent value="explorer" className="flex-1 p-0">
                <div className="p-4">
                  <div className="flex items-center gap-2 mb-4">
                    <Input
                      placeholder="Search files and folders..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="flex-1"
                    />
                    <Button size="sm">
                      <Search className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                <ScrollArea className="flex-1 px-4">
                  <div className="space-y-1">
                    {files.map(file => renderFileItem(file))}
                  </div>
                </ScrollArea>
              </TabsContent>
              
              <TabsContent value="search" className="flex-1 p-4">
                <div className="space-y-4">
                  <div className="flex gap-2">
                    <Input placeholder="Search content..." className="flex-1" />
                    <Input placeholder="File types (*.js, *.tsx)" className="w-48" />
                    <Button>
                      <Search className="w-4 h-4 mr-1" />
                      Search
                    </Button>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="text-sm text-gray-400">
                      Search results will appear here...
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="recent" className="flex-1 p-4">
                <ScrollArea className="h-full">
                  <div className="space-y-3">
                    {recentFiles.map((file) => (
                      <Card key={file.id} className="p-3 bg-gray-800 border-gray-700">
                        <div className="flex items-center gap-3">
                          {getFileIcon({ type: 'file', language: file.type } as FileItem)}
                          <div className="flex-1">
                            <h4 className="text-sm font-medium text-white">{file.name}</h4>
                            <p className="text-xs text-gray-400">{file.path}</p>
                          </div>
                          <div className="text-xs text-gray-400">
                            {formatTimeAgo(file.lastOpened)}
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
              
              <TabsContent value="bookmarks" className="flex-1 p-4">
                <ScrollArea className="h-full">
                  <div className="space-y-3">
                    {bookmarkedFiles.map((file) => (
                      <Card key={file.id} className="p-3 bg-gray-800 border-gray-700">
                        <div className="flex items-center gap-3">
                          <Star className="w-4 h-4 text-yellow-400 fill-current" />
                          {getFileIcon({ type: 'file', language: file.type } as FileItem)}
                          <div className="flex-1">
                            <h4 className="text-sm font-medium text-white">{file.name}</h4>
                            <p className="text-xs text-gray-400">{file.path}</p>
                          </div>
                          <div className="text-xs text-gray-400">
                            Bookmarked {formatTimeAgo(file.bookmarkedAt)}
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
              
              <TabsContent value="operations" className="flex-1 p-4">
                <div className="grid grid-cols-2 gap-4">
                  <Card className="p-4 bg-gray-800 border-gray-700">
                    <h3 className="text-sm font-semibold text-white mb-3">File Operations</h3>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full justify-start">
                        <Copy className="w-4 h-4 mr-2" />
                        Bulk Copy
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <Archive className="w-4 h-4 mr-2" />
                        Create Archive
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Sync Files
                      </Button>
                    </div>
                  </Card>
                  
                  <Card className="p-4 bg-gray-800 border-gray-700">
                    <h3 className="text-sm font-semibold text-white mb-3">Advanced Tools</h3>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full justify-start">
                        <Zap className="w-4 h-4 mr-2" />
                        Quick Actions
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <GitBranch className="w-4 h-4 mr-2" />
                        Git Operations
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <Settings className="w-4 h-4 mr-2" />
                        File Properties
                      </Button>
                    </div>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="compare" className="flex-1 p-4">
                <div className="space-y-4">
                  <div className="text-sm text-gray-400">
                    Select two files to compare their contents...
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="p-4 bg-gray-800 border-gray-700">
                      <h3 className="text-sm font-semibold text-white mb-2">File 1</h3>
                      <div className="text-xs text-gray-400">
                        No file selected
                      </div>
                    </Card>
                    
                    <Card className="p-4 bg-gray-800 border-gray-700">
                      <h3 className="text-sm font-semibold text-white mb-2">File 2</h3>
                      <div className="text-xs text-gray-400">
                        No file selected
                      </div>
                    </Card>
                  </div>
                  
                  <Button disabled>
                    <Eye className="w-4 h-4 mr-2" />
                    Compare Files
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}