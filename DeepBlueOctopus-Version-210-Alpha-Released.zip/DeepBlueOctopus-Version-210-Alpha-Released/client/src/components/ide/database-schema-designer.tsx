import React, { useState, useRef, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Database, Table, Key, Link, Plus, Trash2, Eye,
  Download, Upload, Save, Play, Settings, 
  FileText, GitBranch, CheckCircle2, AlertCircle,
  BarChart3, TrendingUp, Zap, Search, Filter
} from "lucide-react";

interface DatabaseSchemaDesignerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Column {
  id: string;
  name: string;
  type: string;
  nullable: boolean;
  primaryKey: boolean;
  unique: boolean;
  defaultValue?: string;
  length?: number;
  precision?: number;
  scale?: number;
}

interface Relationship {
  id: string;
  type: 'one-to-one' | 'one-to-many' | 'many-to-many';
  fromTable: string;
  fromColumn: string;
  toTable: string;
  toColumn: string;
  onDelete: 'cascade' | 'restrict' | 'set-null';
  onUpdate: 'cascade' | 'restrict' | 'set-null';
}

interface Table {
  id: string;
  name: string;
  schema: string;
  columns: Column[];
  indexes: Index[];
  position: { x: number; y: number };
  description?: string;
}

interface Index {
  id: string;
  name: string;
  columns: string[];
  unique: boolean;
  type: 'btree' | 'hash' | 'gin' | 'gist';
}

interface Migration {
  id: string;
  version: string;
  description: string;
  sql: string;
  applied: boolean;
  appliedAt?: Date;
  rollbackSql?: string;
}

export default function DatabaseSchemaDesigner({ isOpen, onClose }: DatabaseSchemaDesignerProps) {
  const [activeTab, setActiveTab] = useState("designer");
  const [selectedTable, setSelectedTable] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDatabase, setSelectedDatabase] = useState("postgresql");

  const [tables, setTables] = useState<Table[]>([
    {
      id: "users",
      name: "users",
      schema: "public",
      position: { x: 100, y: 100 },
      description: "User accounts and authentication",
      columns: [
        {
          id: "id",
          name: "id",
          type: "SERIAL",
          nullable: false,
          primaryKey: true,
          unique: true
        },
        {
          id: "email",
          name: "email",
          type: "VARCHAR",
          length: 255,
          nullable: false,
          primaryKey: false,
          unique: true
        },
        {
          id: "password_hash",
          name: "password_hash",
          type: "VARCHAR",
          length: 255,
          nullable: false,
          primaryKey: false,
          unique: false
        },
        {
          id: "created_at",
          name: "created_at",
          type: "TIMESTAMP",
          nullable: false,
          primaryKey: false,
          unique: false,
          defaultValue: "CURRENT_TIMESTAMP"
        }
      ],
      indexes: [
        {
          id: "idx_users_email",
          name: "idx_users_email",
          columns: ["email"],
          unique: true,
          type: "btree"
        }
      ]
    },
    {
      id: "projects",
      name: "projects",
      schema: "public",
      position: { x: 400, y: 100 },
      description: "User projects and workspaces",
      columns: [
        {
          id: "id",
          name: "id",
          type: "SERIAL",
          nullable: false,
          primaryKey: true,
          unique: true
        },
        {
          id: "user_id",
          name: "user_id",
          type: "INTEGER",
          nullable: false,
          primaryKey: false,
          unique: false
        },
        {
          id: "name",
          name: "name",
          type: "VARCHAR",
          length: 255,
          nullable: false,
          primaryKey: false,
          unique: false
        },
        {
          id: "description",
          name: "description",
          type: "TEXT",
          nullable: true,
          primaryKey: false,
          unique: false
        }
      ],
      indexes: []
    }
  ]);

  const [relationships, setRelationships] = useState<Relationship[]>([
    {
      id: "users_projects",
      type: "one-to-many",
      fromTable: "users",
      fromColumn: "id",
      toTable: "projects",
      toColumn: "user_id",
      onDelete: "cascade",
      onUpdate: "cascade"
    }
  ]);

  const [migrations, setMigrations] = useState<Migration[]>([
    {
      id: "001",
      version: "001_initial_schema",
      description: "Create initial user and project tables",
      sql: `CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE projects (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  description TEXT
);`,
      applied: true,
      appliedAt: new Date(Date.now() - 86400000)
    },
    {
      id: "002",
      version: "002_add_indexes",
      description: "Add performance indexes",
      sql: `CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_projects_user_id ON projects(user_id);`,
      applied: false
    }
  ]);

  const dataTypes = {
    postgresql: [
      "SERIAL", "INTEGER", "BIGINT", "SMALLINT", "DECIMAL", "NUMERIC",
      "REAL", "DOUBLE PRECISION", "VARCHAR", "CHAR", "TEXT", "BOOLEAN",
      "DATE", "TIME", "TIMESTAMP", "TIMESTAMPTZ", "INTERVAL", "UUID",
      "JSON", "JSONB", "ARRAY", "BYTEA"
    ],
    mysql: [
      "INT", "BIGINT", "SMALLINT", "TINYINT", "DECIMAL", "FLOAT", "DOUBLE",
      "VARCHAR", "CHAR", "TEXT", "LONGTEXT", "BOOLEAN", "DATE", "TIME",
      "DATETIME", "TIMESTAMP", "YEAR", "BINARY", "VARBINARY", "BLOB",
      "LONGBLOB", "JSON"
    ],
    sqlite: [
      "INTEGER", "REAL", "TEXT", "BLOB", "NUMERIC", "BOOLEAN", "DATE",
      "DATETIME", "TIME", "TIMESTAMP"
    ]
  };

  const addTable = () => {
    const newTable: Table = {
      id: `table_${Date.now()}`,
      name: "new_table",
      schema: "public",
      position: { x: 200, y: 200 },
      columns: [
        {
          id: "id",
          name: "id",
          type: selectedDatabase === "postgresql" ? "SERIAL" : "INTEGER",
          nullable: false,
          primaryKey: true,
          unique: true
        }
      ],
      indexes: []
    };
    setTables(prev => [...prev, newTable]);
  };

  const addColumn = (tableId: string) => {
    const newColumn: Column = {
      id: `col_${Date.now()}`,
      name: "new_column",
      type: "VARCHAR",
      nullable: true,
      primaryKey: false,
      unique: false,
      length: 255
    };

    setTables(prev => prev.map(table => 
      table.id === tableId 
        ? { ...table, columns: [...table.columns, newColumn] }
        : table
    ));
  };

  const updateColumn = (tableId: string, columnId: string, updates: Partial<Column>) => {
    setTables(prev => prev.map(table => 
      table.id === tableId 
        ? {
            ...table,
            columns: table.columns.map(col => 
              col.id === columnId ? { ...col, ...updates } : col
            )
          }
        : table
    ));
  };

  const deleteColumn = (tableId: string, columnId: string) => {
    setTables(prev => prev.map(table => 
      table.id === tableId 
        ? { ...table, columns: table.columns.filter(col => col.id !== columnId) }
        : table
    ));
  };

  const generateSQL = () => {
    let sql = "";
    
    // Create tables
    tables.forEach(table => {
      sql += `CREATE TABLE ${table.name} (\n`;
      
      const columnDefs = table.columns.map(col => {
        let def = `  ${col.name} ${col.type}`;
        if (col.length && (col.type === "VARCHAR" || col.type === "CHAR")) {
          def += `(${col.length})`;
        }
        if (col.precision && col.scale) {
          def += `(${col.precision},${col.scale})`;
        }
        if (!col.nullable) def += " NOT NULL";
        if (col.primaryKey) def += " PRIMARY KEY";
        if (col.unique && !col.primaryKey) def += " UNIQUE";
        if (col.defaultValue) def += ` DEFAULT ${col.defaultValue}`;
        return def;
      });
      
      sql += columnDefs.join(",\n") + "\n);\n\n";
      
      // Add indexes
      table.indexes.forEach(index => {
        const uniqueKeyword = index.unique ? "UNIQUE " : "";
        sql += `CREATE ${uniqueKeyword}INDEX ${index.name} ON ${table.name} (${index.columns.join(", ")});\n`;
      });
      
      if (table.indexes.length > 0) sql += "\n";
    });
    
    // Add foreign key constraints
    relationships.forEach(rel => {
      sql += `ALTER TABLE ${rel.toTable} ADD CONSTRAINT fk_${rel.fromTable}_${rel.toTable} `;
      sql += `FOREIGN KEY (${rel.toColumn}) REFERENCES ${rel.fromTable}(${rel.fromColumn})`;
      sql += ` ON DELETE ${rel.onDelete.toUpperCase().replace('-', ' ')}`;
      sql += ` ON UPDATE ${rel.onUpdate.toUpperCase().replace('-', ' ')};\n`;
    });
    
    return sql;
  };

  const applyMigration = (migrationId: string) => {
    setMigrations(prev => prev.map(migration => 
      migration.id === migrationId 
        ? { ...migration, applied: true, appliedAt: new Date() }
        : migration
    ));
  };

  const createMigration = () => {
    const sql = generateSQL();
    const newMigration: Migration = {
      id: `${String(migrations.length + 1).padStart(3, '0')}`,
      version: `${String(migrations.length + 1).padStart(3, '0')}_new_migration`,
      description: "Auto-generated migration",
      sql,
      applied: false
    };
    setMigrations(prev => [...prev, newMigration]);
  };

  const selectedTableData = selectedTable ? tables.find(t => t.id === selectedTable) : null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Database className="h-5 w-5 text-blue-500" />
            Database Schema Designer
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-5 flex-shrink-0">
            <TabsTrigger value="designer" className="flex items-center gap-2">
              <Table className="h-4 w-4" />
              Designer
            </TabsTrigger>
            <TabsTrigger value="tables" className="flex items-center gap-2">
              <Database className="h-4 w-4" />
              Tables
            </TabsTrigger>
            <TabsTrigger value="relationships" className="flex items-center gap-2">
              <Link className="h-4 w-4" />
              Relations
            </TabsTrigger>
            <TabsTrigger value="migrations" className="flex items-center gap-2">
              <GitBranch className="h-4 w-4" />
              Migrations
            </TabsTrigger>
            <TabsTrigger value="sql" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              SQL
            </TabsTrigger>
          </TabsList>

          <TabsContent value="designer" className="flex-1 overflow-hidden flex flex-col">
            <div className="flex items-center gap-4 mb-4 flex-shrink-0">
              <Button onClick={addTable} size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Table
              </Button>
              
              <Select value={selectedDatabase} onValueChange={setSelectedDatabase}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="postgresql">PostgreSQL</SelectItem>
                  <SelectItem value="mysql">MySQL</SelectItem>
                  <SelectItem value="sqlite">SQLite</SelectItem>
                </SelectContent>
              </Select>

              <Separator orientation="vertical" className="h-6" />

              <Button size="sm" variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button size="sm" variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                Import
              </Button>
              <Button size="sm" variant="outline">
                <Save className="h-4 w-4 mr-2" />
                Save
              </Button>
            </div>

            <div className="flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-3 gap-4">
              <div className="lg:col-span-2 bg-gray-50 dark:bg-gray-900 rounded-lg border relative overflow-auto">
                <div className="absolute inset-0 p-4">
                  {/* Visual Schema Designer */}
                  <div className="space-y-4">
                    {tables.map((table) => (
                      <Card 
                        key={table.id} 
                        className={`cursor-pointer transition-all ${
                          selectedTable === table.id ? 'ring-2 ring-blue-500' : ''
                        }`}
                        onClick={() => setSelectedTable(table.id)}
                        style={{
                          position: 'absolute',
                          left: table.position.x,
                          top: table.position.y,
                          minWidth: '250px'
                        }}
                      >
                        <CardHeader className="pb-2">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-sm flex items-center gap-2">
                              <Table className="h-4 w-4" />
                              {table.name}
                            </CardTitle>
                            <Badge variant="outline" className="text-xs">
                              {table.columns.length} cols
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <div className="space-y-1">
                            {table.columns.slice(0, 5).map((column) => (
                              <div key={column.id} className="flex items-center gap-2 text-xs">
                                {column.primaryKey && <Key className="h-3 w-3 text-yellow-500" />}
                                <span className="font-mono">{column.name}</span>
                                <span className="text-muted-foreground">{column.type}</span>
                                {!column.nullable && <span className="text-red-500">*</span>}
                              </div>
                            ))}
                            {table.columns.length > 5 && (
                              <div className="text-xs text-muted-foreground">
                                +{table.columns.length - 5} more columns
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </div>

              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <CardTitle className="text-base">
                    {selectedTableData ? `Edit ${selectedTableData.name}` : 'Select a Table'}
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden">
                  {selectedTableData ? (
                    <ScrollArea className="h-full">
                      <div className="space-y-4">
                        <div>
                          <Label>Table Name</Label>
                          <Input 
                            value={selectedTableData.name}
                            onChange={(e) => {
                              setTables(prev => prev.map(table => 
                                table.id === selectedTable 
                                  ? { ...table, name: e.target.value }
                                  : table
                              ));
                            }}
                            className="mt-1"
                          />
                        </div>

                        <div>
                          <Label>Description</Label>
                          <Textarea 
                            value={selectedTableData.description || ''}
                            onChange={(e) => {
                              setTables(prev => prev.map(table => 
                                table.id === selectedTable 
                                  ? { ...table, description: e.target.value }
                                  : table
                              ));
                            }}
                            className="mt-1"
                            rows={3}
                          />
                        </div>

                        <Separator />

                        <div>
                          <div className="flex items-center justify-between mb-3">
                            <Label>Columns</Label>
                            <Button 
                              size="sm" 
                              onClick={() => addColumn(selectedTable!)}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                          
                          <div className="space-y-3">
                            {selectedTableData.columns.map((column) => (
                              <Card key={column.id} className="p-3">
                                <div className="space-y-2">
                                  <div className="flex items-center gap-2">
                                    <Input 
                                      value={column.name}
                                      onChange={(e) => updateColumn(selectedTable!, column.id, { name: e.target.value })}
                                      placeholder="Column name"
                                      className="flex-1"
                                    />
                                    <Button 
                                      size="sm" 
                                      variant="outline"
                                      onClick={() => deleteColumn(selectedTable!, column.id)}
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </div>
                                  
                                  <div className="grid grid-cols-2 gap-2">
                                    <Select 
                                      value={column.type} 
                                      onValueChange={(value) => updateColumn(selectedTable!, column.id, { type: value })}
                                    >
                                      <SelectTrigger>
                                        <SelectValue />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {dataTypes[selectedDatabase as keyof typeof dataTypes].map(type => (
                                          <SelectItem key={type} value={type}>{type}</SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                    
                                    {(column.type === "VARCHAR" || column.type === "CHAR") && (
                                      <Input 
                                        type="number"
                                        value={column.length || ''}
                                        onChange={(e) => updateColumn(selectedTable!, column.id, { length: parseInt(e.target.value) })}
                                        placeholder="Length"
                                      />
                                    )}
                                  </div>
                                  
                                  <div className="flex items-center gap-4 text-sm">
                                    <label className="flex items-center gap-1">
                                      <input 
                                        type="checkbox" 
                                        checked={column.primaryKey}
                                        onChange={(e) => updateColumn(selectedTable!, column.id, { primaryKey: e.target.checked })}
                                      />
                                      PK
                                    </label>
                                    <label className="flex items-center gap-1">
                                      <input 
                                        type="checkbox" 
                                        checked={!column.nullable}
                                        onChange={(e) => updateColumn(selectedTable!, column.id, { nullable: !e.target.checked })}
                                      />
                                      Not Null
                                    </label>
                                    <label className="flex items-center gap-1">
                                      <input 
                                        type="checkbox" 
                                        checked={column.unique}
                                        onChange={(e) => updateColumn(selectedTable!, column.id, { unique: e.target.checked })}
                                      />
                                      Unique
                                    </label>
                                  </div>
                                </div>
                              </Card>
                            ))}
                          </div>
                        </div>
                      </div>
                    </ScrollArea>
                  ) : (
                    <div className="flex items-center justify-center h-full text-muted-foreground">
                      <div className="text-center">
                        <Table className="h-12 w-12 mx-auto mb-4 opacity-50" />
                        <p>Select a table to edit its properties</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="tables" className="flex-1 overflow-hidden">
            <ScrollArea className="flex-1">
              <div className="space-y-4">
                {tables.map((table) => (
                  <Card key={table.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base">{table.name}</CardTitle>
                        <Badge variant="outline">
                          {table.columns.length} columns
                        </Badge>
                      </div>
                      {table.description && (
                        <CardDescription>{table.description}</CardDescription>
                      )}
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b">
                              <th className="text-left p-2">Column</th>
                              <th className="text-left p-2">Type</th>
                              <th className="text-left p-2">Constraints</th>
                            </tr>
                          </thead>
                          <tbody>
                            {table.columns.map((column) => (
                              <tr key={column.id} className="border-b">
                                <td className="p-2 font-mono">{column.name}</td>
                                <td className="p-2">{column.type}{column.length ? `(${column.length})` : ''}</td>
                                <td className="p-2">
                                  <div className="flex gap-1">
                                    {column.primaryKey && <Badge variant="outline" className="text-xs">PK</Badge>}
                                    {column.unique && <Badge variant="outline" className="text-xs">UNIQUE</Badge>}
                                    {!column.nullable && <Badge variant="outline" className="text-xs">NOT NULL</Badge>}
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="relationships" className="flex-1 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Table Relationships</h3>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Relationship
              </Button>
            </div>

            <ScrollArea className="flex-1">
              <div className="space-y-4">
                {relationships.map((relationship) => (
                  <Card key={relationship.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="text-sm">
                            <span className="font-mono">{relationship.fromTable}.{relationship.fromColumn}</span>
                            <span className="mx-2">→</span>
                            <span className="font-mono">{relationship.toTable}.{relationship.toColumn}</span>
                          </div>
                          <Badge variant="outline">{relationship.type}</Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button size="sm" variant="outline">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <div className="mt-2 text-xs text-muted-foreground">
                        On Delete: {relationship.onDelete} | On Update: {relationship.onUpdate}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="migrations" className="flex-1 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Database Migrations</h3>
              <Button size="sm" onClick={createMigration}>
                <Plus className="h-4 w-4 mr-2" />
                Create Migration
              </Button>
            </div>

            <ScrollArea className="flex-1">
              <div className="space-y-3">
                {migrations.map((migration) => (
                  <Card key={migration.id}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-sm">{migration.version}</CardTitle>
                        <div className="flex items-center gap-2">
                          {migration.applied ? (
                            <Badge variant="default" className="flex items-center gap-1">
                              <CheckCircle2 className="h-3 w-3" />
                              Applied
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="flex items-center gap-1">
                              <AlertCircle className="h-3 w-3" />
                              Pending
                            </Badge>
                          )}
                          {!migration.applied && (
                            <Button 
                              size="sm"
                              onClick={() => applyMigration(migration.id)}
                            >
                              <Play className="h-4 w-4 mr-2" />
                              Apply
                            </Button>
                          )}
                        </div>
                      </div>
                      <CardDescription>{migration.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-3 rounded overflow-x-auto">
                        {migration.sql}
                      </pre>
                      {migration.appliedAt && (
                        <div className="mt-2 text-xs text-muted-foreground">
                          Applied: {migration.appliedAt.toLocaleString()}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="sql" className="flex-1 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Generated SQL</h3>
              <div className="flex gap-2">
                <Button size="sm" variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Export SQL
                </Button>
                <Button size="sm">
                  <Play className="h-4 w-4 mr-2" />
                  Execute
                </Button>
              </div>
            </div>

            <Card className="flex-1 overflow-hidden">
              <CardContent className="p-0 h-full">
                <ScrollArea className="h-full">
                  <pre className="p-4 text-sm font-mono">
                    {generateSQL()}
                  </pre>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}