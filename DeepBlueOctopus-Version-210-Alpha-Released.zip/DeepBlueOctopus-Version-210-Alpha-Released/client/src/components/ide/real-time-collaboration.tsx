import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Users, 
  MessageSquare, 
  Video, 
  Phone,
  Share,
  Edit,
  Eye,
  Code,
  Send,
  Mic,
  MicOff,
  VideoOff,
  ScreenShare,
  UserPlus
} from "lucide-react";

interface RealTimeCollaborationProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Collaborator {
  id: string;
  name: string;
  email: string;
  avatar: string;
  isOnline: boolean;
  role: 'owner' | 'editor' | 'viewer';
  cursor: { line: number; column: number } | null;
  currentFile: string | null;
  lastActivity: Date;
}

interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  message: string;
  timestamp: Date;
  type: 'text' | 'code' | 'file' | 'system';
}

interface CodeChange {
  id: string;
  userId: string;
  userName: string;
  file: string;
  line: number;
  column: number;
  operation: 'insert' | 'delete' | 'replace';
  content: string;
  timestamp: Date;
}

export default function RealTimeCollaboration({ isOpen, onClose }: RealTimeCollaborationProps) {
  const [collaborators, setCollaborators] = useState<Collaborator[]>([
    {
      id: 'user-1',
      name: 'Alice Johnson',
      email: 'alice@example.com',
      avatar: '/avatars/alice.jpg',
      isOnline: true,
      role: 'owner',
      cursor: { line: 15, column: 24 },
      currentFile: 'src/main.js',
      lastActivity: new Date()
    },
    {
      id: 'user-2', 
      name: 'Bob Smith',
      email: 'bob@example.com',
      avatar: '/avatars/bob.jpg',
      isOnline: true,
      role: 'editor',
      cursor: { line: 8, column: 12 },
      currentFile: 'src/components/App.jsx',
      lastActivity: new Date(Date.now() - 5 * 60 * 1000)
    },
    {
      id: 'user-3',
      name: 'Carol Davis',
      email: 'carol@example.com', 
      avatar: '/avatars/carol.jpg',
      isOnline: false,
      role: 'viewer',
      cursor: null,
      currentFile: null,
      lastActivity: new Date(Date.now() - 30 * 60 * 1000)
    }
  ]);

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-1',
      userId: 'user-2',
      userName: 'Bob Smith',
      message: 'I\'ve finished implementing the login component. Could you review it?',
      timestamp: new Date(Date.now() - 10 * 60 * 1000),
      type: 'text'
    },
    {
      id: 'msg-2',
      userId: 'user-1',
      userName: 'Alice Johnson',
      message: 'Great work! I see you used the new authentication hook. Looks good to me.',
      timestamp: new Date(Date.now() - 8 * 60 * 1000),
      type: 'text'
    },
    {
      id: 'msg-3',
      userId: 'system',
      userName: 'System',
      message: 'Carol Davis joined the session',
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
      type: 'system'
    }
  ]);

  const [codeChanges, setCodeChanges] = useState<CodeChange[]>([
    {
      id: 'change-1',
      userId: 'user-2',
      userName: 'Bob Smith',
      file: 'src/main.js',
      line: 15,
      column: 10,
      operation: 'insert',
      content: 'const newVariable = "hello";',
      timestamp: new Date(Date.now() - 2 * 60 * 1000)
    },
    {
      id: 'change-2',
      userId: 'user-1',
      userName: 'Alice Johnson',
      file: 'src/App.jsx',
      line: 25,
      column: 5,
      operation: 'replace',
      content: 'useState(false)',
      timestamp: new Date(Date.now() - 1 * 60 * 1000)
    }
  ]);

  const [newMessage, setNewMessage] = useState('');
  const [isVideoCallActive, setIsVideoCallActive] = useState(false);
  const [isAudioMuted, setIsAudioMuted] = useState(false);
  const [isVideoMuted, setIsVideoMuted] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');

  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatMessages]);

  const sendMessage = () => {
    if (!newMessage.trim()) return;

    const message: ChatMessage = {
      id: `msg-${Date.now()}`,
      userId: 'current-user',
      userName: 'You',
      message: newMessage,
      timestamp: new Date(),
      type: 'text'
    };

    setChatMessages(prev => [...prev, message]);
    setNewMessage('');

    // Simulate response from collaborator
    setTimeout(() => {
      const responses = [
        "That's a great idea!",
        "I agree with that approach.",
        "Let me check that file.",
        "Sounds good to me.",
        "I'll work on that next."
      ];
      
      const response: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        userId: 'user-2',
        userName: 'Bob Smith',
        message: responses[Math.floor(Math.random() * responses.length)],
        timestamp: new Date(),
        type: 'text'
      };
      
      setChatMessages(prev => [...prev, response]);
    }, 1000 + Math.random() * 2000);
  };

  const sendCodeMessage = (code: string) => {
    const message: ChatMessage = {
      id: `msg-${Date.now()}`,
      userId: 'current-user',
      userName: 'You',
      message: code,
      timestamp: new Date(),
      type: 'code'
    };
    setChatMessages(prev => [...prev, message]);
  };

  const inviteCollaborator = () => {
    if (!inviteEmail.trim()) return;

    const newCollaborator: Collaborator = {
      id: `user-${Date.now()}`,
      name: inviteEmail.split('@')[0],
      email: inviteEmail,
      avatar: '/avatars/default.jpg',
      isOnline: true,
      role: 'editor',
      cursor: null,
      currentFile: null,
      lastActivity: new Date()
    };

    setCollaborators(prev => [...prev, newCollaborator]);
    setInviteEmail('');

    // Add system message
    const systemMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      userId: 'system',
      userName: 'System',
      message: `${newCollaborator.name} has been invited to collaborate`,
      timestamp: new Date(),
      type: 'system'
    };
    setChatMessages(prev => [...prev, systemMessage]);
  };

  const startVideoCall = () => {
    setIsVideoCallActive(true);
    const systemMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      userId: 'system',
      userName: 'System',
      message: 'Video call started',
      timestamp: new Date(),
      type: 'system'
    };
    setChatMessages(prev => [...prev, systemMessage]);
  };

  const endVideoCall = () => {
    setIsVideoCallActive(false);
    setIsAudioMuted(false);
    setIsVideoMuted(false);
    setIsScreenSharing(false);
  };

  const toggleScreenShare = () => {
    setIsScreenSharing(!isScreenSharing);
    const action = isScreenSharing ? 'stopped' : 'started';
    const systemMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      userId: 'system',
      userName: 'System',
      message: `Screen sharing ${action}`,
      timestamp: new Date(),
      type: 'system'
    };
    setChatMessages(prev => [...prev, systemMessage]);
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'owner': return 'text-red-400';
      case 'editor': return 'text-blue-400';
      case 'viewer': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case 'owner': return 'destructive' as const;
      case 'editor': return 'secondary' as const;
      case 'viewer': return 'outline' as const;
      default: return 'outline' as const;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-900 border border-gray-700 rounded-lg w-[95vw] h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <Users className="w-6 h-6 text-blue-400" />
            <div>
              <h2 className="text-lg font-semibold text-white">Real-Time Collaboration</h2>
              <p className="text-sm text-gray-400">Work together with live editing and communication</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant="secondary">{collaborators.filter(c => c.isOnline).length} Online</Badge>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onClose}
              className="text-gray-400 hover:text-white"
            >
              ✕
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex flex-1 overflow-hidden">
          {/* Collaboration Panel */}
          <div className="flex-1 flex flex-col">
            <Tabs defaultValue="collaborators" className="flex-1 flex flex-col">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="collaborators">Collaborators</TabsTrigger>
                <TabsTrigger value="chat">Chat</TabsTrigger>
                <TabsTrigger value="changes">Changes</TabsTrigger>
                <TabsTrigger value="video">Video Call</TabsTrigger>
              </TabsList>
              
              <TabsContent value="collaborators" className="flex-1 p-4">
                <div className="space-y-4">
                  {/* Invite Section */}
                  <Card className="p-4 bg-gray-800 border-gray-700">
                    <h3 className="text-sm font-semibold text-white mb-3">Invite Collaborators</h3>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Enter email address..."
                        value={inviteEmail}
                        onChange={(e) => setInviteEmail(e.target.value)}
                        className="flex-1 bg-gray-700 border-gray-600"
                        onKeyPress={(e) => e.key === 'Enter' && inviteCollaborator()}
                      />
                      <Button onClick={inviteCollaborator} disabled={!inviteEmail.trim()}>
                        <UserPlus className="w-4 h-4 mr-1" />
                        Invite
                      </Button>
                    </div>
                  </Card>

                  {/* Active Collaborators */}
                  <div>
                    <h3 className="text-sm font-semibold text-white mb-3">Active Collaborators</h3>
                    <ScrollArea className="h-96">
                      <div className="space-y-3">
                        {collaborators.map((collaborator) => (
                          <Card key={collaborator.id} className="p-4 bg-gray-800 border-gray-700">
                            <div className="flex items-start gap-3">
                              <div className="relative">
                                <Avatar className="w-10 h-10">
                                  <AvatarImage src={collaborator.avatar} />
                                  <AvatarFallback>{collaborator.name.charAt(0)}</AvatarFallback>
                                </Avatar>
                                {collaborator.isOnline && (
                                  <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-gray-800" />
                                )}
                              </div>
                              
                              <div className="flex-1">
                                <div className="flex items-center justify-between">
                                  <h4 className="text-sm font-medium text-white">{collaborator.name}</h4>
                                  <Badge variant={getRoleBadgeVariant(collaborator.role)} className="text-xs">
                                    {collaborator.role}
                                  </Badge>
                                </div>
                                <p className="text-xs text-gray-400">{collaborator.email}</p>
                                
                                {collaborator.isOnline && collaborator.currentFile && (
                                  <div className="mt-2 flex items-center gap-1 text-xs">
                                    <Edit className="w-3 h-3 text-blue-400" />
                                    <span className="text-gray-400">Editing: {collaborator.currentFile}</span>
                                  </div>
                                )}
                                
                                {collaborator.cursor && (
                                  <div className="mt-1 text-xs text-gray-500">
                                    Cursor: Line {collaborator.cursor.line}, Col {collaborator.cursor.column}
                                  </div>
                                )}
                                
                                <div className="mt-2 text-xs text-gray-500">
                                  Last active: {collaborator.lastActivity.toLocaleTimeString()}
                                </div>
                              </div>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="chat" className="flex-1 flex flex-col">
                {/* Chat Messages */}
                <div 
                  ref={chatContainerRef}
                  className="flex-1 p-4 overflow-y-auto"
                >
                  <div className="space-y-3">
                    {chatMessages.map((message) => (
                      <div key={message.id} className={`flex ${message.userId === 'current-user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[70%] ${message.type === 'system' ? 'w-full text-center' : ''}`}>
                          {message.type === 'system' ? (
                            <div className="text-xs text-gray-500 py-2">
                              {message.message}
                            </div>
                          ) : (
                            <Card className={`p-3 ${
                              message.userId === 'current-user' 
                                ? 'bg-blue-600 border-blue-500' 
                                : 'bg-gray-800 border-gray-700'
                            }`}>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-xs font-medium text-white">{message.userName}</span>
                                <span className="text-xs text-gray-400">{message.timestamp.toLocaleTimeString()}</span>
                              </div>
                              {message.type === 'code' ? (
                                <pre className="text-sm bg-gray-900 p-2 rounded mt-2 overflow-x-auto">
                                  <code className="text-green-400">{message.message}</code>
                                </pre>
                              ) : (
                                <p className="text-sm text-white">{message.message}</p>
                              )}
                            </Card>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Chat Input */}
                <div className="p-4 border-t border-gray-700">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Type a message..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                      className="flex-1 bg-gray-800 border-gray-600"
                    />
                    <Button onClick={sendMessage} disabled={!newMessage.trim()}>
                      <Send className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => sendCodeMessage('const example = "code snippet";')}
                    >
                      <Code className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="changes" className="flex-1 p-4">
                <div>
                  <h3 className="text-sm font-semibold text-white mb-3">Recent Code Changes</h3>
                  <ScrollArea className="h-[500px]">
                    <div className="space-y-3">
                      {codeChanges.map((change) => (
                        <Card key={change.id} className="p-4 bg-gray-800 border-gray-700">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Edit className="w-4 h-4 text-blue-400" />
                              <span className="text-sm font-medium text-white">{change.userName}</span>
                              <Badge variant="outline" className="text-xs">{change.operation}</Badge>
                            </div>
                            <span className="text-xs text-gray-400">{change.timestamp.toLocaleTimeString()}</span>
                          </div>
                          
                          <div className="text-sm text-gray-400 mb-2">
                            {change.file} • Line {change.line}, Column {change.column}
                          </div>
                          
                          <pre className="text-sm bg-gray-900 p-2 rounded overflow-x-auto">
                            <code className="text-green-400">{change.content}</code>
                          </pre>
                        </Card>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              </TabsContent>
              
              <TabsContent value="video" className="flex-1 p-4">
                <div className="space-y-4">
                  {/* Video Call Controls */}
                  <Card className="p-4 bg-gray-800 border-gray-700">
                    <h3 className="text-sm font-semibold text-white mb-3">Video Conference</h3>
                    
                    {!isVideoCallActive ? (
                      <div className="text-center py-8">
                        <Video className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-400 mb-4">Start a video call with your team</p>
                        <Button onClick={startVideoCall} className="gap-2">
                          <Video className="w-4 h-4" />
                          Start Video Call
                        </Button>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {/* Video Grid */}
                        <div className="grid grid-cols-2 gap-4 h-64">
                          <div className="bg-gray-900 rounded-lg flex items-center justify-center">
                            <div className="text-center">
                              <Avatar className="w-16 h-16 mx-auto mb-2">
                                <AvatarFallback>You</AvatarFallback>
                              </Avatar>
                              <p className="text-sm text-gray-400">You</p>
                            </div>
                          </div>
                          <div className="bg-gray-900 rounded-lg flex items-center justify-center">
                            <div className="text-center">
                              <Avatar className="w-16 h-16 mx-auto mb-2">
                                <AvatarFallback>BS</AvatarFallback>
                              </Avatar>
                              <p className="text-sm text-gray-400">Bob Smith</p>
                            </div>
                          </div>
                        </div>
                        
                        {/* Call Controls */}
                        <div className="flex items-center justify-center gap-2">
                          <Button
                            variant={isAudioMuted ? "destructive" : "secondary"}
                            size="sm"
                            onClick={() => setIsAudioMuted(!isAudioMuted)}
                          >
                            {isAudioMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                          </Button>
                          
                          <Button
                            variant={isVideoMuted ? "destructive" : "secondary"}
                            size="sm"
                            onClick={() => setIsVideoMuted(!isVideoMuted)}
                          >
                            {isVideoMuted ? <VideoOff className="w-4 h-4" /> : <Video className="w-4 h-4" />}
                          </Button>
                          
                          <Button
                            variant={isScreenSharing ? "secondary" : "outline"}
                            size="sm"
                            onClick={toggleScreenShare}
                          >
                            <ScreenShare className="w-4 h-4" />
                          </Button>
                          
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={endVideoCall}
                          >
                            <Phone className="w-4 h-4" />
                          </Button>
                        </div>
                        
                        {isScreenSharing && (
                          <div className="bg-blue-900/20 border border-blue-700 rounded-lg p-4 text-center">
                            <ScreenShare className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                            <p className="text-sm text-blue-400">Screen sharing is active</p>
                          </div>
                        )}
                      </div>
                    )}
                  </Card>
                  
                  {/* Participants List */}
                  <div>
                    <h3 className="text-sm font-semibold text-white mb-3">Call Participants</h3>
                    <div className="space-y-2">
                      {collaborators.filter(c => c.isOnline).map((collaborator) => (
                        <Card key={collaborator.id} className="p-3 bg-gray-800 border-gray-700">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <Avatar className="w-8 h-8">
                                <AvatarImage src={collaborator.avatar} />
                                <AvatarFallback>{collaborator.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <span className="text-sm text-white">{collaborator.name}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Mic className="w-4 h-4 text-green-400" />
                              <Video className="w-4 h-4 text-green-400" />
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}