import React, { useState, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { 
  Download, Upload, Settings2, Palette, Zap, Monitor,
  Code2, FileText, PlayCircle, Paintbrush, Eye, 
  Lightbulb, Layers, Brush, Type, Hash, Braces,
  Sun, Moon, Contrast, Smile, Star, Search,
  Check, X, ChevronDown, ChevronRight
} from "lucide-react";

interface SyntaxHighlightingSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Theme {
  id: string;
  name: string;
  type: 'dark' | 'light';
  author: string;
  version: string;
  colors: {
    background: string;
    foreground: string;
    keyword: string;
    string: string;
    comment: string;
    function: string;
    variable: string;
    number: string;
    operator: string;
    bracket: string;
    selection: string;
    cursor: string;
  };
  isBuiltIn: boolean;
  downloads: number;
  rating: number;
}

interface LanguageSupport {
  id: string;
  name: string;
  extensions: string[];
  grammarVersion: string;
  features: string[];
  isEnabled: boolean;
  hasTreeSitter: boolean;
  hasSemanticTokens: boolean;
  lastUpdated: string;
}

interface HighlightingRule {
  id: string;
  name: string;
  pattern: string;
  tokenType: string;
  color: string;
  fontStyle: 'normal' | 'bold' | 'italic' | 'underline';
  isActive: boolean;
  scope: string[];
}

export default function SyntaxHighlightingSystem({ isOpen, onClose }: SyntaxHighlightingSystemProps) {
  const [activeTab, setActiveTab] = useState("themes");
  const [selectedTheme, setSelectedTheme] = useState<Theme | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [enableSyntaxHighlighting, setEnableSyntaxHighlighting] = useState(true);
  const [enableSemanticTokens, setEnableSemanticTokens] = useState(true);
  const [highlightingSpeed, setHighlightingSpeed] = useState([85]);
  const [previewCode, setPreviewCode] = useState(`// Sample code for theme preview
class SyntaxHighlighter {
    constructor(theme) {
        this.theme = theme;
        this.rules = [];
    }
    
    highlight(code, language) {
        // Highlighting logic
        return this.applyTheme(code);
    }
    
    /* Multi-line comment
       with syntax highlighting */
    applyTheme(code) {
        const patterns = {
            keyword: /\\b(class|function|return|if|else)\\b/g,
            string: /"[^"]*"/g,
            number: /\\b\\d+\\b/g
        };
        
        return code.replace(patterns.keyword, match => 
            \`<span class="keyword">\${match}</span>\`
        );
    }
}`);

  const themes: Theme[] = [
    {
      id: "deepblue-dark",
      name: "DeepBlue Dark",
      type: "dark",
      author: "DeepBlue IDE",
      version: "2.1.0",
      colors: {
        background: "#0a1628",
        foreground: "#e0f2fe",
        keyword: "#60a5fa",
        string: "#86efac",
        comment: "#64748b",
        function: "#fbbf24",
        variable: "#e0f2fe",
        number: "#f87171",
        operator: "#a78bfa",
        bracket: "#fbbf24",
        selection: "#1e40af",
        cursor: "#60a5fa"
      },
      isBuiltIn: true,
      downloads: 15420,
      rating: 4.9
    },
    {
      id: "ocean-blue",
      name: "Ocean Blue",
      type: "dark",
      author: "Community",
      version: "1.2.1",
      colors: {
        background: "#0f172a",
        foreground: "#f1f5f9",
        keyword: "#3b82f6",
        string: "#10b981",
        comment: "#6b7280",
        function: "#f59e0b",
        variable: "#e5e7eb",
        number: "#ef4444",
        operator: "#8b5cf6",
        bracket: "#f59e0b",
        selection: "#1d4ed8",
        cursor: "#3b82f6"
      },
      isBuiltIn: false,
      downloads: 8920,
      rating: 4.7
    },
    {
      id: "coral-reef",
      name: "Coral Reef",
      type: "light",
      author: "DeepBlue IDE",
      version: "1.0.5",
      colors: {
        background: "#fff7ed",
        foreground: "#1f2937",
        keyword: "#dc2626",
        string: "#059669",
        comment: "#6b7280",
        function: "#d97706",
        variable: "#374151",
        number: "#7c3aed",
        operator: "#be185d",
        bracket: "#d97706",
        selection: "#fde68a",
        cursor: "#dc2626"
      },
      isBuiltIn: true,
      downloads: 12150,
      rating: 4.8
    },
    {
      id: "vs-code-dark",
      name: "VS Code Dark+",
      type: "dark",
      author: "Microsoft",
      version: "1.5.0",
      colors: {
        background: "#1e1e1e",
        foreground: "#d4d4d4",
        keyword: "#569cd6",
        string: "#ce9178",
        comment: "#6a9955",
        function: "#dcdcaa",
        variable: "#9cdcfe",
        number: "#b5cea8",
        operator: "#d4d4d4",
        bracket: "#ffd700",
        selection: "#264f78",
        cursor: "#ffffff"
      },
      isBuiltIn: false,
      downloads: 45200,
      rating: 4.9
    },
    {
      id: "github-light",
      name: "GitHub Light",
      type: "light",
      author: "GitHub",
      version: "2.0.1",
      colors: {
        background: "#ffffff",
        foreground: "#24292f",
        keyword: "#cf222e",
        string: "#032f62",
        comment: "#656d76",
        function: "#8250df",
        variable: "#24292f",
        number: "#0550ae",
        operator: "#cf222e",
        bracket: "#24292f",
        selection: "#0969da",
        cursor: "#24292f"
      },
      isBuiltIn: false,
      downloads: 32800,
      rating: 4.6
    }
  ];

  const languageSupport: LanguageSupport[] = [
    {
      id: "javascript",
      name: "JavaScript",
      extensions: [".js", ".jsx", ".mjs"],
      grammarVersion: "3.2.1",
      features: ["Syntax Highlighting", "Semantic Tokens", "Tree-sitter", "Auto-completion"],
      isEnabled: true,
      hasTreeSitter: true,
      hasSemanticTokens: true,
      lastUpdated: "2025-01-01"
    },
    {
      id: "typescript",
      name: "TypeScript",
      extensions: [".ts", ".tsx"],
      grammarVersion: "4.1.2",
      features: ["Syntax Highlighting", "Semantic Tokens", "Tree-sitter", "Type Checking"],
      isEnabled: true,
      hasTreeSitter: true,
      hasSemanticTokens: true,
      lastUpdated: "2025-01-01"
    },
    {
      id: "python",
      name: "Python",
      extensions: [".py", ".pyw", ".pyi"],
      grammarVersion: "3.11.5",
      features: ["Syntax Highlighting", "Semantic Tokens", "Tree-sitter", "Linting"],
      isEnabled: true,
      hasTreeSitter: true,
      hasSemanticTokens: true,
      lastUpdated: "2024-12-28"
    },
    {
      id: "java",
      name: "Java",
      extensions: [".java"],
      grammarVersion: "17.0.2",
      features: ["Syntax Highlighting", "Semantic Tokens", "Tree-sitter"],
      isEnabled: true,
      hasTreeSitter: true,
      hasSemanticTokens: true,
      lastUpdated: "2024-12-25"
    },
    {
      id: "cpp",
      name: "C++",
      extensions: [".cpp", ".cxx", ".cc", ".h", ".hpp"],
      grammarVersion: "20.0.1",
      features: ["Syntax Highlighting", "Tree-sitter", "IntelliSense"],
      isEnabled: true,
      hasTreeSitter: true,
      hasSemanticTokens: false,
      lastUpdated: "2024-12-20"
    },
    {
      id: "rust",
      name: "Rust",
      extensions: [".rs"],
      grammarVersion: "1.75.0",
      features: ["Syntax Highlighting", "Semantic Tokens", "Tree-sitter", "Cargo Integration"],
      isEnabled: true,
      hasTreeSitter: true,
      hasSemanticTokens: true,
      lastUpdated: "2024-12-30"
    },
    {
      id: "go",
      name: "Go",
      extensions: [".go"],
      grammarVersion: "1.21.5",
      features: ["Syntax Highlighting", "Semantic Tokens", "Tree-sitter"],
      isEnabled: true,
      hasTreeSitter: true,
      hasSemanticTokens: true,
      lastUpdated: "2024-12-22"
    },
    {
      id: "php",
      name: "PHP",
      extensions: [".php", ".phtml"],
      grammarVersion: "8.3.1",
      features: ["Syntax Highlighting", "Tree-sitter"],
      isEnabled: false,
      hasTreeSitter: true,
      hasSemanticTokens: false,
      lastUpdated: "2024-12-15"
    }
  ];

  const customRules: HighlightingRule[] = [
    {
      id: "custom-1",
      name: "TODO Comments",
      pattern: "\\b(TODO|FIXME|HACK|NOTE)\\b",
      tokenType: "comment.todo",
      color: "#fbbf24",
      fontStyle: "bold",
      isActive: true,
      scope: ["comment"]
    },
    {
      id: "custom-2",
      name: "URL Links",
      pattern: "https?://[\\w\\.-]+",
      tokenType: "string.url",
      color: "#60a5fa",
      fontStyle: "underline",
      isActive: true,
      scope: ["string", "comment"]
    },
    {
      id: "custom-3",
      name: "Deprecated Functions",
      pattern: "@deprecated",
      tokenType: "keyword.deprecated",
      color: "#ef4444",
      fontStyle: "italic",
      isActive: true,
      scope: ["comment", "annotation"]
    }
  ];

  const filteredThemes = themes.filter(theme =>
    theme.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    theme.author.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const applyTheme = (theme: Theme) => {
    setSelectedTheme(theme);
    // In a real implementation, this would apply the theme to the Monaco editor
    console.log(`Applied theme: ${theme.name}`);
  };

  const exportTheme = () => {
    if (selectedTheme) {
      const themeData = JSON.stringify(selectedTheme, null, 2);
      const blob = new Blob([themeData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${selectedTheme.name.toLowerCase().replace(/\s+/g, '-')}-theme.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  const renderThemePreview = (theme: Theme) => (
    <div 
      className="p-4 rounded-lg border text-sm font-mono relative overflow-hidden"
      style={{ 
        backgroundColor: theme.colors.background, 
        color: theme.colors.foreground,
        border: `1px solid ${theme.colors.selection}`
      }}
    >
      <div className="space-y-1">
        <div>
          <span style={{ color: theme.colors.comment }}>// JavaScript Example</span>
        </div>
        <div>
          <span style={{ color: theme.colors.keyword }}>class</span>{" "}
          <span style={{ color: theme.colors.function }}>Example</span>{" "}
          <span style={{ color: theme.colors.bracket }}>{"{"}</span>
        </div>
        <div className="ml-4">
          <span style={{ color: theme.colors.keyword }}>constructor</span>
          <span style={{ color: theme.colors.bracket }}>(</span>
          <span style={{ color: theme.colors.variable }}>name</span>
          <span style={{ color: theme.colors.bracket }}>)</span>{" "}
          <span style={{ color: theme.colors.bracket }}>{"{"}</span>
        </div>
        <div className="ml-8">
          <span style={{ color: theme.colors.keyword }}>this</span>
          <span style={{ color: theme.colors.operator }}>.</span>
          <span style={{ color: theme.colors.variable }}>name</span>{" "}
          <span style={{ color: theme.colors.operator }}>=</span>{" "}
          <span style={{ color: theme.colors.string }}>"Hello"</span>
          <span style={{ color: theme.colors.operator }}>;</span>
        </div>
        <div className="ml-4">
          <span style={{ color: theme.colors.bracket }}>{"}"}</span>
        </div>
        <div>
          <span style={{ color: theme.colors.bracket }}>{"}"}</span>
        </div>
      </div>
    </div>
  );

  const renderLanguageCard = (lang: LanguageSupport) => (
    <Card key={lang.id} className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Code2 className="h-5 w-5 text-blue-500" />
            <CardTitle className="text-base">{lang.name}</CardTitle>
          </div>
          <Switch 
            checked={lang.isEnabled}
            onCheckedChange={() => {
              // Toggle language support
              console.log(`Toggled ${lang.name}: ${!lang.isEnabled}`);
            }}
          />
        </div>
        <CardDescription>
          Grammar v{lang.grammarVersion} • Updated {lang.lastUpdated}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div>
          <Label className="text-sm font-medium">Extensions</Label>
          <div className="flex flex-wrap gap-1 mt-1">
            {lang.extensions.map((ext, index) => (
              <Badge key={index} variant="secondary" className="text-xs">{ext}</Badge>
            ))}
          </div>
        </div>
        
        <div>
          <Label className="text-sm font-medium">Features</Label>
          <div className="flex flex-wrap gap-1 mt-1">
            {lang.features.map((feature, index) => (
              <Badge key={index} variant="outline" className="text-xs">{feature}</Badge>
            ))}
          </div>
        </div>
        
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1">
            <div className={`w-2 h-2 rounded-full ${lang.hasTreeSitter ? 'bg-green-500' : 'bg-gray-400'}`} />
            <span>Tree-sitter</span>
          </div>
          <div className="flex items-center gap-1">
            <div className={`w-2 h-2 rounded-full ${lang.hasSemanticTokens ? 'bg-green-500' : 'bg-gray-400'}`} />
            <span>Semantic</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Paintbrush className="h-5 w-5 text-blue-500" />
            Syntax Highlighting System
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-4 flex-shrink-0">
            <TabsTrigger value="themes" className="flex items-center gap-2">
              <Palette className="h-4 w-4" />
              Themes
            </TabsTrigger>
            <TabsTrigger value="languages" className="flex items-center gap-2">
              <Code2 className="h-4 w-4" />
              Languages
            </TabsTrigger>
            <TabsTrigger value="custom-rules" className="flex items-center gap-2">
              <Settings2 className="h-4 w-4" />
              Custom Rules
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="themes" className="flex-1 overflow-hidden flex flex-col">
            <div className="flex items-center gap-4 mb-4 flex-shrink-0">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search themes..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Button variant="outline" size="sm" onClick={exportTheme} disabled={!selectedTheme}>
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button variant="outline" size="sm">
                <Upload className="h-4 w-4 mr-2" />
                Import
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 flex-1 overflow-hidden">
              <div className="flex flex-col">
                <h3 className="text-lg font-semibold mb-3">Available Themes</h3>
                <ScrollArea className="flex-1">
                  <div className="space-y-3 pr-4">
                    {filteredThemes.map((theme) => (
                      <Card 
                        key={theme.id} 
                        className={`cursor-pointer transition-all hover:shadow-md ${
                          selectedTheme?.id === theme.id ? 'ring-2 ring-blue-500' : ''
                        }`}
                        onClick={() => setSelectedTheme(theme)}
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <div>
                              <CardTitle className="text-base flex items-center gap-2">
                                {theme.name}
                                {theme.isBuiltIn && <Badge variant="secondary">Built-in</Badge>}
                                {theme.type === 'dark' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
                              </CardTitle>
                              <CardDescription>
                                by {theme.author} • v{theme.version}
                              </CardDescription>
                            </div>
                            <div className="text-right">
                              <div className="flex items-center gap-1 text-sm">
                                <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                                {theme.rating}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {theme.downloads.toLocaleString()} downloads
                              </div>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          {renderThemePreview(theme)}
                          <Button 
                            size="sm" 
                            className="w-full mt-3"
                            onClick={(e) => {
                              e.stopPropagation();
                              applyTheme(theme);
                            }}
                          >
                            Apply Theme
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </div>

              <div className="flex flex-col">
                <h3 className="text-lg font-semibold mb-3">Theme Preview</h3>
                {selectedTheme ? (
                  <div className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          {selectedTheme.name}
                          {selectedTheme.type === 'dark' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
                        </CardTitle>
                        <CardDescription>
                          by {selectedTheme.author} • Version {selectedTheme.version}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <Label className="text-sm font-medium">Color Palette</Label>
                          <div className="grid grid-cols-4 gap-2 mt-2">
                            {Object.entries(selectedTheme.colors).map(([key, value]) => (
                              <div key={key} className="flex items-center gap-2">
                                <div 
                                  className="w-4 h-4 rounded border border-gray-300"
                                  style={{ backgroundColor: value }}
                                />
                                <span className="text-xs capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <Label className="text-sm font-medium">Full Preview</Label>
                          <div className="mt-2">
                            {renderThemePreview(selectedTheme)}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <Card className="flex-1 flex items-center justify-center">
                    <CardContent className="text-center">
                      <Palette className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-muted-foreground">Select a theme to preview</p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="languages" className="flex-1 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Language Support</h3>
              <Button size="sm">
                <Download className="h-4 w-4 mr-2" />
                Install New Language
              </Button>
            </div>
            
            <ScrollArea className="flex-1">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 pr-4">
                {languageSupport.map(renderLanguageCard)}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="custom-rules" className="flex-1 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Custom Highlighting Rules</h3>
              <Button size="sm">
                <Zap className="h-4 w-4 mr-2" />
                Add Rule
              </Button>
            </div>
            
            <ScrollArea className="flex-1">
              <div className="space-y-4 pr-4">
                {customRules.map((rule) => (
                  <Card key={rule.id}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base">{rule.name}</CardTitle>
                        <Switch checked={rule.isActive} />
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <Label className="text-sm font-medium">Pattern</Label>
                        <Input value={rule.pattern} className="mt-1 font-mono text-sm" readOnly />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label className="text-sm font-medium">Token Type</Label>
                          <Badge variant="outline" className="mt-1">{rule.tokenType}</Badge>
                        </div>
                        <div>
                          <Label className="text-sm font-medium">Style</Label>
                          <div className="flex items-center gap-2 mt-1">
                            <div 
                              className="w-4 h-4 rounded border border-gray-300"
                              style={{ backgroundColor: rule.color }}
                            />
                            <Badge variant="secondary" className="capitalize">{rule.fontStyle}</Badge>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <Label className="text-sm font-medium">Scope</Label>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {rule.scope.map((scope, index) => (
                            <Badge key={index} variant="outline" className="text-xs">{scope}</Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="settings" className="flex-1 overflow-hidden">
            <ScrollArea className="flex-1">
              <div className="space-y-6 pr-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings2 className="h-5 w-5" />
                      General Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-sm font-medium">Enable Syntax Highlighting</Label>
                        <p className="text-xs text-muted-foreground">Turn on/off syntax highlighting globally</p>
                      </div>
                      <Switch 
                        checked={enableSyntaxHighlighting}
                        onCheckedChange={setEnableSyntaxHighlighting}
                      />
                    </div>
                    
                    <Separator />
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="text-sm font-medium">Enable Semantic Tokens</Label>
                        <p className="text-xs text-muted-foreground">Advanced highlighting based on code semantics</p>
                      </div>
                      <Switch 
                        checked={enableSemanticTokens}
                        onCheckedChange={setEnableSemanticTokens}
                      />
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Highlighting Performance</Label>
                      <div className="px-3">
                        <Slider
                          value={highlightingSpeed}
                          onValueChange={setHighlightingSpeed}
                          max={100}
                          min={10}
                          step={5}
                        />
                        <div className="flex justify-between text-xs text-muted-foreground mt-1">
                          <span>Conservative</span>
                          <span>Balanced ({highlightingSpeed[0]}%)</span>
                          <span>Aggressive</span>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Higher values provide faster highlighting but may use more resources
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Eye className="h-5 w-5" />
                      Display Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium">Default Theme</Label>
                        <Select defaultValue="deepblue-dark">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {themes.map((theme) => (
                              <SelectItem key={theme.id} value={theme.id}>
                                {theme.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label className="text-sm font-medium">Color Contrast</Label>
                        <Select defaultValue="normal">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low</SelectItem>
                            <SelectItem value="normal">Normal</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="h-5 w-5" />
                      Performance Metrics
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Highlighting Speed</span>
                          <span>95ms avg</span>
                        </div>
                        <Progress value={88} className="h-2" />
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Memory Usage</span>
                          <span>24.5 MB</span>
                        </div>
                        <Progress value={65} className="h-2" />
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Token Cache Hit Rate</span>
                          <span>92.3%</span>
                        </div>
                        <Progress value={92} className="h-2" />
                      </div>
                    </div>
                    
                    <Button variant="outline" size="sm" className="w-full">
                      <Monitor className="h-4 w-4 mr-2" />
                      View Detailed Metrics
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}