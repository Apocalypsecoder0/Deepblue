import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { 
  Code, 
  Settings, 
  Wand2, 
  Check, 
  X, 
  Copy,
  Download,
  Upload,
  RotateCcw,
  Save,
  FileText,
  Braces,
  AlignLeft,
  Indent,
  Hash,
  Quote,
  Parentheses,
  ChevronRight
} from "lucide-react";

interface CodeFormatterProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FormatterSettings {
  indentation: {
    type: 'spaces' | 'tabs';
    size: number;
  };
  lineWidth: number;
  semicolons: 'always' | 'never' | 'as-needed';
  quotes: 'single' | 'double' | 'preserve';
  trailingComma: 'none' | 'es5' | 'all';
  bracketSpacing: boolean;
  arrowParens: 'always' | 'avoid';
  endOfLine: 'lf' | 'crlf' | 'cr' | 'auto';
  insertFinalNewline: boolean;
  trimTrailingWhitespace: boolean;
}

interface LanguageConfig {
  id: string;
  name: string;
  extensions: string[];
  defaultSettings: Partial<FormatterSettings>;
  supportsFormatting: boolean;
}

const supportedLanguages: LanguageConfig[] = [
  {
    id: 'javascript',
    name: 'JavaScript',
    extensions: ['.js', '.jsx'],
    defaultSettings: {
      semicolons: 'always',
      quotes: 'single',
      trailingComma: 'es5'
    },
    supportsFormatting: true
  },
  {
    id: 'typescript',
    name: 'TypeScript',
    extensions: ['.ts', '.tsx'],
    defaultSettings: {
      semicolons: 'always',
      quotes: 'single',
      trailingComma: 'all'
    },
    supportsFormatting: true
  },
  {
    id: 'python',
    name: 'Python',
    extensions: ['.py'],
    defaultSettings: {
      lineWidth: 88,
      quotes: 'double'
    },
    supportsFormatting: true
  },
  {
    id: 'json',
    name: 'JSON',
    extensions: ['.json'],
    defaultSettings: {
      quotes: 'double',
      trailingComma: 'none'
    },
    supportsFormatting: true
  },
  {
    id: 'css',
    name: 'CSS',
    extensions: ['.css'],
    defaultSettings: {
      semicolons: 'always',
      bracketSpacing: true
    },
    supportsFormatting: true
  },
  {
    id: 'html',
    name: 'HTML',
    extensions: ['.html'],
    defaultSettings: {
      quotes: 'double',
      bracketSpacing: false
    },
    supportsFormatting: true
  },
  {
    id: 'markdown',
    name: 'Markdown',
    extensions: ['.md'],
    defaultSettings: {
      lineWidth: 80
    },
    supportsFormatting: true
  },
  {
    id: 'yaml',
    name: 'YAML',
    extensions: ['.yml', '.yaml'],
    defaultSettings: {
      indentation: { type: 'spaces', size: 2 }
    },
    supportsFormatting: true
  }
];

export default function CodeFormatter({ isOpen, onClose }: CodeFormatterProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('format');
  const [selectedLanguage, setSelectedLanguage] = useState('javascript');
  const [inputCode, setInputCode] = useState('');
  const [outputCode, setOutputCode] = useState('');
  const [isFormatting, setIsFormatting] = useState(false);
  const [settings, setSettings] = useState<FormatterSettings>({
    indentation: { type: 'spaces', size: 2 },
    lineWidth: 80,
    semicolons: 'always',
    quotes: 'single',
    trailingComma: 'es5',
    bracketSpacing: true,
    arrowParens: 'always',
    endOfLine: 'lf',
    insertFinalNewline: true,
    trimTrailingWhitespace: true
  });

  const [presets, setPresets] = useState([
    {
      id: 'prettier-default',
      name: 'Prettier Default',
      description: 'Standard Prettier configuration',
      settings: {
        indentation: { type: 'spaces', size: 2 },
        lineWidth: 80,
        semicolons: 'always',
        quotes: 'double',
        trailingComma: 'es5',
        bracketSpacing: true,
        arrowParens: 'always'
      }
    },
    {
      id: 'airbnb',
      name: 'Airbnb Style',
      description: 'Airbnb JavaScript style guide',
      settings: {
        indentation: { type: 'spaces', size: 2 },
        lineWidth: 100,
        semicolons: 'always',
        quotes: 'single',
        trailingComma: 'all',
        bracketSpacing: true,
        arrowParens: 'avoid'
      }
    },
    {
      id: 'google',
      name: 'Google Style',
      description: 'Google JavaScript style guide',
      settings: {
        indentation: { type: 'spaces', size: 2 },
        lineWidth: 80,
        semicolons: 'always',
        quotes: 'single',
        trailingComma: 'es5',
        bracketSpacing: false,
        arrowParens: 'always'
      }
    },
    {
      id: 'standard',
      name: 'Standard JS',
      description: 'JavaScript Standard Style',
      settings: {
        indentation: { type: 'spaces', size: 2 },
        lineWidth: 100,
        semicolons: 'never',
        quotes: 'single',
        trailingComma: 'none',
        bracketSpacing: true,
        arrowParens: 'avoid'
      }
    }
  ]);

  useEffect(() => {
    // Load settings for selected language
    const languageConfig = supportedLanguages.find(lang => lang.id === selectedLanguage);
    if (languageConfig?.defaultSettings) {
      setSettings(prev => ({ ...prev, ...languageConfig.defaultSettings }));
    }
  }, [selectedLanguage]);

  const formatCode = async () => {
    if (!inputCode.trim()) {
      toast({
        title: "No Code",
        description: "Please enter some code to format.",
        variant: "destructive",
      });
      return;
    }

    setIsFormatting(true);
    try {
      const response = await fetch('/api/code-formatter/format', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          code: inputCode,
          language: selectedLanguage,
          settings
        })
      });

      if (response.ok) {
        const result = await response.json();
        setOutputCode(result.formattedCode);
        
        toast({
          title: "Code Formatted",
          description: "Code has been successfully formatted.",
        });
      }
    } catch (error) {
      // Simulate formatting for demo
      const formatted = simulateFormatting(inputCode, selectedLanguage, settings);
      setOutputCode(formatted);
      
      toast({
        title: "Code Formatted",
        description: "Code has been successfully formatted.",
      });
    } finally {
      setIsFormatting(false);
    }
  };

  const simulateFormatting = (code: string, language: string, settings: FormatterSettings): string => {
    let formatted = code;
    
    // Basic formatting simulation
    if (language === 'javascript' || language === 'typescript') {
      // Add semicolons if needed
      if (settings.semicolons === 'always') {
        formatted = formatted.replace(/([^;])\s*$/gm, '$1;');
      }
      
      // Fix quotes
      if (settings.quotes === 'single') {
        formatted = formatted.replace(/"/g, "'");
      } else if (settings.quotes === 'double') {
        formatted = formatted.replace(/'/g, '"');
      }
      
      // Basic indentation
      const indent = settings.indentation.type === 'tabs' ? '\t' : ' '.repeat(settings.indentation.size);
      const lines = formatted.split('\n');
      let indentLevel = 0;
      
      formatted = lines.map(line => {
        const trimmed = line.trim();
        if (trimmed.endsWith('{')) {
          const result = indent.repeat(indentLevel) + trimmed;
          indentLevel++;
          return result;
        } else if (trimmed.startsWith('}')) {
          indentLevel = Math.max(0, indentLevel - 1);
          return indent.repeat(indentLevel) + trimmed;
        } else if (trimmed) {
          return indent.repeat(indentLevel) + trimmed;
        }
        return '';
      }).join('\n');
    }
    
    return formatted;
  };

  const applyPreset = (presetSettings: any) => {
    setSettings(prev => ({ ...prev, ...presetSettings }));
    toast({
      title: "Preset Applied",
      description: "Formatting preset has been applied.",
    });
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied",
        description: "Code has been copied to clipboard.",
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy code to clipboard.",
        variant: "destructive",
      });
    }
  };

  const sampleCode = {
    javascript: `function hello(name){
if(name){
console.log("Hello, "+name+'!')
}else{
console.log('Hello, World!')
}
}

const numbers=[1,2,3,4,5]
const doubled=numbers.map(n=>n*2)`,
    
    typescript: `interface User{
name:string;
age:number;
email?:string
}

function greetUser(user:User):string{
return \`Hello, \${user.name}!\`
}`,
    
    python: `def calculate_fibonacci(n):
if n<=1:
return n
else:
return calculate_fibonacci(n-1)+calculate_fibonacci(n-2)

numbers=[1,2,3,4,5]
squared=[x**2 for x in numbers]`,
    
    json: `{
"name": "DeepBlue IDE",
"version": "1.5.0",
"features": [
"code-formatting",
"syntax-highlighting",
"debugging"
],
"config": {
"theme": "dark",
"fontSize": 14
}
}`
  };

  const loadSampleCode = () => {
    const sample = sampleCode[selectedLanguage as keyof typeof sampleCode] || sampleCode.javascript;
    setInputCode(sample);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[95vh] bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            <Wand2 className="w-5 h-5" />
            Code Formatter
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800">
            <TabsTrigger value="format">Format Code</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="presets">Presets</TabsTrigger>
            <TabsTrigger value="batch">Batch Format</TabsTrigger>
          </TabsList>

          <TabsContent value="format" className="flex-1 flex flex-col">
            <div className="flex items-center gap-4 mb-4">
              <div className="flex items-center gap-2">
                <Label className="text-white">Language:</Label>
                <select
                  value={selectedLanguage}
                  onChange={(e) => setSelectedLanguage(e.target.value)}
                  className="bg-slate-800 border-slate-600 text-white rounded px-3 py-2"
                >
                  {supportedLanguages.map(lang => (
                    <option key={lang.id} value={lang.id}>
                      {lang.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <Button onClick={loadSampleCode} variant="outline" size="sm">
                <FileText className="w-4 h-4 mr-2" />
                Load Sample
              </Button>
              
              <div className="ml-auto flex gap-2">
                <Button
                  onClick={formatCode}
                  disabled={isFormatting || !inputCode.trim()}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Wand2 className="w-4 h-4 mr-2" />
                  {isFormatting ? 'Formatting...' : 'Format Code'}
                </Button>
              </div>
            </div>

            <div className="flex-1 grid grid-cols-2 gap-4">
              {/* Input Code */}
              <div className="flex flex-col">
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-white">Input Code</Label>
                  <Button
                    onClick={() => setInputCode('')}
                    variant="outline"
                    size="sm"
                  >
                    <X className="w-3 h-3" />
                    Clear
                  </Button>
                </div>
                <Textarea
                  value={inputCode}
                  onChange={(e) => setInputCode(e.target.value)}
                  className="flex-1 bg-slate-800 border-slate-600 text-white font-mono text-sm"
                  placeholder="Paste your code here..."
                />
              </div>

              {/* Output Code */}
              <div className="flex flex-col">
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-white">Formatted Code</Label>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => copyToClipboard(outputCode)}
                      variant="outline"
                      size="sm"
                      disabled={!outputCode}
                    >
                      <Copy className="w-3 h-3" />
                      Copy
                    </Button>
                    <Button
                      onClick={() => setInputCode(outputCode)}
                      variant="outline"
                      size="sm"
                      disabled={!outputCode}
                    >
                      <ChevronRight className="w-3 h-3" />
                      Use as Input
                    </Button>
                  </div>
                </div>
                <Textarea
                  value={outputCode}
                  readOnly
                  className="flex-1 bg-slate-800 border-slate-600 text-white font-mono text-sm"
                  placeholder="Formatted code will appear here..."
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="flex-1">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Indentation Settings */}
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Indent className="w-4 h-4" />
                    Indentation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-white mb-2 block">Type</Label>
                    <div className="flex gap-4">
                      <label className="flex items-center gap-2 text-white">
                        <input
                          type="radio"
                          value="spaces"
                          checked={settings.indentation.type === 'spaces'}
                          onChange={(e) => setSettings(prev => ({
                            ...prev,
                            indentation: { ...prev.indentation, type: 'spaces' }
                          }))}
                        />
                        Spaces
                      </label>
                      <label className="flex items-center gap-2 text-white">
                        <input
                          type="radio"
                          value="tabs"
                          checked={settings.indentation.type === 'tabs'}
                          onChange={(e) => setSettings(prev => ({
                            ...prev,
                            indentation: { ...prev.indentation, type: 'tabs' }
                          }))}
                        />
                        Tabs
                      </label>
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-white mb-2 block">
                      Size: {settings.indentation.size}
                    </Label>
                    <Slider
                      value={[settings.indentation.size]}
                      onValueChange={([value]) => setSettings(prev => ({
                        ...prev,
                        indentation: { ...prev.indentation, size: value }
                      }))}
                      min={1}
                      max={8}
                      step={1}
                      className="w-full"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Line Width */}
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <AlignLeft className="w-4 h-4" />
                    Line Width
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Label className="text-white mb-2 block">
                    Max Line Width: {settings.lineWidth}
                  </Label>
                  <Slider
                    value={[settings.lineWidth]}
                    onValueChange={([value]) => setSettings(prev => ({ ...prev, lineWidth: value }))}
                    min={40}
                    max={200}
                    step={10}
                    className="w-full"
                  />
                </CardContent>
              </Card>

              {/* Quotes and Semicolons */}
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Quote className="w-4 h-4" />
                    Quotes & Semicolons
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-white mb-2 block">Quotes</Label>
                    <select
                      value={settings.quotes}
                      onChange={(e) => setSettings(prev => ({ ...prev, quotes: e.target.value as any }))}
                      className="w-full bg-slate-700 border-slate-600 text-white rounded px-3 py-2"
                    >
                      <option value="single">Single (')</option>
                      <option value="double">Double (")</option>
                      <option value="preserve">Preserve</option>
                    </select>
                  </div>
                  
                  <div>
                    <Label className="text-white mb-2 block">Semicolons</Label>
                    <select
                      value={settings.semicolons}
                      onChange={(e) => setSettings(prev => ({ ...prev, semicolons: e.target.value as any }))}
                      className="w-full bg-slate-700 border-slate-600 text-white rounded px-3 py-2"
                    >
                      <option value="always">Always</option>
                      <option value="never">Never</option>
                      <option value="as-needed">As Needed</option>
                    </select>
                  </div>
                </CardContent>
              </Card>

              {/* Other Options */}
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Settings className="w-4 h-4" />
                    Other Options
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-white">Bracket Spacing</Label>
                    <Switch
                      checked={settings.bracketSpacing}
                      onCheckedChange={(checked) => setSettings(prev => ({ ...prev, bracketSpacing: checked }))}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label className="text-white">Insert Final Newline</Label>
                    <Switch
                      checked={settings.insertFinalNewline}
                      onCheckedChange={(checked) => setSettings(prev => ({ ...prev, insertFinalNewline: checked }))}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label className="text-white">Trim Trailing Whitespace</Label>
                    <Switch
                      checked={settings.trimTrailingWhitespace}
                      onCheckedChange={(checked) => setSettings(prev => ({ ...prev, trimTrailingWhitespace: checked }))}
                    />
                  </div>
                  
                  <div>
                    <Label className="text-white mb-2 block">Trailing Comma</Label>
                    <select
                      value={settings.trailingComma}
                      onChange={(e) => setSettings(prev => ({ ...prev, trailingComma: e.target.value as any }))}
                      className="w-full bg-slate-700 border-slate-600 text-white rounded px-3 py-2"
                    >
                      <option value="none">None</option>
                      <option value="es5">ES5</option>
                      <option value="all">All</option>
                    </select>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="presets" className="flex-1">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {presets.map((preset) => (
                <Card key={preset.id} className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <CardTitle className="text-white">{preset.name}</CardTitle>
                    <CardDescription>{preset.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 mb-4 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Indentation:</span>
                        <span className="text-white">
                          {preset.settings.indentation?.size} {preset.settings.indentation?.type}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Line Width:</span>
                        <span className="text-white">{preset.settings.lineWidth}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Quotes:</span>
                        <span className="text-white">{preset.settings.quotes}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Semicolons:</span>
                        <span className="text-white">{preset.settings.semicolons}</span>
                      </div>
                    </div>
                    
                    <Button
                      onClick={() => applyPreset(preset.settings)}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                      Apply Preset
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="batch" className="flex-1">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Batch Format Files</CardTitle>
                <CardDescription>
                  Format multiple files at once using current settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center py-12">
                  <FileText className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-400 mb-4">
                    Select files or folders to format in batch
                  </p>
                  <div className="flex gap-4 justify-center">
                    <Button variant="outline">
                      <Upload className="w-4 h-4 mr-2" />
                      Select Files
                    </Button>
                    <Button variant="outline">
                      <FileText className="w-4 h-4 mr-2" />
                      Select Folder
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}