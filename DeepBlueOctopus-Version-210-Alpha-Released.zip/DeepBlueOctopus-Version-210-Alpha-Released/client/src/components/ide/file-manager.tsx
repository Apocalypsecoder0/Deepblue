import { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import { SoundButton } from "@/components/ui/sound-system";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  File, 
  Folder, 
  Upload, 
  Download, 
  Search, 
  FileText, 
  Image, 
  Archive, 
  Copy, 
  Move, 
  Trash2, 
  Star, 
  Clock, 
  Filter, 
  Compare, 
  FolderOpen,
  FileCheck,
  FileX,
  FileSearch,
  Package,
  Diff,
  Eye,
  MoreHorizontal,
  RefreshCw,
  Settings,
  BookmarkPlus,
  History
} from "lucide-react";

interface FileManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FileInfo {
  id: number;
  name: string;
  path: string;
  size: number;
  type: 'file' | 'directory';
  lastModified: Date;
  language?: string;
  isBookmarked?: boolean;
  permissions?: string;
  encoding?: string;
}

interface RecentFile {
  id: number;
  name: string;
  path: string;
  lastOpened: Date;
  language: string;
}

interface SearchResult {
  file: FileInfo;
  matches: {
    line: number;
    content: string;
    match: string;
  }[];
}

export default function FileManager({ isOpen, onClose }: FileManagerProps) {
  const { files, projects } = useIDEState();
  const [activeTab, setActiveTab] = useState("explorer");
  const [searchQuery, setSearchQuery] = useState("");
  const [contentSearch, setContentSearch] = useState("");
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<number[]>([]);
  const [currentPath, setCurrentPath] = useState("/");
  const [recentFiles, setRecentFiles] = useState<RecentFile[]>([]);
  const [bookmarkedFiles, setBookmarkedFiles] = useState<number[]>([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [showHidden, setShowHidden] = useState(false);
  const [sortBy, setSortBy] = useState<'name' | 'size' | 'modified' | 'type'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [filterType, setFilterType] = useState<'all' | 'files' | 'directories'>('all');
  const [compressionFormat, setCompressionFormat] = useState<'zip' | 'tar' | 'tar.gz'>('zip');
  const [selectedForCompare, setSelectedForCompare] = useState<FileInfo[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Load recent files from localStorage
    const saved = localStorage.getItem('ide-recent-files');
    if (saved) {
      setRecentFiles(JSON.parse(saved));
    }

    // Load bookmarked files
    const bookmarks = localStorage.getItem('ide-bookmarked-files');
    if (bookmarks) {
      setBookmarkedFiles(JSON.parse(bookmarks));
    }
  }, []);

  // Enhanced file operations
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = event.target.files;
    if (!uploadedFiles) return;

    setIsUploading(true);
    setUploadProgress(0);

    for (let i = 0; i < uploadedFiles.length; i++) {
      const file = uploadedFiles[i];
      const progress = ((i + 1) / uploadedFiles.length) * 100;
      setUploadProgress(progress);

      // Simulate file upload with processing
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Process file content
      const content = await file.text();
      const language = detectLanguageFromExtension(file.name);
      
      console.log(`Uploading ${file.name}:`, {
        size: file.size,
        type: file.type,
        language,
        content: content.substring(0, 100) + '...'
      });
    }

    setIsUploading(false);
    setUploadProgress(0);
  };

  const detectLanguageFromExtension = (filename: string): string => {
    const ext = filename.split('.').pop()?.toLowerCase();
    const langMap: { [key: string]: string } = {
      'js': 'javascript',
      'ts': 'typescript',
      'py': 'python',
      'java': 'java',
      'cpp': 'cpp',
      'c': 'c',
      'cs': 'csharp',
      'php': 'php',
      'rb': 'ruby',
      'go': 'go',
      'rs': 'rust',
      'html': 'html',
      'css': 'css',
      'scss': 'scss',
      'sass': 'sass',
      'json': 'json',
      'xml': 'xml',
      'yaml': 'yaml',
      'yml': 'yaml',
      'md': 'markdown',
      'sql': 'sql',
      'sh': 'bash',
      'dockerfile': 'dockerfile'
    };
    return langMap[ext || ''] || 'plaintext';
  };

  const searchFileContent = async (query: string) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    // Simulate content search across all files
    const results: SearchResult[] = [];
    
    // Mock search results for demonstration
    const mockFiles = Array.isArray(files) ? files : [];
    
    mockFiles.forEach((file: any) => {
      if (file.content && file.content.toLowerCase().includes(query.toLowerCase())) {
        const lines = file.content.split('\n');
        const matches = lines
          .map((line: string, index: number) => ({
            line: index + 1,
            content: line,
            match: query
          }))
          .filter((match: any) => match.content.toLowerCase().includes(query.toLowerCase()));

        if (matches.length > 0) {
          results.push({
            file: {
              id: file.id,
              name: file.name,
              path: file.path,
              size: file.content.length,
              type: file.isDirectory ? 'directory' : 'file',
              lastModified: new Date(),
              language: file.language
            },
            matches
          });
        }
      }
    });

    setSearchResults(results);
  };

  const createArchive = async (format: 'zip' | 'tar' | 'tar.gz') => {
    if (selectedFiles.length === 0) return;

    console.log(`Creating ${format} archive with files:`, selectedFiles);
    
    // Simulate archive creation
    const archiveName = `archive-${Date.now()}.${format}`;
    
    // Mock compression progress
    for (let i = 0; i <= 100; i += 10) {
      setUploadProgress(i);
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    console.log(`Archive created: ${archiveName}`);
    setUploadProgress(0);
  };

  const compareFiles = (files: FileInfo[]) => {
    if (files.length !== 2) return;
    
    console.log('Comparing files:', files.map(f => f.name));
    // Implement side-by-side file comparison
    setSelectedForCompare(files);
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (file: FileInfo) => {
    if (file.type === 'directory') return <Folder className="h-4 w-4 text-blue-400" />;
    
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(ext || '')) {
      return <Image className="h-4 w-4 text-green-400" />;
    }
    if (['zip', 'tar', 'gz', 'rar', '7z'].includes(ext || '')) {
      return <Archive className="h-4 w-4 text-purple-400" />;
    }
    return <FileText className="h-4 w-4 text-gray-400" />;
  };

  const mockFileList: FileInfo[] = [
    {
      id: 1,
      name: 'src',
      path: '/src',
      size: 0,
      type: 'directory',
      lastModified: new Date('2024-01-15'),
      isBookmarked: true
    },
    {
      id: 2,
      name: 'main.js',
      path: '/src/main.js',
      size: 2048,
      type: 'file',
      lastModified: new Date('2024-01-20'),
      language: 'javascript',
      permissions: 'rw-r--r--',
      encoding: 'UTF-8'
    },
    {
      id: 3,
      name: 'styles.css',
      path: '/src/styles.css',
      size: 1024,
      type: 'file',
      lastModified: new Date('2024-01-18'),
      language: 'css',
      permissions: 'rw-r--r--',
      encoding: 'UTF-8'
    },
    {
      id: 4,
      name: 'package.json',
      path: '/package.json',
      size: 512,
      type: 'file',
      lastModified: new Date('2024-01-10'),
      language: 'json',
      permissions: 'rw-r--r--',
      encoding: 'UTF-8'
    }
  ];

  const filteredFiles = mockFileList
    .filter(file => {
      if (filterType !== 'all' && 
          ((filterType === 'files' && file.type !== 'file') ||
           (filterType === 'directories' && file.type !== 'directory'))) {
        return false;
      }
      if (searchQuery && !file.name.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      if (!showHidden && file.name.startsWith('.')) {
        return false;
      }
      return true;
    })
    .sort((a, b) => {
      let aVal: any, bVal: any;
      switch (sortBy) {
        case 'name':
          aVal = a.name.toLowerCase();
          bVal = b.name.toLowerCase();
          break;
        case 'size':
          aVal = a.size;
          bVal = b.size;
          break;
        case 'modified':
          aVal = a.lastModified.getTime();
          bVal = b.lastModified.getTime();
          break;
        case 'type':
          aVal = a.type;
          bVal = b.type;
          break;
        default:
          return 0;
      }
      
      if (sortOrder === 'asc') {
        return aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
      } else {
        return aVal > bVal ? -1 : aVal < bVal ? 1 : 0;
      }
    });

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh] bg-[var(--ide-surface)] border-[var(--ide-border)]">
        <DialogHeader>
          <DialogTitle className="text-[var(--ide-text)] flex items-center gap-2">
            <FolderOpen className="h-5 w-5 text-blue-400" />
            Advanced File Manager
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-6 bg-[var(--ide-surface-secondary)]">
            <TabsTrigger value="explorer" className="data-[state=active]:bg-[var(--ide-accent)]/20">
              <File className="h-4 w-4 mr-2" />
              Explorer
            </TabsTrigger>
            <TabsTrigger value="search" className="data-[state=active]:bg-[var(--ide-accent)]/20">
              <Search className="h-4 w-4 mr-2" />
              Search
            </TabsTrigger>
            <TabsTrigger value="recent" className="data-[state=active]:bg-[var(--ide-accent)]/20">
              <Clock className="h-4 w-4 mr-2" />
              Recent
            </TabsTrigger>
            <TabsTrigger value="bookmarks" className="data-[state=active]:bg-[var(--ide-accent)]/20">
              <Star className="h-4 w-4 mr-2" />
              Bookmarks
            </TabsTrigger>
            <TabsTrigger value="operations" className="data-[state=active]:bg-[var(--ide-accent)]/20">
              <Package className="h-4 w-4 mr-2" />
              Operations
            </TabsTrigger>
            <TabsTrigger value="compare" className="data-[state=active]:bg-[var(--ide-accent)]/20">
              <Diff className="h-4 w-4 mr-2" />
              Compare
            </TabsTrigger>
          </TabsList>

          {/* File Explorer Tab */}
          <TabsContent value="explorer" className="flex-1 flex flex-col space-y-4">
            {/* Toolbar */}
            <div className="flex items-center justify-between gap-4 p-4 bg-[var(--ide-surface-secondary)] rounded-lg">
              <div className="flex items-center gap-2">
                <Input
                  placeholder="Search files..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64"
                />
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value as any)}
                  className="px-3 py-2 bg-[var(--ide-surface)] border border-[var(--ide-border)] rounded"
                >
                  <option value="all">All</option>
                  <option value="files">Files Only</option>
                  <option value="directories">Directories Only</option>
                </select>
                <select
                  value={`${sortBy}-${sortOrder}`}
                  onChange={(e) => {
                    const [sort, order] = e.target.value.split('-');
                    setSortBy(sort as any);
                    setSortOrder(order as any);
                  }}
                  className="px-3 py-2 bg-[var(--ide-surface)] border border-[var(--ide-border)] rounded"
                >
                  <option value="name-asc">Name ↑</option>
                  <option value="name-desc">Name ↓</option>
                  <option value="size-asc">Size ↑</option>
                  <option value="size-desc">Size ↓</option>
                  <option value="modified-asc">Modified ↑</option>
                  <option value="modified-desc">Modified ↓</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <TooltipWrapper
                  title="Upload Files"
                  content="Upload multiple files to the current directory"
                  type="feature"
                >
                  <SoundButton
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-blue-600 hover:bg-blue-500"
                    disabled={isUploading}
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Upload
                  </SoundButton>
                </TooltipWrapper>

                <TooltipWrapper
                  title="Create Archive"
                  content="Create compressed archive from selected files"
                  type="feature"
                >
                  <SoundButton
                    onClick={() => createArchive(compressionFormat)}
                    disabled={selectedFiles.length === 0}
                    className="bg-purple-600 hover:bg-purple-500"
                  >
                    <Archive className="h-4 w-4 mr-2" />
                    Archive
                  </SoundButton>
                </TooltipWrapper>

                <TooltipWrapper
                  title="Compare Files"
                  content="Compare two selected files side by side"
                  type="feature"
                >
                  <SoundButton
                    onClick={() => compareFiles(selectedFiles.map(id => filteredFiles.find(f => f.id === id)!).filter(Boolean))}
                    disabled={selectedFiles.length !== 2}
                    className="bg-green-600 hover:bg-green-500"
                  >
                    <Diff className="h-4 w-4 mr-2" />
                    Compare
                  </SoundButton>
                </TooltipWrapper>

                <TooltipWrapper
                  title="Refresh"
                  content="Refresh file listing and reload directory"
                  type="feature"
                >
                  <SoundButton
                    variant="outline"
                    onClick={() => window.location.reload()}
                  >
                    <RefreshCw className="h-4 w-4" />
                  </SoundButton>
                </TooltipWrapper>
              </div>
            </div>

            {/* Upload Progress */}
            {isUploading && (
              <Card className="bg-blue-900/30 border-blue-700">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-blue-200">Uploading files...</span>
                    <span className="text-blue-300">{uploadProgress.toFixed(0)}%</span>
                  </div>
                  <Progress value={uploadProgress} className="h-2" />
                </CardContent>
              </Card>
            )}

            {/* File List */}
            <ScrollArea className="flex-1">
              <div className="space-y-1">
                {filteredFiles.map((file) => (
                  <div
                    key={file.id}
                    className={`flex items-center gap-3 p-3 rounded-lg hover:bg-[var(--ide-surface-secondary)] cursor-pointer ${
                      selectedFiles.includes(file.id) ? 'bg-[var(--ide-accent)]/20' : ''
                    }`}
                    onClick={() => {
                      if (selectedFiles.includes(file.id)) {
                        setSelectedFiles(prev => prev.filter(id => id !== file.id));
                      } else {
                        setSelectedFiles(prev => [...prev, file.id]);
                      }
                    }}
                  >
                    <div className="flex items-center gap-2 flex-1">
                      {getFileIcon(file)}
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[var(--ide-text)]">{file.name}</span>
                          {file.isBookmarked && <Star className="h-3 w-3 text-yellow-400 fill-current" />}
                          {file.language && (
                            <Badge variant="outline" className="text-xs">
                              {file.language}
                            </Badge>
                          )}
                        </div>
                        <div className="text-xs text-[var(--ide-text-secondary)] flex items-center gap-4">
                          <span>{file.path}</span>
                          <span>{formatFileSize(file.size)}</span>
                          <span>{file.lastModified.toLocaleDateString()}</span>
                          {file.permissions && <span>{file.permissions}</span>}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <TooltipWrapper
                        title="Add Bookmark"
                        content="Bookmark this file for quick access"
                        type="feature"
                      >
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            const newBookmarks = bookmarkedFiles.includes(file.id)
                              ? bookmarkedFiles.filter(id => id !== file.id)
                              : [...bookmarkedFiles, file.id];
                            setBookmarkedFiles(newBookmarks);
                            localStorage.setItem('ide-bookmarked-files', JSON.stringify(newBookmarks));
                          }}
                          className="h-7 w-7 p-0"
                        >
                          <BookmarkPlus className="h-3 w-3" />
                        </Button>
                      </TooltipWrapper>

                      <TooltipWrapper
                        title="More Options"
                        content="Additional file operations and properties"
                        type="feature"
                      >
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 w-7 p-0"
                        >
                          <MoreHorizontal className="h-3 w-3" />
                        </Button>
                      </TooltipWrapper>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          {/* Content Search Tab */}
          <TabsContent value="search" className="flex-1 flex flex-col space-y-4">
            <Card className="bg-[var(--ide-surface-secondary)] border-[var(--ide-border)]">
              <CardHeader>
                <CardTitle className="text-[var(--ide-text)] text-sm flex items-center gap-2">
                  <FileSearch className="h-4 w-4" />
                  Global Content Search
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Search in file contents..."
                    value={contentSearch}
                    onChange={(e) => setContentSearch(e.target.value)}
                    className="flex-1"
                  />
                  <SoundButton
                    onClick={() => searchFileContent(contentSearch)}
                    className="bg-green-600 hover:bg-green-500"
                  >
                    <Search className="h-4 w-4 mr-2" />
                    Search
                  </SoundButton>
                </div>

                <div className="flex items-center gap-4 text-sm text-[var(--ide-text-secondary)]">
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded" />
                    Case sensitive
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded" />
                    Whole word
                  </label>
                  <label className="flex items-center gap-2">
                    <input type="checkbox" className="rounded" />
                    Regular expression
                  </label>
                </div>
              </CardContent>
            </Card>

            <ScrollArea className="flex-1">
              <div className="space-y-4">
                {searchResults.map((result, index) => (
                  <Card key={index} className="bg-[var(--ide-surface-secondary)] border-[var(--ide-border)]">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center gap-2">
                        {getFileIcon(result.file)}
                        {result.file.name}
                        <Badge variant="outline" className="ml-auto">
                          {result.matches.length} matches
                        </Badge>
                      </CardTitle>
                      <p className="text-xs text-[var(--ide-text-secondary)]">{result.file.path}</p>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {result.matches.slice(0, 3).map((match, matchIndex) => (
                        <div key={matchIndex} className="bg-[var(--ide-surface)] p-3 rounded border">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs text-[var(--ide-text-secondary)]">Line {match.line}</span>
                          </div>
                          <code className="text-sm text-[var(--ide-text)] block">
                            {match.content.replace(
                              new RegExp(match.match, 'gi'),
                              '<mark className="bg-yellow-400 text-black">$&</mark>'
                            )}
                          </code>
                        </div>
                      ))}
                      {result.matches.length > 3 && (
                        <p className="text-xs text-[var(--ide-text-secondary)]">
                          +{result.matches.length - 3} more matches
                        </p>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          {/* Recent Files Tab */}
          <TabsContent value="recent" className="flex-1">
            <ScrollArea className="h-full">
              <div className="space-y-2">
                {recentFiles.map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-[var(--ide-surface-secondary)] cursor-pointer"
                  >
                    <FileText className="h-4 w-4 text-gray-400" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[var(--ide-text)]">{file.name}</span>
                        <Badge variant="outline" className="text-xs">
                          {file.language}
                        </Badge>
                      </div>
                      <div className="text-xs text-[var(--ide-text-secondary)] flex items-center gap-4">
                        <span>{file.path}</span>
                        <span>Opened {file.lastOpened.toLocaleString()}</span>
                      </div>
                    </div>
                    <TooltipWrapper
                      title="Open File"
                      content="Open this recently accessed file"
                      type="feature"
                    >
                      <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                        <Eye className="h-3 w-3" />
                      </Button>
                    </TooltipWrapper>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          {/* Bookmarks Tab */}
          <TabsContent value="bookmarks" className="flex-1">
            <ScrollArea className="h-full">
              <div className="space-y-2">
                {filteredFiles
                  .filter(file => bookmarkedFiles.includes(file.id))
                  .map((file) => (
                    <div
                      key={file.id}
                      className="flex items-center gap-3 p-3 rounded-lg hover:bg-[var(--ide-surface-secondary)] cursor-pointer"
                    >
                      {getFileIcon(file)}
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[var(--ide-text)]">{file.name}</span>
                          <Star className="h-3 w-3 text-yellow-400 fill-current" />
                        </div>
                        <div className="text-xs text-[var(--ide-text-secondary)]">
                          {file.path}
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </ScrollArea>
          </TabsContent>

          {/* File Operations Tab */}
          <TabsContent value="operations" className="flex-1 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-[var(--ide-surface-secondary)] border-[var(--ide-border)]">
                <CardHeader>
                  <CardTitle className="text-sm">Bulk Operations</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex gap-2">
                    <select
                      value={compressionFormat}
                      onChange={(e) => setCompressionFormat(e.target.value as any)}
                      className="flex-1 px-3 py-2 bg-[var(--ide-surface)] border border-[var(--ide-border)] rounded"
                    >
                      <option value="zip">ZIP Archive</option>
                      <option value="tar">TAR Archive</option>
                      <option value="tar.gz">TAR.GZ Archive</option>
                    </select>
                    <SoundButton
                      onClick={() => createArchive(compressionFormat)}
                      disabled={selectedFiles.length === 0}
                      className="bg-purple-600 hover:bg-purple-500"
                    >
                      Create
                    </SoundButton>
                  </div>
                  
                  <SoundButton
                    onClick={() => console.log('Batch delete:', selectedFiles)}
                    disabled={selectedFiles.length === 0}
                    variant="destructive"
                    className="w-full"
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete Selected ({selectedFiles.length})
                  </SoundButton>
                </CardContent>
              </Card>

              <Card className="bg-[var(--ide-surface-secondary)] border-[var(--ide-border)]">
                <CardHeader>
                  <CardTitle className="text-sm">File Templates</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {[
                    { name: 'React Component', ext: '.tsx' },
                    { name: 'Python Script', ext: '.py' },
                    { name: 'CSS Stylesheet', ext: '.css' },
                    { name: 'Markdown Document', ext: '.md' },
                    { name: 'JSON Config', ext: '.json' }
                  ].map((template) => (
                    <SoundButton
                      key={template.name}
                      variant="outline"
                      onClick={() => console.log('Create template:', template)}
                      className="w-full justify-start"
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      {template.name}
                    </SoundButton>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* File Compare Tab */}
          <TabsContent value="compare" className="flex-1">
            {selectedForCompare.length === 2 ? (
              <div className="grid grid-cols-2 gap-4 h-full">
                {selectedForCompare.map((file, index) => (
                  <Card key={index} className="bg-[var(--ide-surface-secondary)] border-[var(--ide-border)]">
                    <CardHeader>
                      <CardTitle className="text-sm flex items-center gap-2">
                        {getFileIcon(file)}
                        {file.name}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-96">
                        <pre className="text-sm text-[var(--ide-text)] whitespace-pre-wrap">
                          {/* Mock file content for comparison */}
                          {`// File content for ${file.name}
function example() {
  console.log("This is ${file.name}");
  return "Sample content";
}`}
                        </pre>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-center text-[var(--ide-text-secondary)]">
                <div>
                  <Diff className="h-16 w-16 mx-auto mb-4 opacity-50" />
                  <h3 className="text-lg font-medium mb-2">No Files Selected for Comparison</h3>
                  <p>Select exactly 2 files from the Explorer tab to compare them side by side.</p>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Hidden file input for uploads */}
        <input
          ref={fileInputRef}
          type="file"
          multiple
          onChange={handleFileUpload}
          className="hidden"
        />
      </DialogContent>
    </Dialog>
  );
}