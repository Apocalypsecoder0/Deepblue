import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Terminal, 
  Plus, 
  X, 
  Play, 
  Square,
  RotateCcw,
  History,
  Settings,
  Monitor,
  Cpu,
  HardDrive,
  Wifi
} from "lucide-react";

interface MultiTerminalSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface TerminalSession {
  id: string;
  name: string;
  isActive: boolean;
  directory: string;
  shell: string;
  history: string[];
  output: string[];
  isRunning: boolean;
  startTime: Date;
}

interface SystemStats {
  cpu: number;
  memory: number;
  disk: number;
  network: number;
}

export default function MultiTerminalSystem({ isOpen, onClose }: MultiTerminalSystemProps) {
  const [terminals, setTerminals] = useState<TerminalSession[]>([
    {
      id: 'terminal-1',
      name: 'Main Terminal',
      isActive: true,
      directory: '/home/project',
      shell: 'bash',
      history: ['npm install', 'npm run dev', 'git status'],
      output: ['Welcome to DeepBlue IDE Terminal v2.1.0'],
      isRunning: false,
      startTime: new Date()
    }
  ]);
  
  const [activeTerminal, setActiveTerminal] = useState('terminal-1');
  const [currentCommand, setCurrentCommand] = useState('');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [autoScrollEnabled, setAutoScrollEnabled] = useState(true);
  const [systemStats, setSystemStats] = useState<SystemStats>({
    cpu: 45,
    memory: 68,
    disk: 32,
    network: 15
  });

  const terminalOutputRef = useRef<HTMLDivElement>(null);

  const supportedLanguages = [
    { name: 'JavaScript/Node.js', command: 'node', ext: '.js', example: 'node app.js' },
    { name: 'TypeScript', command: 'tsx', ext: '.ts', example: 'tsx script.ts' },
    { name: 'Python', command: 'python', ext: '.py', example: 'python script.py' },
    { name: 'Java', command: 'java', ext: '.java', example: 'java Main' },
    { name: 'C++', command: 'g++', ext: '.cpp', example: 'g++ -o main main.cpp && ./main' },
    { name: 'C', command: 'gcc', ext: '.c', example: 'gcc -o main main.c && ./main' },
    { name: 'Rust', command: 'cargo', ext: '.rs', example: 'cargo run' },
    { name: 'Go', command: 'go', ext: '.go', example: 'go run main.go' },
    { name: 'PHP', command: 'php', ext: '.php', example: 'php script.php' },
    { name: 'Ruby', command: 'ruby', ext: '.rb', example: 'ruby script.rb' },
    { name: 'Bash', command: 'bash', ext: '.sh', example: 'bash script.sh' }
  ];

  const quickCommands = [
    { name: 'List Files', command: 'ls -la', description: 'List all files and directories' },
    { name: 'Git Status', command: 'git status', description: 'Check Git repository status' },
    { name: 'NPM Install', command: 'npm install', description: 'Install Node.js dependencies' },
    { name: 'NPM Start', command: 'npm start', description: 'Start development server' },
    { name: 'System Info', command: 'uname -a', description: 'Display system information' },
    { name: 'Processes', command: 'ps aux', description: 'List running processes' },
    { name: 'Disk Usage', command: 'df -h', description: 'Show disk space usage' },
    { name: 'Memory Usage', command: 'free -h', description: 'Show memory usage' }
  ];

  useEffect(() => {
    if (autoScrollEnabled && terminalOutputRef.current) {
      terminalOutputRef.current.scrollTop = terminalOutputRef.current.scrollHeight;
    }
  }, [terminals, autoScrollEnabled]);

  useEffect(() => {
    // Simulate system stats updates
    const interval = setInterval(() => {
      setSystemStats(prev => ({
        cpu: Math.max(0, Math.min(100, prev.cpu + (Math.random() - 0.5) * 10)),
        memory: Math.max(0, Math.min(100, prev.memory + (Math.random() - 0.5) * 5)),
        disk: Math.max(0, Math.min(100, prev.disk + (Math.random() - 0.5) * 2)),
        network: Math.max(0, Math.min(100, Math.random() * 50))
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const createNewTerminal = () => {
    const newId = `terminal-${terminals.length + 1}`;
    const newTerminal: TerminalSession = {
      id: newId,
      name: `Terminal ${terminals.length + 1}`,
      isActive: false,
      directory: '/home/project',
      shell: 'bash',
      history: [],
      output: [`Terminal ${terminals.length + 1} initialized`],
      isRunning: false,
      startTime: new Date()
    };

    setTerminals(prev => [...prev, newTerminal]);
    setActiveTerminal(newId);
  };

  const closeTerminal = (terminalId: string) => {
    if (terminals.length === 1) return; // Don't close the last terminal

    setTerminals(prev => prev.filter(t => t.id !== terminalId));
    
    if (activeTerminal === terminalId) {
      const remainingTerminals = terminals.filter(t => t.id !== terminalId);
      setActiveTerminal(remainingTerminals[0]?.id || '');
    }
  };

  const executeCommand = async (command: string) => {
    if (!command.trim()) return;

    const terminal = terminals.find(t => t.id === activeTerminal);
    if (!terminal) return;

    // Add command to history
    setCommandHistory(prev => [...prev, command]);
    setHistoryIndex(-1);
    
    // Update terminal
    setTerminals(prev => prev.map(t => 
      t.id === activeTerminal 
        ? {
            ...t,
            history: [...t.history, command],
            output: [...t.output, `$ ${command}`, '']
          }
        : t
    ));

    // Simulate command execution
    setTimeout(() => {
      const output = simulateCommandExecution(command);
      setTerminals(prev => prev.map(t => 
        t.id === activeTerminal 
          ? {
              ...t,
              output: [...t.output.slice(0, -1), output, '']
            }
          : t
      ));
    }, 500);

    setCurrentCommand('');
  };

  const simulateCommandExecution = (command: string): string => {
    const cmd = command.toLowerCase().trim();
    
    if (cmd === 'ls' || cmd === 'ls -la') {
      return `drwxr-xr-x  12 user user  4096 Jul  1 14:30 .
drwxr-xr-x   3 user user  4096 Jul  1 14:30 ..
-rw-r--r--   1 user user   220 Jul  1 14:30 .bashrc
-rw-r--r--   1 user user  3526 Jul  1 14:30 .gitignore
drwxr-xr-x   8 user user  4096 Jul  1 14:30 .git
-rw-r--r--   1 user user  1024 Jul  1 14:30 package.json
drwxr-xr-x   2 user user  4096 Jul  1 14:30 src
drwxr-xr-x   2 user user  4096 Jul  1 14:30 dist`;
    }
    
    if (cmd === 'pwd') {
      return '/home/project';
    }
    
    if (cmd === 'git status') {
      return `On branch main
Your branch is up to date with 'origin/main'.

Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)
        new file:   client/src/components/ide/multi-terminal-system.tsx

Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)
        modified:   replit.md

Untracked files:
  (use "git add <file>..." to include in what will be committed)
        temp/`;
    }
    
    if (cmd.startsWith('npm')) {
      return `npm WARN deprecated package@1.0.0: This package is deprecated
npm notice created a lockfile as package-lock.json
added 1254 packages in 45.231s`;
    }
    
    if (cmd === 'ps aux') {
      return `USER       PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         1  0.0  0.1  19516  3420 ?        Ss   14:30   0:01 /sbin/init
user      1234  0.5  2.3 123456 23456 pts/0    S+   14:30   0:02 node server.js
user      1235  1.2  3.4 234567 34567 pts/1    S+   14:31   0:05 tsx dev.ts`;
    }
    
    if (cmd === 'df -h') {
      return `Filesystem      Size  Used Avail Use% Mounted on
/dev/sda1        20G  6.4G   12G  35% /
tmpfs           2.0G     0  2.0G   0% /dev/shm
/dev/sda2       100G   45G   50G  48% /home`;
    }
    
    if (cmd === 'free -h') {
      return `              total        used        free      shared  buff/cache   available
Mem:           7.8G        2.1G        3.2G        128M        2.5G        5.3G
Swap:          2.0G          0B        2.0G`;
    }
    
    if (cmd.startsWith('node ') || cmd.startsWith('python ') || cmd.startsWith('java ')) {
      return `Executing ${cmd}...
Process completed successfully.
Exit code: 0`;
    }
    
    return `Command executed: ${command}
Output would appear here in a real terminal environment.`;
  };

  const executeQuickCommand = (command: string) => {
    setCurrentCommand(command);
    executeCommand(command);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      executeCommand(currentCommand);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (historyIndex < commandHistory.length - 1) {
        const newIndex = historyIndex + 1;
        setHistoryIndex(newIndex);
        setCurrentCommand(commandHistory[commandHistory.length - 1 - newIndex]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1;
        setHistoryIndex(newIndex);
        setCurrentCommand(commandHistory[commandHistory.length - 1 - newIndex]);
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setCurrentCommand('');
      }
    }
  };

  const currentTerminal = terminals.find(t => t.id === activeTerminal);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-900 border border-gray-700 rounded-lg w-[95vw] h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <Terminal className="w-6 h-6 text-blue-400" />
            <div>
              <h2 className="text-lg font-semibold text-white">Multi-Terminal System</h2>
              <p className="text-sm text-gray-400">Advanced terminal management with multiple sessions</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            ✕
          </Button>
        </div>

        {/* Content */}
        <div className="flex flex-1 overflow-hidden">
          {/* Terminal Area */}
          <div className="flex-1 flex flex-col">
            {/* Terminal Tabs */}
            <div className="flex items-center justify-between p-2 bg-gray-800 border-b border-gray-700">
              <div className="flex items-center gap-1">
                {terminals.map((terminal) => (
                  <div key={terminal.id} className="flex items-center">
                    <Button
                      variant={activeTerminal === terminal.id ? "secondary" : "ghost"}
                      size="sm"
                      onClick={() => setActiveTerminal(terminal.id)}
                      className="px-3 py-1 h-auto"
                    >
                      <Terminal className="w-3 h-3 mr-1" />
                      {terminal.name}
                    </Button>
                    {terminals.length > 1 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => closeTerminal(terminal.id)}
                        className="px-1 py-1 h-auto ml-1"
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                ))}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={createNewTerminal}
                  className="px-2 py-1 h-auto"
                >
                  <Plus className="w-3 h-3" />
                </Button>
              </div>
              
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{terminals.length} Terminal{terminals.length !== 1 ? 's' : ''}</Badge>
                <div className="flex items-center gap-1">
                  <Switch 
                    checked={autoScrollEnabled}
                    onCheckedChange={setAutoScrollEnabled}
                  />
                  <span className="text-xs text-gray-400">Auto-scroll</span>
                </div>
              </div>
            </div>

            {/* Terminal Output */}
            <div 
              ref={terminalOutputRef}
              className="flex-1 bg-black p-4 overflow-y-auto font-mono text-sm text-green-400"
            >
              {currentTerminal?.output.map((line, index) => (
                <div key={index} className="whitespace-pre-wrap">
                  {line}
                </div>
              ))}
            </div>

            {/* Command Input */}
            <div className="p-3 bg-gray-800 border-t border-gray-700">
              <div className="flex items-center gap-2">
                <span className="text-green-400 font-mono">$</span>
                <Input
                  value={currentCommand}
                  onChange={(e) => setCurrentCommand(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Enter command..."
                  className="flex-1 bg-black border-gray-600 text-green-400 font-mono"
                />
                <Button 
                  size="sm" 
                  onClick={() => executeCommand(currentCommand)}
                  disabled={!currentCommand.trim()}
                >
                  <Play className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Side Panel */}
          <div className="w-80 bg-gray-800 border-l border-gray-700 flex flex-col">
            <Tabs defaultValue="commands" className="flex-1 flex flex-col">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="commands">Commands</TabsTrigger>
                <TabsTrigger value="languages">Languages</TabsTrigger>
                <TabsTrigger value="system">System</TabsTrigger>
              </TabsList>
              
              <TabsContent value="commands" className="flex-1 p-4">
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-semibold text-white mb-2">Quick Commands</h4>
                    <ScrollArea className="h-60">
                      <div className="space-y-2">
                        {quickCommands.map((cmd, index) => (
                          <Card key={index} className="p-3 bg-gray-700 border-gray-600 cursor-pointer hover:bg-gray-600" 
                                onClick={() => executeQuickCommand(cmd.command)}>
                            <div className="flex items-center justify-between">
                              <span className="text-sm font-medium text-white">{cmd.name}</span>
                              <Play className="w-3 h-3 text-gray-400" />
                            </div>
                            <p className="text-xs text-gray-400 mt-1">{cmd.description}</p>
                            <code className="text-xs text-green-400 mt-1 block">{cmd.command}</code>
                          </Card>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-white mb-2">Command History</h4>
                    <ScrollArea className="h-32">
                      <div className="space-y-1">
                        {commandHistory.slice(-10).reverse().map((cmd, index) => (
                          <div key={index} 
                               className="text-xs text-gray-400 p-2 bg-gray-700 rounded cursor-pointer hover:bg-gray-600"
                               onClick={() => setCurrentCommand(cmd)}>
                            <code>{cmd}</code>
                          </div>
                        ))}
                        {commandHistory.length === 0 && (
                          <p className="text-xs text-gray-500">No command history</p>
                        )}
                      </div>
                    </ScrollArea>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="languages" className="flex-1 p-4">
                <div>
                  <h4 className="text-sm font-semibold text-white mb-2">Supported Languages</h4>
                  <ScrollArea className="h-96">
                    <div className="space-y-2">
                      {supportedLanguages.map((lang, index) => (
                        <Card key={index} className="p-3 bg-gray-700 border-gray-600">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-white">{lang.name}</span>
                            <Badge variant="outline" className="text-xs">{lang.ext}</Badge>
                          </div>
                          <p className="text-xs text-gray-400 mt-1">Command: {lang.command}</p>
                          <code className="text-xs text-green-400 mt-1 block">{lang.example}</code>
                        </Card>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              </TabsContent>
              
              <TabsContent value="system" className="flex-1 p-4">
                <div className="space-y-4">
                  <h4 className="text-sm font-semibold text-white mb-2">System Monitoring</h4>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Cpu className="w-4 h-4 text-blue-400" />
                        <span className="text-sm text-white">CPU Usage</span>
                      </div>
                      <span className="text-sm text-gray-400">{systemStats.cpu.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-blue-400 h-2 rounded-full transition-all" 
                        style={{ width: `${systemStats.cpu}%` }}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Monitor className="w-4 h-4 text-green-400" />
                        <span className="text-sm text-white">Memory</span>
                      </div>
                      <span className="text-sm text-gray-400">{systemStats.memory.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-green-400 h-2 rounded-full transition-all" 
                        style={{ width: `${systemStats.memory}%` }}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <HardDrive className="w-4 h-4 text-yellow-400" />
                        <span className="text-sm text-white">Disk Usage</span>
                      </div>
                      <span className="text-sm text-gray-400">{systemStats.disk.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-yellow-400 h-2 rounded-full transition-all" 
                        style={{ width: `${systemStats.disk}%` }}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Wifi className="w-4 h-4 text-purple-400" />
                        <span className="text-sm text-white">Network</span>
                      </div>
                      <span className="text-sm text-gray-400">{systemStats.network.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-purple-400 h-2 rounded-full transition-all" 
                        style={{ width: `${systemStats.network}%` }}
                      />
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <h5 className="text-sm font-semibold text-white mb-2">Active Terminals</h5>
                    <div className="space-y-2">
                      {terminals.map((terminal) => (
                        <Card key={terminal.id} className="p-2 bg-gray-700 border-gray-600">
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-white">{terminal.name}</span>
                            <Badge variant={terminal.id === activeTerminal ? "secondary" : "outline"} className="text-xs">
                              {terminal.shell}
                            </Badge>
                          </div>
                          <p className="text-xs text-gray-400">{terminal.directory}</p>
                          <p className="text-xs text-gray-500">Started: {terminal.startTime.toLocaleTimeString()}</p>
                        </Card>
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}