import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Download, RefreshCw, CheckCircle, AlertTriangle, Info, Star, Crown, Zap } from "lucide-react";

interface UpdateSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Update {
  id: string;
  version: string;
  type: 'major' | 'minor' | 'patch' | 'security';
  title: string;
  description: string;
  features: string[];
  fixes: string[];
  size: string;
  releaseDate: string;
  isRequired: boolean;
  proOnly: boolean;
}

interface SystemInfo {
  currentVersion: string;
  lastUpdate: string;
  nextUpdate: string;
  userTier: 'free' | 'pro';
}

export default function UpdateSystem({ isOpen, onClose }: UpdateSystemProps) {
  const [activeTab, setActiveTab] = useState<'updates' | 'patches' | 'system'>('updates');
  const [isUpdating, setIsUpdating] = useState(false);
  const [updateProgress, setUpdateProgress] = useState(0);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [systemInfo, setSystemInfo] = useState<SystemInfo>({
    currentVersion: '1.5.2',
    lastUpdate: '2025-01-01',
    nextUpdate: '2025-01-15',
    userTier: 'free'
  });

  const availableUpdates: Update[] = [
    {
      id: '1',
      version: '1.6.0',
      type: 'major',
      title: 'Advanced AI Integration',
      description: 'Enhanced AI assistant with GPT-4 integration and code completion',
      features: [
        'GPT-4 powered code completion',
        'Advanced refactoring suggestions',
        'Intelligent error detection',
        'Auto-documentation generation'
      ],
      fixes: ['Fixed memory leaks in terminal', 'Improved file system performance'],
      size: '245 MB',
      releaseDate: '2025-01-15',
      isRequired: false,
      proOnly: true
    },
    {
      id: '2',
      version: '1.5.3',
      type: 'patch',
      title: 'Security & Performance',
      description: 'Critical security updates and performance improvements',
      features: ['Enhanced security protocols', 'Faster compilation times'],
      fixes: [
        'Fixed XSS vulnerability in editor',
        'Resolved terminal crash issues',
        'Fixed file upload security hole'
      ],
      size: '89 MB',
      releaseDate: '2025-01-08',
      isRequired: true,
      proOnly: false
    },
    {
      id: '3',
      version: '1.5.4',
      type: 'minor',
      title: 'UI/UX Improvements',
      description: 'Enhanced user interface and new themes',
      features: [
        'New dark themes',
        'Improved accessibility',
        'Custom color schemes',
        'Better mobile responsiveness'
      ],
      fixes: ['Fixed theme switching bugs', 'Improved tooltip positioning'],
      size: '156 MB',
      releaseDate: '2025-01-10',
      isRequired: false,
      proOnly: false
    }
  ];

  const patchHistory = [
    {
      version: '1.5.2',
      date: '2025-01-01',
      type: 'patch',
      description: 'Fixed critical game engine rendering issues',
      status: 'installed'
    },
    {
      version: '1.5.1',
      date: '2024-12-28',
      type: 'hotfix',
      description: 'Emergency fix for terminal crash',
      status: 'installed'
    },
    {
      version: '1.5.0',
      date: '2024-12-25',
      type: 'major',
      description: 'DeepBlue:Octopus v1.5 release with game engine',
      status: 'installed'
    }
  ];

  const startUpdate = async (updateId: string) => {
    const update = availableUpdates.find(u => u.id === updateId);
    if (!update) return;

    if (update.proOnly && systemInfo.userTier === 'free') {
      alert('This update requires DeepBlue:Octopus Pro subscription');
      return;
    }

    setIsUpdating(true);
    setUpdateProgress(0);
    setDownloadProgress(0);

    // Simulate download progress
    for (let i = 0; i <= 100; i += 5) {
      await new Promise(resolve => setTimeout(resolve, 100));
      setDownloadProgress(i);
    }

    // Simulate installation progress
    for (let i = 0; i <= 100; i += 10) {
      await new Promise(resolve => setTimeout(resolve, 200));
      setUpdateProgress(i);
    }

    setIsUpdating(false);
    setUpdateProgress(100);
    
    // Update system info
    setSystemInfo(prev => ({
      ...prev,
      currentVersion: update.version,
      lastUpdate: new Date().toISOString().split('T')[0]
    }));
  };

  const getUpdateBadge = (type: string) => {
    const badges = {
      major: <Badge className="bg-purple-500">Major</Badge>,
      minor: <Badge className="bg-blue-500">Minor</Badge>,
      patch: <Badge className="bg-green-500">Patch</Badge>,
      security: <Badge className="bg-red-500">Security</Badge>
    };
    return badges[type as keyof typeof badges];
  };

  const getProBadge = () => (
    <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black">
      <Crown className="w-3 h-3 mr-1" />
      Pro Only
    </Badge>
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[80vh] bg-[var(--ide-bg)] border-[var(--ide-border)]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[var(--ide-text)]">
            <RefreshCw className="w-5 h-5" />
            DeepBlue:Octopus Update Center
          </DialogTitle>
          <DialogDescription className="text-[var(--ide-text-secondary)]">
            Manage updates, patches, and system information
          </DialogDescription>
        </DialogHeader>

        <div className="flex h-full">
          {/* Sidebar */}
          <div className="w-48 border-r border-[var(--ide-border)] pr-4">
            <div className="space-y-2">
              <Button
                variant={activeTab === 'updates' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => setActiveTab('updates')}
              >
                <Download className="w-4 h-4 mr-2" />
                Updates
              </Button>
              <Button
                variant={activeTab === 'patches' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => setActiveTab('patches')}
              >
                <Zap className="w-4 h-4 mr-2" />
                Patch History
              </Button>
              <Button
                variant={activeTab === 'system' ? 'default' : 'ghost'}
                className="w-full justify-start"
                onClick={() => setActiveTab('system')}
              >
                <Info className="w-4 h-4 mr-2" />
                System Info
              </Button>
            </div>

            <Separator className="my-4" />

            {/* System Status */}
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-[var(--ide-text-secondary)]">Version:</span>
                <span className="text-[var(--ide-text)]">{systemInfo.currentVersion}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--ide-text-secondary)]">Tier:</span>
                <div className="flex items-center gap-1">
                  {systemInfo.userTier === 'pro' ? (
                    <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-xs">
                      <Crown className="w-3 h-3 mr-1" />
                      Pro
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-xs">Free</Badge>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 pl-6">
            {activeTab === 'updates' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-[var(--ide-text)]">Available Updates</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-[var(--ide-text)]"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Check for Updates
                  </Button>
                </div>

                {isUpdating && (
                  <Alert>
                    <Download className="h-4 w-4" />
                    <AlertDescription>
                      <div className="space-y-2">
                        <div>Downloading update... {downloadProgress}%</div>
                        <Progress value={downloadProgress} className="w-full" />
                        <div>Installing update... {updateProgress}%</div>
                        <Progress value={updateProgress} className="w-full" />
                      </div>
                    </AlertDescription>
                  </Alert>
                )}

                <ScrollArea className="h-[500px]">
                  <div className="space-y-4">
                    {availableUpdates.map((update) => (
                      <Card key={update.id} className="border-[var(--ide-border)]">
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div>
                              <CardTitle className="flex items-center gap-2 text-[var(--ide-text)]">
                                {update.title}
                                {getUpdateBadge(update.type)}
                                {update.proOnly && getProBadge()}
                                {update.isRequired && (
                                  <Badge className="bg-red-500">Required</Badge>
                                )}
                              </CardTitle>
                              <p className="text-sm text-[var(--ide-text-secondary)] mt-1">
                                Version {update.version} • {update.size} • {update.releaseDate}
                              </p>
                            </div>
                            <Button
                              onClick={() => startUpdate(update.id)}
                              disabled={isUpdating || (update.proOnly && systemInfo.userTier === 'free')}
                              className="bg-[var(--bioluminescent)] hover:bg-[var(--sea-foam)]"
                            >
                              Install
                            </Button>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-[var(--ide-text-secondary)] mb-3">
                            {update.description}
                          </p>

                          {update.features.length > 0 && (
                            <div className="mb-3">
                              <h4 className="font-medium text-[var(--ide-text)] mb-2">New Features:</h4>
                              <ul className="space-y-1 text-sm text-[var(--ide-text-secondary)]">
                                {update.features.map((feature, index) => (
                                  <li key={index} className="flex items-center gap-2">
                                    <Star className="w-3 h-3 text-[var(--bioluminescent)]" />
                                    {feature}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {update.fixes.length > 0 && (
                            <div>
                              <h4 className="font-medium text-[var(--ide-text)] mb-2">Bug Fixes:</h4>
                              <ul className="space-y-1 text-sm text-[var(--ide-text-secondary)]">
                                {update.fixes.map((fix, index) => (
                                  <li key={index} className="flex items-center gap-2">
                                    <CheckCircle className="w-3 h-3 text-green-500" />
                                    {fix}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}

            {activeTab === 'patches' && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-[var(--ide-text)]">Patch History</h3>
                <ScrollArea className="h-[500px]">
                  <div className="space-y-3">
                    {patchHistory.map((patch, index) => (
                      <Card key={index} className="border-[var(--ide-border)]">
                        <CardContent className="pt-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium text-[var(--ide-text)]">
                                  {patch.version}
                                </span>
                                {getUpdateBadge(patch.type)}
                                <CheckCircle className="w-4 h-4 text-green-500" />
                              </div>
                              <p className="text-sm text-[var(--ide-text-secondary)] mt-1">
                                {patch.description}
                              </p>
                            </div>
                            <div className="text-right text-sm text-[var(--ide-text-secondary)]">
                              {patch.date}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}

            {activeTab === 'system' && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-[var(--ide-text)]">System Information</h3>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Card className="border-[var(--ide-border)]">
                    <CardHeader>
                      <CardTitle className="text-[var(--ide-text)]">Version Info</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-[var(--ide-text-secondary)]">Current Version:</span>
                        <span className="text-[var(--ide-text)]">{systemInfo.currentVersion}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[var(--ide-text-secondary)]">Last Update:</span>
                        <span className="text-[var(--ide-text)]">{systemInfo.lastUpdate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[var(--ide-text-secondary)]">Next Update:</span>
                        <span className="text-[var(--ide-text)]">{systemInfo.nextUpdate}</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-[var(--ide-border)]">
                    <CardHeader>
                      <CardTitle className="text-[var(--ide-text)]">Subscription</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-[var(--ide-text-secondary)]">Current Plan:</span>
                        {systemInfo.userTier === 'pro' ? (
                          <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black">
                            <Crown className="w-3 h-3 mr-1" />
                            Pro
                          </Badge>
                        ) : (
                          <Badge variant="outline">Free</Badge>
                        )}
                      </div>
                      {systemInfo.userTier === 'free' && (
                        <div className="mt-4 p-3 bg-gradient-to-r from-purple-500/10 to-blue-500/10 rounded-lg border border-purple-500/20">
                          <h4 className="font-medium text-[var(--ide-text)] mb-2">Upgrade to Pro</h4>
                          <p className="text-sm text-[var(--ide-text-secondary)] mb-3">
                            Get access to advanced features, priority updates, and enhanced AI capabilities.
                          </p>
                          <Button className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600">
                            <Crown className="w-4 h-4 mr-2" />
                            Upgrade Now - $9.99/month
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}