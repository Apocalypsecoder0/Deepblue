import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Github, GitBranch, Upload, Download, 
  Plus, Search, Star, GitFork, Clock,
  CheckCircle, XCircle, AlertCircle,
  Key, Settings, Trash2, Copy,
  FileText, Code, Users, Eye
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface GitHubIntegrationProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Repository {
  id: number;
  name: string;
  full_name: string;
  description: string;
  private: boolean;
  html_url: string;
  clone_url: string;
  ssh_url: string;
  stargazers_count: number;
  forks_count: number;
  language: string;
  default_branch: string;
  updated_at: string;
}

interface GitHubUser {
  login: string;
  name: string;
  avatar_url: string;
  public_repos: number;
  followers: number;
  following: number;
}

export function GitHubIntegration({ isOpen, onClose }: GitHubIntegrationProps) {
  const [activeTab, setActiveTab] = useState('auth');
  const [token, setToken] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRepo, setSelectedRepo] = useState<Repository | null>(null);
  const [commitMessage, setCommitMessage] = useState('Update from DeepBlue IDE');
  const [selectedBranch, setBranch] = useState('main');
  const [newRepoName, setNewRepoName] = useState('');
  const [newRepoDescription, setNewRepoDescription] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check authentication status
  const { data: authStatus } = useQuery({
    queryKey: ['/api/github/status'],
    enabled: isOpen
  });

  // Get user repositories
  const { data: repositories = [], isLoading: reposLoading } = useQuery({
    queryKey: ['/api/github/repositories'],
    enabled: isOpen && isAuthenticated
  });

  // Get user information
  const { data: githubUser } = useQuery({
    queryKey: ['/api/github/user'],
    enabled: isOpen && isAuthenticated
  });

  // Authentication mutation
  const authMutation = useMutation({
    mutationFn: (token: string) => apiRequest('/api/github/auth', {
      method: 'POST',
      body: { token }
    }),
    onSuccess: () => {
      setIsAuthenticated(true);
      setActiveTab('repositories');
      queryClient.invalidateQueries({ queryKey: ['/api/github'] });
      toast({
        title: "GitHub Connected",
        description: "Successfully authenticated with GitHub",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Authentication Failed",
        description: error.message || "Invalid GitHub token",
        variant: "destructive",
      });
    }
  });

  // Push to repository mutation
  const pushMutation = useMutation({
    mutationFn: ({ repoName, message, branch }: { repoName: string, message: string, branch: string }) => 
      apiRequest('/api/github/push', {
        method: 'POST',
        body: { 
          repository: repoName,
          commitMessage: message,
          branch: branch
        }
      }),
    onSuccess: (data) => {
      toast({
        title: "Code Pushed Successfully",
        description: `Pushed to ${selectedRepo?.name} on branch ${selectedBranch}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/github'] });
    },
    onError: (error: any) => {
      toast({
        title: "Push Failed",
        description: error.message || "Failed to push code to repository",
        variant: "destructive",
      });
    }
  });

  // Clone repository mutation
  const cloneMutation = useMutation({
    mutationFn: (repoUrl: string) => apiRequest('/api/github/clone', {
      method: 'POST',
      body: { repositoryUrl: repoUrl }
    }),
    onSuccess: () => {
      toast({
        title: "Repository Cloned",
        description: "Successfully cloned repository to your workspace",
      });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Clone Failed",
        description: error.message || "Failed to clone repository",
        variant: "destructive",
      });
    }
  });

  // Create repository mutation
  const createRepoMutation = useMutation({
    mutationFn: ({ name, description, isPrivate }: { name: string, description: string, isPrivate: boolean }) =>
      apiRequest('/api/github/create-repo', {
        method: 'POST',
        body: { name, description, private: isPrivate }
      }),
    onSuccess: (data) => {
      toast({
        title: "Repository Created",
        description: `Successfully created repository ${newRepoName}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/github/repositories'] });
      setNewRepoName('');
      setNewRepoDescription('');
    },
    onError: (error: any) => {
      toast({
        title: "Creation Failed",
        description: error.message || "Failed to create repository",
        variant: "destructive",
      });
    }
  });

  useEffect(() => {
    if (authStatus?.authenticated) {
      setIsAuthenticated(true);
      setActiveTab('repositories');
    }
  }, [authStatus]);

  const handleAuthenticate = () => {
    if (!token.trim()) {
      toast({
        title: "Token Required",
        description: "Please enter your GitHub personal access token",
        variant: "destructive",
      });
      return;
    }
    authMutation.mutate(token);
  };

  const handlePush = () => {
    if (!selectedRepo || !commitMessage.trim()) {
      toast({
        title: "Missing Information",
        description: "Please select a repository and enter a commit message",
        variant: "destructive",
      });
      return;
    }
    
    pushMutation.mutate({
      repoName: selectedRepo.full_name,
      message: commitMessage,
      branch: selectedBranch
    });
  };

  const handleClone = (repo: Repository) => {
    cloneMutation.mutate(repo.clone_url);
  };

  const handleCreateRepo = () => {
    if (!newRepoName.trim()) {
      toast({
        title: "Repository Name Required",
        description: "Please enter a repository name",
        variant: "destructive",
      });
      return;
    }
    
    createRepoMutation.mutate({
      name: newRepoName,
      description: newRepoDescription,
      isPrivate
    });
  };

  const filteredRepos = repositories.filter((repo: Repository) =>
    repo.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    repo.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl w-full h-[85vh] max-h-[85vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Github className="h-5 w-5" />
            GitHub Integration
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid grid-cols-4 w-full">
            <TabsTrigger value="auth">Authentication</TabsTrigger>
            <TabsTrigger value="repositories" disabled={!isAuthenticated}>Repositories</TabsTrigger>
            <TabsTrigger value="push" disabled={!isAuthenticated}>Push Code</TabsTrigger>
            <TabsTrigger value="create" disabled={!isAuthenticated}>Create Repo</TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-hidden">
            <TabsContent value="auth" className="h-full">
              <Card className="h-full">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Key className="h-4 w-4" />
                    GitHub Authentication
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {!isAuthenticated ? (
                    <>
                      <Alert>
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>
                          You need a GitHub Personal Access Token to connect. 
                          <a 
                            href="https://github.com/settings/tokens" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-blue-500 hover:underline ml-1"
                          >
                            Generate one here
                          </a>
                        </AlertDescription>
                      </Alert>
                      
                      <div className="space-y-2">
                        <Label htmlFor="token">Personal Access Token</Label>
                        <Input
                          id="token"
                          type="password"
                          placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                          value={token}
                          onChange={(e) => setToken(e.target.value)}
                        />
                      </div>
                      
                      <Button 
                        onClick={handleAuthenticate}
                        disabled={authMutation.isPending}
                        className="w-full"
                      >
                        {authMutation.isPending ? "Connecting..." : "Connect to GitHub"}
                      </Button>
                    </>
                  ) : (
                    <div className="space-y-4">
                      <Alert>
                        <CheckCircle className="h-4 w-4" />
                        <AlertDescription>
                          Successfully connected to GitHub
                        </AlertDescription>
                      </Alert>
                      
                      {githubUser && (
                        <Card>
                          <CardContent className="pt-4">
                            <div className="flex items-center gap-4">
                              <img 
                                src={githubUser.avatar_url} 
                                alt={githubUser.name}
                                className="w-12 h-12 rounded-full"
                              />
                              <div>
                                <h3 className="font-semibold">{githubUser.name}</h3>
                                <p className="text-sm text-gray-500">@{githubUser.login}</p>
                                <div className="flex gap-4 text-sm text-gray-500 mt-1">
                                  <span>{githubUser.public_repos} repos</span>
                                  <span>{githubUser.followers} followers</span>
                                  <span>{githubUser.following} following</span>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="repositories" className="h-full">
              <Card className="h-full flex flex-col">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      Your Repositories
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <div className="relative">
                        <Search className="h-4 w-4 absolute left-2 top-2.5 text-gray-500" />
                        <Input
                          placeholder="Search repositories..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-8 w-64"
                        />
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden">
                  <ScrollArea className="h-full">
                    {reposLoading ? (
                      <div className="flex items-center justify-center h-32">
                        <div className="text-gray-500">Loading repositories...</div>
                      </div>
                    ) : filteredRepos.length === 0 ? (
                      <div className="flex items-center justify-center h-32">
                        <div className="text-gray-500">No repositories found</div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {filteredRepos.map((repo: Repository) => (
                          <Card key={repo.id} className="hover:shadow-md transition-shadow">
                            <CardContent className="p-4">
                              <div className="flex items-start justify-between">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-2">
                                    <h3 className="font-semibold text-blue-600 hover:underline">
                                      <a href={repo.html_url} target="_blank" rel="noopener noreferrer">
                                        {repo.name}
                                      </a>
                                    </h3>
                                    {repo.private && (
                                      <Badge variant="secondary">Private</Badge>
                                    )}
                                    {repo.language && (
                                      <Badge variant="outline">{repo.language}</Badge>
                                    )}
                                  </div>
                                  
                                  {repo.description && (
                                    <p className="text-sm text-gray-600 mb-2">{repo.description}</p>
                                  )}
                                  
                                  <div className="flex items-center gap-4 text-sm text-gray-500">
                                    <div className="flex items-center gap-1">
                                      <Star className="h-3 w-3" />
                                      {repo.stargazers_count}
                                    </div>
                                    <div className="flex items-center gap-1">
                                      <GitFork className="h-3 w-3" />
                                      {repo.forks_count}
                                    </div>
                                    <div className="flex items-center gap-1">
                                      <Clock className="h-3 w-3" />
                                      {new Date(repo.updated_at).toLocaleDateString()}
                                    </div>
                                  </div>
                                </div>
                                
                                <div className="flex gap-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleClone(repo)}
                                    disabled={cloneMutation.isPending}
                                  >
                                    <Download className="h-3 w-3 mr-1" />
                                    Clone
                                  </Button>
                                  <Button
                                    size="sm"
                                    onClick={() => {
                                      setSelectedRepo(repo);
                                      setActiveTab('push');
                                    }}
                                  >
                                    <Upload className="h-3 w-3 mr-1" />
                                    Select
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="push" className="h-full">
              <Card className="h-full">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Upload className="h-4 w-4" />
                    Push Code to GitHub
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {!selectedRepo ? (
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        Please select a repository from the Repositories tab first.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <>
                      <Card>
                        <CardContent className="pt-4">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold">{selectedRepo.name}</h3>
                            {selectedRepo.private && (
                              <Badge variant="secondary">Private</Badge>
                            )}
                          </div>
                          <p className="text-sm text-gray-600">{selectedRepo.description}</p>
                        </CardContent>
                      </Card>
                      
                      <div className="space-y-2">
                        <Label htmlFor="branch">Target Branch</Label>
                        <Select value={selectedBranch} onValueChange={setBranch}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="main">main</SelectItem>
                            <SelectItem value="master">master</SelectItem>
                            <SelectItem value="develop">develop</SelectItem>
                            <SelectItem value="feature/new">feature/new</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="commit-message">Commit Message</Label>
                        <Textarea
                          id="commit-message"
                          placeholder="Describe your changes..."
                          value={commitMessage}
                          onChange={(e) => setCommitMessage(e.target.value)}
                          rows={3}
                        />
                      </div>
                      
                      <Button 
                        onClick={handlePush}
                        disabled={pushMutation.isPending}
                        className="w-full"
                      >
                        {pushMutation.isPending ? "Pushing..." : "Push Code to Repository"}
                      </Button>
                    </>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="create" className="h-full">
              <Card className="h-full">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Plus className="h-4 w-4" />
                    Create New Repository
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="repo-name">Repository Name</Label>
                    <Input
                      id="repo-name"
                      placeholder="my-awesome-project"
                      value={newRepoName}
                      onChange={(e) => setNewRepoName(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="repo-description">Description (optional)</Label>
                    <Textarea
                      id="repo-description"
                      placeholder="What's this repository about?"
                      value={newRepoDescription}
                      onChange={(e) => setNewRepoDescription(e.target.value)}
                      rows={3}
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="private-repo"
                      checked={isPrivate}
                      onChange={(e) => setIsPrivate(e.target.checked)}
                      className="rounded"
                    />
                    <Label htmlFor="private-repo">Make repository private</Label>
                  </div>
                  
                  <Button 
                    onClick={handleCreateRepo}
                    disabled={createRepoMutation.isPending}
                    className="w-full"
                  >
                    {createRepoMutation.isPending ? "Creating..." : "Create Repository"}
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

export default GitHubIntegration;