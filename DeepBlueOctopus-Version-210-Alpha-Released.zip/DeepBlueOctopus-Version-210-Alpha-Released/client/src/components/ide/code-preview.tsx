import React, { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Play, Square, RefreshCw, ExternalLink, Monitor, Smartphone, 
  Tablet, Maximize2, Eye, Code, Settings, Download, Share2,
  AlertTriangle, CheckCircle, Globe, Zap
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { TooltipWrapper } from "@/components/ui/tooltip-system";

interface CodePreviewProps {
  isOpen: boolean;
  onClose: () => void;
}

interface PreviewFile {
  id: number;
  name: string;
  path: string;
  content: string;
  language: string;
}

interface PreviewSettings {
  autoRefresh: boolean;
  showGrid: boolean;
  showRuler: boolean;
  responsive: boolean;
  darkMode: boolean;
  scale: number;
  device: 'desktop' | 'tablet' | 'mobile';
}

const DEVICE_DIMENSIONS = {
  desktop: { width: '100%', height: '100%', label: 'Desktop' },
  tablet: { width: '768px', height: '1024px', label: 'Tablet' },
  mobile: { width: '375px', height: '667px', label: 'Mobile' }
};

const SAMPLE_FILES: PreviewFile[] = [
  {
    id: 1,
    name: 'index.html',
    path: '/index.html',
    content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Preview Demo</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>Welcome to Code Preview</h1>
            <p>Live preview of your HTML, CSS, and JavaScript</p>
        </header>
        
        <main class="main-content">
            <section class="demo-section">
                <h2>Interactive Demo</h2>
                <button id="demo-btn" class="demo-button">Click Me!</button>
                <div id="output" class="output-area"></div>
            </section>
            
            <section class="features">
                <h2>Features</h2>
                <div class="feature-grid">
                    <div class="feature-card">
                        <h3>🚀 Live Updates</h3>
                        <p>See changes instantly as you code</p>
                    </div>
                    <div class="feature-card">
                        <h3>📱 Responsive</h3>
                        <p>Test on different device sizes</p>
                    </div>
                    <div class="feature-card">
                        <h3>⚡ Fast</h3>
                        <p>Optimized for performance</p>
                    </div>
                </div>
            </section>
        </main>
    </div>
    <script src="script.js"></script>
</body>
</html>`,
    language: 'html'
  },
  {
    id: 2,
    name: 'styles.css',
    path: '/styles.css',
    content: `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    line-height: 1.6;
    color: #333;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
}

.header {
    text-align: center;
    margin-bottom: 3rem;
    color: white;
}

.header h1 {
    font-size: 2.5rem;
    margin-bottom: 0.5rem;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

.header p {
    font-size: 1.1rem;
    opacity: 0.9;
}

.main-content {
    background: white;
    border-radius: 12px;
    padding: 2rem;
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}

.demo-section {
    margin-bottom: 2rem;
    padding-bottom: 2rem;
    border-bottom: 2px solid #f0f0f0;
}

.demo-button {
    background: linear-gradient(45deg, #667eea, #764ba2);
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 8px;
    font-size: 1rem;
    cursor: pointer;
    transition: all 0.3s ease;
    margin: 1rem 0;
}

.demo-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
}

.output-area {
    background: #f8f9fa;
    border: 2px solid #e9ecef;
    border-radius: 8px;
    padding: 1rem;
    margin-top: 1rem;
    min-height: 60px;
    font-family: 'Monaco', monospace;
}

.features {
    margin-top: 2rem;
}

.features h2 {
    text-align: center;
    margin-bottom: 1.5rem;
    color: #333;
}

.feature-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
}

.feature-card {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    color: white;
    padding: 1.5rem;
    border-radius: 10px;
    text-align: center;
    transition: transform 0.3s ease;
}

.feature-card:hover {
    transform: translateY(-5px);
}

.feature-card h3 {
    margin-bottom: 0.5rem;
    font-size: 1.2rem;
}

@media (max-width: 768px) {
    .container {
        padding: 1rem;
    }
    
    .header h1 {
        font-size: 2rem;
    }
    
    .feature-grid {
        grid-template-columns: 1fr;
    }
}`,
    language: 'css'
  },
  {
    id: 3,
    name: 'script.js',
    path: '/script.js',
    content: `// Interactive JavaScript for Code Preview Demo

let clickCount = 0;
const colors = ['#667eea', '#764ba2', '#f093fb', '#f5576c', '#4facfe', '#00f2fe'];

document.addEventListener('DOMContentLoaded', function() {
    const demoBtn = document.getElementById('demo-btn');
    const output = document.getElementById('output');
    
    // Demo button click handler
    demoBtn.addEventListener('click', function() {
        clickCount++;
        
        // Change button color randomly
        const randomColor = colors[Math.floor(Math.random() * colors.length)];
        demoBtn.style.background = randomColor;
        
        // Update output area
        output.innerHTML = \`
            <div style="animation: fadeIn 0.5s ease-in;">
                <strong>Button clicked \${clickCount} time\${clickCount !== 1 ? 's' : ''}!</strong><br>
                <small>Time: \${new Date().toLocaleTimeString()}</small><br>
                <small>Random color: \${randomColor}</small>
            </div>
        \`;
        
        // Add some fun animations
        demoBtn.style.transform = 'scale(0.95)';
        setTimeout(() => {
            demoBtn.style.transform = 'scale(1)';
        }, 150);
    });
    
    // Add CSS animation
    const style = document.createElement('style');
    style.textContent = \`
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
    \`;
    document.head.appendChild(style);
    
    // Add some interactive effects to feature cards
    const featureCards = document.querySelectorAll('.feature-card');
    featureCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.animation = 'pulse 0.6s ease-in-out';
        });
        
        card.addEventListener('animationend', function() {
            this.style.animation = '';
        });
    });
    
    console.log('Code Preview Demo initialized!');
    console.log('Try clicking the button to see interactive features.');
});`,
    language: 'javascript'
  }
];

export function CodePreview({ isOpen, onClose }: CodePreviewProps) {
  const [activeTab, setActiveTab] = useState("preview");
  const [files, setFiles] = useState<PreviewFile[]>(SAMPLE_FILES);
  const [selectedFile, setSelectedFile] = useState<PreviewFile | null>(files[0]);
  const [previewContent, setPreviewContent] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [errors, setErrors] = useState<string[]>([]);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  
  const [settings, setSettings] = useState<PreviewSettings>({
    autoRefresh: true,
    showGrid: false,
    showRuler: false,
    responsive: true,
    darkMode: false,
    scale: 100,
    device: 'desktop'
  });

  // Generate preview content
  const generatePreview = () => {
    const htmlFile = files.find(f => f.language === 'html');
    const cssFile = files.find(f => f.language === 'css');
    const jsFile = files.find(f => f.language === 'javascript');
    
    if (!htmlFile) {
      setErrors(['No HTML file found for preview']);
      return;
    }

    let content = htmlFile.content;
    
    // Inject CSS
    if (cssFile) {
      content = content.replace(
        /<link[^>]*href=['"'][^'">]*styles\.css['"'][^>]*>/gi,
        `<style>${cssFile.content}</style>`
      );
    }
    
    // Inject JavaScript
    if (jsFile) {
      content = content.replace(
        /<script[^>]*src=['"'][^'">]*script\.js['"'][^>]*><\/script>/gi,
        `<script>${jsFile.content}</script>`
      );
    }
    
    // Add responsive meta tag if not present
    if (settings.responsive && !content.includes('viewport')) {
      content = content.replace(
        /<head>/i,
        '<head>\n<meta name="viewport" content="width=device-width, initial-scale=1.0">'
      );
    }
    
    setPreviewContent(content);
    setLastUpdated(new Date());
    setErrors([]);
  };

  // Auto refresh
  useEffect(() => {
    if (settings.autoRefresh && isOpen) {
      generatePreview();
    }
  }, [files, settings.autoRefresh, isOpen]);

  // Manual refresh
  const handleRefresh = () => {
    setIsLoading(true);
    setTimeout(() => {
      generatePreview();
      setIsLoading(false);
    }, 500);
  };

  // Update file content
  const updateFileContent = (fileId: number, newContent: string) => {
    setFiles(prev => prev.map(file => 
      file.id === fileId ? { ...file, content: newContent } : file
    ));
  };

  // Device preview dimensions
  const getDeviceDimensions = () => {
    const device = DEVICE_DIMENSIONS[settings.device];
    return {
      width: device.width,
      height: device.height,
      transform: `scale(${settings.scale / 100})`
    };
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh] ide-panel border-[var(--ide-border)]">
        <DialogHeader className="border-b border-[var(--ide-border)] pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Eye className="h-5 w-5 text-[var(--ide-accent)]" />
              <DialogTitle className="text-[var(--ide-text)]">Code Preview</DialogTitle>
              <Badge variant="outline" className="text-xs">
                Live Preview
              </Badge>
            </div>
            
            <div className="flex items-center space-x-2">
              <TooltipWrapper title="Refresh Preview" content="Manually refresh the preview content">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleRefresh}
                  disabled={isLoading}
                  className="text-[var(--ide-text-secondary)]"
                >
                  <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                </Button>
              </TooltipWrapper>
              
              <TooltipWrapper title="Open in New Tab" content="Open preview in a new browser tab">
                <Button size="sm" variant="outline" className="text-[var(--ide-text-secondary)]">
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </TooltipWrapper>
              
              <Select value={settings.device} onValueChange={(value: any) => 
                setSettings(prev => ({ ...prev, device: value }))
              }>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="desktop">
                    <div className="flex items-center space-x-2">
                      <Monitor className="h-4 w-4" />
                      <span>Desktop</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="tablet">
                    <div className="flex items-center space-x-2">
                      <Tablet className="h-4 w-4" />
                      <span>Tablet</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="mobile">
                    <div className="flex items-center space-x-2">
                      <Smartphone className="h-4 w-4" />
                      <span>Mobile</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 flex">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-4 bg-[var(--ide-bg)]">
              <TabsTrigger value="preview" className="text-[var(--ide-text)]">
                <Eye className="h-4 w-4 mr-2" />
                Preview
              </TabsTrigger>
              <TabsTrigger value="code" className="text-[var(--ide-text)]">
                <Code className="h-4 w-4 mr-2" />
                Code Editor
              </TabsTrigger>
              <TabsTrigger value="settings" className="text-[var(--ide-text)]">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </TabsTrigger>
              <TabsTrigger value="console" className="text-[var(--ide-text)]">
                <AlertTriangle className="h-4 w-4 mr-2" />
                Console
              </TabsTrigger>
            </TabsList>

            {/* Preview Tab */}
            <TabsContent value="preview" className="flex-1 p-4">
              <div className="h-full border border-[var(--ide-border)] rounded-lg overflow-hidden bg-white">
                {errors.length > 0 ? (
                  <div className="p-4">
                    <Alert>
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        {errors.map((error, i) => (
                          <div key={i}>{error}</div>
                        ))}
                      </AlertDescription>
                    </Alert>
                  </div>
                ) : (
                  <div className="h-full flex items-center justify-center" style={{ backgroundColor: '#f5f5f5' }}>
                    <div 
                      className="bg-white shadow-lg"
                      style={getDeviceDimensions()}
                    >
                      <iframe
                        ref={iframeRef}
                        srcDoc={previewContent}
                        className="w-full h-full border-0"
                        sandbox="allow-scripts allow-same-origin allow-forms"
                        title="Code Preview"
                      />
                    </div>
                  </div>
                )}
              </div>
              
              <div className="flex items-center justify-between mt-2 text-xs text-[var(--ide-text-secondary)]">
                <div className="flex items-center space-x-4">
                  <span>Last updated: {lastUpdated.toLocaleTimeString()}</span>
                  <Badge variant="outline" className="text-xs">
                    <Globe className="h-3 w-3 mr-1" />
                    {DEVICE_DIMENSIONS[settings.device].label}
                  </Badge>
                </div>
                <div className="flex items-center space-x-2">
                  <span>Scale: {settings.scale}%</span>
                  <Input
                    type="range"
                    min="25"
                    max="200"
                    step="25"
                    value={settings.scale}
                    onChange={(e) => setSettings(prev => ({ ...prev, scale: parseInt(e.target.value) }))}
                    className="w-20"
                  />
                </div>
              </div>
            </TabsContent>

            {/* Code Editor Tab */}
            <TabsContent value="code" className="flex-1 p-4">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-full">
                <div className="lg:col-span-1">
                  <h3 className="text-sm font-semibold text-[var(--ide-text)] mb-2">Files</h3>
                  <ScrollArea className="h-full border border-[var(--ide-border)] rounded-lg">
                    <div className="p-2 space-y-1">
                      {files.map((file) => (
                        <div
                          key={file.id}
                          className={`p-2 rounded cursor-pointer transition-colors ${
                            selectedFile?.id === file.id
                              ? 'bg-[var(--ide-accent)] text-white'
                              : 'hover:bg-[var(--ide-bg)] text-[var(--ide-text)]'
                          }`}
                          onClick={() => setSelectedFile(file)}
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-sm">{file.name}</span>
                            <Badge variant="secondary" className="text-xs">
                              {file.language}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
                
                <div className="lg:col-span-2">
                  {selectedFile && (
                    <div className="h-full flex flex-col">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-sm font-semibold text-[var(--ide-text)]">
                          Editing: {selectedFile.name}
                        </h3>
                        <Button
                          size="sm"
                          onClick={handleRefresh}
                          className="text-xs"
                        >
                          Update Preview
                        </Button>
                      </div>
                      <textarea
                        value={selectedFile.content}
                        onChange={(e) => updateFileContent(selectedFile.id, e.target.value)}
                        className="flex-1 p-3 border border-[var(--ide-border)] rounded-lg font-mono text-sm resize-none"
                        placeholder="Enter your code here..."
                      />
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings" className="flex-1 p-4">
              <div className="space-y-6 max-w-md">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-[var(--ide-text)]">Preview Settings</h3>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="auto-refresh" className="text-[var(--ide-text)]">Auto Refresh</Label>
                    <Switch
                      id="auto-refresh"
                      checked={settings.autoRefresh}
                      onCheckedChange={(checked) => setSettings(prev => ({ ...prev, autoRefresh: checked }))}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="responsive" className="text-[var(--ide-text)]">Responsive Mode</Label>
                    <Switch
                      id="responsive"
                      checked={settings.responsive}
                      onCheckedChange={(checked) => setSettings(prev => ({ ...prev, responsive: checked }))}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label htmlFor="show-grid" className="text-[var(--ide-text)]">Show Grid</Label>
                    <Switch
                      id="show-grid"
                      checked={settings.showGrid}
                      onCheckedChange={(checked) => setSettings(prev => ({ ...prev, showGrid: checked }))}
                    />
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-[var(--ide-text)]">Display Options</h3>
                  
                  <div className="space-y-2">
                    <Label className="text-[var(--ide-text)]">Preview Scale</Label>
                    <div className="flex items-center space-x-2">
                      <Input
                        type="range"
                        min="25"
                        max="200"
                        step="25"
                        value={settings.scale}
                        onChange={(e) => setSettings(prev => ({ ...prev, scale: parseInt(e.target.value) }))}
                        className="flex-1"
                      />
                      <span className="text-sm text-[var(--ide-text-secondary)] w-12">
                        {settings.scale}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Console Tab */}
            <TabsContent value="console" className="flex-1 p-4">
              <div className="h-full border border-[var(--ide-border)] rounded-lg bg-[var(--ide-bg)] p-4">
                <div className="flex items-center space-x-2 mb-4">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-[var(--ide-text)] text-sm">Preview Console</span>
                </div>
                
                <ScrollArea className="h-full">
                  <div className="space-y-2 font-mono text-sm">
                    <div className="text-green-400">✓ HTML file loaded successfully</div>
                    <div className="text-green-400">✓ CSS styles applied</div>
                    <div className="text-green-400">✓ JavaScript initialized</div>
                    <div className="text-blue-400">ℹ Preview ready at {lastUpdated.toLocaleTimeString()}</div>
                    {errors.length > 0 && (
                      <>
                        <div className="text-red-400">✗ Errors detected:</div>
                        {errors.map((error, i) => (
                          <div key={i} className="text-red-400 ml-4">{error}</div>
                        ))}
                      </>
                    )}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}