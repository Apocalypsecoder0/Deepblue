import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { 
  Package, 
  Search, 
  Download, 
  Trash2, 
  RefreshCw, 
  Star,
  ExternalLink,
  Plus,
  Settings,
  AlertTriangle,
  CheckCircle,
  Clock,
  Globe,
  User,
  Calendar,
  BarChart3,
  Filter,
  ArrowUpDown,
  Eye,
  Shield,
  Zap
} from "lucide-react";

interface PackageManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Package {
  name: string;
  version: string;
  description: string;
  author: string;
  homepage?: string;
  repository?: string;
  license: string;
  downloads: number;
  stars: number;
  lastUpdated: string;
  size: string;
  dependencies: number;
  keywords: string[];
  isInstalled: boolean;
  installedVersion?: string;
  hasUpdate: boolean;
  security: 'safe' | 'warning' | 'vulnerable';
}

interface ProjectDependency {
  name: string;
  version: string;
  type: 'dependency' | 'devDependency' | 'peerDependency';
  size: string;
  status: 'installed' | 'missing' | 'outdated';
  latestVersion: string;
}

export default function PackageManager({ isOpen, onClose }: PackageManagerProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('installed');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Package[]>([]);
  const [installedPackages, setInstalledPackages] = useState<ProjectDependency[]>([]);
  const [loading, setLoading] = useState(false);
  const [sortBy, setSortBy] = useState<'name' | 'downloads' | 'stars' | 'updated'>('downloads');
  const [filterSecurity, setFilterSecurity] = useState<'all' | 'safe' | 'warning' | 'vulnerable'>('all');

  useEffect(() => {
    if (isOpen) {
      loadInstalledPackages();
    }
  }, [isOpen]);

  const loadInstalledPackages = async () => {
    try {
      const response = await fetch('/api/packages/installed');
      const data = await response.json();
      setInstalledPackages(data);
    } catch (error) {
      console.error('Failed to load installed packages:', error);
      // Load sample packages
      setInstalledPackages([
        {
          name: 'react',
          version: '18.2.0',
          type: 'dependency',
          size: '2.3 MB',
          status: 'installed',
          latestVersion: '18.2.0'
        },
        {
          name: 'typescript',
          version: '5.0.2',
          type: 'devDependency',
          size: '8.7 MB',
          status: 'outdated',
          latestVersion: '5.3.3'
        },
        {
          name: 'vite',
          version: '4.4.5',
          type: 'devDependency',
          size: '15.2 MB',
          status: 'installed',
          latestVersion: '4.4.5'
        },
        {
          name: 'tailwindcss',
          version: '3.3.0',
          type: 'devDependency',
          size: '3.1 MB',
          status: 'outdated',
          latestVersion: '3.4.0'
        },
        {
          name: 'lucide-react',
          version: '0.263.1',
          type: 'dependency',
          size: '1.8 MB',
          status: 'installed',
          latestVersion: '0.263.1'
        }
      ]);
    }
  };

  const searchPackages = async () => {
    if (!searchQuery.trim()) return;

    setLoading(true);
    try {
      const response = await fetch(`/api/packages/search?q=${encodeURIComponent(searchQuery)}`);
      const data = await response.json();
      setSearchResults(data);
    } catch (error) {
      console.error('Failed to search packages:', error);
      // Load sample search results
      const sampleResults: Package[] = [
        {
          name: 'lodash',
          version: '4.17.21',
          description: 'A modern JavaScript utility library delivering modularity, performance, & extras.',
          author: 'John-David Dalton',
          homepage: 'https://lodash.com/',
          repository: 'https://github.com/lodash/lodash',
          license: 'MIT',
          downloads: 32000000,
          stars: 55000,
          lastUpdated: '2024-11-15',
          size: '526 kB',
          dependencies: 0,
          keywords: ['util', 'functional', 'server', 'client', 'browser'],
          isInstalled: false,
          hasUpdate: false,
          security: 'safe'
        },
        {
          name: 'axios',
          version: '1.6.2',
          description: 'Promise based HTTP client for the browser and node.js',
          author: 'Matt Zabriskie',
          homepage: 'https://axios-http.com',
          repository: 'https://github.com/axios/axios',
          license: 'MIT',
          downloads: 28000000,
          stars: 103000,
          lastUpdated: '2024-11-20',
          size: '472 kB',
          dependencies: 5,
          keywords: ['xhr', 'http', 'ajax', 'promise', 'node'],
          isInstalled: true,
          installedVersion: '1.5.0',
          hasUpdate: true,
          security: 'safe'
        },
        {
          name: 'express',
          version: '4.18.2',
          description: 'Fast, unopinionated, minimalist web framework',
          author: 'TJ Holowaychuk',
          homepage: 'http://expressjs.com/',
          repository: 'https://github.com/expressjs/express',
          license: 'MIT',
          downloads: 22000000,
          stars: 63000,
          lastUpdated: '2024-10-30',
          size: '209 kB',
          dependencies: 56,
          keywords: ['express', 'framework', 'sinatra', 'web', 'http'],
          isInstalled: false,
          hasUpdate: false,
          security: 'warning'
        },
        {
          name: 'moment',
          version: '2.29.4',
          description: 'Parse, validate, manipulate, and display dates',
          author: 'Iskren Ivov Chernev',
          homepage: 'http://momentjs.com',
          repository: 'https://github.com/moment/moment',
          license: 'MIT',
          downloads: 15000000,
          stars: 47000,
          lastUpdated: '2024-06-15',
          size: '288 kB',
          dependencies: 0,
          keywords: ['moment', 'date', 'time', 'parse', 'format'],
          isInstalled: false,
          hasUpdate: false,
          security: 'vulnerable'
        }
      ];
      
      // Filter and sort results
      let filtered = sampleResults.filter(pkg => 
        pkg.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        pkg.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        pkg.keywords.some(k => k.toLowerCase().includes(searchQuery.toLowerCase()))
      );
      
      if (filterSecurity !== 'all') {
        filtered = filtered.filter(pkg => pkg.security === filterSecurity);
      }
      
      filtered.sort((a, b) => {
        switch (sortBy) {
          case 'name': return a.name.localeCompare(b.name);
          case 'downloads': return b.downloads - a.downloads;
          case 'stars': return b.stars - a.stars;
          case 'updated': return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
          default: return 0;
        }
      });
      
      setSearchResults(filtered);
    } finally {
      setLoading(false);
    }
  };

  const installPackage = async (packageName: string, version?: string) => {
    setLoading(true);
    try {
      const response = await fetch('/api/packages/install', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name: packageName, version })
      });

      if (response.ok) {
        await loadInstalledPackages();
        toast({
          title: "Package Installed",
          description: `${packageName} has been installed successfully.`,
        });
      }
    } catch (error) {
      toast({
        title: "Installation Failed",
        description: `Failed to install ${packageName}.`,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const uninstallPackage = async (packageName: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/packages/uninstall/${packageName}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        await loadInstalledPackages();
        toast({
          title: "Package Uninstalled",
          description: `${packageName} has been uninstalled.`,
        });
      }
    } catch (error) {
      toast({
        title: "Uninstall Failed",
        description: `Failed to uninstall ${packageName}.`,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updatePackage = async (packageName: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/packages/update/${packageName}`, {
        method: 'POST'
      });

      if (response.ok) {
        await loadInstalledPackages();
        toast({
          title: "Package Updated",
          description: `${packageName} has been updated to the latest version.`,
        });
      }
    } catch (error) {
      toast({
        title: "Update Failed",
        description: `Failed to update ${packageName}.`,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getSecurityIcon = (security: Package['security']) => {
    switch (security) {
      case 'safe': return <Shield className="w-4 h-4 text-green-400" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case 'vulnerable': return <AlertTriangle className="w-4 h-4 text-red-400" />;
      default: return <Shield className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusIcon = (status: ProjectDependency['status']) => {
    switch (status) {
      case 'installed': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'missing': return <AlertTriangle className="w-4 h-4 text-red-400" />;
      case 'outdated': return <Clock className="w-4 h-4 text-yellow-400" />;
      default: return <Package className="w-4 h-4 text-gray-400" />;
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}k`;
    return num.toString();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[95vh] bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            <Package className="w-5 h-5" />
            Package Manager
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-4 bg-slate-800">
            <TabsTrigger value="installed">
              Installed ({installedPackages.length})
            </TabsTrigger>
            <TabsTrigger value="search">Search Packages</TabsTrigger>
            <TabsTrigger value="updates">Updates Available</TabsTrigger>
            <TabsTrigger value="security">Security Audit</TabsTrigger>
          </TabsList>

          <TabsContent value="installed" className="flex-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Installed Packages</h3>
              <div className="flex gap-2">
                <Button
                  onClick={loadInstalledPackages}
                  variant="outline"
                  size="sm"
                  disabled={loading}
                >
                  <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                </Button>
                <Button variant="outline" size="sm">
                  <Settings className="w-4 h-4" />
                  Config
                </Button>
              </div>
            </div>

            <div className="space-y-3">
              {installedPackages.map((pkg) => (
                <Card key={pkg.name} className="bg-slate-800 border-slate-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {getStatusIcon(pkg.status)}
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-white">{pkg.name}</span>
                            <Badge className="text-xs">v{pkg.version}</Badge>
                            <Badge variant="outline" className={
                              pkg.type === 'dependency' ? 'border-blue-400 text-blue-400' :
                              pkg.type === 'devDependency' ? 'border-yellow-400 text-yellow-400' :
                              'border-purple-400 text-purple-400'
                            }>
                              {pkg.type}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-slate-400 mt-1">
                            <span>Size: {pkg.size}</span>
                            {pkg.status === 'outdated' && (
                              <span className="text-yellow-400">
                                Update available: v{pkg.latestVersion}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        {pkg.status === 'outdated' && (
                          <Button
                            onClick={() => updatePackage(pkg.name)}
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700"
                            disabled={loading}
                          >
                            <Download className="w-3 h-3 mr-1" />
                            Update
                          </Button>
                        )}
                        <Button
                          onClick={() => uninstallPackage(pkg.name)}
                          variant="outline"
                          size="sm"
                          disabled={loading}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="search" className="flex-1">
            <div className="space-y-4">
              {/* Search Controls */}
              <div className="flex items-center gap-4">
                <div className="flex-1 flex gap-2">
                  <Input
                    placeholder="Search packages..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && searchPackages()}
                    className="bg-slate-800 border-slate-600 text-white"
                  />
                  <Button
                    onClick={searchPackages}
                    disabled={loading || !searchQuery.trim()}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Search className="w-4 h-4" />
                  </Button>
                </div>

                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-slate-800 border-slate-600 text-white rounded px-3 py-2"
                >
                  <option value="downloads">Most Downloaded</option>
                  <option value="stars">Most Stars</option>
                  <option value="updated">Recently Updated</option>
                  <option value="name">Name</option>
                </select>

                <select
                  value={filterSecurity}
                  onChange={(e) => setFilterSecurity(e.target.value as any)}
                  className="bg-slate-800 border-slate-600 text-white rounded px-3 py-2"
                >
                  <option value="all">All Security</option>
                  <option value="safe">Safe Only</option>
                  <option value="warning">With Warnings</option>
                  <option value="vulnerable">Vulnerable</option>
                </select>
              </div>

              {/* Search Results */}
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {searchResults.map((pkg) => (
                    <Card key={pkg.name} className="bg-slate-800 border-slate-700">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <span className="font-medium text-white text-lg">{pkg.name}</span>
                              <Badge>v{pkg.version}</Badge>
                              {getSecurityIcon(pkg.security)}
                              {pkg.isInstalled && (
                                <Badge className="bg-green-600">Installed</Badge>
                              )}
                              {pkg.hasUpdate && (
                                <Badge className="bg-yellow-600">Update Available</Badge>
                              )}
                            </div>

                            <p className="text-slate-300 text-sm mb-3">{pkg.description}</p>

                            <div className="flex items-center gap-6 text-sm text-slate-400">
                              <div className="flex items-center gap-1">
                                <Download className="w-3 h-3" />
                                {formatNumber(pkg.downloads)}/week
                              </div>
                              <div className="flex items-center gap-1">
                                <Star className="w-3 h-3" />
                                {formatNumber(pkg.stars)}
                              </div>
                              <div className="flex items-center gap-1">
                                <User className="w-3 h-3" />
                                {pkg.author}
                              </div>
                              <div className="flex items-center gap-1">
                                <Package className="w-3 h-3" />
                                {pkg.size}
                              </div>
                              <div className="flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {new Date(pkg.lastUpdated).toLocaleDateString()}
                              </div>
                            </div>

                            {pkg.keywords.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-2">
                                {pkg.keywords.slice(0, 5).map((keyword) => (
                                  <Badge key={keyword} variant="outline" className="text-xs">
                                    {keyword}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>

                          <div className="flex flex-col gap-2 ml-4">
                            {pkg.homepage && (
                              <Button variant="outline" size="sm">
                                <ExternalLink className="w-3 h-3" />
                              </Button>
                            )}
                            
                            {pkg.isInstalled ? (
                              pkg.hasUpdate ? (
                                <Button
                                  onClick={() => updatePackage(pkg.name)}
                                  size="sm"
                                  className="bg-yellow-600 hover:bg-yellow-700"
                                  disabled={loading}
                                >
                                  <Download className="w-3 h-3 mr-1" />
                                  Update
                                </Button>
                              ) : (
                                <Button
                                  onClick={() => uninstallPackage(pkg.name)}
                                  variant="outline"
                                  size="sm"
                                  disabled={loading}
                                >
                                  <Trash2 className="w-3 h-3 mr-1" />
                                  Uninstall
                                </Button>
                              )
                            ) : (
                              <Button
                                onClick={() => installPackage(pkg.name, pkg.version)}
                                size="sm"
                                className="bg-green-600 hover:bg-green-700"
                                disabled={loading}
                              >
                                <Plus className="w-3 h-3 mr-1" />
                                Install
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="updates" className="flex-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Available Updates</h3>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Download className="w-4 h-4 mr-2" />
                Update All
              </Button>
            </div>

            <div className="space-y-3">
              {installedPackages.filter(pkg => pkg.status === 'outdated').map((pkg) => (
                <Card key={pkg.name} className="bg-slate-800 border-slate-700">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-white">{pkg.name}</span>
                          <Badge variant="outline">v{pkg.version}</Badge>
                          <span className="text-slate-400">→</span>
                          <Badge className="bg-green-600">v{pkg.latestVersion}</Badge>
                        </div>
                        <p className="text-sm text-slate-400">
                          Update available • Size: {pkg.size}
                        </p>
                      </div>
                      
                      <Button
                        onClick={() => updatePackage(pkg.name)}
                        size="sm"
                        className="bg-blue-600 hover:bg-blue-700"
                        disabled={loading}
                      >
                        <Download className="w-3 h-3 mr-1" />
                        Update
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="security" className="flex-1">
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-slate-800 border-slate-700">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Shield className="w-4 h-4 text-green-400" />
                      <span className="text-sm font-medium text-white">Safe Packages</span>
                    </div>
                    <p className="text-2xl font-bold text-green-400">
                      {installedPackages.length - 1}
                    </p>
                  </CardContent>
                </Card>

                <Card className="bg-slate-800 border-slate-700">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="w-4 h-4 text-yellow-400" />
                      <span className="text-sm font-medium text-white">Warnings</span>
                    </div>
                    <p className="text-2xl font-bold text-yellow-400">1</p>
                  </CardContent>
                </Card>

                <Card className="bg-slate-800 border-slate-700">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="w-4 h-4 text-red-400" />
                      <span className="text-sm font-medium text-white">Vulnerabilities</span>
                    </div>
                    <p className="text-2xl font-bold text-red-400">0</p>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Security Report</CardTitle>
                  <CardDescription>
                    Security analysis of your project dependencies
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-center h-32">
                    <div className="text-center">
                      <CheckCircle className="w-8 h-8 text-green-400 mx-auto mb-2" />
                      <p className="text-slate-400">No security vulnerabilities found</p>
                      <p className="text-sm text-slate-500 mt-1">
                        Last scanned: {new Date().toLocaleString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}