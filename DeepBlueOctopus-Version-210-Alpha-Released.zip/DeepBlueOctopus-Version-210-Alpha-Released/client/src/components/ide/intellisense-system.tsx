import { useState, useRef, useEffect } from "react";
import * as monaco from "monaco-editor";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { 
  Zap, 
  Lightbulb, 
  Code2, 
  FileText, 
  Search, 
  Brain,
  CheckCircle,
  AlertCircle,
  Info,
  Settings
} from "lucide-react";

interface IntelliSenseSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface CompletionItem {
  label: string;
  kind: string;
  detail: string;
  documentation: string;
  insertText: string;
}

interface DiagnosticItem {
  line: number;
  column: number;
  severity: 'error' | 'warning' | 'info';
  message: string;
  source: string;
}

export default function IntelliSenseSystem({ isOpen, onClose }: IntelliSenseSystemProps) {
  const [completions, setCompletions] = useState<CompletionItem[]>([]);
  const [diagnostics, setDiagnostics] = useState<DiagnosticItem[]>([]);
  const [enableAutoComplete, setEnableAutoComplete] = useState(true);
  const [enableQuickInfo, setEnableQuickInfo] = useState(true);
  const [enableParameterHints, setEnableParameterHints] = useState(true);
  const [enableErrorSquiggles, setEnableErrorSquiggles] = useState(true);
  const [completionDelay, setCompletionDelay] = useState([300]);
  const [maxSuggestions, setMaxSuggestions] = useState([10]);
  const [currentLanguage, setCurrentLanguage] = useState('javascript');
  const editorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const intelligenceFeatures = [
    { 
      name: "Auto-completion", 
      enabled: enableAutoComplete,
      setter: setEnableAutoComplete,
      icon: <Zap className="w-4 h-4" />,
      description: "Intelligent code completion suggestions"
    },
    { 
      name: "Quick Info", 
      enabled: enableQuickInfo,
      setter: setEnableQuickInfo,
      icon: <Info className="w-4 h-4" />,
      description: "Hover tooltips with type information"
    },
    { 
      name: "Parameter Hints", 
      enabled: enableParameterHints,
      setter: setEnableParameterHints,
      icon: <FileText className="w-4 h-4" />,
      description: "Function parameter suggestions"
    },
    { 
      name: "Error Squiggles", 
      enabled: enableErrorSquiggles,
      setter: setEnableErrorSquiggles,
      icon: <AlertCircle className="w-4 h-4" />,
      description: "Real-time error highlighting"
    }
  ];

  const completionTypes = {
    'Method': { icon: '⚡', color: 'text-blue-400' },
    'Function': { icon: '𝑓', color: 'text-purple-400' },
    'Variable': { icon: '📄', color: 'text-green-400' },
    'Class': { icon: '🏗️', color: 'text-orange-400' },
    'Interface': { icon: '🔗', color: 'text-cyan-400' },
    'Property': { icon: '⚙️', color: 'text-yellow-400' },
    'Keyword': { icon: '🔑', color: 'text-red-400' },
    'Snippet': { icon: '📝', color: 'text-pink-400' }
  };

  useEffect(() => {
    if (isOpen && containerRef.current) {
      initializeEditor();
      setupIntelliSense();
    }
    return () => {
      if (editorRef.current) {
        editorRef.current.dispose();
      }
    };
  }, [isOpen]);

  const initializeEditor = () => {
    if (containerRef.current) {
      const sampleCode = `// IntelliSense Demo - Try typing to see suggestions
import React, { useState, useEffect } from 'react';

// Custom interface for demonstration
interface User {
  id: number;
  name: string;
  email: string;
  isActive: boolean;
  preferences: {
    theme: 'light' | 'dark';
    notifications: boolean;
  };
}

// Custom class with methods
class UserManager {
  private users: User[] = [];
  
  constructor() {
    this.initialize();
  }
  
  // Method with parameters - try typing userManager.
  addUser(userData: Partial<User>): User {
    const newUser: User = {
      id: Date.now(),
      name: userData.name || '',
      email: userData.email || '',
      isActive: userData.isActive ?? true,
      preferences: {
        theme: 'light',
        notifications: true,
        ...userData.preferences
      }
    };
    
    this.users.push(newUser);
    return newUser;
  }
  
  // Try typing "this." to see available methods
  getUserById(id: number): User | undefined {
    return this.users.find(user => user.id === id);
  }
  
  updateUserPreferences(userId: number, prefs: Partial<User['preferences']>): boolean {
    const user = this.getUserById(userId);
    if (user) {
      user.preferences = { ...user.preferences, ...prefs };
      return true;
    }
    return false;
  }
  
  getAllActiveUsers(): User[] {
    return this.users.filter(user => user.isActive);
  }
}

// React component with hooks - try typing "use" to see hook suggestions
function UserComponent() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Try typing "userManager." to see method completions
  const userManager = new UserManager();
  
  useEffect(() => {
    // Try typing "console." to see available methods
    console.log('Component mounted');
    
    // Fetch users - try typing to see async/await suggestions
    const fetchUsers = async () => {
      setLoading(true);
      try {
        // Simulate API call
        const response = await fetch('/api/users');
        const userData = await response.json();
        setUsers(userData);
      } catch (err) {
        setError('Failed to fetch users');
      } finally {
        setLoading(false);
      }
    };
    
    fetchUsers();
  }, []);
  
  // Event handler - try typing "event." to see event properties
  const handleUserClick = (event: React.MouseEvent, user: User) => {
    event.preventDefault();
    console.log('User clicked:', user.name);
    
    // Try typing "user." to see User interface properties
    if (user.isActive) {
      userManager.updateUserPreferences(user.id, {
        theme: user.preferences.theme === 'light' ? 'dark' : 'light'
      });
    }
  };
  
  // Try typing JSX elements and see completion suggestions
  return (
    <div className="user-component">
      <h1>User Management</h1>
      
      {loading && <p>Loading...</p>}
      {error && <p className="error">{error}</p>}
      
      <ul>
        {users.map(user => (
          <li 
            key={user.id}
            onClick={(e) => handleUserClick(e, user)}
            className={user.isActive ? 'active' : 'inactive'}
          >
            {user.name} ({user.email})
          </li>
        ))}
      </ul>
    </div>
  );
}

// Try typing mathematical operations or string methods
const utils = {
  calculateAge: (birthDate: Date): number => {
    const today = new Date();
    return today.getFullYear() - birthDate.getFullYear();
  },
  
  formatUserName: (user: User): string => {
    return user.name.trim().toLowerCase().replace(/\\s+/g, '-');
  },
  
  validateEmail: (email: string): boolean => {
    return email.includes('@') && email.includes('.');
  }
};

export default UserComponent;`;

      editorRef.current = monaco.editor.create(containerRef.current, {
        value: sampleCode,
        language: currentLanguage,
        theme: 'vs-dark',
        fontSize: 14,
        lineNumbers: 'on',
        minimap: { enabled: true },
        wordWrap: 'on',
        suggestOnTriggerCharacters: enableAutoComplete,
        quickSuggestions: enableAutoComplete,
        parameterHints: { enabled: enableParameterHints },
        hover: { enabled: enableQuickInfo },
        scrollBeyondLastLine: false,
        automaticLayout: true,
      });

      // Update completions when cursor changes
      editorRef.current.onDidChangeCursorPosition(() => {
        updateCompletions();
      });

      // Update diagnostics when model changes
      editorRef.current.onDidChangeModelContent(() => {
        updateDiagnostics();
      });
    }
  };

  const setupIntelliSense = () => {
    if (!editorRef.current) return;

    // Register completion provider
    monaco.languages.registerCompletionItemProvider(currentLanguage, {
      provideCompletionItems: (model, position) => {
        const word = model.getWordUntilPosition(position);
        const range = {
          startLineNumber: position.lineNumber,
          endLineNumber: position.lineNumber,
          startColumn: word.startColumn,
          endColumn: word.endColumn
        };

        return {
          suggestions: generateCompletionSuggestions(range)
        };
      }
    });

    // Register hover provider
    monaco.languages.registerHoverProvider(currentLanguage, {
      provideHover: (model, position) => {
        const word = model.getWordAtPosition(position);
        if (word) {
          return {
            range: new monaco.Range(
              position.lineNumber,
              word.startColumn,
              position.lineNumber,
              word.endColumn
            ),
            contents: [
              { value: `**${word.word}**` },
              { value: `Type information and documentation for ${word.word}` }
            ]
          };
        }
        return null;
      }
    });

    // Register signature help provider
    monaco.languages.registerSignatureHelpProvider(currentLanguage, {
      signatureHelpTriggerCharacters: ['(', ','],
      provideSignatureHelp: (model, position) => {
        return {
          value: {
            signatures: [{
              label: 'function example(param1: string, param2: number): void',
              documentation: 'Example function signature',
              parameters: [
                { label: 'param1: string', documentation: 'First parameter' },
                { label: 'param2: number', documentation: 'Second parameter' }
              ]
            }],
            activeSignature: 0,
            activeParameter: 0
          },
          dispose: () => {}
        };
      }
    });
  };

  const generateCompletionSuggestions = (range: any): monaco.languages.CompletionItem[] => {
    const suggestions = [
      // React hooks
      {
        label: 'useState',
        kind: monaco.languages.CompletionItemKind.Function,
        documentation: 'React hook for managing state',
        insertText: 'useState(${1:initialValue})',
        insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
        range
      },
      {
        label: 'useEffect',
        kind: monaco.languages.CompletionItemKind.Function,
        documentation: 'React hook for side effects',
        insertText: 'useEffect(() => {\n\t${1:// effect}\n}, [${2:dependencies}])',
        insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
        range
      },
      // JavaScript methods
      {
        label: 'console.log',
        kind: monaco.languages.CompletionItemKind.Method,
        documentation: 'Outputs a message to the console',
        insertText: 'console.log(${1:message})',
        insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
        range
      },
      // TypeScript interfaces
      {
        label: 'interface',
        kind: monaco.languages.CompletionItemKind.Keyword,
        documentation: 'Define a TypeScript interface',
        insertText: 'interface ${1:InterfaceName} {\n\t${2:property}: ${3:type};\n}',
        insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
        range
      },
      // Class methods
      {
        label: 'constructor',
        kind: monaco.languages.CompletionItemKind.Constructor,
        documentation: 'Class constructor method',
        insertText: 'constructor(${1:parameters}) {\n\t${2:// initialization}\n}',
        insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
        range
      }
    ];

    return suggestions.slice(0, maxSuggestions[0]);
  };

  const updateCompletions = () => {
    if (!editorRef.current) return;

    const position = editorRef.current.getPosition();
    if (position) {
      const model = editorRef.current.getModel();
      if (model) {
        const word = model.getWordAtPosition(position);
        const completionItems: CompletionItem[] = [
          {
            label: word?.word || 'current',
            kind: 'Variable',
            detail: 'Local variable',
            documentation: 'Current word at cursor position',
            insertText: word?.word || 'current'
          }
        ];
        setCompletions(completionItems);
      }
    }
  };

  const updateDiagnostics = () => {
    if (!editorRef.current) return;

    const model = editorRef.current.getModel();
    if (model) {
      const markers = monaco.editor.getModelMarkers({ resource: model.uri });
      const diagnosticItems: DiagnosticItem[] = markers.map(marker => ({
        line: marker.startLineNumber,
        column: marker.startColumn,
        severity: marker.severity === 8 ? 'error' : marker.severity === 4 ? 'warning' : 'info',
        message: marker.message,
        source: marker.source || 'TypeScript'
      }));
      setDiagnostics(diagnosticItems);
    }
  };

  const toggleFeature = (feature: string, enabled: boolean) => {
    if (!editorRef.current) return;

    switch (feature) {
      case 'autoComplete':
        editorRef.current.updateOptions({
          suggestOnTriggerCharacters: enabled,
          quickSuggestions: enabled
        });
        break;
      case 'quickInfo':
        editorRef.current.updateOptions({
          hover: { enabled }
        });
        break;
      case 'parameterHints':
        editorRef.current.updateOptions({
          parameterHints: { enabled }
        });
        break;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-900 border border-gray-700 rounded-lg w-[95vw] h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <Brain className="w-6 h-6 text-blue-400" />
            <div>
              <h2 className="text-lg font-semibold text-white">IntelliSense System</h2>
              <p className="text-sm text-gray-400">Intelligent code completion and assistance</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            ✕
          </Button>
        </div>

        {/* Content */}
        <div className="flex flex-1 overflow-hidden">
          {/* Editor Panel */}
          <div className="flex-1 flex flex-col">
            {/* Toolbar */}
            <div className="flex items-center justify-between p-3 bg-gray-800 border-b border-gray-700">
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{completions.length} Suggestions</Badge>
                <Badge variant={diagnostics.length > 0 ? "destructive" : "secondary"}>
                  {diagnostics.length} Issues
                </Badge>
                <Badge variant="outline">{currentLanguage}</Badge>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Settings className="w-4 h-4 text-gray-400" />
                  <span className="text-sm text-gray-300">Delay: {completionDelay[0]}ms</span>
                </div>
              </div>
            </div>

            {/* Editor */}
            <div ref={containerRef} className="flex-1" />
          </div>

          {/* Controls Panel */}
          <div className="w-80 bg-gray-800 border-l border-gray-700 flex flex-col">
            <div className="p-4">
              <h3 className="text-sm font-semibold text-white mb-3">IntelliSense Settings</h3>
              
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  {/* Feature Toggles */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-semibold text-gray-400 uppercase">Features</h4>
                    {intelligenceFeatures.map((feature, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            {feature.icon}
                            <span className="text-sm text-white">{feature.name}</span>
                          </div>
                          <Switch 
                            checked={feature.enabled}
                            onCheckedChange={(checked) => {
                              feature.setter(checked);
                              toggleFeature(feature.name.toLowerCase().replace(/[^a-z]/g, ''), checked);
                            }}
                          />
                        </div>
                        <p className="text-xs text-gray-400 ml-6">{feature.description}</p>
                      </div>
                    ))}
                  </div>

                  {/* Configuration */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-semibold text-gray-400 uppercase">Configuration</h4>
                    
                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">Completion Delay (ms)</label>
                      <Slider
                        value={completionDelay}
                        onValueChange={setCompletionDelay}
                        max={1000}
                        min={0}
                        step={50}
                        className="w-full"
                      />
                      <span className="text-xs text-gray-400">{completionDelay[0]}ms</span>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm text-gray-300">Max Suggestions</label>
                      <Slider
                        value={maxSuggestions}
                        onValueChange={setMaxSuggestions}
                        max={50}
                        min={5}
                        step={5}
                        className="w-full"
                      />
                      <span className="text-xs text-gray-400">{maxSuggestions[0]} items</span>
                    </div>
                  </div>

                  {/* Current Completions */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-semibold text-gray-400 uppercase">Active Suggestions</h4>
                    <div className="space-y-1 max-h-32 overflow-y-auto">
                      {completions.map((completion, index) => (
                        <Card key={index} className="p-2 bg-gray-700 border-gray-600">
                          <div className="flex items-center gap-2">
                            <span className={`text-xs ${completionTypes[completion.kind as keyof typeof completionTypes]?.color || 'text-gray-400'}`}>
                              {completionTypes[completion.kind as keyof typeof completionTypes]?.icon || '📄'}
                            </span>
                            <span className="text-sm text-white">{completion.label}</span>
                          </div>
                          <p className="text-xs text-gray-400 mt-1">{completion.detail}</p>
                        </Card>
                      ))}
                      {completions.length === 0 && (
                        <p className="text-xs text-gray-500">Start typing to see suggestions</p>
                      )}
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </div>

            {/* Diagnostics */}
            <div className="p-4 border-t border-gray-700">
              <h4 className="text-sm font-semibold text-white mb-2">Diagnostics</h4>
              <ScrollArea className="h-32">
                <div className="space-y-1">
                  {diagnostics.map((diagnostic, index) => (
                    <div key={index} className="text-xs p-2 bg-gray-700 rounded">
                      <div className="flex items-center gap-2">
                        {diagnostic.severity === 'error' && <AlertCircle className="w-3 h-3 text-red-400" />}
                        {diagnostic.severity === 'warning' && <AlertCircle className="w-3 h-3 text-yellow-400" />}
                        {diagnostic.severity === 'info' && <Info className="w-3 h-3 text-blue-400" />}
                        <span className="text-white">Line {diagnostic.line}</span>
                      </div>
                      <p className="text-gray-400 mt-1">{diagnostic.message}</p>
                    </div>
                  ))}
                  {diagnostics.length === 0 && (
                    <div className="flex items-center gap-2 text-green-400">
                      <CheckCircle className="w-4 h-4" />
                      <span className="text-xs">No issues detected</span>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}