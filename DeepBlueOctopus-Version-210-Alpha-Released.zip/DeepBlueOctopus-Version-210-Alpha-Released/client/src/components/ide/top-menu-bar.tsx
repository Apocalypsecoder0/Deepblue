import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { useIDEState } from "@/hooks/use-ide-state";
import OctopusLogo from "@/components/ui/octopus-logo";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import { SoundControl, SoundSettings } from "@/components/ui/sound-system";
import { ThemeSelector, useTheme } from "@/components/ui/theme-system";
import { Palette, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import AboutDialog from "./about-dialog";
import UMLDesigner from "./uml-designer";
import MobileFramework from "./mobile-framework";
import GameEngine from "./game-engine";
import AIAssistant from "./ai-assistant";
import AdvancedDebugger from "./advanced-debugger";
import VersionControl from "./version-control";
import WorkspaceManager from "./workspace-manager";
import ObjectStudio from "./object-studio";
import AudioVideoEditor from "./audio-video-editor";
import MathematicsLibrary from "./mathematics-library";
import SystemAccountManager from "./account-manager";
import AuthDialog from "@/components/auth/auth-dialog";
import UserAccountManager from "@/components/auth/account-manager";
import UpdateSystem from "./update-system";
import ErrorLoggingSystem from "./error-logging-system";
import SubscriptionManager from "./subscription-manager";
import FileManager from "./file-manager";
import AutoCADBlueprintSystem from "./autocad-blueprint";
import CodeStylingSystem from "./code-styling-system";
import ServerManagement from "./server-management";
import PluginManager from "./plugin-manager";
import GitHubIntegration from "./github-integration";
import MissionSystem from "./mission-system";
import DatabaseManager from "./database-manager";
import PlatformSupport from "./platform-support";
import PerformanceMonitor from "./performance-monitor";
import CodeFormatter from "./code-formatter";
import PackageManager from "./package-manager";
import LanguageServer from "./language-server";
import DeployManager from "./deploy-manager";
import DeveloperToolkit from "./developer-toolkit";
import DocumentationGenerator from "./documentation-generator";
import WriteTool from "./write-tool";
import MultiCursorEditor from "./multi-cursor-editor";
import IDELogicSystem from "./ide-logic-system";
import SubMenuManager from "./sub-menu-manager";
import CodeFoldingSystem from "./code-folding-system";
import IntelliSenseSystem from "./intellisense-system";
import MultiTerminalSystem from "./multi-terminal-system";
import RealTimeCollaboration from "./real-time-collaboration";
import EnhancedFileExplorer from "./enhanced-file-explorer";
import ExtensionsPanel from "./extensions-panel";
import Collaboration from "./collaboration";
import SyntaxHighlightingSystem from "./syntax-highlighting-system";
import TestingFramework from "./testing-framework";
import CodeAnalysisSystem from "./code-analysis-system";
import FileOperationsManager from "./file-operations-manager";
import DatabaseSchemaDesigner from "./database-schema-designer";
import RestApiClient from "./rest-api-client";
import AdvancedTextEditor from "./advanced-text-editor";
import AdvancedFileSystem from "./advanced-file-system";
import AdvancedViewSystem from "./advanced-view-system";
import AdvancedEditSystem from "./advanced-edit-system";
import AdvancedServerSystem from "./advanced-server-system";
import { CodePreview } from "./code-preview";
import { GameDevelopmentStudio } from "./game-development-studio";
import { AutoFileLoader } from "./auto-file-loader";


export default function TopMenuBar() {
  const { createNewFile, saveCurrentFile, openFile } = useIDEState();
  const [showAbout, setShowAbout] = useState(false);
  const [showGameEngine, setShowGameEngine] = useState(false);
  const [showThemeSelector, setShowThemeSelector] = useState(false);
  const [showSoundSettings, setShowSoundSettings] = useState(false);
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [showDebugger, setShowDebugger] = useState(false);
  const [showVersionControl, setShowVersionControl] = useState(false);
  const [showWorkspaceManager, setShowWorkspaceManager] = useState(false);
  const [showObjectStudio, setShowObjectStudio] = useState(false);
  const [showAudioVideoEditor, setShowAudioVideoEditor] = useState(false);
  const [showMathematicsLibrary, setShowMathematicsLibrary] = useState(false);
  const [showAccountManager, setShowAccountManager] = useState(false);
  const [showUpdateSystem, setShowUpdateSystem] = useState(false);
  const [showErrorLogging, setShowErrorLogging] = useState(false);
  const [showAutoCADBlueprint, setShowAutoCADBlueprint] = useState(false);
  const [showCodeStyling, setShowCodeStyling] = useState(false);
  const [showServerManagement, setShowServerManagement] = useState(false);
  const [showFileManager, setShowFileManager] = useState(false);
  const [showSubscriptionManager, setShowSubscriptionManager] = useState(false);
  const [showPluginManager, setShowPluginManager] = useState(false);
  const [showGitHubIntegration, setShowGitHubIntegration] = useState(false);
  const [showMissionSystem, setShowMissionSystem] = useState(false);
  const [showDatabaseManager, setShowDatabaseManager] = useState(false);
  const [showPerformanceMonitor, setShowPerformanceMonitor] = useState(false);
  const [showCodeFormatter, setShowCodeFormatter] = useState(false);
  const [showPackageManager, setShowPackageManager] = useState(false);
  const [showLanguageServer, setShowLanguageServer] = useState(false);
  const [showDeployManager, setShowDeployManager] = useState(false);
  const [showDeveloperToolkit, setShowDeveloperToolkit] = useState(false);
  const [showDocumentationGenerator, setShowDocumentationGenerator] = useState(false);
  const [showWriteTool, setShowWriteTool] = useState(false);
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  const [showUserAccountManager, setShowUserAccountManager] = useState(false);
  const [showPlatformSupport, setShowPlatformSupport] = useState(false);
  const [showMultiCursorEditor, setShowMultiCursorEditor] = useState(false);
  const [showCodeFolding, setShowCodeFolding] = useState(false);
  const [showIntelliSense, setShowIntelliSense] = useState(false);
  const [showMultiTerminal, setShowMultiTerminal] = useState(false);
  const [showCollaboration, setShowCollaboration] = useState(false);
  const [showEnhancedFileExplorer, setShowEnhancedFileExplorer] = useState(false);
  const [showExtensionsPanel, setShowExtensionsPanel] = useState(false);
  const [showSyntaxHighlighting, setShowSyntaxHighlighting] = useState(false);
  const [showTestingFramework, setShowTestingFramework] = useState(false);
  const [showCodeAnalysis, setShowCodeAnalysis] = useState(false);
  const [showFileOperations, setShowFileOperations] = useState(false);
  const [showDatabaseDesigner, setShowDatabaseDesigner] = useState(false);
  const [showRestApiClient, setShowRestApiClient] = useState(false);
  const [showAdvancedTextEditor, setShowAdvancedTextEditor] = useState(false);
  const [showAdvancedFileSystem, setShowAdvancedFileSystem] = useState(false);
  const [showAdvancedViewSystem, setShowAdvancedViewSystem] = useState(false);
  const [showAdvancedEditSystem, setShowAdvancedEditSystem] = useState(false);
  const [showAdvancedServerSystem, setShowAdvancedServerSystem] = useState(false);
  const [showIDELogicSystem, setShowIDELogicSystem] = useState(false);
  const [showSubMenuManager, setShowSubMenuManager] = useState(false);
  const [showCodePreview, setShowCodePreview] = useState(false);
  const [showGameStudio, setShowGameStudio] = useState(false);
  const [showUMLDesigner, setShowUMLDesigner] = useState(false);
  const [showMobileFramework, setShowMobileFramework] = useState(false);

  const [currentUser, setCurrentUser] = useState<any>(null);
  const { currentTheme } = useTheme();

  const menuItems = [
    {
      label: "File",
      items: [
        { label: "New File", action: () => createNewFile(), shortcut: "Ctrl+N" },
        { label: "New Project", action: () => console.log("New Project"), shortcut: "Ctrl+Shift+N" },
        { label: "Open File", action: () => console.log("Open File"), shortcut: "Ctrl+O" },
        { label: "Open Folder", action: () => console.log("Open Folder"), shortcut: "Ctrl+K Ctrl+O" },
        { label: "File Manager", action: () => setShowFileManager(true), shortcut: "Ctrl+Shift+E" },
        { label: "Enhanced File Explorer", action: () => setShowEnhancedFileExplorer(true), shortcut: "Ctrl+Alt+E" },
        { label: "Save", action: () => saveCurrentFile(), shortcut: "Ctrl+S" },
        { label: "Save As", action: () => console.log("Save As"), shortcut: "Ctrl+Shift+S" },
        { label: "Save All", action: () => console.log("Save All"), shortcut: "Ctrl+K S" },
        { label: "Export Project", action: () => console.log("Export Project") },
        { label: "Platform Support", action: () => setShowPlatformSupport(true), shortcut: "Ctrl+Shift+P" },
        { label: "Project Settings", action: () => console.log("Project Settings") },
        { label: "Close Tab", action: () => console.log("Close Tab"), shortcut: "Ctrl+W" },
        { label: "Close All Tabs", action: () => console.log("Close All Tabs"), shortcut: "Ctrl+Shift+W" },
      ]
    },
    {
      label: "Edit", 
      items: [
        { label: "Undo", action: () => document.execCommand('undo'), shortcut: "Ctrl+Z" },
        { label: "Redo", action: () => document.execCommand('redo'), shortcut: "Ctrl+Y" },
        { label: "Cut", action: () => document.execCommand('cut'), shortcut: "Ctrl+X" },
        { label: "Copy", action: () => document.execCommand('copy'), shortcut: "Ctrl+C" },
        { label: "Paste", action: () => document.execCommand('paste'), shortcut: "Ctrl+V" },
        { label: "Select All", action: () => document.execCommand('selectAll'), shortcut: "Ctrl+A" },
        { label: "Find", action: () => document.dispatchEvent(new CustomEvent('ide:show-find')), shortcut: "Ctrl+F" },
        { label: "Replace", action: () => document.dispatchEvent(new CustomEvent('ide:show-replace')), shortcut: "Ctrl+H" },
        { label: "Find in Files", action: () => document.dispatchEvent(new CustomEvent('ide:show-search')), shortcut: "Ctrl+Shift+F" },
        { label: "Go to Line", action: () => document.dispatchEvent(new CustomEvent('ide:goto-line')), shortcut: "Ctrl+G" },
        { label: "Format Document", action: () => document.dispatchEvent(new CustomEvent('ide:format-document')), shortcut: "Shift+Alt+F" },
        { label: "Toggle Comment", action: () => document.dispatchEvent(new CustomEvent('ide:toggle-comment')), shortcut: "Ctrl+/" },
        { label: "Indent", action: () => document.dispatchEvent(new CustomEvent('ide:indent')), shortcut: "Tab" },
        { label: "Outdent", action: () => document.dispatchEvent(new CustomEvent('ide:outdent')), shortcut: "Shift+Tab" },
        { label: "Multi-Cursor Editor", action: () => setShowMultiCursorEditor(true), shortcut: "Ctrl+Alt+M" },
        { label: "Code Folding", action: () => setShowCodeFolding(true), shortcut: "Ctrl+Shift+[" },
        { label: "IntelliSense", action: () => setShowIntelliSense(true), shortcut: "Ctrl+Space" },
        { label: "Syntax Highlighting", action: () => setShowSyntaxHighlighting(true), shortcut: "Ctrl+K Ctrl+H" },
        { label: "Testing Framework", action: () => setShowTestingFramework(true), shortcut: "Ctrl+Shift+T" },
        { label: "Code Analysis", action: () => setShowCodeAnalysis(true), shortcut: "Ctrl+Shift+A" },
        { label: "File Operations Manager", action: () => setShowFileOperations(true), shortcut: "Ctrl+Alt+F" },
        { label: "Database Schema Designer", action: () => setShowDatabaseDesigner(true), shortcut: "Ctrl+Alt+D" },
        { label: "REST API Client", action: () => setShowRestApiClient(true), shortcut: "Ctrl+Alt+R" },
        { label: "Advanced Text Editor", action: () => setShowAdvancedTextEditor(true), shortcut: "Ctrl+Alt+T" },
        { label: "Advanced File System", action: () => setShowAdvancedFileSystem(true), shortcut: "Ctrl+Alt+E" },
        { label: "Advanced View System", action: () => setShowAdvancedViewSystem(true), shortcut: "Ctrl+Alt+V" },
        { label: "Advanced Edit System", action: () => setShowAdvancedEditSystem(true), shortcut: "Ctrl+Alt+I" },
        { label: "Advanced Server System", action: () => setShowAdvancedServerSystem(true), shortcut: "Ctrl+Alt+S" },
      ]
    },
    {
      label: "View",
      items: [
        { label: "Explorer", action: () => document.dispatchEvent(new CustomEvent('ide:toggle-sidebar')), shortcut: "Ctrl+Shift+E" },
        { label: "Search", action: () => document.dispatchEvent(new CustomEvent('ide:show-search')), shortcut: "Ctrl+Shift+F" },
        { label: "Source Control", action: () => setShowVersionControl(true), shortcut: "Ctrl+Shift+G" },
        { label: "Debug Console", action: () => setShowDebugger(true), shortcut: "Ctrl+Shift+D" },
        { label: "Extensions", action: () => setShowExtensionsPanel(true), shortcut: "Ctrl+Shift+X" },
        { label: "Terminal", action: () => document.dispatchEvent(new CustomEvent('ide:toggle-terminal')), shortcut: "Ctrl+`" },
        { label: "Command Palette", action: () => document.dispatchEvent(new CustomEvent('ide:show-command-palette')), shortcut: "Ctrl+Shift+P" },
        { label: "Toggle Sidebar", action: () => document.dispatchEvent(new CustomEvent('ide:toggle-sidebar')), shortcut: "Ctrl+B" },
        { label: "AI Assistant", action: () => setShowAIAssistant(true), shortcut: "Ctrl+I" },
        { label: "Multi-Terminal", action: () => setShowMultiTerminal(true), shortcut: "Ctrl+Shift+`" },
        { label: "Collaboration", action: () => setShowCollaboration(true), shortcut: "Ctrl+Shift+C" },
        { label: "Zoom In", action: () => document.body.style.zoom = (parseFloat(document.body.style.zoom || '1') + 0.1).toString(), shortcut: "Ctrl+=" },
        { label: "Zoom Out", action: () => document.body.style.zoom = Math.max(0.5, parseFloat(document.body.style.zoom || '1') - 0.1).toString(), shortcut: "Ctrl+-" },
        { label: "Reset Zoom", action: () => document.body.style.zoom = '1', shortcut: "Ctrl+0" },
      ]
    },
    {
      label: "Run",
      items: [
        { label: "Run Code", action: () => document.dispatchEvent(new CustomEvent('ide:run-code')), shortcut: "F5" },
        { label: "Debug Code", action: () => setShowDebugger(true), shortcut: "Ctrl+F5" },
        { label: "Run Terminal Command", action: () => document.dispatchEvent(new CustomEvent('ide:focus-terminal')), shortcut: "Ctrl+Shift+T" },
        { label: "Build Project", action: () => document.dispatchEvent(new CustomEvent('ide:build-project')), shortcut: "Ctrl+Shift+B" },
        { label: "Test Project", action: () => document.dispatchEvent(new CustomEvent('ide:test-project')), shortcut: "Ctrl+Shift+T" },
        { label: "Toggle Breakpoint", action: () => document.dispatchEvent(new CustomEvent('ide:toggle-breakpoint')), shortcut: "F9" },
        { label: "Step Over", action: () => document.dispatchEvent(new CustomEvent('ide:step-over')), shortcut: "F10" },
        { label: "Step Into", action: () => document.dispatchEvent(new CustomEvent('ide:step-into')), shortcut: "F11" },
        { label: "Step Out", action: () => document.dispatchEvent(new CustomEvent('ide:step-out')), shortcut: "Shift+F11" },
        { label: "Stop Debugging", action: () => document.dispatchEvent(new CustomEvent('ide:stop-debug')), shortcut: "Shift+F5" },
      ]
    },
    {
      label: "Tools",
      items: [
        { label: "AI Assistant", action: () => setShowAIAssistant(true), shortcut: "Ctrl+I" },
        { label: "Advanced Debugger", action: () => setShowDebugger(true), shortcut: "F5" },
        { label: "Version Control", action: () => setShowVersionControl(true), shortcut: "Ctrl+Shift+G" },
        { label: "GitHub Integration", action: () => setShowGitHubIntegration(true), shortcut: "Ctrl+Shift+H" },
        { label: "Mission System", action: () => setShowMissionSystem(true), shortcut: "Ctrl+Alt+M" },
        { label: "UML Designer", action: () => setShowUMLDesigner(true), shortcut: "Ctrl+Shift+U" },
        { label: "Mobile Framework", action: () => setShowMobileFramework(true), shortcut: "Ctrl+Shift+F" },
        { label: "Game Engine", action: () => setShowGameEngine(true), shortcut: "Ctrl+Alt+G" },
        { label: "Workspace Manager", action: () => setShowWorkspaceManager(true), shortcut: "Ctrl+Shift+W" },
        { label: "2D/3D Object Studio", action: () => setShowObjectStudio(true), shortcut: "Ctrl+Shift+O" },
        { label: "Audio/Video Editor", action: () => setShowAudioVideoEditor(true), shortcut: "Ctrl+Shift+A" },
        { label: "Mathematics Library", action: () => setShowMathematicsLibrary(true), shortcut: "Ctrl+Shift+M" },
        { label: "Plugin Manager", action: () => setShowPluginManager(true), shortcut: "Ctrl+Shift+P" },
        { label: "AutoCAD Blueprint System", action: () => setShowAutoCADBlueprint(true), shortcut: "Ctrl+Alt+B" },
        { label: "Code Styling System", action: () => setShowCodeStyling(true), shortcut: "Ctrl+Alt+S" },
        { label: "Update System", action: () => setShowUpdateSystem(true), shortcut: "Ctrl+Shift+U" },
        { label: "Error Logging", action: () => setShowErrorLogging(true), shortcut: "Ctrl+Shift+E" },
        { label: "Subscription Manager", action: () => setShowSubscriptionManager(true), shortcut: "Ctrl+Shift+S" },
        { label: "Database Manager", action: () => setShowDatabaseManager(true), shortcut: "Ctrl+Shift+D" },
        { label: "Code Formatter", action: () => setShowCodeFormatter(true), shortcut: "Shift+Alt+F" },
        { label: "Package Manager", action: () => setShowPackageManager(true), shortcut: "Ctrl+Shift+N" },
        { label: "Performance Monitor", action: () => setShowPerformanceMonitor(true), shortcut: "Ctrl+Shift+R" },
        { label: "Language Server", action: () => setShowLanguageServer(true), shortcut: "Ctrl+Shift+L" },
        { label: "Deploy Manager", action: () => setShowDeployManager(true), shortcut: "Ctrl+Shift+Y" },
        { label: "Developer Toolkit", action: () => setShowDeveloperToolkit(true), shortcut: "Ctrl+Alt+T" },
        { label: "Documentation Generator", action: () => setShowDocumentationGenerator(true), shortcut: "Ctrl+Alt+D" },
        { label: "Write Tool", action: () => setShowWriteTool(true), shortcut: "Ctrl+Alt+W" },
        { label: "IDE Logic System", action: () => setShowIDELogicSystem(true), shortcut: "Ctrl+Alt+I" },
        { label: "Sub-Menu Manager", action: () => setShowSubMenuManager(true), shortcut: "Ctrl+Alt+L" },
        { label: "Code Preview", action: () => setShowCodePreview(true), shortcut: "Ctrl+Alt+P" },
        { label: "Game Development Studio", action: () => setShowGameStudio(true), shortcut: "Ctrl+Alt+G" },
      ]
    },
    {
      label: "Server",
      items: [
        { label: "Server Management", action: () => setShowServerManagement(true), shortcut: "Ctrl+Alt+M" },
        { label: "Start Development Server", action: () => console.log("Start Server"), shortcut: "Ctrl+Alt+D" },
        { label: "Deploy to Production", action: () => console.log("Deploy"), shortcut: "Ctrl+Alt+P" },
        { label: "Database Console", action: () => console.log("Database Console"), shortcut: "Ctrl+Alt+B" },
        { label: "Web View Preview", action: () => window.open(window.location.origin, "_blank"), shortcut: "Ctrl+Alt+W" },
        { label: "Server Logs", action: () => console.log("Server Logs"), shortcut: "Ctrl+Alt+L" },
        { label: "Performance Metrics", action: () => console.log("Performance Metrics") },
        { label: "API Documentation", action: () => console.log("API Docs") },
      ]
    },
    {
      label: "Window",
      items: [
        { label: "New Window", action: () => console.log("New Window"), shortcut: "Ctrl+Shift+N" },
        { label: "Close Window", action: () => console.log("Close Window"), shortcut: "Ctrl+Shift+W" },
        { label: "Split Editor", action: () => console.log("Split Editor"), shortcut: "Ctrl+\\" },
        { label: "Switch Window", action: () => console.log("Switch Window"), shortcut: "Alt+Tab" },
        { label: "Previous Tab", action: () => console.log("Previous Tab"), shortcut: "Ctrl+PageUp" },
        { label: "Next Tab", action: () => console.log("Next Tab"), shortcut: "Ctrl+PageDown" },
        { label: "Fullscreen", action: () => console.log("Fullscreen"), shortcut: "F11" },
        { label: "Developer Tools", action: () => console.log("Developer Tools"), shortcut: "F12" },
      ]
    },
    {
      label: "Help",
      items: [
        { label: "Welcome Guide", action: () => document.dispatchEvent(new CustomEvent('ide:show-welcome')) },
        { label: "Show All Commands", action: () => document.dispatchEvent(new CustomEvent('ide:show-command-palette')), shortcut: "Ctrl+Shift+P" },
        { label: "Keyboard Shortcuts", action: () => document.dispatchEvent(new CustomEvent('ide:show-shortcuts')), shortcut: "Ctrl+K Ctrl+S" },
        { label: "AI Assistant", action: () => setShowAIAssistant(true), shortcut: "Ctrl+I" },
        { label: "Documentation", action: () => window.open("https://docs.deepblue-octopus.dev", "_blank") },
        { label: "Community Forum", action: () => window.open("https://community.deepblue-octopus.dev", "_blank") },
        { label: "Video Tutorials", action: () => window.open("https://learn.deepblue-octopus.dev", "_blank") },
        { label: "Report Issue", action: () => window.open("https://github.com/apocalypsecode0/deepblue-octopus/issues", "_blank") },
        { label: "Feature Request", action: () => window.open("https://github.com/apocalypsecode0/deepblue-octopus/discussions", "_blank") },
        { label: "Release Notes", action: () => setShowUpdateSystem(true) },
        { label: "Check for Updates", action: () => setShowUpdateSystem(true) },
        { label: "Contact Support", action: () => window.open("mailto:stephend8846@gmail.com", "_blank") },
        { label: "About DeepBlue:Octopus", action: () => setShowAbout(true) },
      ]
    }
  ];

  return (
    <>
      <div className="ide-panel border-b ide-border h-10 flex items-center px-4 text-sm">
        <div className="flex space-x-6">
          {menuItems.map((menu) => (
            <DropdownMenu key={menu.label}>
              <DropdownMenuTrigger className="cursor-pointer hover:bg-[var(--ide-bg)] px-2 py-1 rounded transition-colors">
                {menu.label}
              </DropdownMenuTrigger>
              <DropdownMenuContent className="ide-panel border-[var(--ide-border)]">
                {menu.items.map((item) => (
                  <DropdownMenuItem
                    key={item.label}
                    onClick={item.action}
                    className="text-[var(--ide-text)] hover:bg-[var(--ide-bg)] cursor-pointer flex justify-between"
                  >
                    <span>{item.label}</span>
                    {item.shortcut && (
                      <span className="text-[var(--ide-text-secondary)] text-xs ml-4">
                        {item.shortcut}
                      </span>
                    )}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          ))}
        </div>
        <div className="ml-auto flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <TooltipWrapper
              title="Theme Selection"
              content="Switch between different themes including Deep Blue Octopus, Dark Professional, Light, Forest, Neon Cyber, and Fire Dragon"
              type="feature"
            >
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowThemeSelector(true)}
                className="text-[var(--ide-text-secondary)] hover:text-[var(--ide-text)] p-1"
              >
                <Palette className="h-4 w-4" />
              </Button>
            </TooltipWrapper>
            
            <TooltipWrapper
              title="Sound Control"
              content="Enable/disable sound effects and adjust volume settings for IDE interactions"
              type="feature"
            >
              <SoundControl />
            </TooltipWrapper>
          </div>

          <div className="flex items-center space-x-4">
            {currentUser ? (
              <TooltipWrapper
                title="Account Management"
                content="Manage user profile, preferences, security settings, and view statistics"
                type="feature"
              >
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowUserAccountManager(true)}
                  className="text-blue-200 hover:bg-blue-800/50 hover:text-blue-100"
                >
                  <div className="h-4 w-4 mr-2 rounded-full bg-blue-500 flex items-center justify-center text-xs text-white">
                    {currentUser.firstName ? currentUser.firstName[0] : currentUser.username[0]}
                  </div>
                  {currentUser.firstName ? `${currentUser.firstName} ${currentUser.lastName}` : currentUser.username}
                </Button>
              </TooltipWrapper>
            ) : (
              <TooltipWrapper
                title="Login to IDE"
                content="Access your projects, settings, and advanced features"
                type="feature"
              >
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowAuthDialog(true)}
                  className="text-blue-200 hover:bg-blue-800/50 hover:text-blue-100"
                >
                  <div className="h-4 w-4 mr-2 rounded-full bg-gray-500 flex items-center justify-center text-xs text-white">?</div>
                  Login
                </Button>
              </TooltipWrapper>
            )}

            <TooltipWrapper
              title="DeepBlue:Octopus IDE"
              content="Professional web-based development environment with comprehensive language support, game engine, and advanced tools"
              type="info"
            >
              <div className="flex items-center space-x-2">
                <OctopusLogo size={20} animated={true} />
                <span className="ide-text-secondary font-semibold">DeepBlue:Octopus v1.5</span>
              </div>
            </TooltipWrapper>
          </div>
        </div>
      </div>

      {/* Dialog Components */}
      <AboutDialog 
        isOpen={showAbout} 
        onClose={() => setShowAbout(false)} 
      />
      <UMLDesigner 
        isOpen={showUMLDesigner} 
        onClose={() => setShowUMLDesigner(false)} 
      />
      <MobileFramework 
        isOpen={showMobileFramework} 
        onClose={() => setShowMobileFramework(false)} 
      />
      <GameEngine 
        isOpen={showGameEngine} 
        onClose={() => setShowGameEngine(false)} 
      />
      
      {showThemeSelector && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <ThemeSelector onClose={() => setShowThemeSelector(false)} />
        </div>
      )}
      
      <SoundSettings 
        isOpen={showSoundSettings} 
        onClose={() => setShowSoundSettings(false)} 
      />
      
      <AIAssistant
        isOpen={showAIAssistant}
        onClose={() => setShowAIAssistant(false)}
      />
      
      <AdvancedDebugger
        isOpen={showDebugger}
        onClose={() => setShowDebugger(false)}
      />
      
      <UMLDesigner
        isOpen={showUMLDesigner}
        onClose={() => setShowUMLDesigner(false)}
      />
      
      <MobileFramework
        isOpen={showMobileFramework}
        onClose={() => setShowMobileFramework(false)}
      />
      
      <VersionControl
        isOpen={showVersionControl}
        onClose={() => setShowVersionControl(false)}
      />
      
      <WorkspaceManager
        isOpen={showWorkspaceManager}
        onClose={() => setShowWorkspaceManager(false)}
      />
      
      <ObjectStudio
        isOpen={showObjectStudio}
        onClose={() => setShowObjectStudio(false)}
      />
      
      <AudioVideoEditor
        isOpen={showAudioVideoEditor}
        onClose={() => setShowAudioVideoEditor(false)}
      />
      
      <MathematicsLibrary
        isOpen={showMathematicsLibrary}
        onClose={() => setShowMathematicsLibrary(false)}
      />
      
      <SystemAccountManager
        isOpen={showAccountManager}
        onClose={() => setShowAccountManager(false)}
      />
      
      <UpdateSystem
        isOpen={showUpdateSystem}
        onClose={() => setShowUpdateSystem(false)}
      />
      
      <ErrorLoggingSystem
        isOpen={showErrorLogging}
        onClose={() => setShowErrorLogging(false)}
      />
      
      <SubscriptionManager
        isOpen={showSubscriptionManager}
        onClose={() => setShowSubscriptionManager(false)}
      />
      
      <FileManager
        isOpen={showFileManager}
        onClose={() => setShowFileManager(false)}
      />
      
      <AutoCADBlueprintSystem
        isOpen={showAutoCADBlueprint}
        onClose={() => setShowAutoCADBlueprint(false)}
      />
      
      <CodeStylingSystem
        isOpen={showCodeStyling}
        onClose={() => setShowCodeStyling(false)}
      />
      
      <ServerManagement
        isOpen={showServerManagement}
        onClose={() => setShowServerManagement(false)}
      />
      
      <PluginManager
        isOpen={showPluginManager}
        onClose={() => setShowPluginManager(false)}
      />
      
      <GitHubIntegration
        isOpen={showGitHubIntegration}
        onClose={() => setShowGitHubIntegration(false)}
      />
      
      <MissionSystem
        isOpen={showMissionSystem}
        onClose={() => setShowMissionSystem(false)}
      />
      
      <DatabaseManager
        isOpen={showDatabaseManager}
        onClose={() => setShowDatabaseManager(false)}
      />
      
      <PerformanceMonitor
        isOpen={showPerformanceMonitor}
        onClose={() => setShowPerformanceMonitor(false)}
      />
      
      <CodeFormatter
        isOpen={showCodeFormatter}
        onClose={() => setShowCodeFormatter(false)}
      />
      
      <PackageManager
        isOpen={showPackageManager}
        onClose={() => setShowPackageManager(false)}
      />
      
      <LanguageServer
        isOpen={showLanguageServer}
        onClose={() => setShowLanguageServer(false)}
      />
      
      <DeployManager
        isOpen={showDeployManager}
        onClose={() => setShowDeployManager(false)}
      />
      
      <DeveloperToolkit
        isOpen={showDeveloperToolkit}
        onClose={() => setShowDeveloperToolkit(false)}
      />
      
      <DocumentationGenerator
        isOpen={showDocumentationGenerator}
        onClose={() => setShowDocumentationGenerator(false)}
      />
      
      <WriteTool
        isOpen={showWriteTool}
        onClose={() => setShowWriteTool(false)}
      />
      
      <PlatformSupport
        isOpen={showPlatformSupport}
        onClose={() => setShowPlatformSupport(false)}
      />
      
      <AuthDialog
        isOpen={showAuthDialog}
        onClose={() => setShowAuthDialog(false)}
        onAuthSuccess={(user) => {
          setCurrentUser(user);
          setShowAuthDialog(false);
        }}
      />
      
      {currentUser && (
        <UserAccountManager
          isOpen={showUserAccountManager}
          onClose={() => setShowUserAccountManager(false)}
          currentUser={currentUser}
          onSignOut={() => {
            setCurrentUser(null);
            setShowUserAccountManager(false);
          }}
        />
      )}

      <MultiCursorEditor 
        isOpen={showMultiCursorEditor}
        onClose={() => setShowMultiCursorEditor(false)}
      />
      
      <CodeFoldingSystem 
        isOpen={showCodeFolding}
        onClose={() => setShowCodeFolding(false)}
      />
      
      <IntelliSenseSystem 
        isOpen={showIntelliSense}
        onClose={() => setShowIntelliSense(false)}
      />
      
      <MultiTerminalSystem 
        isOpen={showMultiTerminal}
        onClose={() => setShowMultiTerminal(false)}
      />
      
      <RealTimeCollaboration 
        isOpen={showCollaboration}
        onClose={() => setShowCollaboration(false)}
      />

      <EnhancedFileExplorer
        isOpen={showEnhancedFileExplorer}
        onClose={() => setShowEnhancedFileExplorer(false)}
      />

      <ExtensionsPanel
        isOpen={showExtensionsPanel}
        onClose={() => setShowExtensionsPanel(false)}
      />

      <Collaboration
        isOpen={showCollaboration}
        onClose={() => setShowCollaboration(false)}
      />

      <SyntaxHighlightingSystem
        isOpen={showSyntaxHighlighting}
        onClose={() => setShowSyntaxHighlighting(false)}
      />

      <TestingFramework
        isOpen={showTestingFramework}
        onClose={() => setShowTestingFramework(false)}
      />

      <CodeAnalysisSystem
        isOpen={showCodeAnalysis}
        onClose={() => setShowCodeAnalysis(false)}
      />

      <FileOperationsManager
        isOpen={showFileOperations}
        onClose={() => setShowFileOperations(false)}
      />

      <DatabaseSchemaDesigner
        isOpen={showDatabaseDesigner}
        onClose={() => setShowDatabaseDesigner(false)}
      />

      <RestApiClient
        isOpen={showRestApiClient}
        onClose={() => setShowRestApiClient(false)}
      />

      <AdvancedTextEditor
        isOpen={showAdvancedTextEditor}
        onClose={() => setShowAdvancedTextEditor(false)}
      />

      <AdvancedFileSystem
        isOpen={showAdvancedFileSystem}
        onClose={() => setShowAdvancedFileSystem(false)}
      />

      <AdvancedViewSystem
        isOpen={showAdvancedViewSystem}
        onClose={() => setShowAdvancedViewSystem(false)}
      />

      <AdvancedEditSystem
        isOpen={showAdvancedEditSystem}
        onClose={() => setShowAdvancedEditSystem(false)}
      />

      <AdvancedServerSystem
        isOpen={showAdvancedServerSystem}
        onClose={() => setShowAdvancedServerSystem(false)}
      />

      <IDELogicSystem
        isOpen={showIDELogicSystem}
        onClose={() => setShowIDELogicSystem(false)}
      />

      <SubMenuManager
        isOpen={showSubMenuManager}
        onClose={() => setShowSubMenuManager(false)}
      />

      <CodePreview
        isOpen={showCodePreview}
        onClose={() => setShowCodePreview(false)}
      />

      <GameDevelopmentStudio
        isOpen={showGameStudio}
        onClose={() => setShowGameStudio(false)}
      />

      <GitHubIntegration
        isOpen={showGitHubIntegration}
        onClose={() => setShowGitHubIntegration(false)}
      />

      <AutoFileLoader onFileOpen={openFile} />
    </>
  );
}
