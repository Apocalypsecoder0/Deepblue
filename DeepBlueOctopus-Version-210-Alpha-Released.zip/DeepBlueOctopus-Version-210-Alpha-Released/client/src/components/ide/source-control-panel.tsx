import { useState } from "react";
import { GitBranch, Plus, RefreshCw, Upload, Download, GitCommit, MoreHorizontal, GitMerge, Eye, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface FileChange {
  file: string;
  status: "modified" | "added" | "deleted" | "renamed" | "untracked";
  changes: number;
}

interface Commit {
  id: string;
  message: string;
  author: string;
  date: Date;
  files: number;
}

interface Branch {
  name: string;
  current: boolean;
  ahead: number;
  behind: number;
  lastCommit: Date;
}

export default function SourceControlPanel() {
  const [commitMessage, setCommitMessage] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<Set<string>>(new Set());

  const changes: FileChange[] = [
    { file: "src/main.js", status: "modified", changes: 15 },
    { file: "src/components/editor.tsx", status: "modified", changes: 8 },
    { file: "src/utils/helpers.ts", status: "added", changes: 42 },
    { file: "docs/README.md", status: "modified", changes: 3 },
    { file: "package.json", status: "modified", changes: 2 },
    { file: "src/legacy/old-code.js", status: "deleted", changes: 0 },
  ];

  const commits: Commit[] = [
    {
      id: "a1b2c3d",
      message: "Add Monaco editor integration",
      author: "Developer",
      date: new Date(Date.now() - 2 * 60 * 60 * 1000),
      files: 5
    },
    {
      id: "e4f5g6h",
      message: "Implement file tree navigation",
      author: "Developer", 
      date: new Date(Date.now() - 5 * 60 * 60 * 1000),
      files: 3
    },
    {
      id: "i7j8k9l",
      message: "Setup project structure and dependencies",
      author: "Developer",
      date: new Date(Date.now() - 24 * 60 * 60 * 1000),
      files: 8
    }
  ];

  const branches: Branch[] = [
    { name: "main", current: true, ahead: 2, behind: 0, lastCommit: new Date(Date.now() - 2 * 60 * 60 * 1000) },
    { name: "feature/settings-panel", current: false, ahead: 5, behind: 1, lastCommit: new Date(Date.now() - 24 * 60 * 60 * 1000) },
    { name: "bugfix/terminal-fixes", current: false, ahead: 0, behind: 3, lastCommit: new Date(Date.now() - 48 * 60 * 60 * 1000) }
  ];

  const getStatusIcon = (status: FileChange["status"]) => {
    switch (status) {
      case "modified": return "M";
      case "added": return "A";
      case "deleted": return "D";
      case "renamed": return "R";
      case "untracked": return "U";
    }
  };

  const getStatusColor = (status: FileChange["status"]) => {
    switch (status) {
      case "modified": return "text-orange-400";
      case "added": return "text-green-400";
      case "deleted": return "text-red-400";
      case "renamed": return "text-blue-400";
      case "untracked": return "text-gray-400";
    }
  };

  const toggleFileSelection = (file: string) => {
    const newSelected = new Set(selectedFiles);
    if (newSelected.has(file)) {
      newSelected.delete(file);
    } else {
      newSelected.add(file);
    }
    setSelectedFiles(newSelected);
  };

  const selectAllFiles = () => {
    setSelectedFiles(new Set(changes.map(c => c.file)));
  };

  const deselectAllFiles = () => {
    setSelectedFiles(new Set());
  };

  const handleCommit = () => {
    if (commitMessage.trim() && selectedFiles.size > 0) {
      console.log("Committing files:", Array.from(selectedFiles));
      console.log("Commit message:", commitMessage);
      setCommitMessage("");
      setSelectedFiles(new Set());
    }
  };

  const formatRelativeTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) {
      const minutes = Math.floor(diff / (1000 * 60));
      return `${minutes}m ago`;
    } else if (hours < 24) {
      return `${hours}h ago`;
    } else {
      const days = Math.floor(hours / 24);
      return `${days}d ago`;
    }
  };

  return (
    <div className="ide-sidebar w-80 border-r ide-border flex flex-col h-full">
      {/* Header */}
      <div className="p-3 border-b ide-border">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-medium text-sm">SOURCE CONTROL</h3>
          <div className="flex space-x-1">
            <Button
              variant="ghost"
              size="sm"
              className="text-[var(--ide-text-secondary)] hover:text-[var(--ide-text)] p-1"
              title="Refresh"
            >
              <RefreshCw className="h-3 w-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-[var(--ide-text-secondary)] hover:text-[var(--ide-text)] p-1"
              title="More Actions"
            >
              <MoreHorizontal className="h-3 w-3" />
            </Button>
          </div>
        </div>

        {/* Repository Status */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center space-x-2">
              <GitBranch className="h-3 w-3" />
              <span className="font-medium">main</span>
              {branches.find(b => b.current)?.ahead ? (
                <Badge variant="outline" className="text-xs px-1 py-0">
                  ↑{branches.find(b => b.current)?.ahead}
                </Badge>
              ) : null}
            </div>
            <div className="flex space-x-1">
              <Button
                variant="ghost"
                size="sm"
                className="text-[var(--ide-text-secondary)] hover:text-[var(--ide-text)] p-1"
                title="Pull"
              >
                <Download className="h-3 w-3" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-[var(--ide-text-secondary)] hover:text-[var(--ide-text)] p-1"
                title="Push"
              >
                <Upload className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        <Tabs defaultValue="changes" className="h-full flex flex-col">
          <TabsList className="border-b ide-border w-full justify-start rounded-none bg-transparent p-0 h-auto">
            <TabsTrigger 
              value="changes" 
              className="data-[state=active]:bg-[var(--ide-panel)] text-xs px-3 py-2"
            >
              Changes ({changes.length})
            </TabsTrigger>
            <TabsTrigger 
              value="history" 
              className="data-[state=active]:bg-[var(--ide-panel)] text-xs px-3 py-2"
            >
              History
            </TabsTrigger>
            <TabsTrigger 
              value="branches" 
              className="data-[state=active]:bg-[var(--ide-panel)] text-xs px-3 py-2"
            >
              Branches
            </TabsTrigger>
          </TabsList>

          <TabsContent value="changes" className="flex-1 m-0 overflow-hidden flex flex-col">
            {/* Commit Section */}
            <div className="p-3 border-b ide-border">
              <Textarea
                placeholder="Message (press Ctrl+Enter to commit)"
                value={commitMessage}
                onChange={(e) => setCommitMessage(e.target.value)}
                className="min-h-[60px] mb-2 text-xs bg-[var(--ide-panel)] border-[var(--ide-border)] resize-none"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && e.ctrlKey) {
                    handleCommit();
                  }
                }}
              />
              <div className="flex items-center justify-between">
                <div className="text-xs text-[var(--ide-text-secondary)]">
                  {selectedFiles.size} of {changes.length} files staged
                </div>
                <Button
                  onClick={handleCommit}
                  disabled={!commitMessage.trim() || selectedFiles.size === 0}
                  size="sm"
                  className="text-xs px-3 py-1 h-auto"
                >
                  <GitCommit className="h-3 w-3 mr-1" />
                  Commit
                </Button>
              </div>
            </div>

            {/* File Changes */}
            <div className="flex-1 overflow-hidden">
              <div className="p-3 border-b ide-border">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium">CHANGES</span>
                  <div className="flex space-x-1">
                    <Button
                      onClick={selectAllFiles}
                      variant="ghost"
                      size="sm"
                      className="text-xs px-2 py-1 h-auto"
                    >
                      <Plus className="h-3 w-3 mr-1" />
                      Stage All
                    </Button>
                  </div>
                </div>
              </div>
              
              <ScrollArea className="flex-1">
                <div className="space-y-1 p-2">
                  {changes.map((change) => (
                    <div
                      key={change.file}
                      className="flex items-center justify-between p-2 rounded hover:bg-[var(--ide-panel)] transition-colors cursor-pointer group"
                      onClick={() => toggleFileSelection(change.file)}
                    >
                      <div className="flex items-center space-x-2 flex-1 min-w-0">
                        <div className={`text-xs font-mono w-4 text-center ${getStatusColor(change.status)}`}>
                          {getStatusIcon(change.status)}
                        </div>
                        <span className="text-xs font-mono truncate">{change.file}</span>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        {change.changes > 0 && (
                          <span className="text-xs text-[var(--ide-text-secondary)]">
                            +{change.changes}
                          </span>
                        )}
                        <div className={`w-3 h-3 rounded border ${
                          selectedFiles.has(change.file)
                            ? 'bg-[var(--ide-accent)] border-[var(--ide-accent)]'
                            : 'border-[var(--ide-border)]'
                        }`} />
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="history" className="flex-1 m-0 overflow-hidden">
            <ScrollArea className="h-full">
              <div className="p-3 space-y-3">
                {commits.map((commit) => (
                  <Card key={commit.id} className="bg-[var(--ide-panel)] border-[var(--ide-border)]">
                    <CardContent className="p-3">
                      <div className="space-y-2">
                        <div className="flex items-start justify-between">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-[var(--ide-text)] truncate">
                              {commit.message}
                            </p>
                            <div className="flex items-center space-x-2 text-xs text-[var(--ide-text-secondary)] mt-1">
                              <span>{commit.author}</span>
                              <span>•</span>
                              <span>{formatRelativeTime(commit.date)}</span>
                              <span>•</span>
                              <span>{commit.files} files</span>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="p-1 opacity-0 group-hover:opacity-100"
                          >
                            <Eye className="h-3 w-3" />
                          </Button>
                        </div>
                        <div className="font-mono text-xs text-[var(--ide-text-secondary)]">
                          {commit.id}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="branches" className="flex-1 m-0 overflow-hidden">
            <ScrollArea className="h-full">
              <div className="p-3 space-y-2">
                {branches.map((branch) => (
                  <div
                    key={branch.name}
                    className={`p-2 rounded transition-colors cursor-pointer ${
                      branch.current ? 'bg-[var(--ide-panel)]' : 'hover:bg-[var(--ide-panel)]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <GitBranch className={`h-3 w-3 ${
                          branch.current ? 'text-[var(--ide-accent)]' : 'text-[var(--ide-text-secondary)]'
                        }`} />
                        <span className={`text-sm font-mono ${
                          branch.current ? 'font-medium text-[var(--ide-text)]' : 'text-[var(--ide-text-secondary)]'
                        }`}>
                          {branch.name}
                        </span>
                        {branch.current && (
                          <Badge variant="outline" className="text-xs px-1 py-0">
                            current
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center space-x-1">
                        {branch.ahead > 0 && (
                          <Badge variant="outline" className="text-xs px-1 py-0">
                            ↑{branch.ahead}
                          </Badge>
                        )}
                        {branch.behind > 0 && (
                          <Badge variant="outline" className="text-xs px-1 py-0">
                            ↓{branch.behind}
                          </Badge>
                        )}
                        {!branch.current && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="p-1"
                            title="Switch to branch"
                          >
                            <GitMerge className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </div>
                    
                    <div className="text-xs text-[var(--ide-text-secondary)] mt-1 ml-5">
                      Last commit {formatRelativeTime(branch.lastCommit)}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}