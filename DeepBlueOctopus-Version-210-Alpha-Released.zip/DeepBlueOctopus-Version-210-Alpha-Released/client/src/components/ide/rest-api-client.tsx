import React, { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { 
  Send, Save, Folder, History, Code, Eye,
  Download, Upload, Copy, Trash2, Plus,
  Clock, CheckCircle2, XCircle, AlertCircle,
  Globe, Key, Server, BarChart3, Settings
} from "lucide-react";

interface RestApiClientProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ApiRequest {
  id: string;
  name: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH' | 'HEAD' | 'OPTIONS';
  url: string;
  headers: Record<string, string>;
  body?: string;
  params: Record<string, string>;
  auth?: {
    type: 'none' | 'bearer' | 'basic' | 'api-key';
    token?: string;
    username?: string;
    password?: string;
    apiKey?: string;
    apiKeyHeader?: string;
  };
  timestamp: Date;
}

interface ApiResponse {
  id: string;
  requestId: string;
  status: number;
  statusText: string;
  headers: Record<string, string>;
  body: string;
  responseTime: number;
  size: number;
  timestamp: Date;
}

interface Environment {
  id: string;
  name: string;
  variables: Record<string, string>;
  active: boolean;
}

interface Collection {
  id: string;
  name: string;
  description: string;
  requests: string[];
  folder?: string;
}

export default function RestApiClient({ isOpen, onClose }: RestApiClientProps) {
  const [activeTab, setActiveTab] = useState("request");
  const [currentRequest, setCurrentRequest] = useState<ApiRequest>({
    id: 'new',
    name: 'Untitled Request',
    method: 'GET',
    url: 'https://jsonplaceholder.typicode.com/posts',
    headers: { 'Content-Type': 'application/json' },
    params: {},
    auth: { type: 'none' },
    timestamp: new Date()
  });

  const [responses, setResponses] = useState<ApiResponse[]>([
    {
      id: 'resp-1',
      requestId: 'req-1',
      status: 200,
      statusText: 'OK',
      headers: {
        'content-type': 'application/json; charset=utf-8',
        'content-length': '1234',
        'server': 'nginx/1.18.0'
      },
      body: JSON.stringify([
        { id: 1, title: 'Hello World', body: 'This is a test post', userId: 1 },
        { id: 2, title: 'Another Post', body: 'Another test post', userId: 1 }
      ], null, 2),
      responseTime: 234,
      size: 1234,
      timestamp: new Date(Date.now() - 300000)
    }
  ]);

  const [savedRequests, setSavedRequests] = useState<ApiRequest[]>([
    {
      id: 'req-1',
      name: 'Get Posts',
      method: 'GET',
      url: 'https://jsonplaceholder.typicode.com/posts',
      headers: { 'Content-Type': 'application/json' },
      params: {},
      auth: { type: 'none' },
      timestamp: new Date(Date.now() - 3600000)
    },
    {
      id: 'req-2',
      name: 'Create Post',
      method: 'POST',
      url: 'https://jsonplaceholder.typicode.com/posts',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'New Post',
        body: 'Post content',
        userId: 1
      }, null, 2),
      params: {},
      auth: { type: 'bearer', token: 'your-auth-token' },
      timestamp: new Date(Date.now() - 1800000)
    }
  ]);

  const [environments, setEnvironments] = useState<Environment[]>([
    {
      id: 'local',
      name: 'Local Development',
      variables: {
        'baseUrl': 'http://localhost:3000',
        'apiKey': 'dev-api-key-123'
      },
      active: true
    },
    {
      id: 'staging',
      name: 'Staging',
      variables: {
        'baseUrl': 'https://staging-api.example.com',
        'apiKey': 'staging-api-key-456'
      },
      active: false
    },
    {
      id: 'production',
      name: 'Production',
      variables: {
        'baseUrl': 'https://api.example.com',
        'apiKey': 'prod-api-key-789'
      },
      active: false
    }
  ]);

  const [collections, setCollections] = useState<Collection[]>([
    {
      id: 'coll-1',
      name: 'JSONPlaceholder API',
      description: 'Testing endpoints for JSONPlaceholder',
      requests: ['req-1', 'req-2']
    }
  ]);

  const [isLoading, setIsLoading] = useState(false);
  const [currentResponse, setCurrentResponse] = useState<ApiResponse | null>(
    responses.length > 0 ? responses[0] : null
  );

  const methodColors = {
    GET: 'bg-green-500',
    POST: 'bg-blue-500',
    PUT: 'bg-yellow-500',
    DELETE: 'bg-red-500',
    PATCH: 'bg-purple-500',
    HEAD: 'bg-gray-500',
    OPTIONS: 'bg-orange-500'
  };

  const sendRequest = async () => {
    setIsLoading(true);
    
    try {
      // Simulate API request
      await new Promise(resolve => setTimeout(resolve, Math.random() * 2000 + 500));
      
      const newResponse: ApiResponse = {
        id: `resp-${Date.now()}`,
        requestId: currentRequest.id,
        status: Math.random() > 0.8 ? 500 : 200,
        statusText: Math.random() > 0.8 ? 'Internal Server Error' : 'OK',
        headers: {
          'content-type': 'application/json; charset=utf-8',
          'content-length': '1234',
          'server': 'nginx/1.18.0',
          'x-response-time': '234ms'
        },
        body: currentRequest.method === 'GET' 
          ? JSON.stringify([
              { id: 1, title: 'Sample Post', body: 'This is a sample response', userId: 1 },
              { id: 2, title: 'Another Post', body: 'Another sample response', userId: 1 }
            ], null, 2)
          : JSON.stringify({ id: 3, title: 'Created Post', body: 'New post created', userId: 1 }, null, 2),
        responseTime: Math.floor(Math.random() * 1000 + 100),
        size: Math.floor(Math.random() * 5000 + 1000),
        timestamp: new Date()
      };
      
      setResponses(prev => [newResponse, ...prev]);
      setCurrentResponse(newResponse);
    } finally {
      setIsLoading(false);
    }
  };

  const saveRequest = () => {
    const requestToSave = {
      ...currentRequest,
      id: currentRequest.id === 'new' ? `req-${Date.now()}` : currentRequest.id,
      timestamp: new Date()
    };
    
    setSavedRequests(prev => {
      const existing = prev.find(req => req.id === requestToSave.id);
      if (existing) {
        return prev.map(req => req.id === requestToSave.id ? requestToSave : req);
      }
      return [requestToSave, ...prev];
    });
    
    setCurrentRequest(requestToSave);
  };

  const loadRequest = (request: ApiRequest) => {
    setCurrentRequest({ ...request });
    const response = responses.find(resp => resp.requestId === request.id);
    if (response) setCurrentResponse(response);
  };

  const updateHeader = (key: string, value: string) => {
    setCurrentRequest(prev => ({
      ...prev,
      headers: { ...prev.headers, [key]: value }
    }));
  };

  const removeHeader = (key: string) => {
    setCurrentRequest(prev => {
      const { [key]: removed, ...rest } = prev.headers;
      return { ...prev, headers: rest };
    });
  };

  const addHeader = () => {
    updateHeader('New-Header', '');
  };

  const updateParam = (key: string, value: string) => {
    setCurrentRequest(prev => ({
      ...prev,
      params: { ...prev.params, [key]: value }
    }));
  };

  const removeParam = (key: string) => {
    setCurrentRequest(prev => {
      const { [key]: removed, ...rest } = prev.params;
      return { ...prev, params: rest };
    });
  };

  const addParam = () => {
    updateParam('new_param', '');
  };

  const replaceVariables = (text: string) => {
    const activeEnv = environments.find(env => env.active);
    if (!activeEnv) return text;
    
    let result = text;
    Object.entries(activeEnv.variables).forEach(([key, value]) => {
      result = result.replace(new RegExp(`{{${key}}}`, 'g'), value);
    });
    return result;
  };

  const formatResponseBody = (body: string, contentType: string) => {
    try {
      if (contentType.includes('application/json')) {
        return JSON.stringify(JSON.parse(body), null, 2);
      }
      return body;
    } catch {
      return body;
    }
  };

  const exportCollection = (collection: Collection) => {
    const data = {
      collection,
      requests: savedRequests.filter(req => collection.requests.includes(req.id))
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${collection.name}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return 'text-green-600';
    if (status >= 300 && status < 400) return 'text-yellow-600';
    if (status >= 400 && status < 500) return 'text-orange-600';
    if (status >= 500) return 'text-red-600';
    return 'text-gray-600';
  };

  const activeEnvironment = environments.find(env => env.active);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5 text-blue-500" />
            REST API Client
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Sidebar */}
          <Card className="lg:col-span-1 flex flex-col">
            <CardHeader className="flex-shrink-0">
              <CardTitle className="text-base">Collections & History</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-hidden">
              <Tabs defaultValue="collections" className="h-full flex flex-col">
                <TabsList className="grid w-full grid-cols-2 flex-shrink-0">
                  <TabsTrigger value="collections">Collections</TabsTrigger>
                  <TabsTrigger value="history">History</TabsTrigger>
                </TabsList>
                
                <TabsContent value="collections" className="flex-1 overflow-hidden mt-4">
                  <ScrollArea className="h-full">
                    <div className="space-y-3">
                      {collections.map((collection) => (
                        <div key={collection.id} className="border rounded-lg p-3">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium text-sm">{collection.name}</h4>
                            <Button size="sm" variant="outline" onClick={() => exportCollection(collection)}>
                              <Download className="h-3 w-3" />
                            </Button>
                          </div>
                          <p className="text-xs text-muted-foreground mb-2">{collection.description}</p>
                          <div className="space-y-1">
                            {collection.requests.map((requestId) => {
                              const request = savedRequests.find(req => req.id === requestId);
                              if (!request) return null;
                              
                              return (
                                <div 
                                  key={requestId}
                                  className="flex items-center gap-2 p-2 rounded hover:bg-accent cursor-pointer text-xs"
                                  onClick={() => loadRequest(request)}
                                >
                                  <Badge className={`${methodColors[request.method]} text-white text-xs`}>
                                    {request.method}
                                  </Badge>
                                  <span className="truncate">{request.name}</span>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </TabsContent>
                
                <TabsContent value="history" className="flex-1 overflow-hidden mt-4">
                  <ScrollArea className="h-full">
                    <div className="space-y-2">
                      {savedRequests.map((request) => (
                        <div 
                          key={request.id}
                          className="flex items-center gap-2 p-2 rounded hover:bg-accent cursor-pointer"
                          onClick={() => loadRequest(request)}
                        >
                          <Badge className={`${methodColors[request.method]} text-white text-xs`}>
                            {request.method}
                          </Badge>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{request.name}</p>
                            <p className="text-xs text-muted-foreground truncate">{request.url}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Main Content */}
          <div className="lg:col-span-3 flex flex-col space-y-4">
            {/* Environment Selector */}
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <Label>Environment:</Label>
                  <Select 
                    value={activeEnvironment?.id} 
                    onValueChange={(envId) => {
                      setEnvironments(prev => prev.map(env => ({
                        ...env,
                        active: env.id === envId
                      })));
                    }}
                  >
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {environments.map(env => (
                        <SelectItem key={env.id} value={env.id}>{env.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button size="sm" variant="outline">
                    <Settings className="h-4 w-4 mr-2" />
                    Manage
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Request Builder */}
            <Card className="flex-1 overflow-hidden">
              <CardHeader className="flex-shrink-0">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">Request</CardTitle>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={saveRequest}>
                      <Save className="h-4 w-4 mr-2" />
                      Save
                    </Button>
                    <Button size="sm" onClick={sendRequest} disabled={isLoading}>
                      <Send className="h-4 w-4 mr-2" />
                      {isLoading ? 'Sending...' : 'Send'}
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="flex-1 overflow-hidden">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
                  <div className="flex items-center gap-4 mb-4 flex-shrink-0">
                    <Input 
                      value={currentRequest.name}
                      onChange={(e) => setCurrentRequest(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Request name"
                      className="w-48"
                    />
                    <Select 
                      value={currentRequest.method} 
                      onValueChange={(method) => setCurrentRequest(prev => ({ ...prev, method: method as any }))}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.keys(methodColors).map(method => (
                          <SelectItem key={method} value={method}>{method}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input 
                      value={currentRequest.url}
                      onChange={(e) => setCurrentRequest(prev => ({ ...prev, url: e.target.value }))}
                      placeholder="Enter request URL"
                      className="flex-1"
                    />
                  </div>

                  <TabsList className="grid w-full grid-cols-5 flex-shrink-0">
                    <TabsTrigger value="request">Params</TabsTrigger>
                    <TabsTrigger value="headers">Headers</TabsTrigger>
                    <TabsTrigger value="body">Body</TabsTrigger>
                    <TabsTrigger value="auth">Auth</TabsTrigger>
                    <TabsTrigger value="response">Response</TabsTrigger>
                  </TabsList>

                  <TabsContent value="request" className="flex-1 overflow-hidden">
                    <ScrollArea className="h-full">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label>Query Parameters</Label>
                          <Button size="sm" variant="outline" onClick={addParam}>
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                        {Object.entries(currentRequest.params).map(([key, value]) => (
                          <div key={key} className="flex items-center gap-2">
                            <Input 
                              value={key}
                              onChange={(e) => {
                                const newKey = e.target.value;
                                removeParam(key);
                                updateParam(newKey, value);
                              }}
                              placeholder="Parameter name"
                              className="flex-1"
                            />
                            <Input 
                              value={value}
                              onChange={(e) => updateParam(key, e.target.value)}
                              placeholder="Parameter value"
                              className="flex-1"
                            />
                            <Button size="sm" variant="outline" onClick={() => removeParam(key)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </TabsContent>

                  <TabsContent value="headers" className="flex-1 overflow-hidden">
                    <ScrollArea className="h-full">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label>Headers</Label>
                          <Button size="sm" variant="outline" onClick={addHeader}>
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                        {Object.entries(currentRequest.headers).map(([key, value]) => (
                          <div key={key} className="flex items-center gap-2">
                            <Input 
                              value={key}
                              onChange={(e) => {
                                const newKey = e.target.value;
                                removeHeader(key);
                                updateHeader(newKey, value);
                              }}
                              placeholder="Header name"
                              className="flex-1"
                            />
                            <Input 
                              value={value}
                              onChange={(e) => updateHeader(key, e.target.value)}
                              placeholder="Header value"
                              className="flex-1"
                            />
                            <Button size="sm" variant="outline" onClick={() => removeHeader(key)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </TabsContent>

                  <TabsContent value="body" className="flex-1 overflow-hidden">
                    <div className="space-y-3 h-full">
                      <Label>Request Body</Label>
                      <Textarea 
                        value={currentRequest.body || ''}
                        onChange={(e) => setCurrentRequest(prev => ({ ...prev, body: e.target.value }))}
                        placeholder="Enter request body (JSON, XML, etc.)"
                        className="flex-1 font-mono text-sm"
                        style={{ minHeight: '300px' }}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="auth" className="flex-1 overflow-hidden">
                    <ScrollArea className="h-full">
                      <div className="space-y-4">
                        <div>
                          <Label>Authentication Type</Label>
                          <Select 
                            value={currentRequest.auth?.type} 
                            onValueChange={(type) => setCurrentRequest(prev => ({ 
                              ...prev, 
                              auth: { ...prev.auth, type: type as any } 
                            }))}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="none">No Auth</SelectItem>
                              <SelectItem value="bearer">Bearer Token</SelectItem>
                              <SelectItem value="basic">Basic Auth</SelectItem>
                              <SelectItem value="api-key">API Key</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {currentRequest.auth?.type === 'bearer' && (
                          <div>
                            <Label>Bearer Token</Label>
                            <Input 
                              value={currentRequest.auth.token || ''}
                              onChange={(e) => setCurrentRequest(prev => ({ 
                                ...prev, 
                                auth: { ...prev.auth, token: e.target.value } 
                              }))}
                              placeholder="Enter bearer token"
                              className="mt-1"
                            />
                          </div>
                        )}

                        {currentRequest.auth?.type === 'basic' && (
                          <>
                            <div>
                              <Label>Username</Label>
                              <Input 
                                value={currentRequest.auth.username || ''}
                                onChange={(e) => setCurrentRequest(prev => ({ 
                                  ...prev, 
                                  auth: { ...prev.auth, username: e.target.value } 
                                }))}
                                placeholder="Username"
                                className="mt-1"
                              />
                            </div>
                            <div>
                              <Label>Password</Label>
                              <Input 
                                type="password"
                                value={currentRequest.auth.password || ''}
                                onChange={(e) => setCurrentRequest(prev => ({ 
                                  ...prev, 
                                  auth: { ...prev.auth, password: e.target.value } 
                                }))}
                                placeholder="Password"
                                className="mt-1"
                              />
                            </div>
                          </>
                        )}

                        {currentRequest.auth?.type === 'api-key' && (
                          <>
                            <div>
                              <Label>API Key</Label>
                              <Input 
                                value={currentRequest.auth.apiKey || ''}
                                onChange={(e) => setCurrentRequest(prev => ({ 
                                  ...prev, 
                                  auth: { ...prev.auth, apiKey: e.target.value } 
                                }))}
                                placeholder="API Key"
                                className="mt-1"
                              />
                            </div>
                            <div>
                              <Label>Header Name</Label>
                              <Input 
                                value={currentRequest.auth.apiKeyHeader || 'X-API-Key'}
                                onChange={(e) => setCurrentRequest(prev => ({ 
                                  ...prev, 
                                  auth: { ...prev.auth, apiKeyHeader: e.target.value } 
                                }))}
                                placeholder="X-API-Key"
                                className="mt-1"
                              />
                            </div>
                          </>
                        )}
                      </div>
                    </ScrollArea>
                  </TabsContent>

                  <TabsContent value="response" className="flex-1 overflow-hidden">
                    {currentResponse ? (
                      <div className="space-y-4 h-full">
                        <div className="flex items-center gap-4">
                          <Badge className={`${getStatusColor(currentResponse.status)} text-white`}>
                            {currentResponse.status} {currentResponse.statusText}
                          </Badge>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span>Time: {currentResponse.responseTime}ms</span>
                            <span>Size: {(currentResponse.size / 1024).toFixed(1)} KB</span>
                          </div>
                          <Button size="sm" variant="outline">
                            <Copy className="h-4 w-4 mr-2" />
                            Copy
                          </Button>
                        </div>

                        <Tabs defaultValue="body" className="flex-1 flex flex-col">
                          <TabsList className="grid w-full grid-cols-2 flex-shrink-0">
                            <TabsTrigger value="body">Response Body</TabsTrigger>
                            <TabsTrigger value="headers">Response Headers</TabsTrigger>
                          </TabsList>

                          <TabsContent value="body" className="flex-1 overflow-hidden">
                            <ScrollArea className="h-full">
                              <pre className="text-sm font-mono bg-gray-100 dark:bg-gray-800 p-4 rounded overflow-x-auto">
                                {formatResponseBody(currentResponse.body, currentResponse.headers['content-type'] || '')}
                              </pre>
                            </ScrollArea>
                          </TabsContent>

                          <TabsContent value="headers" className="flex-1 overflow-hidden">
                            <ScrollArea className="h-full">
                              <div className="space-y-2">
                                {Object.entries(currentResponse.headers).map(([key, value]) => (
                                  <div key={key} className="flex items-center gap-2 p-2 border rounded">
                                    <span className="font-mono text-sm font-medium">{key}:</span>
                                    <span className="font-mono text-sm">{value}</span>
                                  </div>
                                ))}
                              </div>
                            </ScrollArea>
                          </TabsContent>
                        </Tabs>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center h-full text-muted-foreground">
                        <div className="text-center">
                          <Send className="h-12 w-12 mx-auto mb-4 opacity-50" />
                          <p>Send a request to see the response</p>
                        </div>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}