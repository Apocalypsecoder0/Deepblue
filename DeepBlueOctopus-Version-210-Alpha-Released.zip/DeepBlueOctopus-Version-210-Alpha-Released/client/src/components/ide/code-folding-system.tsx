import { useState, useRef, useEffect } from "react";
import * as monaco from "monaco-editor";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { 
  ChevronDown, 
  ChevronRight, 
  FoldVertical,
  UnfoldVertical,
  Minus,
  Plus,
  Code2,
  Braces,
  Hash
} from "lucide-react";

interface CodeFoldingSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CodeFoldingSystem({ isOpen, onClose }: CodeFoldingSystemProps) {
  const [foldedRegions, setFoldedRegions] = useState<Array<{startLine: number, endLine: number, type: string}>>([]);
  const [autoFold, setAutoFold] = useState(false);
  const [foldComments, setFoldComments] = useState(true);
  const [foldImports, setFoldImports] = useState(false);
  const [foldFunctions, setFoldFunctions] = useState(false);
  const [foldClasses, setFoldClasses] = useState(false);
  const [foldLevel, setFoldLevel] = useState(1);
  const editorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const foldingActions = [
    { 
      name: "Fold All", 
      icon: <FoldVertical className="w-4 h-4" />,
      action: () => foldAll(),
      shortcut: "Ctrl+K, Ctrl+0"
    },
    { 
      name: "Unfold All", 
      icon: <UnfoldVertical className="w-4 h-4" />,
      action: () => unfoldAll(),
      shortcut: "Ctrl+K, Ctrl+J"
    },
    { 
      name: "Fold Level 1", 
      icon: <Minus className="w-4 h-4" />,
      action: () => foldLevel1(),
      shortcut: "Ctrl+K, Ctrl+1"
    },
    { 
      name: "Fold Level 2", 
      icon: <Minus className="w-4 h-4" />,
      action: () => foldLevel2(),
      shortcut: "Ctrl+K, Ctrl+2"
    },
    { 
      name: "Fold Recursively", 
      icon: <ChevronDown className="w-4 h-4" />,
      action: () => foldRecursively(),
      shortcut: "Ctrl+K, Ctrl+["
    },
    { 
      name: "Unfold Recursively", 
      icon: <ChevronRight className="w-4 h-4" />,
      action: () => unfoldRecursively(),
      shortcut: "Ctrl+K, Ctrl+]"
    }
  ];

  const foldingTypes = [
    { type: "function", icon: <Code2 className="w-4 h-4" />, name: "Functions", count: 0 },
    { type: "class", icon: <Braces className="w-4 h-4" />, name: "Classes", count: 0 },
    { type: "comment", icon: <Hash className="w-4 h-4" />, name: "Comments", count: 0 },
    { type: "imports", icon: <Plus className="w-4 h-4" />, name: "Imports", count: 0 }
  ];

  useEffect(() => {
    if (isOpen && containerRef.current) {
      initializeEditor();
    }
    return () => {
      if (editorRef.current) {
        editorRef.current.dispose();
      }
    };
  }, [isOpen]);

  const initializeEditor = () => {
    if (containerRef.current) {
      const sampleCode = `import React from 'react';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';

/**
 * This is a complex React component that demonstrates
 * various code folding capabilities including:
 * - Import statements
 * - Multi-line comments
 * - Class definitions
 * - Function definitions
 * - Object literals
 * - Arrays and nested structures
 */

// Configuration object with nested properties
const CONFIG = {
  theme: {
    colors: {
      primary: '#007acc',
      secondary: '#ff6b35',
      background: '#1e1e1e'
    },
    typography: {
      fontFamily: 'Monaco, monospace',
      fontSize: 14,
      lineHeight: 1.5
    }
  },
  features: {
    folding: true,
    minimap: true,
    lineNumbers: true
  }
};

/**
 * UserProfile class representing a user in the system
 * Contains user data and methods for manipulation
 */
class UserProfile {
  constructor(name, email, preferences) {
    this.name = name;
    this.email = email;
    this.preferences = preferences;
    this.createdAt = new Date();
  }

  // Method to update user preferences
  updatePreferences(newPreferences) {
    this.preferences = {
      ...this.preferences,
      ...newPreferences
    };
  }

  // Method to get user display name
  getDisplayName() {
    return this.name || this.email.split('@')[0];
  }

  // Method to validate user data
  validate() {
    return this.name && this.email && this.email.includes('@');
  }
}

/**
 * Main application component with complex nested structure
 * Demonstrates various React patterns and code organization
 */
function ApplicationComponent() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Effect hook for loading initial data
  useEffect(() => {
    async function loadUsers() {
      setLoading(true);
      try {
        const response = await fetch('/api/users');
        const userData = await response.json();
        setUsers(userData);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }
    loadUsers();
  }, []);

  // Handler for adding new user
  const handleAddUser = async (userData) => {
    try {
      const newUser = new UserProfile(
        userData.name,
        userData.email,
        userData.preferences
      );
      
      if (newUser.validate()) {
        setUsers(prev => [...prev, newUser]);
      }
    } catch (error) {
      setError('Failed to add user');
    }
  };

  // Handler for updating user
  const handleUpdateUser = (userId, updates) => {
    setUsers(prev => 
      prev.map(user => 
        user.id === userId 
          ? { ...user, ...updates }
          : user
      )
    );
  };

  // Render helper for user list
  const renderUserList = () => {
    if (loading) {
      return <div>Loading users...</div>;
    }

    if (error) {
      return <div>Error: {error}</div>;
    }

    return (
      <div className="user-list">
        {users.map(user => (
          <div key={user.id} className="user-item">
            <h3>{user.getDisplayName()}</h3>
            <p>{user.email}</p>
            <Button 
              onClick={() => handleUpdateUser(user.id, { active: !user.active })}
            >
              Toggle Active
            </Button>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="application">
      <header className="app-header">
        <h1>User Management System</h1>
      </header>
      
      <main className="app-main">
        {renderUserList()}
      </main>
      
      <footer className="app-footer">
        <p>© 2025 DeepBlue IDE</p>
      </footer>
    </div>
  );
}

export default ApplicationComponent;`;

      editorRef.current = monaco.editor.create(containerRef.current, {
        value: sampleCode,
        language: 'javascript',
        theme: 'vs-dark',
        fontSize: 14,
        lineNumbers: 'on',
        minimap: { enabled: true },
        wordWrap: 'on',
        folding: true,
        foldingStrategy: 'auto',
        foldingHighlight: true,
        unfoldOnClickAfterEndOfLine: true,
        showFoldedAreaOnHoverTimeout: 300,
      });

      // Listen for folding changes
      editorRef.current.onDidChangeFoldingState(() => {
        updateFoldedRegions();
      });

      // Set up auto-folding if enabled
      if (autoFold) {
        setTimeout(() => {
          applyAutoFolding();
        }, 500);
      }
    }
  };

  const updateFoldedRegions = () => {
    if (!editorRef.current) return;

    const model = editorRef.current.getModel();
    if (model) {
      const foldingRegions = editorRef.current.getHiddenAreas();
      const regions = foldingRegions.map(region => ({
        startLine: region.startLineNumber,
        endLine: region.endLineNumber,
        type: detectRegionType(model, region.startLineNumber)
      }));
      setFoldedRegions(regions);
    }
  };

  const detectRegionType = (model: monaco.editor.ITextModel, startLine: number) => {
    const lineContent = model.getLineContent(startLine);
    
    if (lineContent.includes('import') || lineContent.includes('require')) {
      return 'imports';
    } else if (lineContent.includes('/*') || lineContent.includes('//')) {
      return 'comment';
    } else if (lineContent.includes('function') || lineContent.includes('=>')) {
      return 'function';
    } else if (lineContent.includes('class')) {
      return 'class';
    }
    return 'block';
  };

  const foldAll = () => {
    if (editorRef.current) {
      editorRef.current.trigger('fold', 'editor.foldAll', {});
    }
  };

  const unfoldAll = () => {
    if (editorRef.current) {
      editorRef.current.trigger('unfold', 'editor.unfoldAll', {});
    }
  };

  const foldLevel1 = () => {
    if (editorRef.current) {
      editorRef.current.trigger('fold', 'editor.foldLevel1', {});
    }
  };

  const foldLevel2 = () => {
    if (editorRef.current) {
      editorRef.current.trigger('fold', 'editor.foldLevel2', {});
    }
  };

  const foldRecursively = () => {
    if (editorRef.current) {
      editorRef.current.trigger('fold', 'editor.foldRecursively', {});
    }
  };

  const unfoldRecursively = () => {
    if (editorRef.current) {
      editorRef.current.trigger('unfold', 'editor.unfoldRecursively', {});
    }
  };

  const applyAutoFolding = () => {
    if (!editorRef.current) return;

    if (foldImports) {
      // Fold import statements
      editorRef.current.trigger('fold', 'editor.foldAllMarkerRegions', {});
    }
    
    if (foldComments) {
      // Fold comment blocks
      editorRef.current.trigger('fold', 'editor.foldAllBlockComments', {});
    }

    if (foldFunctions) {
      // Fold function definitions
      // This would require custom logic to detect function boundaries
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-900 border border-gray-700 rounded-lg w-[95vw] h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <FoldVertical className="w-6 h-6 text-blue-400" />
            <div>
              <h2 className="text-lg font-semibold text-white">Code Folding System</h2>
              <p className="text-sm text-gray-400">Advanced code organization and navigation</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            ✕
          </Button>
        </div>

        {/* Content */}
        <div className="flex flex-1 overflow-hidden">
          {/* Editor Panel */}
          <div className="flex-1 flex flex-col">
            {/* Toolbar */}
            <div className="flex items-center justify-between p-3 bg-gray-800 border-b border-gray-700">
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{foldedRegions.length} Folded Regions</Badge>
                <Badge variant="outline">Level {foldLevel}</Badge>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Switch 
                    checked={autoFold}
                    onCheckedChange={setAutoFold}
                  />
                  <span className="text-sm text-gray-300">Auto-fold</span>
                </div>
              </div>
            </div>

            {/* Editor */}
            <div ref={containerRef} className="flex-1" />
          </div>

          {/* Controls Panel */}
          <div className="w-80 bg-gray-800 border-l border-gray-700 flex flex-col">
            <div className="p-4">
              <h3 className="text-sm font-semibold text-white mb-3">Folding Controls</h3>
              
              <ScrollArea className="h-96">
                <div className="space-y-3">
                  {/* Folding Actions */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-semibold text-gray-400 uppercase">Actions</h4>
                    {foldingActions.map((action, index) => (
                      <div key={index} className="space-y-1">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={action.action}
                          className="w-full justify-start text-left"
                        >
                          {action.icon}
                          <span className="ml-2">{action.name}</span>
                        </Button>
                        <p className="text-xs text-gray-400 ml-6">{action.shortcut}</p>
                      </div>
                    ))}
                  </div>

                  {/* Auto-folding Options */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-semibold text-gray-400 uppercase">Auto-fold</h4>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-300">Comments</span>
                        <Switch 
                          checked={foldComments}
                          onCheckedChange={setFoldComments}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-300">Imports</span>
                        <Switch 
                          checked={foldImports}
                          onCheckedChange={setFoldImports}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-300">Functions</span>
                        <Switch 
                          checked={foldFunctions}
                          onCheckedChange={setFoldFunctions}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-300">Classes</span>
                        <Switch 
                          checked={foldClasses}
                          onCheckedChange={setFoldClasses}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Folding Statistics */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-semibold text-gray-400 uppercase">Statistics</h4>
                    {foldingTypes.map((type, index) => (
                      <Card key={index} className="p-3 bg-gray-700 border-gray-600">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            {type.icon}
                            <span className="text-sm text-white">{type.name}</span>
                          </div>
                          <Badge variant="secondary">{type.count}</Badge>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              </ScrollArea>
            </div>

            {/* Active Folded Regions */}
            <div className="p-4 border-t border-gray-700">
              <h4 className="text-sm font-semibold text-white mb-2">Folded Regions</h4>
              <ScrollArea className="h-32">
                <div className="space-y-1">
                  {foldedRegions.map((region, index) => (
                    <div key={index} className="text-xs text-gray-400 p-2 bg-gray-700 rounded">
                      <div className="flex items-center justify-between">
                        <span>Lines {region.startLine}-{region.endLine}</span>
                        <Badge variant="outline" className="text-xs">{region.type}</Badge>
                      </div>
                    </div>
                  ))}
                  {foldedRegions.length === 0 && (
                    <p className="text-xs text-gray-500">No folded regions</p>
                  )}
                </div>
              </ScrollArea>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}