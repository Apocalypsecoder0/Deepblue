import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  Target, 
  Trophy, 
  Star, 
  Clock, 
  CheckCircle, 
  XCircle, 
  PlayCircle,
  PauseCircle,
  RotateCcw,
  Calendar,
  User,
  Award,
  Zap,
  Coins,
  Gift,
  Users,
  TrendingUp,
  Settings,
  Plus,
  Edit,
  Trash2,
  Filter,
  Search,
  BookOpen,
  Code,
  Database,
  Globe,
  Gamepad2,
  Sparkles
} from "lucide-react";

interface MissionSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Mission {
  id: string;
  title: string;
  description: string;
  category: 'coding' | 'learning' | 'collaboration' | 'achievement' | 'daily' | 'weekly';
  difficulty: 'easy' | 'medium' | 'hard' | 'expert';
  status: 'active' | 'completed' | 'failed' | 'pending';
  progress: number;
  maxProgress: number;
  reward: {
    points: number;
    coins: number;
    badges: string[];
    unlocks: string[];
  };
  requirements: {
    description: string;
    completed: boolean;
  }[];
  timeLimit?: number; // in hours
  createdAt: string;
  completedAt?: string;
  assignedBy?: string;
}

interface UserStats {
  totalMissions: number;
  completedMissions: number;
  failedMissions: number;
  totalPoints: number;
  totalCoins: number;
  currentLevel: number;
  experiencePoints: number;
  nextLevelExp: number;
  badges: string[];
  streak: number;
  rank: string;
}

export default function MissionSystem({ isOpen, onClose }: MissionSystemProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('active');
  const [missions, setMissions] = useState<Mission[]>([]);
  const [userStats, setUserStats] = useState<UserStats>({
    totalMissions: 0,
    completedMissions: 0,
    failedMissions: 0,
    totalPoints: 0,
    totalCoins: 0,
    currentLevel: 1,
    experiencePoints: 0,
    nextLevelExp: 1000,
    badges: [],
    streak: 0,
    rank: 'Novice'
  });
  const [loading, setLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateMission, setShowCreateMission] = useState(false);
  const [newMission, setNewMission] = useState({
    title: '',
    description: '',
    category: 'coding' as Mission['category'],
    difficulty: 'medium' as Mission['difficulty'],
    timeLimit: 24,
    requirements: ['']
  });

  useEffect(() => {
    if (isOpen) {
      loadMissions();
      loadUserStats();
    }
  }, [isOpen]);

  const loadMissions = async () => {
    try {
      const response = await fetch('/api/missions');
      const data = await response.json();
      setMissions(data);
    } catch (error) {
      console.error('Failed to load missions:', error);
      // Initialize with sample missions
      setMissions(sampleMissions);
    }
  };

  const loadUserStats = async () => {
    try {
      const response = await fetch('/api/missions/stats');
      const data = await response.json();
      setUserStats(data);
    } catch (error) {
      console.error('Failed to load user stats:', error);
      // Use sample stats
      setUserStats({
        totalMissions: 15,
        completedMissions: 8,
        failedMissions: 2,
        totalPoints: 2450,
        totalCoins: 125,
        currentLevel: 5,
        experiencePoints: 2450,
        nextLevelExp: 3000,
        badges: ['First Steps', 'Code Warrior', 'Team Player'],
        streak: 7,
        rank: 'Advanced'
      });
    }
  };

  const startMission = async (missionId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/missions/${missionId}/start`, {
        method: 'POST'
      });
      
      if (response.ok) {
        await loadMissions();
        toast({
          title: "Mission Started",
          description: "Mission has been activated and is now in progress.",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to start mission.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const completeMission = async (missionId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/missions/${missionId}/complete`, {
        method: 'POST'
      });
      
      if (response.ok) {
        const result = await response.json();
        await loadMissions();
        await loadUserStats();
        
        toast({
          title: "Mission Completed!",
          description: `Earned ${result.reward.points} points and ${result.reward.coins} coins!`,
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to complete mission.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const createMission = async () => {
    if (!newMission.title || !newMission.description) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/missions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newMission,
          requirements: newMission.requirements.filter(req => req.trim() !== '')
        })
      });
      
      if (response.ok) {
        await loadMissions();
        setShowCreateMission(false);
        setNewMission({
          title: '',
          description: '',
          category: 'coding',
          difficulty: 'medium',
          timeLimit: 24,
          requirements: ['']
        });
        
        toast({
          title: "Mission Created",
          description: "New mission has been created successfully.",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create mission.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredMissions = missions.filter(mission => {
    const matchesCategory = selectedCategory === 'all' || mission.category === selectedCategory;
    const matchesSearch = mission.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         mission.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTab = activeTab === 'all' || 
                      (activeTab === 'active' && mission.status === 'active') ||
                      (activeTab === 'completed' && mission.status === 'completed') ||
                      (activeTab === 'available' && mission.status === 'pending');
    
    return matchesCategory && matchesSearch && matchesTab;
  });

  const getCategoryIcon = (category: Mission['category']) => {
    switch (category) {
      case 'coding': return <Code className="w-4 h-4" />;
      case 'learning': return <BookOpen className="w-4 h-4" />;
      case 'collaboration': return <Users className="w-4 h-4" />;
      case 'achievement': return <Trophy className="w-4 h-4" />;
      case 'daily': return <Calendar className="w-4 h-4" />;
      case 'weekly': return <Clock className="w-4 h-4" />;
      default: return <Target className="w-4 h-4" />;
    }
  };

  const getDifficultyColor = (difficulty: Mission['difficulty']) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-600';
      case 'medium': return 'bg-yellow-600';
      case 'hard': return 'bg-orange-600';
      case 'expert': return 'bg-red-600';
      default: return 'bg-gray-600';
    }
  };

  const getStatusIcon = (status: Mission['status']) => {
    switch (status) {
      case 'active': return <PlayCircle className="w-4 h-4 text-blue-400" />;
      case 'completed': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'failed': return <XCircle className="w-4 h-4 text-red-400" />;
      case 'pending': return <PauseCircle className="w-4 h-4 text-gray-400" />;
      default: return <Target className="w-4 h-4" />;
    }
  };

  const getLevelProgress = () => {
    return (userStats.experiencePoints / userStats.nextLevelExp) * 100;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[95vh] bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            <Target className="w-5 h-5" />
            Mission Control Center
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col h-full">
          {/* User Stats Header */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <User className="w-4 h-4 text-blue-400" />
                  <span className="text-sm font-medium text-white">Level {userStats.currentLevel}</span>
                </div>
                <Progress value={getLevelProgress()} className="h-2 mb-1" />
                <p className="text-xs text-slate-400">
                  {userStats.experiencePoints} / {userStats.nextLevelExp} XP
                </p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm font-medium text-white">{userStats.totalPoints}</span>
                </div>
                <p className="text-xs text-slate-400">Total Points</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Coins className="w-4 h-4 text-green-400" />
                  <span className="text-sm font-medium text-white">{userStats.totalCoins}</span>
                </div>
                <p className="text-xs text-slate-400">Coins</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-4 h-4 text-orange-400" />
                  <span className="text-sm font-medium text-white">{userStats.streak}</span>
                </div>
                <p className="text-xs text-slate-400">Day Streak</p>
              </CardContent>
            </Card>

            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Award className="w-4 h-4 text-purple-400" />
                  <span className="text-sm font-medium text-white">{userStats.rank}</span>
                </div>
                <p className="text-xs text-slate-400">Current Rank</p>
              </CardContent>
            </Card>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search missions..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64 bg-slate-800 border-slate-600 text-white"
                />
              </div>
              
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-slate-800 border-slate-600 text-white rounded px-3 py-2"
              >
                <option value="all">All Categories</option>
                <option value="coding">Coding</option>
                <option value="learning">Learning</option>
                <option value="collaboration">Collaboration</option>
                <option value="achievement">Achievement</option>
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
              </select>
            </div>

            <Button onClick={() => setShowCreateMission(true)} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Create Mission
            </Button>
          </div>

          {/* Missions Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-4 bg-slate-800">
              <TabsTrigger value="active">Active ({missions.filter(m => m.status === 'active').length})</TabsTrigger>
              <TabsTrigger value="available">Available ({missions.filter(m => m.status === 'pending').length})</TabsTrigger>
              <TabsTrigger value="completed">Completed ({missions.filter(m => m.status === 'completed').length})</TabsTrigger>
              <TabsTrigger value="all">All ({missions.length})</TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="flex-1">
              <ScrollArea className="h-full">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredMissions.map((mission) => (
                    <Card key={mission.id} className="bg-slate-800 border-slate-700 hover:border-slate-600 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            {getCategoryIcon(mission.category)}
                            <CardTitle className="text-sm text-white truncate">{mission.title}</CardTitle>
                          </div>
                          {getStatusIcon(mission.status)}
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Badge className={`text-xs ${getDifficultyColor(mission.difficulty)}`}>
                            {mission.difficulty}
                          </Badge>
                          <Badge variant="outline" className="text-xs border-slate-600">
                            {mission.category}
                          </Badge>
                          {mission.timeLimit && (
                            <Badge variant="outline" className="text-xs border-slate-600">
                              <Clock className="w-3 h-3 mr-1" />
                              {mission.timeLimit}h
                            </Badge>
                          )}
                        </div>
                      </CardHeader>

                      <CardContent className="space-y-4">
                        <CardDescription className="text-slate-400 text-sm line-clamp-2">
                          {mission.description}
                        </CardDescription>

                        {mission.status === 'active' && (
                          <div>
                            <div className="flex justify-between text-sm mb-1">
                              <span className="text-slate-400">Progress</span>
                              <span className="text-white">{mission.progress}/{mission.maxProgress}</span>
                            </div>
                            <Progress value={(mission.progress / mission.maxProgress) * 100} className="h-2" />
                          </div>
                        )}

                        <div className="space-y-2">
                          <p className="text-xs font-medium text-slate-300">Requirements:</p>
                          {mission.requirements.slice(0, 2).map((req, idx) => (
                            <div key={idx} className="flex items-center gap-2 text-xs">
                              {req.completed ? (
                                <CheckCircle className="w-3 h-3 text-green-400" />
                              ) : (
                                <XCircle className="w-3 h-3 text-slate-500" />
                              )}
                              <span className={req.completed ? 'text-green-400' : 'text-slate-400'}>
                                {req.description}
                              </span>
                            </div>
                          ))}
                          {mission.requirements.length > 2 && (
                            <p className="text-xs text-slate-500">+{mission.requirements.length - 2} more...</p>
                          )}
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4 text-xs">
                            <span className="flex items-center gap-1 text-yellow-400">
                              <Star className="w-3 h-3" />
                              {mission.reward.points}
                            </span>
                            <span className="flex items-center gap-1 text-green-400">
                              <Coins className="w-3 h-3" />
                              {mission.reward.coins}
                            </span>
                          </div>

                          <div className="flex gap-2">
                            {mission.status === 'pending' && (
                              <Button
                                size="sm"
                                onClick={() => startMission(mission.id)}
                                disabled={loading}
                                className="bg-blue-600 hover:bg-blue-700"
                              >
                                Start
                              </Button>
                            )}
                            {mission.status === 'active' && mission.progress >= mission.maxProgress && (
                              <Button
                                size="sm"
                                onClick={() => completeMission(mission.id)}
                                disabled={loading}
                                className="bg-green-600 hover:bg-green-700"
                              >
                                Complete
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </div>

        {/* Create Mission Dialog */}
        <Dialog open={showCreateMission} onOpenChange={setShowCreateMission}>
          <DialogContent className="bg-slate-900 border-slate-700">
            <DialogHeader>
              <DialogTitle className="text-white">Create New Mission</DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <Label htmlFor="mission-title" className="text-white">Title</Label>
                <Input
                  id="mission-title"
                  value={newMission.title}
                  onChange={(e) => setNewMission({...newMission, title: e.target.value})}
                  className="bg-slate-800 border-slate-600 text-white"
                  placeholder="Enter mission title"
                />
              </div>

              <div>
                <Label htmlFor="mission-description" className="text-white">Description</Label>
                <Textarea
                  id="mission-description"
                  value={newMission.description}
                  onChange={(e) => setNewMission({...newMission, description: e.target.value})}
                  className="bg-slate-800 border-slate-600 text-white"
                  placeholder="Describe the mission objectives and goals"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="mission-category" className="text-white">Category</Label>
                  <select
                    id="mission-category"
                    value={newMission.category}
                    onChange={(e) => setNewMission({...newMission, category: e.target.value as Mission['category']})}
                    className="w-full bg-slate-800 border-slate-600 text-white rounded px-3 py-2"
                  >
                    <option value="coding">Coding</option>
                    <option value="learning">Learning</option>
                    <option value="collaboration">Collaboration</option>
                    <option value="achievement">Achievement</option>
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                  </select>
                </div>

                <div>
                  <Label htmlFor="mission-difficulty" className="text-white">Difficulty</Label>
                  <select
                    id="mission-difficulty"
                    value={newMission.difficulty}
                    onChange={(e) => setNewMission({...newMission, difficulty: e.target.value as Mission['difficulty']})}
                    className="w-full bg-slate-800 border-slate-600 text-white rounded px-3 py-2"
                  >
                    <option value="easy">Easy</option>
                    <option value="medium">Medium</option>
                    <option value="hard">Hard</option>
                    <option value="expert">Expert</option>
                  </select>
                </div>
              </div>

              <div>
                <Label htmlFor="mission-time-limit" className="text-white">Time Limit (hours)</Label>
                <Input
                  id="mission-time-limit"
                  type="number"
                  value={newMission.timeLimit}
                  onChange={(e) => setNewMission({...newMission, timeLimit: Number(e.target.value)})}
                  className="bg-slate-800 border-slate-600 text-white"
                  min="1"
                  max="168"
                />
              </div>

              <div>
                <Label className="text-white">Requirements</Label>
                {newMission.requirements.map((req, idx) => (
                  <div key={idx} className="flex gap-2 mt-2">
                    <Input
                      value={req}
                      onChange={(e) => {
                        const newReqs = [...newMission.requirements];
                        newReqs[idx] = e.target.value;
                        setNewMission({...newMission, requirements: newReqs});
                      }}
                      className="bg-slate-800 border-slate-600 text-white"
                      placeholder="Enter requirement"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const newReqs = newMission.requirements.filter((_, i) => i !== idx);
                        setNewMission({...newMission, requirements: newReqs});
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setNewMission({...newMission, requirements: [...newMission.requirements, '']})}
                  className="mt-2"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Requirement
                </Button>
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowCreateMission(false)}>
                  Cancel
                </Button>
                <Button onClick={createMission} disabled={loading} className="bg-blue-600 hover:bg-blue-700">
                  Create Mission
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
}

// Sample missions data
const sampleMissions: Mission[] = [
  {
    id: 'mission-1',
    title: 'Complete First JavaScript Project',
    description: 'Build a simple calculator application using vanilla JavaScript with basic arithmetic operations.',
    category: 'coding',
    difficulty: 'easy',
    status: 'active',
    progress: 3,
    maxProgress: 5,
    reward: {
      points: 100,
      coins: 25,
      badges: ['JavaScript Beginner'],
      unlocks: ['Advanced JS Missions']
    },
    requirements: [
      { description: 'Create HTML structure', completed: true },
      { description: 'Implement basic operations', completed: true },
      { description: 'Add CSS styling', completed: true },
      { description: 'Test all functions', completed: false },
      { description: 'Deploy to GitHub Pages', completed: false }
    ],
    timeLimit: 48,
    createdAt: '2025-01-01T10:00:00Z',
    assignedBy: 'System'
  },
  {
    id: 'mission-2',
    title: 'Master Git Version Control',
    description: 'Learn essential Git commands and workflow by managing a real project with branches, commits, and merges.',
    category: 'learning',
    difficulty: 'medium',
    status: 'pending',
    progress: 0,
    maxProgress: 8,
    reward: {
      points: 200,
      coins: 50,
      badges: ['Git Master'],
      unlocks: ['Collaboration Missions']
    },
    requirements: [
      { description: 'Create repository', completed: false },
      { description: 'Make 10 commits', completed: false },
      { description: 'Create and merge branch', completed: false },
      { description: 'Resolve merge conflict', completed: false },
      { description: 'Use pull requests', completed: false },
      { description: 'Tag a release', completed: false },
      { description: 'Collaborate with team', completed: false },
      { description: 'Write good commit messages', completed: false }
    ],
    timeLimit: 72,
    createdAt: '2025-01-01T12:00:00Z',
    assignedBy: 'System'
  },
  {
    id: 'mission-3',
    title: 'Database Design Challenge',
    description: 'Design and implement a relational database schema for an e-commerce application with proper normalization.',
    category: 'coding',
    difficulty: 'hard',
    status: 'pending',
    progress: 0,
    maxProgress: 6,
    reward: {
      points: 350,
      coins: 100,
      badges: ['Database Architect'],
      unlocks: ['Advanced Database Missions']
    },
    requirements: [
      { description: 'Design ER diagram', completed: false },
      { description: 'Create normalized tables', completed: false },
      { description: 'Implement relationships', completed: false },
      { description: 'Write complex queries', completed: false },
      { description: 'Add indexes and constraints', completed: false },
      { description: 'Test data integrity', completed: false }
    ],
    timeLimit: 96,
    createdAt: '2025-01-01T14:00:00Z',
    assignedBy: 'System'
  },
  {
    id: 'mission-4',
    title: 'Daily Code Review',
    description: 'Review and provide constructive feedback on team member\'s code submissions.',
    category: 'daily',
    difficulty: 'easy',
    status: 'completed',
    progress: 1,
    maxProgress: 1,
    reward: {
      points: 50,
      coins: 10,
      badges: [],
      unlocks: []
    },
    requirements: [
      { description: 'Review 3 pull requests', completed: true }
    ],
    timeLimit: 24,
    createdAt: '2025-01-01T08:00:00Z',
    completedAt: '2025-01-01T16:30:00Z',
    assignedBy: 'System'
  },
  {
    id: 'mission-5',
    title: 'Team Collaboration Sprint',
    description: 'Successfully complete a week-long sprint with your development team, meeting all sprint goals.',
    category: 'collaboration',
    difficulty: 'medium',
    status: 'active',
    progress: 4,
    maxProgress: 7,
    reward: {
      points: 250,
      coins: 75,
      badges: ['Team Player', 'Sprint Champion'],
      unlocks: ['Leadership Missions']
    },
    requirements: [
      { description: 'Attend all daily standups', completed: true },
      { description: 'Complete assigned tasks', completed: true },
      { description: 'Help team members', completed: true },
      { description: 'Participate in retrospective', completed: true },
      { description: 'Meet sprint deadline', completed: false },
      { description: 'Zero critical bugs', completed: false },
      { description: 'Document deliverables', completed: false }
    ],
    timeLimit: 168,
    createdAt: '2024-12-30T09:00:00Z',
    assignedBy: 'Team Lead'
  }
];