interface OctopusLogoProps {
  size?: number;
  animated?: boolean;
  className?: string;
}

export default function OctopusLogo({ size = 60, animated = false, className = "" }: OctopusLogoProps) {
  return (
    <div 
      className={`octopus-logo ${animated ? 'animate-octopus' : ''} ${className}`} 
      style={{ width: size, height: size }}
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 120 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Octopus Head */}
        <circle
          cx="60"
          cy="45"
          r="25"
          fill="url(#octopusGradient)"
          stroke="url(#strokeGradient)"
          strokeWidth="2"
        />
        
        {/* Eyes */}
        <circle cx="52" cy="40" r="4" fill="var(--pearl-white)" />
        <circle cx="68" cy="40" r="4" fill="var(--pearl-white)" />
        <circle cx="52" cy="40" r="2" fill="var(--ocean-deep)" />
        <circle cx="68" cy="40" r="2" fill="var(--ocean-deep)" />
        
        {/* Eye highlights */}
        <circle cx="53" cy="39" r="1" fill="var(--bioluminescent)" opacity="0.8" />
        <circle cx="69" cy="39" r="1" fill="var(--bioluminescent)" opacity="0.8" />
        
        {/* Tentacles */}
        {/* Tentacle 1 - Top Left */}
        <path
          className="tentacle-1"
          d="M42 55 Q30 65 25 80 Q20 95 30 105"
          stroke="url(#tentacleGradient1)"
          strokeWidth="6"
          fill="none"
          strokeLinecap="round"
        />
        
        {/* Tentacle 2 - Top Right */}
        <path
          className="tentacle-2"
          d="M78 55 Q90 65 95 80 Q100 95 90 105"
          stroke="url(#tentacleGradient2)"
          strokeWidth="6"
          fill="none"
          strokeLinecap="round"
        />
        
        {/* Tentacle 3 - Middle Left */}
        <path
          className="tentacle-3"
          d="M38 60 Q20 70 15 90 Q10 105 25 110"
          stroke="url(#tentacleGradient3)"
          strokeWidth="5"
          fill="none"
          strokeLinecap="round"
        />
        
        {/* Tentacle 4 - Middle Right */}
        <path
          className="tentacle-4"
          d="M82 60 Q100 70 105 90 Q110 105 95 110"
          stroke="url(#tentacleGradient4)"
          strokeWidth="5"
          fill="none"
          strokeLinecap="round"
        />
        
        {/* Tentacle 5 - Bottom Left */}
        <path
          className="tentacle-5"
          d="M45 65 Q35 85 40 105 Q45 115 55 110"
          stroke="url(#tentacleGradient5)"
          strokeWidth="4"
          fill="none"
          strokeLinecap="round"
        />
        
        {/* Tentacle 6 - Bottom Right */}
        <path
          className="tentacle-6"
          d="M75 65 Q85 85 80 105 Q75 115 65 110"
          stroke="url(#tentacleGradient6)"
          strokeWidth="4"
          fill="none"
          strokeLinecap="round"
        />
        
        {/* Bioluminescent spots */}
        <circle cx="50" cy="50" r="2" fill="var(--bioluminescent)" opacity="0.6">
          <animate attributeName="opacity" values="0.6;1;0.6" dur="2s" repeatCount="indefinite" />
        </circle>
        <circle cx="70" cy="48" r="1.5" fill="var(--bioluminescent)" opacity="0.6">
          <animate attributeName="opacity" values="0.6;1;0.6" dur="2.5s" repeatCount="indefinite" />
        </circle>
        <circle cx="55" cy="55" r="1" fill="var(--bioluminescent)" opacity="0.6">
          <animate attributeName="opacity" values="0.6;1;0.6" dur="3s" repeatCount="indefinite" />
        </circle>
        
        {/* Gradients */}
        <defs>
          <radialGradient id="octopusGradient" cx="0.3" cy="0.3" r="0.8">
            <stop offset="0%" stopColor="var(--ocean-light)" />
            <stop offset="50%" stopColor="var(--ocean-medium)" />
            <stop offset="100%" stopColor="var(--tentacle-dark)" />
          </radialGradient>
          
          <linearGradient id="strokeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="var(--bioluminescent)" />
            <stop offset="100%" stopColor="var(--sea-foam)" />
          </linearGradient>
          
          <linearGradient id="tentacleGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="var(--tentacle-light)" />
            <stop offset="50%" stopColor="var(--tentacle-medium)" />
            <stop offset="100%" stopColor="var(--tentacle-dark)" />
          </linearGradient>
          
          <linearGradient id="tentacleGradient2" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="var(--tentacle-light)" />
            <stop offset="50%" stopColor="var(--tentacle-medium)" />
            <stop offset="100%" stopColor="var(--tentacle-dark)" />
          </linearGradient>
          
          <linearGradient id="tentacleGradient3" x1="0%" y1="30%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="var(--ocean-light)" />
            <stop offset="50%" stopColor="var(--tentacle-medium)" />
            <stop offset="100%" stopColor="var(--tentacle-dark)" />
          </linearGradient>
          
          <linearGradient id="tentacleGradient4" x1="100%" y1="30%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="var(--ocean-light)" />
            <stop offset="50%" stopColor="var(--tentacle-medium)" />
            <stop offset="100%" stopColor="var(--tentacle-dark)" />
          </linearGradient>
          
          <linearGradient id="tentacleGradient5" x1="0%" y1="50%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="var(--bioluminescent)" />
            <stop offset="50%" stopColor="var(--tentacle-medium)" />
            <stop offset="100%" stopColor="var(--ocean-deep)" />
          </linearGradient>
          
          <linearGradient id="tentacleGradient6" x1="100%" y1="50%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="var(--bioluminescent)" />
            <stop offset="50%" stopColor="var(--tentacle-medium)" />
            <stop offset="100%" stopColor="var(--ocean-deep)" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}