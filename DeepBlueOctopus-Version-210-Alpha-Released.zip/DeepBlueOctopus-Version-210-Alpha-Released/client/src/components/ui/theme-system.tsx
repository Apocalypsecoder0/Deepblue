import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Moon, Sun, Monitor, Palette, Waves, TreePine, Zap, Flame } from 'lucide-react';

export interface Theme {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    surface: string;
    text: string;
    textSecondary: string;
    border: string;
    success: string;
    warning: string;
    error: string;
  };
  cssVariables: Record<string, string>;
}

export const themes: Theme[] = [
  {
    id: 'deep-blue',
    name: 'Deep Blue Octopus',
    icon: <Waves className="w-4 h-4" />,
    description: 'Ocean-inspired theme with deep blues and bioluminescent accents',
    colors: {
      primary: 'hsl(210, 85%, 45%)',
      secondary: 'hsl(195, 75%, 35%)',
      accent: 'hsl(180, 90%, 55%)',
      background: 'hsl(220, 25%, 8%)',
      surface: 'hsl(215, 20%, 12%)',
      text: 'hsl(210, 20%, 85%)',
      textSecondary: 'hsl(210, 15%, 65%)',
      border: 'hsl(215, 15%, 20%)',
      success: 'hsl(142, 76%, 36%)',
      warning: 'hsl(38, 92%, 50%)',
      error: 'hsl(0, 84%, 60%)',
    },
    cssVariables: {
      '--background': 'hsl(220, 25%, 8%)',
      '--foreground': 'hsl(210, 20%, 85%)',
      '--card': 'hsl(215, 20%, 12%)',
      '--card-foreground': 'hsl(210, 20%, 85%)',
      '--popover': 'hsl(215, 20%, 12%)',
      '--popover-foreground': 'hsl(210, 20%, 85%)',
      '--primary': 'hsl(210, 85%, 45%)',
      '--primary-foreground': 'hsl(210, 20%, 98%)',
      '--secondary': 'hsl(215, 20%, 15%)',
      '--secondary-foreground': 'hsl(210, 20%, 85%)',
      '--muted': 'hsl(215, 20%, 15%)',
      '--muted-foreground': 'hsl(210, 15%, 65%)',
      '--accent': 'hsl(180, 90%, 55%)',
      '--accent-foreground': 'hsl(220, 25%, 8%)',
      '--destructive': 'hsl(0, 84%, 60%)',
      '--destructive-foreground': 'hsl(210, 20%, 98%)',
      '--border': 'hsl(215, 15%, 20%)',
      '--input': 'hsl(215, 15%, 20%)',
      '--ring': 'hsl(210, 85%, 45%)',
      '--radius': '0.5rem',
    }
  },
  {
    id: 'dark',
    name: 'Dark Professional',
    icon: <Moon className="w-4 h-4" />,
    description: 'Classic dark theme for focused development',
    colors: {
      primary: 'hsl(210, 40%, 50%)',
      secondary: 'hsl(210, 30%, 40%)',
      accent: 'hsl(210, 40%, 60%)',
      background: 'hsl(0, 0%, 8%)',
      surface: 'hsl(0, 0%, 12%)',
      text: 'hsl(210, 40%, 98%)',
      textSecondary: 'hsl(215, 20%, 65%)',
      border: 'hsl(217, 33%, 17%)',
      success: 'hsl(142, 76%, 36%)',
      warning: 'hsl(38, 92%, 50%)',
      error: 'hsl(0, 84%, 60%)',
    },
    cssVariables: {
      '--background': 'hsl(0, 0%, 8%)',
      '--foreground': 'hsl(210, 40%, 98%)',
      '--card': 'hsl(0, 0%, 12%)',
      '--card-foreground': 'hsl(210, 40%, 98%)',
      '--popover': 'hsl(0, 0%, 12%)',
      '--popover-foreground': 'hsl(210, 40%, 98%)',
      '--primary': 'hsl(210, 40%, 50%)',
      '--primary-foreground': 'hsl(210, 40%, 98%)',
      '--secondary': 'hsl(217, 33%, 17%)',
      '--secondary-foreground': 'hsl(210, 40%, 98%)',
      '--muted': 'hsl(217, 33%, 17%)',
      '--muted-foreground': 'hsl(215, 20%, 65%)',
      '--accent': 'hsl(210, 40%, 60%)',
      '--accent-foreground': 'hsl(210, 40%, 98%)',
      '--destructive': 'hsl(0, 84%, 60%)',
      '--destructive-foreground': 'hsl(210, 40%, 98%)',
      '--border': 'hsl(217, 33%, 17%)',
      '--input': 'hsl(217, 33%, 17%)',
      '--ring': 'hsl(210, 40%, 50%)',
      '--radius': '0.5rem',
    }
  },
  {
    id: 'light',
    name: 'Light Professional',
    icon: <Sun className="w-4 h-4" />,
    description: 'Clean light theme for bright environments',
    colors: {
      primary: 'hsl(210, 70%, 45%)',
      secondary: 'hsl(210, 50%, 35%)',
      accent: 'hsl(210, 60%, 55%)',
      background: 'hsl(0, 0%, 100%)',
      surface: 'hsl(210, 40%, 98%)',
      text: 'hsl(222, 84%, 5%)',
      textSecondary: 'hsl(215, 25%, 27%)',
      border: 'hsl(214, 32%, 91%)',
      success: 'hsl(142, 76%, 36%)',
      warning: 'hsl(38, 92%, 50%)',
      error: 'hsl(0, 84%, 60%)',
    },
    cssVariables: {
      '--background': 'hsl(0, 0%, 100%)',
      '--foreground': 'hsl(222, 84%, 5%)',
      '--card': 'hsl(210, 40%, 98%)',
      '--card-foreground': 'hsl(222, 84%, 5%)',
      '--popover': 'hsl(210, 40%, 98%)',
      '--popover-foreground': 'hsl(222, 84%, 5%)',
      '--primary': 'hsl(210, 70%, 45%)',
      '--primary-foreground': 'hsl(210, 40%, 98%)',
      '--secondary': 'hsl(210, 40%, 96%)',
      '--secondary-foreground': 'hsl(222, 84%, 5%)',
      '--muted': 'hsl(210, 40%, 96%)',
      '--muted-foreground': 'hsl(215, 25%, 27%)',
      '--accent': 'hsl(210, 60%, 55%)',
      '--accent-foreground': 'hsl(210, 40%, 98%)',
      '--destructive': 'hsl(0, 84%, 60%)',
      '--destructive-foreground': 'hsl(210, 40%, 98%)',
      '--border': 'hsl(214, 32%, 91%)',
      '--input': 'hsl(214, 32%, 91%)',
      '--ring': 'hsl(210, 70%, 45%)',
      '--radius': '0.5rem',
    }
  },
  {
    id: 'forest',
    name: 'Forest Grove',
    icon: <TreePine className="w-4 h-4" />,
    description: 'Nature-inspired green theme for calm coding',
    colors: {
      primary: 'hsl(120, 60%, 40%)',
      secondary: 'hsl(140, 50%, 30%)',
      accent: 'hsl(100, 70%, 50%)',
      background: 'hsl(140, 30%, 8%)',
      surface: 'hsl(135, 25%, 12%)',
      text: 'hsl(120, 20%, 85%)',
      textSecondary: 'hsl(120, 15%, 65%)',
      border: 'hsl(135, 20%, 20%)',
      success: 'hsl(142, 76%, 36%)',
      warning: 'hsl(38, 92%, 50%)',
      error: 'hsl(0, 84%, 60%)',
    },
    cssVariables: {
      '--background': 'hsl(140, 30%, 8%)',
      '--foreground': 'hsl(120, 20%, 85%)',
      '--card': 'hsl(135, 25%, 12%)',
      '--card-foreground': 'hsl(120, 20%, 85%)',
      '--popover': 'hsl(135, 25%, 12%)',
      '--popover-foreground': 'hsl(120, 20%, 85%)',
      '--primary': 'hsl(120, 60%, 40%)',
      '--primary-foreground': 'hsl(120, 20%, 98%)',
      '--secondary': 'hsl(135, 20%, 15%)',
      '--secondary-foreground': 'hsl(120, 20%, 85%)',
      '--muted': 'hsl(135, 20%, 15%)',
      '--muted-foreground': 'hsl(120, 15%, 65%)',
      '--accent': 'hsl(100, 70%, 50%)',
      '--accent-foreground': 'hsl(140, 30%, 8%)',
      '--destructive': 'hsl(0, 84%, 60%)',
      '--destructive-foreground': 'hsl(120, 20%, 98%)',
      '--border': 'hsl(135, 20%, 20%)',
      '--input': 'hsl(135, 20%, 20%)',
      '--ring': 'hsl(120, 60%, 40%)',
      '--radius': '0.5rem',
    }
  },
  {
    id: 'neon',
    name: 'Neon Cyber',
    icon: <Zap className="w-4 h-4" />,
    description: 'Futuristic neon theme with electric accents',
    colors: {
      primary: 'hsl(300, 80%, 60%)',
      secondary: 'hsl(280, 70%, 50%)',
      accent: 'hsl(180, 100%, 50%)',
      background: 'hsl(260, 50%, 5%)',
      surface: 'hsl(260, 40%, 10%)',
      text: 'hsl(300, 50%, 90%)',
      textSecondary: 'hsl(300, 30%, 70%)',
      border: 'hsl(260, 30%, 20%)',
      success: 'hsl(142, 76%, 36%)',
      warning: 'hsl(38, 92%, 50%)',
      error: 'hsl(0, 84%, 60%)',
    },
    cssVariables: {
      '--background': 'hsl(260, 50%, 5%)',
      '--foreground': 'hsl(300, 50%, 90%)',
      '--card': 'hsl(260, 40%, 10%)',
      '--card-foreground': 'hsl(300, 50%, 90%)',
      '--popover': 'hsl(260, 40%, 10%)',
      '--popover-foreground': 'hsl(300, 50%, 90%)',
      '--primary': 'hsl(300, 80%, 60%)',
      '--primary-foreground': 'hsl(300, 50%, 5%)',
      '--secondary': 'hsl(260, 30%, 15%)',
      '--secondary-foreground': 'hsl(300, 50%, 90%)',
      '--muted': 'hsl(260, 30%, 15%)',
      '--muted-foreground': 'hsl(300, 30%, 70%)',
      '--accent': 'hsl(180, 100%, 50%)',
      '--accent-foreground': 'hsl(260, 50%, 5%)',
      '--destructive': 'hsl(0, 84%, 60%)',
      '--destructive-foreground': 'hsl(300, 50%, 90%)',
      '--border': 'hsl(260, 30%, 20%)',
      '--input': 'hsl(260, 30%, 20%)',
      '--ring': 'hsl(300, 80%, 60%)',
      '--radius': '0.5rem',
    }
  },
  {
    id: 'fire',
    name: 'Fire Dragon',
    icon: <Flame className="w-4 h-4" />,
    description: 'Warm fire theme with orange and red highlights',
    colors: {
      primary: 'hsl(15, 80%, 50%)',
      secondary: 'hsl(25, 70%, 40%)',
      accent: 'hsl(40, 90%, 60%)',
      background: 'hsl(15, 30%, 8%)',
      surface: 'hsl(20, 25%, 12%)',
      text: 'hsl(40, 30%, 85%)',
      textSecondary: 'hsl(40, 20%, 65%)',
      border: 'hsl(20, 20%, 20%)',
      success: 'hsl(142, 76%, 36%)',
      warning: 'hsl(38, 92%, 50%)',
      error: 'hsl(0, 84%, 60%)',
    },
    cssVariables: {
      '--background': 'hsl(15, 30%, 8%)',
      '--foreground': 'hsl(40, 30%, 85%)',
      '--card': 'hsl(20, 25%, 12%)',
      '--card-foreground': 'hsl(40, 30%, 85%)',
      '--popover': 'hsl(20, 25%, 12%)',
      '--popover-foreground': 'hsl(40, 30%, 85%)',
      '--primary': 'hsl(15, 80%, 50%)',
      '--primary-foreground': 'hsl(40, 30%, 98%)',
      '--secondary': 'hsl(20, 20%, 15%)',
      '--secondary-foreground': 'hsl(40, 30%, 85%)',
      '--muted': 'hsl(20, 20%, 15%)',
      '--muted-foreground': 'hsl(40, 20%, 65%)',
      '--accent': 'hsl(40, 90%, 60%)',
      '--accent-foreground': 'hsl(15, 30%, 8%)',
      '--destructive': 'hsl(0, 84%, 60%)',
      '--destructive-foreground': 'hsl(40, 30%, 98%)',
      '--border': 'hsl(20, 20%, 20%)',
      '--input': 'hsl(20, 20%, 20%)',
      '--ring': 'hsl(15, 80%, 50%)',
      '--radius': '0.5rem',
    }
  }
];

interface ThemeContextType {
  currentTheme: Theme;
  setTheme: (themeId: string) => void;
  availableThemes: Theme[];
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}

interface ThemeProviderProps {
  children: ReactNode;
}

export function ThemeProvider({ children }: ThemeProviderProps) {
  const [currentTheme, setCurrentTheme] = useState<Theme>(() => {
    const savedTheme = localStorage.getItem('ide-theme');
    return themes.find(theme => theme.id === savedTheme) || themes[0];
  });

  const setTheme = (themeId: string) => {
    const theme = themes.find(t => t.id === themeId);
    if (theme) {
      setCurrentTheme(theme);
      localStorage.setItem('ide-theme', themeId);
    }
  };

  useEffect(() => {
    // Apply theme CSS variables to document root
    const root = document.documentElement;
    Object.entries(currentTheme.cssVariables).forEach(([property, value]) => {
      root.style.setProperty(property, value);
    });

    // Add theme class to document for additional styling
    document.body.className = `theme-${currentTheme.id}`;
  }, [currentTheme]);

  return (
    <ThemeContext.Provider value={{ currentTheme, setTheme, availableThemes: themes }}>
      {children}
    </ThemeContext.Provider>
  );
}

// Theme selector component
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

interface ThemeSelectorProps {
  onClose?: () => void;
}

export function ThemeSelector({ onClose }: ThemeSelectorProps) {
  const { currentTheme, setTheme, availableThemes } = useTheme();

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Palette className="w-5 h-5" />
          Theme Selection
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {availableThemes.map((theme) => (
            <div
              key={theme.id}
              className={`relative p-4 rounded-lg border-2 cursor-pointer transition-all hover:border-primary ${
                currentTheme.id === theme.id ? 'border-primary bg-primary/10' : 'border-border'
              }`}
              onClick={() => setTheme(theme.id)}
            >
              {currentTheme.id === theme.id && (
                <Check className="absolute top-2 right-2 w-4 h-4 text-primary" />
              )}
              
              <div className="flex items-center gap-3 mb-2">
                {theme.icon}
                <h3 className="font-medium">{theme.name}</h3>
              </div>
              
              <p className="text-sm text-muted-foreground mb-3">
                {theme.description}
              </p>
              
              <div className="flex gap-1">
                <div 
                  className="w-4 h-4 rounded-full border"
                  style={{ backgroundColor: theme.colors.primary }}
                />
                <div 
                  className="w-4 h-4 rounded-full border"
                  style={{ backgroundColor: theme.colors.secondary }}
                />
                <div 
                  className="w-4 h-4 rounded-full border"
                  style={{ backgroundColor: theme.colors.accent }}
                />
              </div>
            </div>
          ))}
        </div>
        
        {onClose && (
          <div className="flex justify-end mt-6">
            <Button onClick={onClose}>
              Close
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}