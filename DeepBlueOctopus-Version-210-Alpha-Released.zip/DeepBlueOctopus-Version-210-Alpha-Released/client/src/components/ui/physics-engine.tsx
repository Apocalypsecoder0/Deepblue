// Physics Engine for DeepBlue Game Engine
export interface Vector2 {
  x: number;
  y: number;
}

export interface Transform {
  position: Vector2;
  rotation: number;
  scale: Vector2;
}

export interface RigidBody {
  id: string;
  transform: Transform;
  velocity: Vector2;
  acceleration: Vector2;
  mass: number;
  drag: number;
  angularVelocity: number;
  angularDrag: number;
  isStatic: boolean;
  material: PhysicsMaterial;
  collider: Collider;
}

export interface PhysicsMaterial {
  friction: number;
  restitution: number; // Bounciness
  density: number;
}

export interface Collider {
  type: 'box' | 'circle' | 'polygon';
  size: Vector2; // For box: width/height, for circle: radius stored in x
  vertices?: Vector2[]; // For polygon
  isTrigger: boolean;
}

export interface CollisionInfo {
  bodyA: RigidBody;
  bodyB: RigidBody;
  contactPoint: Vector2;
  normal: Vector2;
  penetrationDepth: number;
  impulse: number;
}

export class PhysicsWorld {
  private bodies: Map<string, RigidBody> = new Map();
  private gravity: Vector2 = { x: 0, y: 981 }; // 9.81 m/s^2 * 100 (pixels)
  private timeStep: number = 1/60; // 60 FPS
  private iterations: number = 10; // Position correction iterations
  
  // World bounds
  private bounds: { min: Vector2; max: Vector2 } = {
    min: { x: -10000, y: -10000 },
    max: { x: 10000, y: 10000 }
  };

  constructor(gravity: Vector2 = { x: 0, y: 981 }) {
    this.gravity = gravity;
  }

  addBody(body: RigidBody): void {
    this.bodies.set(body.id, body);
  }

  removeBody(id: string): void {
    this.bodies.delete(id);
  }

  getBody(id: string): RigidBody | undefined {
    return this.bodies.get(id);
  }

  getAllBodies(): RigidBody[] {
    return Array.from(this.bodies.values());
  }

  setGravity(gravity: Vector2): void {
    this.gravity = gravity;
  }

  setBounds(min: Vector2, max: Vector2): void {
    this.bounds = { min, max };
  }

  step(deltaTime: number = this.timeStep): void {
    // Apply forces
    this.applyForces(deltaTime);
    
    // Update velocities and positions
    this.integrateVelocities(deltaTime);
    
    // Detect and resolve collisions
    const collisions = this.detectCollisions();
    this.resolveCollisions(collisions);
    
    // Apply constraints (bounds checking)
    this.applyConstraints();
  }

  private applyForces(deltaTime: number): void {
    for (const body of this.bodies.values()) {
      if (body.isStatic) continue;

      // Apply gravity
      body.acceleration.x += this.gravity.x;
      body.acceleration.y += this.gravity.y;

      // Apply drag
      body.velocity.x *= (1 - body.drag * deltaTime);
      body.velocity.y *= (1 - body.drag * deltaTime);
      body.angularVelocity *= (1 - body.angularDrag * deltaTime);
    }
  }

  private integrateVelocities(deltaTime: number): void {
    for (const body of this.bodies.values()) {
      if (body.isStatic) continue;

      // Update velocity
      body.velocity.x += body.acceleration.x * deltaTime;
      body.velocity.y += body.acceleration.y * deltaTime;

      // Update position
      body.transform.position.x += body.velocity.x * deltaTime;
      body.transform.position.y += body.velocity.y * deltaTime;

      // Update rotation
      body.transform.rotation += body.angularVelocity * deltaTime;

      // Reset acceleration
      body.acceleration.x = 0;
      body.acceleration.y = 0;
    }
  }

  private detectCollisions(): CollisionInfo[] {
    const collisions: CollisionInfo[] = [];
    const bodies = Array.from(this.bodies.values());

    for (let i = 0; i < bodies.length; i++) {
      for (let j = i + 1; j < bodies.length; j++) {
        const bodyA = bodies[i];
        const bodyB = bodies[j];

        // Skip if both are static
        if (bodyA.isStatic && bodyB.isStatic) continue;

        const collision = this.checkCollision(bodyA, bodyB);
        if (collision) {
          collisions.push(collision);
        }
      }
    }

    return collisions;
  }

  private checkCollision(bodyA: RigidBody, bodyB: RigidBody): CollisionInfo | null {
    const colliderA = bodyA.collider;
    const colliderB = bodyB.collider;

    // Circle vs Circle
    if (colliderA.type === 'circle' && colliderB.type === 'circle') {
      return this.checkCircleCircleCollision(bodyA, bodyB);
    }

    // Box vs Box
    if (colliderA.type === 'box' && colliderB.type === 'box') {
      return this.checkBoxBoxCollision(bodyA, bodyB);
    }

    // Circle vs Box
    if (colliderA.type === 'circle' && colliderB.type === 'box') {
      return this.checkCircleBoxCollision(bodyA, bodyB);
    }

    if (colliderA.type === 'box' && colliderB.type === 'circle') {
      const collision = this.checkCircleBoxCollision(bodyB, bodyA);
      if (collision) {
        // Swap bodies and invert normal
        return {
          bodyA: bodyA,
          bodyB: bodyB,
          contactPoint: collision.contactPoint,
          normal: { x: -collision.normal.x, y: -collision.normal.y },
          penetrationDepth: collision.penetrationDepth,
          impulse: collision.impulse
        };
      }
    }

    return null;
  }

  private checkCircleCircleCollision(bodyA: RigidBody, bodyB: RigidBody): CollisionInfo | null {
    const posA = bodyA.transform.position;
    const posB = bodyB.transform.position;
    const radiusA = bodyA.collider.size.x;
    const radiusB = bodyB.collider.size.x;

    const dx = posB.x - posA.x;
    const dy = posB.y - posA.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const minDistance = radiusA + radiusB;

    if (distance < minDistance && distance > 0) {
      const normal = { x: dx / distance, y: dy / distance };
      const contactPoint = {
        x: posA.x + normal.x * radiusA,
        y: posA.y + normal.y * radiusA
      };

      return {
        bodyA,
        bodyB,
        contactPoint,
        normal,
        penetrationDepth: minDistance - distance,
        impulse: 0
      };
    }

    return null;
  }

  private checkBoxBoxCollision(bodyA: RigidBody, bodyB: RigidBody): CollisionInfo | null {
    const posA = bodyA.transform.position;
    const posB = bodyB.transform.position;
    const sizeA = bodyA.collider.size;
    const sizeB = bodyB.collider.size;

    const halfWidthA = sizeA.x / 2;
    const halfHeightA = sizeA.y / 2;
    const halfWidthB = sizeB.x / 2;
    const halfHeightB = sizeB.y / 2;

    const dx = posB.x - posA.x;
    const dy = posB.y - posA.y;

    const overlapX = halfWidthA + halfWidthB - Math.abs(dx);
    const overlapY = halfHeightA + halfHeightB - Math.abs(dy);

    if (overlapX > 0 && overlapY > 0) {
      let normal: Vector2;
      let penetrationDepth: number;

      if (overlapX < overlapY) {
        normal = { x: dx > 0 ? 1 : -1, y: 0 };
        penetrationDepth = overlapX;
      } else {
        normal = { x: 0, y: dy > 0 ? 1 : -1 };
        penetrationDepth = overlapY;
      }

      const contactPoint = {
        x: posA.x + dx / 2,
        y: posA.y + dy / 2
      };

      return {
        bodyA,
        bodyB,
        contactPoint,
        normal,
        penetrationDepth,
        impulse: 0
      };
    }

    return null;
  }

  private checkCircleBoxCollision(circle: RigidBody, box: RigidBody): CollisionInfo | null {
    const circlePos = circle.transform.position;
    const boxPos = box.transform.position;
    const radius = circle.collider.size.x;
    const boxSize = box.collider.size;

    const halfWidth = boxSize.x / 2;
    const halfHeight = boxSize.y / 2;

    // Find closest point on box to circle center
    const closestX = Math.max(boxPos.x - halfWidth, Math.min(circlePos.x, boxPos.x + halfWidth));
    const closestY = Math.max(boxPos.y - halfHeight, Math.min(circlePos.y, boxPos.y + halfHeight));

    const dx = circlePos.x - closestX;
    const dy = circlePos.y - closestY;
    const distance = Math.sqrt(dx * dx + dy * dy);

    if (distance < radius) {
      const normal = distance > 0 ? 
        { x: dx / distance, y: dy / distance } : 
        { x: 1, y: 0 }; // Default normal if distance is 0

      const contactPoint = { x: closestX, y: closestY };

      return {
        bodyA: circle,
        bodyB: box,
        contactPoint,
        normal,
        penetrationDepth: radius - distance,
        impulse: 0
      };
    }

    return null;
  }

  private resolveCollisions(collisions: CollisionInfo[]): void {
    for (const collision of collisions) {
      this.resolveCollision(collision);
    }
  }

  private resolveCollision(collision: CollisionInfo): void {
    const { bodyA, bodyB, normal, penetrationDepth } = collision;

    if (bodyA.collider.isTrigger || bodyB.collider.isTrigger) {
      // Trigger collision - no physical response
      this.onTriggerCollision?.(collision);
      return;
    }

    // Position correction
    this.correctPositions(bodyA, bodyB, normal, penetrationDepth);

    // Impulse resolution
    this.resolveImpulse(bodyA, bodyB, normal);
  }

  private correctPositions(bodyA: RigidBody, bodyB: RigidBody, normal: Vector2, penetrationDepth: number): void {
    const totalMass = bodyA.isStatic ? bodyB.mass : (bodyB.isStatic ? bodyA.mass : bodyA.mass + bodyB.mass);
    const percent = 0.8; // Position correction percentage
    const slop = 0.01; // Penetration allowance

    const correction = Math.max(penetrationDepth - slop, 0) / totalMass * percent;

    if (!bodyA.isStatic) {
      const correctionA = bodyA.mass * correction;
      bodyA.transform.position.x -= normal.x * correctionA;
      bodyA.transform.position.y -= normal.y * correctionA;
    }

    if (!bodyB.isStatic) {
      const correctionB = bodyB.mass * correction;
      bodyB.transform.position.x += normal.x * correctionB;
      bodyB.transform.position.y += normal.y * correctionB;
    }
  }

  private resolveImpulse(bodyA: RigidBody, bodyB: RigidBody, normal: Vector2): void {
    // Relative velocity
    const relativeVelocity = {
      x: bodyB.velocity.x - bodyA.velocity.x,
      y: bodyB.velocity.y - bodyA.velocity.y
    };

    // Relative velocity along normal
    const velAlongNormal = relativeVelocity.x * normal.x + relativeVelocity.y * normal.y;

    // Don't resolve if velocities are separating
    if (velAlongNormal > 0) return;

    // Calculate restitution
    const restitution = Math.min(bodyA.material.restitution, bodyB.material.restitution);

    // Calculate impulse scalar
    let j = -(1 + restitution) * velAlongNormal;
    
    if (!bodyA.isStatic && !bodyB.isStatic) {
      j /= (1 / bodyA.mass) + (1 / bodyB.mass);
    } else if (!bodyA.isStatic) {
      j /= (1 / bodyA.mass);
    } else if (!bodyB.isStatic) {
      j /= (1 / bodyB.mass);
    }

    // Apply impulse
    const impulse = { x: j * normal.x, y: j * normal.y };

    if (!bodyA.isStatic) {
      bodyA.velocity.x -= impulse.x / bodyA.mass;
      bodyA.velocity.y -= impulse.y / bodyA.mass;
    }

    if (!bodyB.isStatic) {
      bodyB.velocity.x += impulse.x / bodyB.mass;
      bodyB.velocity.y += impulse.y / bodyB.mass;
    }

    // Friction
    this.applyFriction(bodyA, bodyB, normal, j);
  }

  private applyFriction(bodyA: RigidBody, bodyB: RigidBody, normal: Vector2, impulseNormal: number): void {
    // Relative velocity
    const relativeVelocity = {
      x: bodyB.velocity.x - bodyA.velocity.x,
      y: bodyB.velocity.y - bodyA.velocity.y
    };

    // Tangent vector
    const tangent = {
      x: relativeVelocity.x - (relativeVelocity.x * normal.x + relativeVelocity.y * normal.y) * normal.x,
      y: relativeVelocity.y - (relativeVelocity.x * normal.x + relativeVelocity.y * normal.y) * normal.y
    };

    const tangentLength = Math.sqrt(tangent.x * tangent.x + tangent.y * tangent.y);
    if (tangentLength < 0.001) return;

    tangent.x /= tangentLength;
    tangent.y /= tangentLength;

    // Friction magnitude
    let jt = -(relativeVelocity.x * tangent.x + relativeVelocity.y * tangent.y);
    
    if (!bodyA.isStatic && !bodyB.isStatic) {
      jt /= (1 / bodyA.mass) + (1 / bodyB.mass);
    } else if (!bodyA.isStatic) {
      jt /= (1 / bodyA.mass);
    } else if (!bodyB.isStatic) {
      jt /= (1 / bodyB.mass);
    }

    // Friction coefficient
    const mu = Math.sqrt(bodyA.material.friction * bodyA.material.friction + 
                        bodyB.material.friction * bodyB.material.friction);

    // Clamp friction
    let frictionImpulse: Vector2;
    if (Math.abs(jt) < impulseNormal * mu) {
      frictionImpulse = { x: jt * tangent.x, y: jt * tangent.y };
    } else {
      frictionImpulse = { 
        x: -impulseNormal * tangent.x * mu, 
        y: -impulseNormal * tangent.y * mu 
      };
    }

    // Apply friction impulse
    if (!bodyA.isStatic) {
      bodyA.velocity.x -= frictionImpulse.x / bodyA.mass;
      bodyA.velocity.y -= frictionImpulse.y / bodyA.mass;
    }

    if (!bodyB.isStatic) {
      bodyB.velocity.x += frictionImpulse.x / bodyB.mass;
      bodyB.velocity.y += frictionImpulse.y / bodyB.mass;
    }
  }

  private applyConstraints(): void {
    for (const body of this.bodies.values()) {
      if (body.isStatic) continue;

      // Bounds checking
      const pos = body.transform.position;
      const size = body.collider.size;

      // Left bound
      if (pos.x - size.x/2 < this.bounds.min.x) {
        pos.x = this.bounds.min.x + size.x/2;
        body.velocity.x *= -body.material.restitution;
      }

      // Right bound
      if (pos.x + size.x/2 > this.bounds.max.x) {
        pos.x = this.bounds.max.x - size.x/2;
        body.velocity.x *= -body.material.restitution;
      }

      // Top bound
      if (pos.y - size.y/2 < this.bounds.min.y) {
        pos.y = this.bounds.min.y + size.y/2;
        body.velocity.y *= -body.material.restitution;
      }

      // Bottom bound
      if (pos.y + size.y/2 > this.bounds.max.y) {
        pos.y = this.bounds.max.y - size.y/2;
        body.velocity.y *= -body.material.restitution;
      }
    }
  }

  // Event callback for trigger collisions
  onTriggerCollision?: (collision: CollisionInfo) => void;

  // Utility methods
  addForce(bodyId: string, force: Vector2): void {
    const body = this.bodies.get(bodyId);
    if (body && !body.isStatic) {
      body.acceleration.x += force.x / body.mass;
      body.acceleration.y += force.y / body.mass;
    }
  }

  addImpulse(bodyId: string, impulse: Vector2): void {
    const body = this.bodies.get(bodyId);
    if (body && !body.isStatic) {
      body.velocity.x += impulse.x / body.mass;
      body.velocity.y += impulse.y / body.mass;
    }
  }

  setVelocity(bodyId: string, velocity: Vector2): void {
    const body = this.bodies.get(bodyId);
    if (body && !body.isStatic) {
      body.velocity = { ...velocity };
    }
  }

  getVelocity(bodyId: string): Vector2 | null {
    const body = this.bodies.get(bodyId);
    return body ? { ...body.velocity } : null;
  }

  setPosition(bodyId: string, position: Vector2): void {
    const body = this.bodies.get(bodyId);
    if (body) {
      body.transform.position = { ...position };
    }
  }

  getPosition(bodyId: string): Vector2 | null {
    const body = this.bodies.get(bodyId);
    return body ? { ...body.transform.position } : null;
  }
}

// Helper functions
export function createRigidBody(
  id: string,
  position: Vector2,
  collider: Collider,
  mass: number = 1,
  isStatic: boolean = false
): RigidBody {
  return {
    id,
    transform: {
      position: { ...position },
      rotation: 0,
      scale: { x: 1, y: 1 }
    },
    velocity: { x: 0, y: 0 },
    acceleration: { x: 0, y: 0 },
    mass: isStatic ? Infinity : mass,
    drag: 0.1,
    angularVelocity: 0,
    angularDrag: 0.1,
    isStatic,
    material: {
      friction: 0.5,
      restitution: 0.5,
      density: 1.0
    },
    collider
  };
}

export function createBoxCollider(width: number, height: number, isTrigger: boolean = false): Collider {
  return {
    type: 'box',
    size: { x: width, y: height },
    isTrigger
  };
}

export function createCircleCollider(radius: number, isTrigger: boolean = false): Collider {
  return {
    type: 'circle',
    size: { x: radius, y: radius },
    isTrigger
  };
}

export function createPolygonCollider(vertices: Vector2[], isTrigger: boolean = false): Collider {
  // Calculate bounding box for size
  const minX = Math.min(...vertices.map(v => v.x));
  const maxX = Math.max(...vertices.map(v => v.x));
  const minY = Math.min(...vertices.map(v => v.y));
  const maxY = Math.max(...vertices.map(v => v.y));

  return {
    type: 'polygon',
    size: { x: maxX - minX, y: maxY - minY },
    vertices: vertices.map(v => ({ ...v })),
    isTrigger
  };
}