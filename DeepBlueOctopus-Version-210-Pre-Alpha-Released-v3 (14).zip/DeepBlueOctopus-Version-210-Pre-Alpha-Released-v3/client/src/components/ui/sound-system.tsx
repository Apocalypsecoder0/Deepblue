import React, { createContext, useContext, useRef, useEffect } from 'react';

interface SoundContextType {
  playSound: (soundType: 'click' | 'hover' | 'success' | 'error' | 'loading' | 'notification') => void;
  setVolume: (volume: number) => void;
  mute: () => void;
  unmute: () => void;
}

const SoundContext = createContext<SoundContextType | null>(null);

export const useSoundSystem = () => {
  const context = useContext(SoundContext);
  if (!context) {
    throw new Error('useSoundSystem must be used within SoundProvider');
  }
  return context;
};

interface SoundProviderProps {
  children: React.ReactNode;
}

export const SoundProvider: React.FC<SoundProviderProps> = ({ children }) => {
  const audioRefs = useRef<{ [key: string]: HTMLAudioElement }>({});
  const volumeRef = useRef(0.3);
  const mutedRef = useRef(false);

  useEffect(() => {
    // Create audio elements for different sound types
    const sounds = {
      click: createToneSequence([800, 600], [0.1, 0.1]),
      hover: createToneSequence([400], [0.05]),
      success: createToneSequence([523, 659, 784], [0.15, 0.15, 0.2]),
      error: createToneSequence([200, 150], [0.2, 0.3]),
      loading: createToneSequence([400, 500, 600], [0.3, 0.3, 0.3]),
      notification: createToneSequence([659, 523], [0.1, 0.2])
    };

    Object.entries(sounds).forEach(([key, audioElement]) => {
      audioRefs.current[key] = audioElement;
    });

    return () => {
      Object.values(audioRefs.current).forEach(audio => {
        audio.pause();
        audio.currentTime = 0;
      });
    };
  }, []);

  const createToneSequence = (frequencies: number[], durations: number[]): HTMLAudioElement => {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const totalDuration = durations.reduce((sum, duration) => sum + duration, 0);
    
    const buffer = audioContext.createBuffer(1, audioContext.sampleRate * totalDuration, audioContext.sampleRate);
    const data = buffer.getChannelData(0);
    
    let currentTime = 0;
    frequencies.forEach((frequency, index) => {
      const duration = durations[index];
      const startSample = Math.floor(currentTime * audioContext.sampleRate);
      const endSample = Math.floor((currentTime + duration) * audioContext.sampleRate);
      
      for (let i = startSample; i < endSample; i++) {
        const t = (i - startSample) / audioContext.sampleRate;
        const envelope = Math.sin(Math.PI * t / duration); // Simple envelope
        data[i] = envelope * Math.sin(2 * Math.PI * frequency * t) * 0.1;
      }
      currentTime += duration;
    });

    // Convert buffer to audio element
    const audio = new Audio();
    const blob = bufferToWave(buffer, audioContext.sampleRate);
    audio.src = URL.createObjectURL(blob);
    
    return audio;
  };

  const bufferToWave = (buffer: AudioBuffer, sampleRate: number): Blob => {
    const length = buffer.length;
    const arrayBuffer = new ArrayBuffer(44 + length * 2);
    const view = new DataView(arrayBuffer);
    const data = buffer.getChannelData(0);

    // WAV header
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    writeString(0, 'RIFF');
    view.setUint32(4, 36 + length * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, length * 2, true);

    // Convert float32 to int16
    let offset = 44;
    for (let i = 0; i < length; i++) {
      const sample = Math.max(-1, Math.min(1, data[i] || 0));
      view.setInt16(offset, Math.floor(sample * 0x7FFF), true);
      offset += 2;
    }

    return new Blob([arrayBuffer], { type: 'audio/wav' });
  };

  const playSound = (soundType: 'click' | 'hover' | 'success' | 'error' | 'loading' | 'notification') => {
    if (mutedRef.current) return;
    
    try {
      const audio = audioRefs.current[soundType];
      if (audio && audio.readyState >= 2) { // Ensure audio is loaded
        audio.volume = volumeRef.current;
        audio.currentTime = 0;
        audio.play().catch(() => {
          // Silently handle audio play failures
        });
      }
    } catch (error) {
      // Prevent infinite loops from sound system errors
    }
  };

  const setVolume = (volume: number) => {
    volumeRef.current = Math.max(0, Math.min(1, volume));
  };

  const mute = () => {
    mutedRef.current = true;
  };

  const unmute = () => {
    mutedRef.current = false;
  };

  return (
    <SoundContext.Provider value={{ playSound, setVolume, mute, unmute }}>
      {children}
    </SoundContext.Provider>
  );
};

// Sound Control Components
export const SoundControl: React.FC = () => {
  const { playSound, mute, unmute } = useSoundSystem();
  const [isMuted, setIsMuted] = React.useState(false);

  const toggleMute = () => {
    if (isMuted) {
      unmute();
      setIsMuted(false);
    } else {
      mute();
      setIsMuted(true);
    }
  };

  return (
    <button 
      onClick={toggleMute}
      className="p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-800"
    >
      {isMuted ? '🔇' : '🔊'}
    </button>
  );
};

export const SoundSettings: React.FC = () => {
  const { setVolume } = useSoundSystem();
  const [volume, setVolumeState] = React.useState(30);

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0];
    setVolumeState(newVolume);
    setVolume(newVolume / 100);
  };

  return (
    <div className="flex items-center space-x-2 p-2">
      <span className="text-sm">Volume:</span>
      <input
        type="range"
        min="0"
        max="100"
        value={volume}
        onChange={(e) => handleVolumeChange([parseInt(e.target.value)])}
        className="w-20"
      />
      <span className="text-sm">{volume}%</span>
    </div>
  );
};

export const SoundButton: React.FC<{ 
  children: React.ReactNode; 
  onClick?: () => void; 
  className?: string;
  soundType?: 'click' | 'hover' | 'success' | 'error' | 'loading' | 'notification';
  disabled?: boolean;
}> = ({ children, onClick, className = "", soundType = 'click', disabled = false }) => {
  const { playSound } = useSoundSystem();

  const handleClick = () => {
    if (!disabled) {
      playSound(soundType);
      onClick?.();
    }
  };

  const handleHover = () => {
    if (!disabled) {
      playSound('hover');
    }
  };

  return (
    <button 
      onClick={handleClick}
      onMouseEnter={handleHover}
      className={className}
      disabled={disabled}
    >
      {children}
    </button>
  );
};