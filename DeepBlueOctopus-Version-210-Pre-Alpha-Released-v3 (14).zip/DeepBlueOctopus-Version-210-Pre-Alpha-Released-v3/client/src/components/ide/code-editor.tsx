import { useEffect, useRef, useState } from "react";
import { useIDEState } from "@/hooks/use-ide-state";
import type { File } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import { Search, Replace, Map, Code, Braces, Settings, ChevronDown, ChevronRight } from "lucide-react";

export default function CodeEditor() {
  const editorRef = useRef<HTMLDivElement>(null);
  const { activeTab, updateFileContent } = useIDEState();
  const editorInstanceRef = useRef<any>(null);
  const [showMinimap, setShowMinimap] = useState(true);
  const [showLineNumbers, setShowLineNumbers] = useState(true);
  const [wordWrap, setWordWrap] = useState(true);
  const [foldingStrategy, setFoldingStrategy] = useState("indentation");
  const [showFind, setShowFind] = useState(false);
  const [editorConfig, setEditorConfig] = useState({
    fontSize: 14,
    fontFamily: "'JetBrains Mono', 'Courier New', monospace",
    tabSize: 2,
    insertSpaces: true,
    bracketMatching: true,
    autoClosingBrackets: true,
    autoIndent: "full",
    formatOnPaste: true,
    formatOnType: true,
    quickSuggestions: true,
    parameterHints: true,
    codeLens: true,
    foldingHighlight: true,
    showFoldingControls: "mouseover",
  });

  useEffect(() => {
    // Initialize Monaco Editor with enhanced features
    if (typeof window !== "undefined" && editorRef.current && !editorInstanceRef.current) {
      import("monaco-editor").then((monaco) => {
        // Configure live syntax error highlighting
        monaco.languages.typescript.javascriptDefaults.setDiagnosticsOptions({
          noSemanticValidation: false,
          noSyntaxValidation: false,
          noSuggestionDiagnostics: false
        });

        monaco.languages.typescript.typescriptDefaults.setDiagnosticsOptions({
          noSemanticValidation: false,
          noSyntaxValidation: false,
          noSuggestionDiagnostics: false
        });

        // Configure enhanced Monaco theme
        monaco.editor.defineTheme("deepblue-dark", {
          base: "vs-dark",
          inherit: true,
          rules: [
            { token: "keyword", foreground: "569CD6", fontStyle: "bold" },
            { token: "string", foreground: "D7BA7D" },
            { token: "variable", foreground: "9CDCFE" },
            { token: "comment", foreground: "6A9955", fontStyle: "italic" },
            { token: "function", foreground: "DCDCAA", fontStyle: "bold" },
            { token: "number", foreground: "B5CEA8" },
            { token: "operator", foreground: "D4D4D4" },
            { token: "type", foreground: "4EC9B0" },
            { token: "class", foreground: "4EC9B0", fontStyle: "bold" },
            { token: "interface", foreground: "B8D7A3" },
            { token: "enum", foreground: "DCDCAA" },
            { token: "namespace", foreground: "4FC1FF" },
          ],
          colors: {
            "editor.background": "#1E1E1E",
            "editor.foreground": "#CCCCCC",
            "editor.lineHighlightBackground": "#2A2D2E",
            "editorLineNumber.foreground": "#858585",
            "editorLineNumber.activeForeground": "#C6C6C6",
            "editor.selectionBackground": "#264F78",
            "editor.inactiveSelectionBackground": "#3A3D41",
            "editor.findMatchBackground": "#515C6A",
            "editor.findMatchHighlightBackground": "#EA5C0055",
            "editor.findRangeHighlightBackground": "#3A3D4166",
            "editorBracketMatch.background": "#0064001A",
            "editorBracketMatch.border": "#888888",
            "editorCodeLens.foreground": "#999999",
            "editorError.foreground": "#F44747",
            "editorWarning.foreground": "#FF8C00",
            "editorInfo.foreground": "#75BEFF",
            "editorHint.foreground": "#EEEEEE",
          },
        });

        // Configure enhanced TypeScript and JavaScript language features
        monaco.languages.typescript.javascriptDefaults.setEagerModelSync(true);
        monaco.languages.typescript.typescriptDefaults.setEagerModelSync(true);
        
        // Enable advanced IntelliSense options
        monaco.languages.typescript.javascriptDefaults.setCompilerOptions({
          target: monaco.languages.typescript.ScriptTarget.ES2020,
          allowNonTsExtensions: true,
          moduleResolution: monaco.languages.typescript.ModuleResolutionKind.NodeJs,
          module: monaco.languages.typescript.ModuleKind.CommonJS,
          noEmit: true,
          esModuleInterop: true,
          allowJs: true,
          typeRoots: ["node_modules/@types"],
        });

        // Add extra libraries for enhanced IntelliSense
        monaco.languages.typescript.javascriptDefaults.addExtraLib(`
          declare var console: {
            log(...args: any[]): void;
            error(...args: any[]): void;
            warn(...args: any[]): void;
            info(...args: any[]): void;
          };
          declare var document: any;
          declare var window: any;
          declare var process: any;
        `, 'ts:globals.d.ts');

        editorInstanceRef.current = monaco.editor.create(editorRef.current!, {
          value: activeTab?.content || "",
          language: getMonacoLanguage(activeTab?.language || "javascript"),
          theme: "deepblue-dark",
          automaticLayout: true,
          
          // Enhanced editor options
          minimap: { 
            enabled: showMinimap,
            showSlider: "mouseover",
            renderCharacters: false,
            maxColumn: 120,
            scale: 1
          },
          
          // Font and display
          fontSize: editorConfig.fontSize,
          fontFamily: editorConfig.fontFamily,
          fontLigatures: true,
          lineHeight: 1.5,
          letterSpacing: 0.5,
          
          // Line numbers and folding
          lineNumbers: showLineNumbers ? "on" : "off",
          lineNumbersMinChars: 3,
          folding: true,
          foldingStrategy: foldingStrategy as any,
          foldingHighlight: editorConfig.foldingHighlight,
          showFoldingControls: editorConfig.showFoldingControls as any,
          foldingImportsByDefault: true,
          
          // Indentation and formatting
          tabSize: editorConfig.tabSize,
          insertSpaces: editorConfig.insertSpaces,
          detectIndentation: true,
          trimAutoWhitespace: true,
          formatOnPaste: editorConfig.formatOnPaste,
          formatOnType: editorConfig.formatOnType,
          
          // Word wrapping and scrolling
          wordWrap: wordWrap ? "on" : "off",
          wordWrapColumn: 120,
          wrappingIndent: "indent",
          renderWhitespace: "selection",
          scrollBeyondLastLine: false,
          smoothScrolling: true,
          
          // Bracket matching and auto-closing
          matchBrackets: "always",
          autoClosingBrackets: editorConfig.autoClosingBrackets ? "always" : "never",
          autoClosingQuotes: "always",
          autoSurround: "languageDefined",
          bracketPairColorization: { enabled: true },
          
          // IntelliSense and suggestions
          quickSuggestions: {
            other: editorConfig.quickSuggestions,
            comments: false,
            strings: false
          },
          quickSuggestionsDelay: 100,
          suggestOnTriggerCharacters: true,
          acceptSuggestionOnCommitCharacter: true,
          acceptSuggestionOnEnter: "on",
          tabCompletion: "on",
          wordBasedSuggestions: true,
          parameterHints: { enabled: editorConfig.parameterHints },
          
          // Code lens and hover
          codeLens: editorConfig.codeLens,
          hover: { enabled: true, delay: 300 },
          lightbulb: { enabled: true },
          
          // Selection and find
          find: {
            seedSearchStringFromSelection: "selection",
            autoFindInSelection: "never",
            globalFindClipboard: false,
            addExtraSpaceOnTop: true
          },
          selectionHighlight: true,
          occurrencesHighlight: true,
          
          // Cursor and selection
          cursorBlinking: "blink",
          cursorSmoothCaretAnimation: true,
          cursorStyle: "line",
          cursorWidth: 2,
          multiCursorModifier: "alt",
          multiCurselectionKeyboard: true,
          
          // Performance and rendering
          renderControlCharacters: false,
          renderLineHighlight: "line",
          renderLineHighlightOnlyWhenFocus: false,
          hideCursorInOverviewRuler: false,
          scrollbar: {
            useShadows: false,
            verticalHasArrows: false,
            horizontalHasArrows: false,
            vertical: "visible",
            horizontal: "visible",
            verticalScrollbarSize: 14,
            horizontalScrollbarSize: 12
          },
          
          // Accessibility
          accessibilitySupport: "auto",
          ariaLabel: "Code Editor",
          
          // Drag and drop
          dragAndDrop: true,
          dropIntoEditor: { enabled: true },
          
          // Other features
          links: true,
          colorDecorators: true,
          contextmenu: true,
          mouseWheelZoom: true,
          fastScrollSensitivity: 5,
          scrollPredominantAxis: true,
          columnSelection: false,
          disableLayerHinting: false,
          disableMonospaceOptimizations: false,
          
          // Advanced editing
          autoIndent: editorConfig.autoIndent as any,
          smartSelect: { selectLeadingAndTrailingWhitespace: true },
          copyWithSyntaxHighlighting: true,
          emptySelectionClipboard: true,
          useTabStops: true,
        });

        // Enhanced event listeners
        editorInstanceRef.current.onDidChangeModelContent(() => {
          if (activeTab) {
            const newContent = editorInstanceRef.current.getValue();
            updateFileContent(activeTab.id, newContent);
          }
        });

        // Add keyboard shortcuts for advanced features
        editorInstanceRef.current.addAction({
          id: 'toggle-minimap',
          label: 'Toggle Minimap',
          keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyM],
          contextMenuGroupId: 'view',
          run: () => {
            setShowMinimap(!showMinimap);
            editorInstanceRef.current.updateOptions({ 
              minimap: { enabled: !showMinimap } 
            });
          }
        });

        editorInstanceRef.current.addAction({
          id: 'toggle-word-wrap',
          label: 'Toggle Word Wrap',
          keybindings: [monaco.KeyMod.Alt | monaco.KeyCode.KeyZ],
          contextMenuGroupId: 'view',
          run: () => {
            const newWrap = !wordWrap;
            setWordWrap(newWrap);
            editorInstanceRef.current.updateOptions({ 
              wordWrap: newWrap ? "on" : "off" 
            });
          }
        });

        editorInstanceRef.current.addAction({
          id: 'toggle-line-numbers',
          label: 'Toggle Line Numbers',
          keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.KeyL],
          contextMenuGroupId: 'view',
          run: () => {
            const newLineNumbers = !showLineNumbers;
            setShowLineNumbers(newLineNumbers);
            editorInstanceRef.current.updateOptions({ 
              lineNumbers: newLineNumbers ? "on" : "off" 
            });
          }
        });

        editorInstanceRef.current.addAction({
          id: 'format-document',
          label: 'Format Document',
          keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.KeyF],
          contextMenuGroupId: 'format',
          run: () => {
            editorInstanceRef.current.getAction('editor.action.formatDocument').run();
          }
        });

        editorInstanceRef.current.addAction({
          id: 'go-to-definition',
          label: 'Go to Definition',
          keybindings: [monaco.KeyCode.F12],
          contextMenuGroupId: 'navigation',
          run: () => {
            editorInstanceRef.current.getAction('editor.action.revealDefinition').run();
          }
        });

        editorInstanceRef.current.addAction({
          id: 'show-hover',
          label: 'Show Hover',
          keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyK, monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyI],
          contextMenuGroupId: 'help',
          run: () => {
            editorInstanceRef.current.getAction('editor.action.showHover').run();
          }
        });

        // Add multi-cursor support
        editorInstanceRef.current.addAction({
          id: 'add-cursor-above',
          label: 'Add Cursor Above',
          keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyMod.Alt | monaco.KeyCode.UpArrow],
          run: () => {
            editorInstanceRef.current.getAction('editor.action.insertCursorAbove').run();
          }
        });

        editorInstanceRef.current.addAction({
          id: 'add-cursor-below',
          label: 'Add Cursor Below',
          keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyMod.Alt | monaco.KeyCode.DownArrow],
          run: () => {
            editorInstanceRef.current.getAction('editor.action.insertCursorBelow').run();
          }
        });

        // Enhanced find functionality
        editorInstanceRef.current.addAction({
          id: 'advanced-find',
          label: 'Advanced Find & Replace',
          keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.KeyH],
          run: () => {
            setShowFind(true);
            editorInstanceRef.current.getAction('editor.action.startFindReplaceAction').run();
          }
        });
      });
    }

    return () => {
      if (editorInstanceRef.current) {
        editorInstanceRef.current.dispose();
        editorInstanceRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    // Update editor content when active tab changes
    if (editorInstanceRef.current && activeTab) {
      const currentValue = editorInstanceRef.current.getValue();
      if (currentValue !== activeTab.content) {
        editorInstanceRef.current.setValue(activeTab.content || "");
      }
      
      // Update language
      const model = editorInstanceRef.current.getModel();
      if (model) {
        import("monaco-editor").then((monaco) => {
          monaco.editor.setModelLanguage(model, getMonacoLanguage(activeTab.language));
        });
      }
    }
  }, [activeTab]);

  const getMonacoLanguage = (language: string): string => {
    const languageMap: { [key: string]: string } = {
      javascript: "javascript",
      typescript: "typescript",
      python: "python",
      html: "html",
      css: "css",
      json: "json",
      markdown: "markdown",
      xml: "xml",
      yaml: "yaml",
      sql: "sql",
    };
    return languageMap[language] || "plaintext";
  };

  if (!activeTab) {
    return (
      <div className="flex-1 flex items-center justify-center text-[var(--ide-text-secondary)]">
        <div className="text-center">
          <h3 className="text-lg font-medium mb-2">No file open</h3>
          <p>Select a file from the explorer to start editing</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 relative overflow-hidden">
      <div ref={editorRef} className="h-full w-full" />
      
      {/* Enhanced Editor Controls */}
      <div className="absolute top-2 right-2 flex items-center gap-1 bg-[var(--ide-surface)]/90 backdrop-blur-sm rounded-lg p-1 border border-[var(--ide-border)]">
        <TooltipWrapper
          title="Toggle Minimap"
          content="Show/hide code minimap on the right side of the editor"
          type="feature"
        >
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setShowMinimap(!showMinimap);
              if (editorInstanceRef.current) {
                editorInstanceRef.current.updateOptions({ 
                  minimap: { enabled: !showMinimap } 
                });
              }
            }}
            className={`h-7 w-7 p-0 ${showMinimap ? 'bg-[var(--ide-accent)]/20' : ''}`}
          >
            <Map className="h-3 w-3" />
          </Button>
        </TooltipWrapper>

        <TooltipWrapper
          title="Toggle Line Numbers"
          content="Show/hide line numbers in the editor"
          type="feature"
        >
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setShowLineNumbers(!showLineNumbers);
              if (editorInstanceRef.current) {
                editorInstanceRef.current.updateOptions({ 
                  lineNumbers: !showLineNumbers ? "on" : "off" 
                });
              }
            }}
            className={`h-7 w-7 p-0 ${showLineNumbers ? 'bg-[var(--ide-accent)]/20' : ''}`}
          >
            <Code className="h-3 w-3" />
          </Button>
        </TooltipWrapper>

        <TooltipWrapper
          title="Toggle Word Wrap"
          content="Enable/disable word wrapping for long lines"
          type="feature"
        >
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setWordWrap(!wordWrap);
              if (editorInstanceRef.current) {
                editorInstanceRef.current.updateOptions({ 
                  wordWrap: !wordWrap ? "on" : "off" 
                });
              }
            }}
            className={`h-7 w-7 p-0 ${wordWrap ? 'bg-[var(--ide-accent)]/20' : ''}`}
          >
            <ChevronRight className="h-3 w-3" />
          </Button>
        </TooltipWrapper>

        <TooltipWrapper
          title="Advanced Find"
          content="Open advanced find and replace panel (Ctrl+Shift+H)"
          type="shortcut"
        >
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              if (editorInstanceRef.current) {
                editorInstanceRef.current.getAction('editor.action.startFindReplaceAction').run();
              }
            }}
            className="h-7 w-7 p-0"
          >
            <Search className="h-3 w-3" />
          </Button>
        </TooltipWrapper>

        <TooltipWrapper
          title="Editor Settings"
          content="Configure editor preferences and display options"
          type="feature"
        >
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              // Toggle editor settings panel
              console.log("Editor settings");
            }}
            className="h-7 w-7 p-0"
          >
            <Settings className="h-3 w-3" />
          </Button>
        </TooltipWrapper>
      </div>
      
      {/* Editor info display */}
      <div className="absolute bottom-2 right-2 flex items-center gap-2 bg-[var(--ide-surface)]/90 backdrop-blur-sm rounded-lg px-3 py-1 border border-[var(--ide-border)]">
        <div className="text-xs text-[var(--ide-text-secondary)]">
          {activeTab.language.charAt(0).toUpperCase() + activeTab.language.slice(1)}
        </div>
        <div className="w-px h-3 bg-[var(--ide-border)]" />
        <div className="text-xs text-[var(--ide-text-secondary)]">
          UTF-8
        </div>
        <div className="w-px h-3 bg-[var(--ide-border)]" />
        <div className="text-xs text-[var(--ide-text-secondary)]">
          Tab: {editorConfig.tabSize}
        </div>
      </div>

      {/* Enhanced keyboard shortcuts info */}
      <div className="absolute bottom-2 left-2 text-xs text-[var(--ide-text-secondary)]/60">
        <div>Ctrl+M: Minimap • Alt+Z: Word Wrap • F12: Go to Definition</div>
        <div>Ctrl+Shift+F: Format • Ctrl+Shift+H: Find & Replace</div>
      </div>
    </div>
  );
}
