import React, { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { 
  Folder, File, FolderOpen, Upload, Download, Copy, 
  Move, Trash2, Star, Clock, Search, Filter,
  Grid, List, MoreHorizontal, Eye, Lock, Unlock,
  Archive, Share, Link, Settings,
  HardDrive, Wifi, Cloud, Server, Database,
  Image, Video, Music, FileText, Code, Package
} from "lucide-react";

interface AdvancedFileSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FileSystemItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  path: string;
  size: number;
  lastModified: Date;
  created: Date;
  permissions: {
    read: boolean;
    write: boolean;
    execute: boolean;
  };
  isHidden: boolean;
  isStarred: boolean;
  tags: string[];
  description: string;
  mimeType: string;
  extension: string;
  parentId: string | null;
  children?: FileSystemItem[];
}

interface FileSystemLocation {
  id: string;
  name: string;
  type: 'local' | 'cloud' | 'network' | 'database';
  path: string;
  connected: boolean;
  capacity: {
    used: number;
    total: number;
  };
  icon: string;
}

interface FileOperation {
  id: string;
  type: 'copy' | 'move' | 'delete' | 'upload' | 'download' | 'compress' | 'extract';
  items: string[];
  progress: number;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  source: string;
  destination?: string;
  timestamp: Date;
  estimatedTime?: number;
  speed?: number;
}

export default function AdvancedFileSystem({ isOpen, onClose }: AdvancedFileSystemProps) {
  const [activeTab, setActiveTab] = useState("explorer");
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list');
  const [currentLocation, setCurrentLocation] = useState('local');
  const [currentPath, setCurrentPath] = useState('/');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [showHidden, setShowHidden] = useState(false);
  const [sortBy, setSortBy] = useState<'name' | 'size' | 'modified' | 'type'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  const [locations, setLocations] = useState<FileSystemLocation[]>([
    {
      id: 'local',
      name: 'Local Files',
      type: 'local',
      path: '/',
      connected: true,
      capacity: { used: 125.6, total: 512 },
      icon: '💻'
    },
    {
      id: 'cloud',
      name: 'Cloud Storage',
      type: 'cloud',
      path: '/cloud',
      connected: true,
      capacity: { used: 45.2, total: 100 },
      icon: '☁️'
    },
    {
      id: 'network',
      name: 'Network Drive',
      type: 'network',
      path: '/network',
      connected: false,
      capacity: { used: 0, total: 1024 },
      icon: '🌐'
    },
    {
      id: 'database',
      name: 'Database Files',
      type: 'database',
      path: '/db',
      connected: true,
      capacity: { used: 2.8, total: 50 },
      icon: '🗄️'
    }
  ]);

  const [fileItems, setFileItems] = useState<FileSystemItem[]>([
    {
      id: '1',
      name: 'Documents',
      type: 'folder',
      path: '/Documents',
      size: 0,
      lastModified: new Date(Date.now() - 86400000),
      created: new Date(Date.now() - 604800000),
      permissions: { read: true, write: true, execute: true },
      isHidden: false,
      isStarred: true,
      tags: ['important'],
      description: 'Personal documents folder',
      mimeType: 'inode/directory',
      extension: '',
      parentId: null
    },
    {
      id: '2',
      name: 'project.md',
      type: 'file',
      path: '/Documents/project.md',
      size: 15420,
      lastModified: new Date(Date.now() - 3600000),
      created: new Date(Date.now() - 172800000),
      permissions: { read: true, write: true, execute: false },
      isHidden: false,
      isStarred: false,
      tags: ['work', 'markdown'],
      description: 'Project documentation file',
      mimeType: 'text/markdown',
      extension: 'md',
      parentId: '1'
    },
    {
      id: '3',
      name: 'Images',
      type: 'folder',
      path: '/Images',
      size: 0,
      lastModified: new Date(Date.now() - 172800000),
      created: new Date(Date.now() - 1209600000),
      permissions: { read: true, write: true, execute: true },
      isHidden: false,
      isStarred: true,
      tags: ['media'],
      description: 'Image collection',
      mimeType: 'inode/directory',
      extension: '',
      parentId: null
    },
    {
      id: '4',
      name: 'photo.jpg',
      type: 'file',
      path: '/Images/photo.jpg',
      size: 2048576,
      lastModified: new Date(Date.now() - 259200000),
      created: new Date(Date.now() - 259200000),
      permissions: { read: true, write: true, execute: false },
      isHidden: false,
      isStarred: false,
      tags: ['photo'],
      description: 'Sample photo file',
      mimeType: 'image/jpeg',
      extension: 'jpg',
      parentId: '3'
    },
    {
      id: '5',
      name: '.env',
      type: 'file',
      path: '/.env',
      size: 256,
      lastModified: new Date(Date.now() - 86400000),
      created: new Date(Date.now() - 604800000),
      permissions: { read: true, write: true, execute: false },
      isHidden: true,
      isStarred: false,
      tags: ['config', 'secret'],
      description: 'Environment variables',
      mimeType: 'text/plain',
      extension: 'env',
      parentId: null
    }
  ]);

  const [operations, setOperations] = useState<FileOperation[]>([
    {
      id: 'op1',
      type: 'upload',
      items: ['backup.zip', 'photos.tar.gz'],
      progress: 75,
      status: 'running',
      source: 'local',
      destination: '/uploads',
      timestamp: new Date(),
      estimatedTime: 120,
      speed: 2.5
    },
    {
      id: 'op2',
      type: 'copy',
      items: ['/Documents/project.md'],
      progress: 100,
      status: 'completed',
      source: '/Documents',
      destination: '/Backup',
      timestamp: new Date(Date.now() - 300000),
      speed: 15.2
    }
  ]);

  const [recentFiles, setRecentFiles] = useState([
    { name: 'project.md', path: '/Documents/project.md', lastAccessed: new Date() },
    { name: 'config.json', path: '/config.json', lastAccessed: new Date(Date.now() - 1800000) },
    { name: 'photo.jpg', path: '/Images/photo.jpg', lastAccessed: new Date(Date.now() - 3600000) }
  ]);

  const [starredItems, setStarredItems] = useState([
    { name: 'Documents', path: '/Documents', type: 'folder' },
    { name: 'Images', path: '/Images', type: 'folder' }
  ]);

  const getFileIcon = (item: FileSystemItem) => {
    if (item.type === 'folder') {
      return <Folder className="h-4 w-4 text-blue-500" />;
    }
    
    switch (item.extension) {
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
        return <Image className="h-4 w-4 text-green-500" />;
      case 'mp4':
      case 'avi':
      case 'mov':
        return <Video className="h-4 w-4 text-purple-500" />;
      case 'mp3':
      case 'wav':
      case 'flac':
        return <Music className="h-4 w-4 text-orange-500" />;
      case 'md':
      case 'txt':
      case 'doc':
        return <FileText className="h-4 w-4 text-blue-600" />;
      case 'js':
      case 'ts':
      case 'py':
      case 'cpp':
        return <Code className="h-4 w-4 text-indigo-500" />;
      case 'zip':
      case 'tar':
      case 'gz':
        return <Archive className="h-4 w-4 text-yellow-500" />;
      default:
        return <File className="h-4 w-4 text-gray-500" />;
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const filteredItems = fileItems
    .filter(item => showHidden || !item.isHidden)
    .filter(item => item.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      let comparison = 0;
      switch (sortBy) {
        case 'name':
          comparison = a.name.localeCompare(b.name);
          break;
        case 'size':
          comparison = a.size - b.size;
          break;
        case 'modified':
          comparison = a.lastModified.getTime() - b.lastModified.getTime();
          break;
        case 'type':
          comparison = a.type.localeCompare(b.type);
          break;
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });

  const handleItemSelect = (itemId: string) => {
    setSelectedItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const handleBulkOperation = (operation: string) => {
    if (selectedItems.length === 0) return;
    
    const newOperation: FileOperation = {
      id: `op${Date.now()}`,
      type: operation as any,
      items: selectedItems.map(id => fileItems.find(item => item.id === id)?.name || ''),
      progress: 0,
      status: 'pending',
      source: currentPath,
      timestamp: new Date()
    };

    setOperations(prev => [newOperation, ...prev]);
    
    // Simulate operation progress
    setTimeout(() => {
      setOperations(prev => prev.map(op => 
        op.id === newOperation.id ? { ...op, status: 'running' as const } : op
      ));
      
      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 20;
        if (progress >= 100) {
          progress = 100;
          clearInterval(interval);
          setOperations(prev => prev.map(op => 
            op.id === newOperation.id 
              ? { ...op, status: 'completed' as const, progress: 100 }
              : op
          ));
        } else {
          setOperations(prev => prev.map(op => 
            op.id === newOperation.id ? { ...op, progress: Math.floor(progress) } : op
          ));
        }
      }, 500);
    }, 1000);
    
    setSelectedItems([]);
  };

  const toggleStar = (itemId: string) => {
    setFileItems(prev => prev.map(item => 
      item.id === itemId ? { ...item, isStarred: !item.isStarred } : item
    ));
  };

  const createNewFolder = () => {
    const newFolder: FileSystemItem = {
      id: `folder_${Date.now()}`,
      name: 'New Folder',
      type: 'folder',
      path: `${currentPath}/New Folder`,
      size: 0,
      lastModified: new Date(),
      created: new Date(),
      permissions: { read: true, write: true, execute: true },
      isHidden: false,
      isStarred: false,
      tags: [],
      description: '',
      mimeType: 'inode/directory',
      extension: '',
      parentId: null
    };
    
    setFileItems(prev => [...prev, newFolder]);
  };

  const currentLocationData = locations.find(loc => loc.id === currentLocation);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <HardDrive className="h-5 w-5 text-blue-500" />
            Advanced File System Manager
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-5 gap-4">
          {/* Sidebar */}
          <Card className="lg:col-span-1 flex flex-col">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Locations</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 overflow-hidden">
              <div className="space-y-2">
                {locations.map((location) => (
                  <div
                    key={location.id}
                    className={`p-3 rounded border cursor-pointer transition-colors ${
                      currentLocation === location.id ? 'bg-accent border-primary' : 'hover:bg-accent/50'
                    }`}
                    onClick={() => setCurrentLocation(location.id)}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-lg">{location.icon}</span>
                      <span className="font-medium text-sm">{location.name}</span>
                      {location.connected ? (
                        <div className="w-2 h-2 bg-green-500 rounded-full" />
                      ) : (
                        <div className="w-2 h-2 bg-red-500 rounded-full" />
                      )}
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{formatFileSize(location.capacity.used * 1024 * 1024 * 1024)}</span>
                        <span>{formatFileSize(location.capacity.total * 1024 * 1024 * 1024)}</span>
                      </div>
                      <Progress 
                        value={(location.capacity.used / location.capacity.total) * 100} 
                        className="h-1"
                      />
                    </div>
                  </div>
                ))}
              </div>

              <Separator className="my-4" />

              <div className="space-y-2">
                <h4 className="font-medium text-sm">Quick Access</h4>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 p-2 rounded hover:bg-accent/50 cursor-pointer text-sm">
                    <Star className="h-4 w-4 text-yellow-500" />
                    <span>Starred</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 rounded hover:bg-accent/50 cursor-pointer text-sm">
                    <Clock className="h-4 w-4 text-blue-500" />
                    <span>Recent</span>
                  </div>
                  <div className="flex items-center gap-2 p-2 rounded hover:bg-accent/50 cursor-pointer text-sm">
                    <Trash2 className="h-4 w-4 text-red-500" />
                    <span>Trash</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Main Content */}
          <div className="lg:col-span-4 flex flex-col">
            {/* Toolbar */}
            <Card className="mb-4">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Button size="sm" onClick={createNewFolder}>
                        <Folder className="h-4 w-4 mr-2" />
                        New Folder
                      </Button>
                      <Button size="sm" variant="outline">
                        <Upload className="h-4 w-4 mr-2" />
                        Upload
                      </Button>
                    </div>

                    <Separator orientation="vertical" className="h-6" />

                    <div className="flex items-center gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        disabled={selectedItems.length === 0}
                        onClick={() => handleBulkOperation('copy')}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        disabled={selectedItems.length === 0}
                        onClick={() => handleBulkOperation('move')}
                      >
                        <Move className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="destructive"
                        disabled={selectedItems.length === 0}
                        onClick={() => handleBulkOperation('delete')}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Search files..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-9 w-64"
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <Button 
                        size="sm" 
                        variant={viewMode === 'list' ? 'default' : 'outline'}
                        onClick={() => setViewMode('list')}
                      >
                        <List className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant={viewMode === 'grid' ? 'default' : 'outline'}
                        onClick={() => setViewMode('grid')}
                      >
                        <Grid className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-4">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Label className="text-sm">Sort by:</Label>
                      <Select value={sortBy} onValueChange={(value) => setSortBy(value as any)}>
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="name">Name</SelectItem>
                          <SelectItem value="size">Size</SelectItem>
                          <SelectItem value="modified">Modified</SelectItem>
                          <SelectItem value="type">Type</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
                      >
                        {sortOrder === 'asc' ? '↑' : '↓'}
                      </Button>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch 
                        checked={showHidden}
                        onCheckedChange={setShowHidden}
                      />
                      <Label className="text-sm">Show hidden files</Label>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">
                      {selectedItems.length} selected
                    </Badge>
                    <Badge variant="outline">
                      {filteredItems.length} items
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* File Browser */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
              <TabsList className="grid w-full grid-cols-4 mb-4">
                <TabsTrigger value="explorer">Explorer</TabsTrigger>
                <TabsTrigger value="operations">Operations</TabsTrigger>
                <TabsTrigger value="recent">Recent</TabsTrigger>
                <TabsTrigger value="starred">Starred</TabsTrigger>
              </TabsList>

              <TabsContent value="explorer" className="flex-1 overflow-hidden">
                <Card className="h-full flex flex-col">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base flex items-center gap-2">
                        {currentLocationData?.icon} {currentLocationData?.name}
                      </CardTitle>
                      <div className="text-sm text-muted-foreground">
                        {currentPath}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1 overflow-hidden">
                    <ScrollArea className="h-full">
                      {viewMode === 'list' ? (
                        <div className="space-y-1">
                          {filteredItems.map((item) => (
                            <div
                              key={item.id}
                              className={`flex items-center gap-3 p-3 rounded border cursor-pointer transition-colors ${
                                selectedItems.includes(item.id) 
                                  ? 'bg-accent border-primary' 
                                  : 'hover:bg-accent/50'
                              }`}
                              onClick={() => handleItemSelect(item.id)}
                            >
                              <div className="flex items-center gap-2 flex-1 min-w-0">
                                {getFileIcon(item)}
                                <span className="font-medium truncate">{item.name}</span>
                                {item.isStarred && <Star className="h-3 w-3 text-yellow-500 fill-current" />}
                                {item.isHidden && <Eye className="h-3 w-3 text-gray-400" />}
                              </div>
                              
                              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                                <span className="w-20 text-right">
                                  {item.type === 'file' ? formatFileSize(item.size) : '—'}
                                </span>
                                <span className="w-32">
                                  {item.lastModified.toLocaleDateString()}
                                </span>
                                <div className="flex gap-1">
                                  {item.tags.map(tag => (
                                    <Badge key={tag} variant="outline" className="text-xs">
                                      {tag}
                                    </Badge>
                                  ))}
                                </div>
                                <Button 
                                  size="sm" 
                                  variant="ghost"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    toggleStar(item.id);
                                  }}
                                >
                                  <Star className={`h-4 w-4 ${item.isStarred ? 'text-yellow-500 fill-current' : 'text-gray-400'}`} />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                          {filteredItems.map((item) => (
                            <div
                              key={item.id}
                              className={`p-4 border rounded cursor-pointer transition-colors ${
                                selectedItems.includes(item.id) 
                                  ? 'bg-accent border-primary' 
                                  : 'hover:bg-accent/50'
                              }`}
                              onClick={() => handleItemSelect(item.id)}
                            >
                              <div className="flex flex-col items-center text-center">
                                <div className="mb-2">
                                  {getFileIcon(item)}
                                </div>
                                <span className="text-sm font-medium truncate w-full">
                                  {item.name}
                                </span>
                                {item.type === 'file' && (
                                  <span className="text-xs text-muted-foreground mt-1">
                                    {formatFileSize(item.size)}
                                  </span>
                                )}
                                {item.isStarred && (
                                  <Star className="h-3 w-3 text-yellow-500 fill-current mt-1" />
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="operations" className="flex-1 overflow-hidden">
                <Card className="h-full flex flex-col">
                  <CardHeader>
                    <CardTitle className="text-base">File Operations</CardTitle>
                    <CardDescription>Monitor ongoing file operations</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 overflow-hidden">
                    <ScrollArea className="h-full">
                      <div className="space-y-3">
                        {operations.map((operation) => (
                          <div key={operation.id} className="p-4 border rounded">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <span className="font-medium capitalize">{operation.type}</span>
                                <Badge variant={
                                  operation.status === 'completed' ? 'default' :
                                  operation.status === 'running' ? 'secondary' :
                                  operation.status === 'failed' ? 'destructive' : 'outline'
                                }>
                                  {operation.status}
                                </Badge>
                              </div>
                              <span className="text-sm text-muted-foreground">
                                {operation.timestamp.toLocaleTimeString()}
                              </span>
                            </div>
                            
                            <div className="text-sm text-muted-foreground mb-2">
                              {operation.items.slice(0, 2).join(', ')}
                              {operation.items.length > 2 && ` +${operation.items.length - 2} more`}
                            </div>
                            
                            {operation.status === 'running' && (
                              <div className="space-y-2">
                                <Progress value={operation.progress} className="h-2" />
                                <div className="flex justify-between text-xs text-muted-foreground">
                                  <span>{operation.progress}% complete</span>
                                  {operation.speed && (
                                    <span>{operation.speed} MB/s</span>
                                  )}
                                  {operation.estimatedTime && (
                                    <span>{Math.floor(operation.estimatedTime / 60)}:{(operation.estimatedTime % 60).toString().padStart(2, '0')} remaining</span>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="recent" className="flex-1 overflow-hidden">
                <Card className="h-full flex flex-col">
                  <CardHeader>
                    <CardTitle className="text-base">Recent Files</CardTitle>
                    <CardDescription>Recently accessed files and folders</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 overflow-hidden">
                    <ScrollArea className="h-full">
                      <div className="space-y-2">
                        {recentFiles.map((file, index) => (
                          <div key={index} className="flex items-center gap-3 p-3 border rounded hover:bg-accent/50 cursor-pointer">
                            <FileText className="h-4 w-4 text-blue-500" />
                            <div className="flex-1 min-w-0">
                              <div className="font-medium">{file.name}</div>
                              <div className="text-sm text-muted-foreground truncate">{file.path}</div>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {file.lastAccessed.toLocaleString()}
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="starred" className="flex-1 overflow-hidden">
                <Card className="h-full flex flex-col">
                  <CardHeader>
                    <CardTitle className="text-base">Starred Items</CardTitle>
                    <CardDescription>Your bookmarked files and folders</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 overflow-hidden">
                    <ScrollArea className="h-full">
                      <div className="space-y-2">
                        {starredItems.map((item, index) => (
                          <div key={index} className="flex items-center gap-3 p-3 border rounded hover:bg-accent/50 cursor-pointer">
                            {item.type === 'folder' ? (
                              <Folder className="h-4 w-4 text-blue-500" />
                            ) : (
                              <File className="h-4 w-4 text-gray-500" />
                            )}
                            <div className="flex-1 min-w-0">
                              <div className="font-medium">{item.name}</div>
                              <div className="text-sm text-muted-foreground truncate">{item.path}</div>
                            </div>
                            <Star className="h-4 w-4 text-yellow-500 fill-current" />
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}