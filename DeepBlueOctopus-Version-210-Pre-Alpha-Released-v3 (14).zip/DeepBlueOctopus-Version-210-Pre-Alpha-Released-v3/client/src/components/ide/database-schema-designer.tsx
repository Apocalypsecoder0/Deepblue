import React, { useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  Database, Plus, Edit, Trash2, Link, Key, 
  Download, Upload, Code, Table, Grid,
  Settings, Eye, Copy, ArrowRight
} from "lucide-react";

interface DatabaseSchemaDesignerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Column {
  id: string;
  name: string;
  type: string;
  nullable: boolean;
  primaryKey: boolean;
  foreignKey?: {
    table: string;
    column: string;
  };
  unique: boolean;
  defaultValue?: string;
  length?: number;
  precision?: number;
  scale?: number;
}

interface Table {
  id: string;
  name: string;
  description: string;
  columns: Column[];
  position: { x: number; y: number };
  indexes: Index[];
}

interface Index {
  id: string;
  name: string;
  columns: string[];
  unique: boolean;
  type: 'btree' | 'hash' | 'gin' | 'gist';
}

interface Relationship {
  id: string;
  fromTable: string;
  fromColumn: string;
  toTable: string;
  toColumn: string;
  type: 'one-to-one' | 'one-to-many' | 'many-to-many' | 'many-to-one';
  onDelete: 'cascade' | 'restrict' | 'set-null' | 'no-action';
  onUpdate: 'cascade' | 'restrict' | 'set-null' | 'no-action';
}

interface Schema {
  id: string;
  name: string;
  description: string;
  database: 'postgresql' | 'mysql' | 'sqlite' | 'mongodb';
  tables: Table[];
  relationships: Relationship[];
  version: string;
  createdAt: Date;
}

export default function DatabaseSchemaDesigner({ isOpen, onClose }: DatabaseSchemaDesignerProps) {
  const [schemas, setSchemas] = useState<Schema[]>([
    {
      id: '1',
      name: 'E-commerce Schema',
      description: 'Complete e-commerce database schema',
      database: 'postgresql',
      version: '1.0.0',
      createdAt: new Date(),
      tables: [
        {
          id: '1',
          name: 'users',
          description: 'User accounts',
          position: { x: 100, y: 100 },
          columns: [
            {
              id: '1',
              name: 'id',
              type: 'SERIAL',
              nullable: false,
              primaryKey: true,
              unique: true
            },
            {
              id: '2',
              name: 'email',
              type: 'VARCHAR',
              length: 255,
              nullable: false,
              primaryKey: false,
              unique: true
            },
            {
              id: '3',
              name: 'password_hash',
              type: 'VARCHAR',
              length: 255,
              nullable: false,
              primaryKey: false,
              unique: false
            },
            {
              id: '4',
              name: 'created_at',
              type: 'TIMESTAMP',
              nullable: false,
              primaryKey: false,
              unique: false,
              defaultValue: 'NOW()'
            }
          ],
          indexes: [
            {
              id: '1',
              name: 'idx_users_email',
              columns: ['email'],
              unique: true,
              type: 'btree'
            }
          ]
        },
        {
          id: '2',
          name: 'products',
          description: 'Product catalog',
          position: { x: 400, y: 100 },
          columns: [
            {
              id: '1',
              name: 'id',
              type: 'SERIAL',
              nullable: false,
              primaryKey: true,
              unique: true
            },
            {
              id: '2',
              name: 'name',
              type: 'VARCHAR',
              length: 255,
              nullable: false,
              primaryKey: false,
              unique: false
            },
            {
              id: '3',
              name: 'price',
              type: 'DECIMAL',
              precision: 10,
              scale: 2,
              nullable: false,
              primaryKey: false,
              unique: false
            },
            {
              id: '4',
              name: 'category_id',
              type: 'INTEGER',
              nullable: true,
              primaryKey: false,
              unique: false,
              foreignKey: {
                table: 'categories',
                column: 'id'
              }
            }
          ],
          indexes: [
            {
              id: '1',
              name: 'idx_products_category',
              columns: ['category_id'],
              unique: false,
              type: 'btree'
            }
          ]
        },
        {
          id: '3',
          name: 'categories',
          description: 'Product categories',
          position: { x: 700, y: 100 },
          columns: [
            {
              id: '1',
              name: 'id',
              type: 'SERIAL',
              nullable: false,
              primaryKey: true,
              unique: true
            },
            {
              id: '2',
              name: 'name',
              type: 'VARCHAR',
              length: 100,
              nullable: false,
              primaryKey: false,
              unique: true
            },
            {
              id: '3',
              name: 'parent_id',
              type: 'INTEGER',
              nullable: true,
              primaryKey: false,
              unique: false,
              foreignKey: {
                table: 'categories',
                column: 'id'
              }
            }
          ],
          indexes: []
        }
      ],
      relationships: [
        {
          id: '1',
          fromTable: 'products',
          fromColumn: 'category_id',
          toTable: 'categories',
          toColumn: 'id',
          type: 'many-to-one',
          onDelete: 'set-null',
          onUpdate: 'cascade'
        },
        {
          id: '2',
          fromTable: 'categories',
          fromColumn: 'parent_id',
          toTable: 'categories',
          toColumn: 'id',
          type: 'many-to-one',
          onDelete: 'cascade',
          onUpdate: 'cascade'
        }
      ]
    }
  ]);

  const [selectedSchema, setSelectedSchema] = useState<Schema>(schemas[0]);
  const [selectedTable, setSelectedTable] = useState<Table | null>(null);
  const [isEditingTable, setIsEditingTable] = useState(false);
  const [editingColumn, setEditingColumn] = useState<Column | null>(null);

  const { toast } = useToast();

  const createNewTable = useCallback(() => {
    const newTable: Table = {
      id: Date.now().toString(),
      name: 'new_table',
      description: '',
      position: { x: 200, y: 200 },
      columns: [
        {
          id: Date.now().toString(),
          name: 'id',
          type: 'SERIAL',
          nullable: false,
          primaryKey: true,
          unique: true
        }
      ],
      indexes: []
    };

    setSchemas(prev => prev.map(schema => 
      schema.id === selectedSchema.id
        ? { ...schema, tables: [...schema.tables, newTable] }
        : schema
    ));

    setSelectedSchema(prev => ({
      ...prev,
      tables: [...prev.tables, newTable]
    }));

    setSelectedTable(newTable);
    setIsEditingTable(true);

    toast({
      title: "Table created",
      description: "New table has been added to the schema",
    });
  }, [selectedSchema, toast]);

  const addColumn = useCallback(() => {
    if (!selectedTable) return;

    const newColumn: Column = {
      id: Date.now().toString(),
      name: 'new_column',
      type: 'VARCHAR',
      nullable: true,
      primaryKey: false,
      unique: false,
      length: 255
    };

    const updatedTable = {
      ...selectedTable,
      columns: [...selectedTable.columns, newColumn]
    };

    setSelectedTable(updatedTable);
    setEditingColumn(newColumn);

    // Update in schemas
    setSchemas(prev => prev.map(schema => 
      schema.id === selectedSchema.id
        ? {
            ...schema,
            tables: schema.tables.map(table => 
              table.id === selectedTable.id ? updatedTable : table
            )
          }
        : schema
    ));

    setSelectedSchema(prev => ({
      ...prev,
      tables: prev.tables.map(table => 
        table.id === selectedTable.id ? updatedTable : table
      )
    }));
  }, [selectedTable, selectedSchema]);

  const updateColumn = useCallback((columnId: string, updates: Partial<Column>) => {
    if (!selectedTable) return;

    const updatedTable = {
      ...selectedTable,
      columns: selectedTable.columns.map(col => 
        col.id === columnId ? { ...col, ...updates } : col
      )
    };

    setSelectedTable(updatedTable);

    // Update in schemas
    setSchemas(prev => prev.map(schema => 
      schema.id === selectedSchema.id
        ? {
            ...schema,
            tables: schema.tables.map(table => 
              table.id === selectedTable.id ? updatedTable : table
            )
          }
        : schema
    ));

    setSelectedSchema(prev => ({
      ...prev,
      tables: prev.tables.map(table => 
        table.id === selectedTable.id ? updatedTable : table
      )
    }));
  }, [selectedTable, selectedSchema]);

  const deleteColumn = useCallback((columnId: string) => {
    if (!selectedTable) return;

    const updatedTable = {
      ...selectedTable,
      columns: selectedTable.columns.filter(col => col.id !== columnId)
    };

    setSelectedTable(updatedTable);

    // Update in schemas
    setSchemas(prev => prev.map(schema => 
      schema.id === selectedSchema.id
        ? {
            ...schema,
            tables: schema.tables.map(table => 
              table.id === selectedTable.id ? updatedTable : table
            )
          }
        : schema
    ));

    setSelectedSchema(prev => ({
      ...prev,
      tables: prev.tables.map(table => 
        table.id === selectedTable.id ? updatedTable : table
      )
    }));

    toast({
      title: "Column deleted",
      description: "Column has been removed from the table",
    });
  }, [selectedTable, selectedSchema, toast]);

  const generateSQL = useCallback(() => {
    let sql = `-- Schema: ${selectedSchema.name}\n`;
    sql += `-- Database: ${selectedSchema.database.toUpperCase()}\n\n`;

    // Create tables
    selectedSchema.tables.forEach(table => {
      sql += `CREATE TABLE ${table.name} (\n`;
      
      const columnDefs = table.columns.map(col => {
        let def = `  ${col.name} ${col.type}`;
        
        if (col.length) def += `(${col.length})`;
        if (col.precision && col.scale) def += `(${col.precision}, ${col.scale})`;
        
        if (!col.nullable) def += ' NOT NULL';
        if (col.unique && !col.primaryKey) def += ' UNIQUE';
        if (col.defaultValue) def += ` DEFAULT ${col.defaultValue}`;
        
        return def;
      });

      // Add primary key constraint
      const primaryKeys = table.columns.filter(col => col.primaryKey).map(col => col.name);
      if (primaryKeys.length > 0) {
        columnDefs.push(`  PRIMARY KEY (${primaryKeys.join(', ')})`);
      }

      sql += columnDefs.join(',\n') + '\n);\n\n';

      // Create indexes
      table.indexes.forEach(index => {
        sql += `CREATE ${index.unique ? 'UNIQUE ' : ''}INDEX ${index.name} ON ${table.name} (${index.columns.join(', ')});\n`;
      });

      if (table.indexes.length > 0) sql += '\n';
    });

    // Add foreign key constraints
    selectedSchema.relationships.forEach(rel => {
      sql += `ALTER TABLE ${rel.fromTable} ADD CONSTRAINT fk_${rel.fromTable}_${rel.fromColumn} `;
      sql += `FOREIGN KEY (${rel.fromColumn}) REFERENCES ${rel.toTable}(${rel.toColumn})`;
      sql += ` ON DELETE ${rel.onDelete.toUpperCase().replace('-', ' ')}`;
      sql += ` ON UPDATE ${rel.onUpdate.toUpperCase().replace('-', ' ')};\n`;
    });

    return sql;
  }, [selectedSchema]);

  const exportSchema = useCallback(() => {
    const sql = generateSQL();
    const blob = new Blob([sql], { type: 'text/sql' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedSchema.name.toLowerCase().replace(/\s+/g, '_')}_schema.sql`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Schema exported",
      description: "SQL schema has been downloaded",
    });
  }, [generateSQL, selectedSchema, toast]);

  const getTypeColor = (type: string) => {
    if (['SERIAL', 'INTEGER', 'BIGINT'].includes(type)) return 'bg-blue-100 text-blue-800';
    if (['VARCHAR', 'TEXT', 'CHAR'].includes(type)) return 'bg-green-100 text-green-800';
    if (['TIMESTAMP', 'DATE', 'TIME'].includes(type)) return 'bg-purple-100 text-purple-800';
    if (['DECIMAL', 'NUMERIC', 'FLOAT'].includes(type)) return 'bg-orange-100 text-orange-800';
    if (['BOOLEAN'].includes(type)) return 'bg-pink-100 text-pink-800';
    return 'bg-gray-100 text-gray-800';
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            Database Schema Designer
            <Badge variant="outline">
              {selectedSchema.database.toUpperCase()}
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex gap-4">
          {/* Schema Sidebar */}
          <div className="w-80 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Schema Info</span>
                  <Button size="sm" onClick={exportSchema}>
                    <Download className="w-4 h-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <span className="text-sm text-gray-500">Name:</span>
                    <p className="font-medium">{selectedSchema.name}</p>
                  </div>
                  <div>
                    <span className="text-sm text-gray-500">Database:</span>
                    <p className="font-medium">{selectedSchema.database.toUpperCase()}</p>
                  </div>
                  <div>
                    <span className="text-sm text-gray-500">Tables:</span>
                    <p className="font-medium">{selectedSchema.tables.length}</p>
                  </div>
                  <div>
                    <span className="text-sm text-gray-500">Relationships:</span>
                    <p className="font-medium">{selectedSchema.relationships.length}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Tables</span>
                  <Button size="sm" onClick={createNewTable}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <div className="space-y-2">
                    {selectedSchema.tables.map((table) => (
                      <div
                        key={table.id}
                        className={`p-3 border rounded cursor-pointer transition-colors ${
                          selectedTable?.id === table.id 
                            ? 'border-blue-300 bg-blue-50 dark:bg-blue-950' 
                            : 'hover:bg-gray-50 dark:hover:bg-gray-800'
                        }`}
                        onClick={() => setSelectedTable(table)}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium">{table.name}</span>
                          <Badge variant="outline">{table.columns.length}</Badge>
                        </div>
                        <p className="text-sm text-gray-500">{table.description || 'No description'}</p>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full">
                    <Code className="w-4 h-4 mr-2" />
                    Generate Migration
                  </Button>
                  <Button variant="outline" className="w-full">
                    <Eye className="w-4 h-4 mr-2" />
                    Preview SQL
                  </Button>
                  <Button variant="outline" className="w-full">
                    <Upload className="w-4 h-4 mr-2" />
                    Import Schema
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1 space-y-4">
            {selectedTable ? (
              <>
                {/* Table Header */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Table className="w-5 h-5" />
                        <Input
                          value={selectedTable.name}
                          onChange={(e) => {
                            const updatedTable = { ...selectedTable, name: e.target.value };
                            setSelectedTable(updatedTable);
                            // Update in schema...
                          }}
                          className="font-medium text-lg border-none p-0 h-auto"
                          disabled={!isEditingTable}
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setIsEditingTable(!isEditingTable)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button size="sm" onClick={addColumn}>
                          <Plus className="w-4 h-4 mr-1" />
                          Add Column
                        </Button>
                      </div>
                    </CardTitle>
                  </CardHeader>
                </Card>

                {/* Columns */}
                <Card>
                  <CardHeader>
                    <CardTitle>Columns</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {selectedTable.columns.map((column) => (
                        <Card key={column.id} className="p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-3">
                              <Input
                                value={column.name}
                                onChange={(e) => updateColumn(column.id, { name: e.target.value })}
                                className="font-medium w-32"
                              />
                              <select
                                value={column.type}
                                onChange={(e) => updateColumn(column.id, { type: e.target.value })}
                                className="px-3 py-2 border rounded-md"
                              >
                                <option value="SERIAL">SERIAL</option>
                                <option value="INTEGER">INTEGER</option>
                                <option value="BIGINT">BIGINT</option>
                                <option value="VARCHAR">VARCHAR</option>
                                <option value="TEXT">TEXT</option>
                                <option value="TIMESTAMP">TIMESTAMP</option>
                                <option value="DATE">DATE</option>
                                <option value="BOOLEAN">BOOLEAN</option>
                                <option value="DECIMAL">DECIMAL</option>
                                <option value="JSON">JSON</option>
                              </select>
                              {(column.type === 'VARCHAR' || column.type === 'CHAR') && (
                                <Input
                                  type="number"
                                  value={column.length || ''}
                                  onChange={(e) => updateColumn(column.id, { length: parseInt(e.target.value) })}
                                  placeholder="Length"
                                  className="w-20"
                                />
                              )}
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteColumn(column.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                          
                          <div className="flex items-center gap-4 text-sm">
                            <div className="flex items-center gap-2">
                              <input
                                type="checkbox"
                                checked={column.primaryKey}
                                onChange={(e) => updateColumn(column.id, { primaryKey: e.target.checked })}
                                className="rounded"
                              />
                              <span>Primary Key</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="checkbox"
                                checked={!column.nullable}
                                onChange={(e) => updateColumn(column.id, { nullable: !e.target.checked })}
                                className="rounded"
                              />
                              <span>Required</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="checkbox"
                                checked={column.unique}
                                onChange={(e) => updateColumn(column.id, { unique: e.target.checked })}
                                className="rounded"
                              />
                              <span>Unique</span>
                            </div>
                            {column.foreignKey && (
                              <Badge variant="outline" className="flex items-center gap-1">
                                <Link className="w-3 h-3" />
                                FK: {column.foreignKey.table}.{column.foreignKey.column}
                              </Badge>
                            )}
                          </div>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Indexes */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>Indexes</span>
                      <Button size="sm">
                        <Plus className="w-4 h-4 mr-1" />
                        Add Index
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedTable.indexes.length > 0 ? (
                      <div className="space-y-2">
                        {selectedTable.indexes.map((index) => (
                          <div key={index.id} className="flex items-center justify-between p-3 border rounded">
                            <div>
                              <span className="font-medium">{index.name}</span>
                              <div className="text-sm text-gray-500">
                                Columns: {index.columns.join(', ')}
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant={index.unique ? "default" : "secondary"}>
                                {index.unique ? 'Unique' : 'Standard'}
                              </Badge>
                              <Badge variant="outline">{index.type}</Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-center text-gray-500 py-4">No indexes defined</p>
                    )}
                  </CardContent>
                </Card>
              </>
            ) : (
              <Card>
                <CardContent className="flex flex-col items-center justify-center h-64">
                  <Database className="w-12 h-12 text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Table Selected</h3>
                  <p className="text-gray-500 text-center mb-4">
                    Select a table from the sidebar or create a new one
                  </p>
                  <Button onClick={createNewTable}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Table
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* SQL Preview Sidebar */}
          <div className="w-96 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="w-4 h-4" />
                  SQL Preview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-50 dark:bg-gray-900 p-3 rounded">
                  <pre className="text-xs overflow-auto max-h-64">
                    {generateSQL()}
                  </pre>
                </div>
                <div className="flex gap-2 mt-3">
                  <Button variant="outline" size="sm" className="flex-1">
                    <Copy className="w-3 h-3 mr-1" />
                    Copy
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Download className="w-3 h-3 mr-1" />
                    Export
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Relationships</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-32">
                  <div className="space-y-2">
                    {selectedSchema.relationships.map((rel) => (
                      <div key={rel.id} className="text-sm p-2 border rounded">
                        <div className="flex items-center gap-1">
                          <span className="font-medium">{rel.fromTable}</span>
                          <ArrowRight className="w-3 h-3" />
                          <span className="font-medium">{rel.toTable}</span>
                        </div>
                        <div className="text-xs text-gray-500">
                          {rel.fromColumn} → {rel.toColumn}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}