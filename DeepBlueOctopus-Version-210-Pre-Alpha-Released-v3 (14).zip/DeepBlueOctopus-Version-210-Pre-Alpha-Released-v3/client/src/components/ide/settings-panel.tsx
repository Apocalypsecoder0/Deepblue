import { useState } from "react";
import { Settings, X, Search, Monitor, Palette, Type, Code2, Terminal, GitBranch, Package, Keyboard, User, Bell, Shield, Cloud, Archive } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SettingsPanel({ isOpen, onClose }: SettingsPanelProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [settings, setSettings] = useState({
    // Editor settings
    fontSize: 14,
    fontFamily: "JetBrains Mono",
    theme: "deepblue-dark",
    tabSize: 2,
    wordWrap: true,
    lineNumbers: true,
    minimap: false,
    autoSave: true,
    formatOnSave: false,
    cursorBlinking: "blink",
    cursorStyle: "line",
    
    // Workbench settings
    sidebarPosition: "left",
    activityBarPosition: "default",
    zenMode: false,
    fullScreen: false,
    breadcrumbs: true,
    
    // Terminal settings
    terminalFontSize: 14,
    terminalShell: "bash",
    terminalCursorBlinking: true,
    
    // Git settings
    gitEnabled: true,
    gitAutoFetch: true,
    gitAutoStage: false,
    
    // Extensions
    extensionsAutoUpdate: true,
    extensionRecommendations: true,
    
    // Security
    trustedDomains: [],
    restrictedMode: false,
    
    // Performance
    searchMaxResults: 20000,
    indexingMaxFiles: 10000,
  });

  const settingsCategories = [
    {
      id: "editor",
      label: "Editor",
      icon: <Code2 className="h-4 w-4" />,
      description: "Font, cursor, and editing behavior"
    },
    {
      id: "workbench",
      label: "Workbench",
      icon: <Monitor className="h-4 w-4" />,
      description: "Layout, themes, and UI appearance"
    },
    {
      id: "terminal",
      label: "Terminal",
      icon: <Terminal className="h-4 w-4" />,
      description: "Terminal settings and shell configuration"
    },
    {
      id: "git",
      label: "Source Control",
      icon: <GitBranch className="h-4 w-4" />,
      description: "Git and version control settings"
    },
    {
      id: "extensions",
      label: "Extensions",
      icon: <Package className="h-4 w-4" />,
      description: "Extension marketplace and updates"
    },
    {
      id: "keyboard",
      label: "Keyboard",
      icon: <Keyboard className="h-4 w-4" />,
      description: "Keyboard shortcuts and key bindings"
    },
    {
      id: "user",
      label: "User",
      icon: <User className="h-4 w-4" />,
      description: "User profile and account settings"
    },
    {
      id: "security",
      label: "Security",
      icon: <Shield className="h-4 w-4" />,
      description: "Trust, permissions, and security"
    }
  ];

  const updateSetting = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex">
      <div className="ml-auto bg-[var(--ide-bg)] text-[var(--ide-text)] w-[900px] h-full flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b ide-border">
          <div className="flex items-center space-x-3">
            <Settings className="h-5 w-5" />
            <h2 className="text-lg font-semibold">Settings</h2>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="text-[var(--ide-text-secondary)] hover:text-[var(--ide-text)]"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Search */}
        <div className="p-4 border-b ide-border">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-[var(--ide-text-secondary)]" />
            <Input
              placeholder="Search settings"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-[var(--ide-panel)] border-[var(--ide-border)] text-[var(--ide-text)]"
            />
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Categories Sidebar */}
          <div className="w-64 border-r ide-border overflow-auto">
            <div className="p-4 space-y-2">
              {settingsCategories.map((category) => (
                <div
                  key={category.id}
                  className="flex items-center space-x-3 p-3 rounded cursor-pointer hover:bg-[var(--ide-panel)] transition-colors"
                >
                  {category.icon}
                  <div>
                    <div className="font-medium">{category.label}</div>
                    <div className="text-xs text-[var(--ide-text-secondary)]">{category.description}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Settings Content */}
          <div className="flex-1 overflow-auto">
            <Tabs defaultValue="editor" className="h-full">
              <TabsList className="border-b ide-border w-full justify-start rounded-none bg-transparent p-0">
                <TabsTrigger value="editor" className="data-[state=active]:bg-[var(--ide-panel)]">Editor</TabsTrigger>
                <TabsTrigger value="workbench" className="data-[state=active]:bg-[var(--ide-panel)]">Workbench</TabsTrigger>
                <TabsTrigger value="terminal" className="data-[state=active]:bg-[var(--ide-panel)]">Terminal</TabsTrigger>
                <TabsTrigger value="extensions" className="data-[state=active]:bg-[var(--ide-panel)]">Extensions</TabsTrigger>
              </TabsList>

              <TabsContent value="editor" className="p-6 space-y-6 m-0">
                <Card className="bg-[var(--ide-panel)] border-[var(--ide-border)]">
                  <CardHeader>
                    <CardTitle className="text-[var(--ide-text)]">Font</CardTitle>
                    <CardDescription className="text-[var(--ide-text-secondary)]">
                      Configure font family, size, and weight
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-[var(--ide-text)]">Font Family</Label>
                      <Select value={settings.fontFamily} onValueChange={(value) => updateSetting("fontFamily", value)}>
                        <SelectTrigger className="bg-[var(--ide-bg)] border-[var(--ide-border)]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-[var(--ide-panel)] border-[var(--ide-border)]">
                          <SelectItem value="JetBrains Mono">JetBrains Mono</SelectItem>
                          <SelectItem value="Fira Code">Fira Code</SelectItem>
                          <SelectItem value="Monaco">Monaco</SelectItem>
                          <SelectItem value="Consolas">Consolas</SelectItem>
                          <SelectItem value="Source Code Pro">Source Code Pro</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label className="text-[var(--ide-text)]">Font Size</Label>
                      <div className="flex items-center space-x-4">
                        <Slider
                          value={[settings.fontSize]}
                          onValueChange={(value) => updateSetting("fontSize", value[0])}
                          max={24}
                          min={10}
                          step={1}
                          className="flex-1"
                        />
                        <span className="text-sm text-[var(--ide-text-secondary)] w-8">{settings.fontSize}px</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-[var(--ide-panel)] border-[var(--ide-border)]">
                  <CardHeader>
                    <CardTitle className="text-[var(--ide-text)]">Editor</CardTitle>
                    <CardDescription className="text-[var(--ide-text-secondary)]">
                      Basic editor behavior and appearance
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label className="text-[var(--ide-text)]">Word Wrap</Label>
                      <Switch
                        checked={settings.wordWrap}
                        onCheckedChange={(checked) => updateSetting("wordWrap", checked)}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label className="text-[var(--ide-text)]">Line Numbers</Label>
                      <Switch
                        checked={settings.lineNumbers}
                        onCheckedChange={(checked) => updateSetting("lineNumbers", checked)}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label className="text-[var(--ide-text)]">Minimap</Label>
                      <Switch
                        checked={settings.minimap}
                        onCheckedChange={(checked) => updateSetting("minimap", checked)}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label className="text-[var(--ide-text)]">Auto Save</Label>
                      <Switch
                        checked={settings.autoSave}
                        onCheckedChange={(checked) => updateSetting("autoSave", checked)}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label className="text-[var(--ide-text)]">Format on Save</Label>
                      <Switch
                        checked={settings.formatOnSave}
                        onCheckedChange={(checked) => updateSetting("formatOnSave", checked)}
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="workbench" className="p-6 space-y-6 m-0">
                <Card className="bg-[var(--ide-panel)] border-[var(--ide-border)]">
                  <CardHeader>
                    <CardTitle className="text-[var(--ide-text)]">Appearance</CardTitle>
                    <CardDescription className="text-[var(--ide-text-secondary)]">
                      Theme and color customization
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-[var(--ide-text)]">Color Theme</Label>
                      <Select value={settings.theme} onValueChange={(value) => updateSetting("theme", value)}>
                        <SelectTrigger className="bg-[var(--ide-bg)] border-[var(--ide-border)]">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-[var(--ide-panel)] border-[var(--ide-border)]">
                          <SelectItem value="deepblue-dark">DeepBlue Dark</SelectItem>
                          <SelectItem value="deepblue-light">DeepBlue Light</SelectItem>
                          <SelectItem value="high-contrast">High Contrast</SelectItem>
                          <SelectItem value="monokai">Monokai</SelectItem>
                          <SelectItem value="github-dark">GitHub Dark</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="terminal" className="p-6 space-y-6 m-0">
                <Card className="bg-[var(--ide-panel)] border-[var(--ide-border)]">
                  <CardHeader>
                    <CardTitle className="text-[var(--ide-text)]">Terminal</CardTitle>
                    <CardDescription className="text-[var(--ide-text-secondary)]">
                      Terminal appearance and behavior
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-[var(--ide-text)]">Font Size</Label>
                      <div className="flex items-center space-x-4">
                        <Slider
                          value={[settings.terminalFontSize]}
                          onValueChange={(value) => updateSetting("terminalFontSize", value[0])}
                          max={20}
                          min={10}
                          step={1}
                          className="flex-1"
                        />
                        <span className="text-sm text-[var(--ide-text-secondary)] w-8">{settings.terminalFontSize}px</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label className="text-[var(--ide-text)]">Cursor Blinking</Label>
                      <Switch
                        checked={settings.terminalCursorBlinking}
                        onCheckedChange={(checked) => updateSetting("terminalCursorBlinking", checked)}
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="extensions" className="p-6 space-y-6 m-0">
                <Card className="bg-[var(--ide-panel)] border-[var(--ide-border)]">
                  <CardHeader>
                    <CardTitle className="text-[var(--ide-text)]">Extension Management</CardTitle>
                    <CardDescription className="text-[var(--ide-text-secondary)]">
                      Configure extension behavior and updates
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label className="text-[var(--ide-text)]">Auto Update Extensions</Label>
                      <Switch
                        checked={settings.extensionsAutoUpdate}
                        onCheckedChange={(checked) => updateSetting("extensionsAutoUpdate", checked)}
                      />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <Label className="text-[var(--ide-text)]">Show Extension Recommendations</Label>
                      <Switch
                        checked={settings.extensionRecommendations}
                        onCheckedChange={(checked) => updateSetting("extensionRecommendations", checked)}
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}