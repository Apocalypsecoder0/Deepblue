import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Puzzle, 
  Download, 
  Star, 
  Users, 
  Calendar, 
  Settings, 
  Search, 
  Trash2, 
  RefreshCw, 
  Package,
  Globe,
  Code,
  Palette,
  Zap,
  Shield,
  Heart,
  TrendingUp,
  Filter,
  Eye,
  CheckCircle,
  AlertCircle
} from "lucide-react";

interface ExtensionsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Extension {
  id: string;
  name: string;
  description: string;
  version: string;
  author: string;
  category: string;
  rating: number;
  downloads: number;
  size: string;
  installed: boolean;
  enabled: boolean;
  lastUpdated: string;
  icon: string;
  tags: string[];
  homepage?: string;
  repository?: string;
  premium?: boolean;
}

export default function ExtensionsPanel({ isOpen, onClose }: ExtensionsPanelProps) {
  const [activeTab, setActiveTab] = useState("marketplace");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortBy, setSortBy] = useState("popularity");

  // Sample extensions data
  const [extensions] = useState<Extension[]>([
    {
      id: "1",
      name: "Python IntelliSense",
      description: "Advanced Python code completion and error detection with type hints support.",
      version: "2.1.0",
      author: "Python Tools Team",
      category: "languages",
      rating: 4.8,
      downloads: 125000,
      size: "2.4 MB",
      installed: true,
      enabled: true,
      lastUpdated: "2025-01-01",
      icon: "🐍",
      tags: ["python", "intellisense", "autocomplete"],
      homepage: "https://python-tools.dev",
      repository: "https://github.com/python-tools/intellisense"
    },
    {
      id: "2", 
      name: "Dark Ocean Theme",
      description: "Beautiful dark theme inspired by deep ocean colors with smooth animations.",
      version: "1.5.2",
      author: "Theme Studio",
      category: "themes",
      rating: 4.9,
      downloads: 89000,
      size: "1.1 MB",
      installed: false,
      enabled: false,
      lastUpdated: "2024-12-28",
      icon: "🌊",
      tags: ["theme", "dark", "ocean", "blue"],
      premium: false
    },
    {
      id: "3",
      name: "Git Graph Visualizer",
      description: "Visual git branch and commit history with interactive timeline.",
      version: "3.0.1", 
      author: "Git Tools Inc",
      category: "tools",
      rating: 4.7,
      downloads: 67000,
      size: "3.2 MB",
      installed: true,
      enabled: false,
      lastUpdated: "2024-12-30",
      icon: "🌳",
      tags: ["git", "visualization", "history"]
    },
    {
      id: "4",
      name: "TypeScript Pro",
      description: "Enhanced TypeScript support with advanced debugging and refactoring tools.",
      version: "4.1.0",
      author: "TS Developers",
      category: "languages",
      rating: 4.6,
      downloads: 156000,
      size: "4.8 MB",
      installed: false,
      enabled: false,
      lastUpdated: "2025-01-01",
      icon: "📘",
      tags: ["typescript", "debugging", "refactoring"],
      premium: true
    },
    {
      id: "5",
      name: "Bracket Colorizer Pro",
      description: "Color-coded brackets and parentheses with customizable themes.",
      version: "2.3.0",
      author: "Code Visuals",
      category: "productivity",
      rating: 4.5,
      downloads: 92000,
      size: "1.8 MB",
      installed: true,
      enabled: true,
      lastUpdated: "2024-12-25",
      icon: "🌈",
      tags: ["brackets", "colors", "productivity"]
    },
    {
      id: "6",
      name: "Live Share Collaboration",
      description: "Real-time collaborative editing with voice chat and screen sharing.",
      version: "1.8.0",
      author: "Collab Tech",
      category: "collaboration",
      rating: 4.4,
      downloads: 45000,
      size: "5.1 MB",
      installed: false,
      enabled: false,
      lastUpdated: "2024-12-20",
      icon: "🤝",
      tags: ["collaboration", "share", "teamwork"],
      premium: true
    }
  ]);

  const categories = [
    { id: "all", name: "All Extensions", icon: <Package className="h-4 w-4" /> },
    { id: "languages", name: "Languages", icon: <Code className="h-4 w-4" /> },
    { id: "themes", name: "Themes", icon: <Palette className="h-4 w-4" /> },
    { id: "tools", name: "Tools", icon: <Zap className="h-4 w-4" /> },
    { id: "productivity", name: "Productivity", icon: <TrendingUp className="h-4 w-4" /> },
    { id: "collaboration", name: "Collaboration", icon: <Users className="h-4 w-4" /> },
    { id: "security", name: "Security", icon: <Shield className="h-4 w-4" /> }
  ];

  const installedExtensions = extensions.filter(ext => ext.installed);
  const enabledExtensions = installedExtensions.filter(ext => ext.enabled);

  const filteredExtensions = extensions.filter(ext => {
    const matchesSearch = ext.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         ext.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         ext.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = selectedCategory === "all" || ext.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const sortedExtensions = [...filteredExtensions].sort((a, b) => {
    switch (sortBy) {
      case "popularity":
        return b.downloads - a.downloads;
      case "rating":
        return b.rating - a.rating;
      case "updated":
        return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
      case "name":
        return a.name.localeCompare(b.name);
      default:
        return 0;
    }
  });

  const getCategoryIcon = (category: string) => {
    const cat = categories.find(c => c.id === category);
    return cat?.icon || <Package className="h-4 w-4" />;
  };

  const toggleExtension = (id: string) => {
    console.log("Toggling extension:", id);
    // In real implementation, this would enable/disable the extension
  };

  const installExtension = (id: string) => {
    console.log("Installing extension:", id);
    // In real implementation, this would install the extension
  };

  const uninstallExtension = (id: string) => {
    console.log("Uninstalling extension:", id);
    // In real implementation, this would uninstall the extension
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star 
        key={i} 
        className={`h-3 w-3 ${i < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-400'}`} 
      />
    ));
  };

  const formatDownloads = (downloads: number) => {
    if (downloads >= 1000000) return `${(downloads / 1000000).toFixed(1)}M`;
    if (downloads >= 1000) return `${(downloads / 1000).toFixed(1)}K`;
    return downloads.toString();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Puzzle className="h-5 w-5 text-purple-500" />
            Extensions Marketplace
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="grid grid-cols-3 w-full flex-shrink-0">
            <TabsTrigger value="marketplace">Marketplace</TabsTrigger>
            <TabsTrigger value="installed">Installed ({installedExtensions.length})</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="marketplace" className="flex-1 overflow-hidden">
            <div className="flex flex-col h-full gap-4">
              {/* Search and Filters */}
              <div className="flex flex-col sm:flex-row gap-4 flex-shrink-0">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search extensions..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        <div className="flex items-center gap-2">
                          {category.icon}
                          {category.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-36">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="popularity">Most Popular</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                    <SelectItem value="updated">Recently Updated</SelectItem>
                    <SelectItem value="name">Name (A-Z)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Extensions Grid */}
              <ScrollArea className="flex-1">
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4 p-1">
                  {sortedExtensions.map((extension) => (
                    <Card key={extension.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className="text-2xl">{extension.icon}</div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <CardTitle className="text-base truncate">{extension.name}</CardTitle>
                                {extension.premium && <Badge variant="secondary" className="text-xs">Pro</Badge>}
                              </div>
                              <div className="flex items-center gap-2 mt-1">
                                <span className="text-sm text-muted-foreground">by {extension.author}</span>
                                <span className="text-xs text-muted-foreground">v{extension.version}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-1">
                            {getCategoryIcon(extension.category)}
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <CardDescription className="mb-3 line-clamp-2">
                          {extension.description}
                        </CardDescription>
                        
                        <div className="flex items-center gap-4 mb-3 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            {renderStars(extension.rating)}
                            <span className="ml-1">{extension.rating}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Download className="h-3 w-3" />
                            {formatDownloads(extension.downloads)}
                          </div>
                          <span>{extension.size}</span>
                        </div>

                        <div className="flex flex-wrap gap-1 mb-3">
                          {extension.tags.slice(0, 3).map((tag) => (
                            <Badge key={tag} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">
                            Updated {new Date(extension.lastUpdated).toLocaleDateString()}
                          </span>
                          {extension.installed ? (
                            <Badge variant="secondary" className="text-xs">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Installed
                            </Badge>
                          ) : (
                            <Button size="sm" onClick={() => installExtension(extension.id)}>
                              <Download className="h-3 w-3 mr-1" />
                              Install
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="installed" className="flex-1 overflow-hidden">
            <div className="h-full flex flex-col">
              <div className="flex items-center justify-between mb-4 flex-shrink-0">
                <div>
                  <h3 className="font-medium">Installed Extensions</h3>
                  <p className="text-sm text-muted-foreground">
                    {enabledExtensions.length} enabled of {installedExtensions.length} installed
                  </p>
                </div>
                <Button size="sm" variant="outline">
                  <RefreshCw className="h-4 w-4 mr-1" />
                  Check for Updates
                </Button>
              </div>

              <ScrollArea className="flex-1">
                <div className="space-y-3">
                  {installedExtensions.map((extension) => (
                    <Card key={extension.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="text-xl">{extension.icon}</div>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium">{extension.name}</span>
                                <Badge variant="outline" className="text-xs">v{extension.version}</Badge>
                                {extension.enabled ? (
                                  <Badge variant="default" className="text-xs">
                                    <CheckCircle className="h-3 w-3 mr-1" />
                                    Enabled
                                  </Badge>
                                ) : (
                                  <Badge variant="secondary" className="text-xs">
                                    <AlertCircle className="h-3 w-3 mr-1" />
                                    Disabled
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground">{extension.description}</p>
                              <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                                <span>by {extension.author}</span>
                                <span>{extension.size}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Switch
                              checked={extension.enabled}
                              onCheckedChange={() => toggleExtension(extension.id)}
                            />
                            <Button size="sm" variant="outline">
                              <Settings className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => uninstallExtension(extension.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="flex-1 overflow-hidden">
            <ScrollArea className="h-full">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Extension Settings</CardTitle>
                    <CardDescription>Configure how extensions behave in your IDE</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">Auto-update extensions</span>
                        <p className="text-sm text-muted-foreground">Automatically update extensions when new versions are available</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">Show extension recommendations</span>
                        <p className="text-sm text-muted-foreground">Show recommended extensions based on your workspace</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">Enable extension marketplace</span>
                        <p className="text-sm text-muted-foreground">Allow browsing and installing extensions from marketplace</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Extension Marketplace</CardTitle>
                    <CardDescription>Configure marketplace behavior and preferences</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Default sort order</label>
                      <Select defaultValue="popularity">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="popularity">Most Popular</SelectItem>
                          <SelectItem value="rating">Highest Rated</SelectItem>
                          <SelectItem value="updated">Recently Updated</SelectItem>
                          <SelectItem value="name">Name (A-Z)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">Show premium extensions</span>
                        <p className="text-sm text-muted-foreground">Display premium/paid extensions in search results</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Performance</CardTitle>
                    <CardDescription>Extension performance and resource management</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">Limit extension startup time</span>
                        <p className="text-sm text-muted-foreground">Prevent slow extensions from delaying IDE startup</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Memory limit per extension</label>
                      <Select defaultValue="128">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="64">64 MB</SelectItem>
                          <SelectItem value="128">128 MB</SelectItem>
                          <SelectItem value="256">256 MB</SelectItem>
                          <SelectItem value="512">512 MB</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}