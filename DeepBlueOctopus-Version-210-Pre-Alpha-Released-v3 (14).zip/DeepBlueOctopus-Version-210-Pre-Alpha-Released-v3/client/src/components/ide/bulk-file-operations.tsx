import React, { useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { useIDEState } from "@/hooks/use-ide-state";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Files, Copy, Move, Trash2, Archive,
  FolderPlus, FileText, Search, Filter,
  CheckSquare, Square, MoreHorizontal,
  Download, Upload, Folder, Eye,
  AlertCircle, Check, X, PlayCircle
} from "lucide-react";

interface BulkFileOperationsProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FileOperation {
  id: string;
  type: 'copy' | 'move' | 'delete' | 'rename' | 'compress' | 'extract';
  files: number[];
  destination?: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  progress: number;
  error?: string;
  createdAt: Date;
}

export default function BulkFileOperations({ isOpen, onClose }: BulkFileOperationsProps) {
  const [selectedFiles, setSelectedFiles] = useState<number[]>([]);
  const [operationType, setOperationType] = useState<'copy' | 'move' | 'delete' | 'compress'>('copy');
  const [destinationPath, setDestinationPath] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'files' | 'folders'>('all');
  const [operations, setOperations] = useState<FileOperation[]>([]);
  const [currentOperation, setCurrentOperation] = useState<FileOperation | null>(null);

  const { files } = useIDEState();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const bulkOperationMutation = useMutation({
    mutationFn: async (operation: Omit<FileOperation, 'id' | 'status' | 'progress' | 'createdAt'>) => {
      const operationId = Date.now().toString();
      const newOperation: FileOperation = {
        ...operation,
        id: operationId,
        status: 'running',
        progress: 0,
        createdAt: new Date()
      };

      setCurrentOperation(newOperation);
      setOperations(prev => [...prev, newOperation]);

      // Simulate progress updates
      for (let progress = 0; progress <= 100; progress += 10) {
        await new Promise(resolve => setTimeout(resolve, 100));
        setCurrentOperation(prev => prev ? { ...prev, progress } : null);
        setOperations(prev => prev.map(op => 
          op.id === operationId ? { ...op, progress } : op
        ));
      }

      // Execute the actual operation based on type
      switch (operation.type) {
        case 'copy':
          return await Promise.all(operation.files.map(async (fileId) => {
            const file = files?.find(f => f.id === fileId);
            if (file) {
              const newFile = {
                ...file,
                name: `${file.name}_copy`,
                path: `${operation.destination}/${file.name}_copy`,
              };
              return apiRequest("POST", "/api/files", newFile);
            }
          }));
        
        case 'move':
          return await Promise.all(operation.files.map(async (fileId) => {
            const file = files?.find(f => f.id === fileId);
            if (file) {
              return apiRequest("PUT", `/api/files/${fileId}`, {
                ...file,
                path: `${operation.destination}/${file.name}`
              });
            }
          }));
        
        case 'delete':
          return await Promise.all(operation.files.map(async (fileId) => {
            return apiRequest("DELETE", `/api/files/${fileId}`);
          }));
        
        case 'compress':
          // Simulate compression
          return { type: 'archive', files: operation.files, path: `${operation.destination}/archive.zip` };
        
        default:
          throw new Error(`Unsupported operation: ${operation.type}`);
      }
    },
    onSuccess: () => {
      setCurrentOperation(prev => prev ? { ...prev, status: 'completed' } : null);
      setOperations(prev => prev.map(op => 
        op.id === currentOperation?.id ? { ...op, status: 'completed' } : op
      ));
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
      toast({
        title: "Operation completed",
        description: "Bulk file operation completed successfully",
      });
      setSelectedFiles([]);
    },
    onError: (error: any) => {
      setCurrentOperation(prev => prev ? { ...prev, status: 'failed', error: error.message } : null);
      setOperations(prev => prev.map(op => 
        op.id === currentOperation?.id ? { ...op, status: 'failed', error: error.message } : op
      ));
      toast({
        title: "Operation failed",
        description: error.message || "Bulk file operation failed",
        variant: "destructive",
      });
    },
  });

  const filteredFiles = files?.filter(file => {
    const matchesSearch = file.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || 
      (filterType === 'files' && !file.isDirectory) || 
      (filterType === 'folders' && file.isDirectory);
    return matchesSearch && matchesType;
  }) || [];

  const handleSelectFile = useCallback((fileId: number) => {
    setSelectedFiles(prev => 
      prev.includes(fileId) 
        ? prev.filter(id => id !== fileId)
        : [...prev, fileId]
    );
  }, []);

  const handleSelectAll = useCallback(() => {
    if (selectedFiles.length === filteredFiles.length) {
      setSelectedFiles([]);
    } else {
      setSelectedFiles(filteredFiles.map(f => f.id));
    }
  }, [selectedFiles, filteredFiles]);

  const handleExecuteOperation = useCallback(() => {
    if (selectedFiles.length === 0) {
      toast({
        title: "No files selected",
        description: "Please select files to perform the operation",
        variant: "destructive",
      });
      return;
    }

    if ((operationType === 'copy' || operationType === 'move') && !destinationPath) {
      toast({
        title: "No destination specified",
        description: "Please specify a destination path",
        variant: "destructive",
      });
      return;
    }

    bulkOperationMutation.mutate({
      type: operationType,
      files: selectedFiles,
      destination: destinationPath || undefined
    });
  }, [selectedFiles, operationType, destinationPath, bulkOperationMutation, toast]);

  const getOperationIcon = (type: string) => {
    switch (type) {
      case 'copy': return <Copy className="w-4 h-4" />;
      case 'move': return <Move className="w-4 h-4" />;
      case 'delete': return <Trash2 className="w-4 h-4" />;
      case 'compress': return <Archive className="w-4 h-4" />;
      default: return <Files className="w-4 h-4" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <Check className="w-4 h-4 text-green-500" />;
      case 'failed': return <X className="w-4 h-4 text-red-500" />;
      case 'running': return <PlayCircle className="w-4 h-4 text-blue-500 animate-spin" />;
      default: return <AlertCircle className="w-4 h-4 text-gray-500" />;
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[85vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Files className="w-5 h-5" />
            Bulk File Operations
            {selectedFiles.length > 0 && (
              <Badge variant="outline">
                {selectedFiles.length} selected
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="operations" className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="operations">Operations</TabsTrigger>
            <TabsTrigger value="files">File Selection</TabsTrigger>
            <TabsTrigger value="history">Operation History</TabsTrigger>
          </TabsList>

          <TabsContent value="operations" className="flex-1 flex flex-col space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PlayCircle className="w-4 h-4" />
                  Configure Operation
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-4 gap-4">
                  <Button
                    variant={operationType === 'copy' ? 'default' : 'outline'}
                    onClick={() => setOperationType('copy')}
                    className="flex flex-col items-center gap-2 h-16"
                  >
                    <Copy className="w-5 h-5" />
                    Copy
                  </Button>
                  <Button
                    variant={operationType === 'move' ? 'default' : 'outline'}
                    onClick={() => setOperationType('move')}
                    className="flex flex-col items-center gap-2 h-16"
                  >
                    <Move className="w-5 h-5" />
                    Move
                  </Button>
                  <Button
                    variant={operationType === 'delete' ? 'default' : 'outline'}
                    onClick={() => setOperationType('delete')}
                    className="flex flex-col items-center gap-2 h-16"
                  >
                    <Trash2 className="w-5 h-5" />
                    Delete
                  </Button>
                  <Button
                    variant={operationType === 'compress' ? 'default' : 'outline'}
                    onClick={() => setOperationType('compress')}
                    className="flex flex-col items-center gap-2 h-16"
                  >
                    <Archive className="w-5 h-5" />
                    Compress
                  </Button>
                </div>

                {(operationType === 'copy' || operationType === 'move' || operationType === 'compress') && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Destination Path</label>
                    <Input
                      placeholder="Enter destination path (e.g., /src/backup)"
                      value={destinationPath}
                      onChange={(e) => setDestinationPath(e.target.value)}
                    />
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">
                      {selectedFiles.length} files selected
                    </span>
                  </div>
                  <Button
                    onClick={handleExecuteOperation}
                    disabled={selectedFiles.length === 0 || bulkOperationMutation.isPending}
                    className="flex items-center gap-2"
                  >
                    {getOperationIcon(operationType)}
                    Execute {operationType}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {currentOperation && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getStatusIcon(currentOperation.status)}
                    Current Operation
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="capitalize">{currentOperation.type} operation</span>
                      <Badge variant="outline">{currentOperation.status}</Badge>
                    </div>
                    <Progress value={currentOperation.progress} className="h-2" />
                    <p className="text-sm text-gray-500">
                      Processing {currentOperation.files.length} files... {currentOperation.progress}%
                    </p>
                    {currentOperation.error && (
                      <p className="text-sm text-red-500">{currentOperation.error}</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="files" className="flex-1 flex flex-col space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="w-4 h-4" />
                  File Selection
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex-1">
                    <Input
                      placeholder="Search files..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <select
                    value={filterType}
                    onChange={(e) => setFilterType(e.target.value as any)}
                    className="px-3 py-2 border rounded-md"
                  >
                    <option value="all">All</option>
                    <option value="files">Files Only</option>
                    <option value="folders">Folders Only</option>
                  </select>
                  <Button
                    variant="outline"
                    onClick={handleSelectAll}
                    className="flex items-center gap-2"
                  >
                    {selectedFiles.length === filteredFiles.length ? <CheckSquare /> : <Square />}
                    Select All
                  </Button>
                </div>

                <ScrollArea className="h-96">
                  <div className="space-y-2">
                    {filteredFiles.map((file) => (
                      <div
                        key={file.id}
                        className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                          selectedFiles.includes(file.id) 
                            ? 'bg-blue-50 dark:bg-blue-950 border-blue-200' 
                            : 'hover:bg-gray-50 dark:hover:bg-gray-800'
                        }`}
                        onClick={() => handleSelectFile(file.id)}
                      >
                        <Checkbox
                          checked={selectedFiles.includes(file.id)}
                          onChange={() => handleSelectFile(file.id)}
                        />
                        <div className="flex items-center gap-2">
                          {file.isDirectory ? (
                            <Folder className="w-4 h-4 text-blue-500" />
                          ) : (
                            <FileText className="w-4 h-4 text-gray-500" />
                          )}
                          <div className="flex-1">
                            <p className="font-medium">{file.name}</p>
                            <p className="text-sm text-gray-500">{file.path}</p>
                          </div>
                        </div>
                        <div className="text-right text-sm text-gray-500">
                          {!file.isDirectory && file.size && (
                            <p>{formatFileSize(file.size)}</p>
                          )}
                          <p>{file.lastModified?.toLocaleDateString()}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="flex-1 flex flex-col space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  Operation History
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {operations.length === 0 ? (
                      <p className="text-center text-gray-500 py-8">No operations performed yet</p>
                    ) : (
                      operations.map((operation) => (
                        <div key={operation.id} className="flex items-center gap-3 p-3 border rounded-lg">
                          <div className="flex items-center gap-2">
                            {getOperationIcon(operation.type)}
                            {getStatusIcon(operation.status)}
                          </div>
                          <div className="flex-1">
                            <p className="font-medium capitalize">
                              {operation.type} operation
                            </p>
                            <p className="text-sm text-gray-500">
                              {operation.files.length} files • {operation.createdAt.toLocaleString()}
                            </p>
                            {operation.destination && (
                              <p className="text-sm text-blue-500">
                                Destination: {operation.destination}
                              </p>
                            )}
                            {operation.error && (
                              <p className="text-sm text-red-500">{operation.error}</p>
                            )}
                          </div>
                          <div className="text-right">
                            <Badge variant="outline">{operation.status}</Badge>
                            {operation.status === 'running' && (
                              <Progress value={operation.progress} className="w-20 h-2 mt-1" />
                            )}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}