import React, { useState, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  BarChart3, TrendingUp, TrendingDown, AlertTriangle, 
  CheckCircle2, XCircle, Clock, Target, Bug, Shield,
  Search, Filter, Download, RefreshCw, Settings,
  LineChart, PieChart, Activity, Zap, Code2,
  FileText, GitBranch, Users, Calendar
} from "lucide-react";

interface CodeAnalysisSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface CodeIssue {
  id: string;
  type: 'error' | 'warning' | 'info' | 'suggestion';
  severity: 'high' | 'medium' | 'low';
  file: string;
  line: number;
  column: number;
  message: string;
  rule: string;
  category: string;
  fixable: boolean;
  estimatedTime: number;
}

interface CodeMetrics {
  file: string;
  linesOfCode: number;
  cyclomaticComplexity: number;
  maintainabilityIndex: number;
  technicalDebt: number;
  duplicateLines: number;
  testCoverage: number;
  lastModified: Date;
  author: string;
}

interface QualityGate {
  id: string;
  name: string;
  metric: string;
  operator: 'gt' | 'lt' | 'eq';
  threshold: number;
  status: 'passed' | 'failed' | 'warning';
  actualValue: number;
}

interface AnalysisRun {
  id: string;
  timestamp: Date;
  duration: number;
  filesAnalyzed: number;
  totalIssues: number;
  errorCount: number;
  warningCount: number;
  qualityScore: number;
  status: 'completed' | 'running' | 'failed';
}

export default function CodeAnalysisSystem({ isOpen, onClose }: CodeAnalysisSystemProps) {
  const [activeTab, setActiveTab] = useState("issues");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterSeverity, setFilterSeverity] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [autoAnalysis, setAutoAnalysis] = useState(true);

  const [codeIssues, setCodeIssues] = useState<CodeIssue[]>([
    {
      id: "issue-1",
      type: "error",
      severity: "high",
      file: "src/components/Button.tsx",
      line: 42,
      column: 15,
      message: "Property 'onClick' is missing in type 'ButtonProps'",
      rule: "typescript/no-missing-props",
      category: "Type Safety",
      fixable: true,
      estimatedTime: 2
    },
    {
      id: "issue-2",
      type: "warning",
      severity: "medium",
      file: "src/utils/helpers.ts",
      line: 128,
      column: 8,
      message: "Function has too many parameters (8). Maximum allowed is 5",
      rule: "complexity/max-params",
      category: "Code Complexity",
      fixable: false,
      estimatedTime: 15
    },
    {
      id: "issue-3",
      type: "suggestion",
      severity: "low",
      file: "src/services/api.ts",
      line: 67,
      column: 23,
      message: "Consider using async/await instead of Promise.then()",
      rule: "style/prefer-async-await",
      category: "Code Style",
      fixable: true,
      estimatedTime: 3
    },
    {
      id: "issue-4",
      type: "warning",
      severity: "medium",
      file: "src/components/Modal.tsx",
      line: 15,
      column: 1,
      message: "Duplicate code block detected (12 lines)",
      rule: "duplication/no-duplicate-code",
      category: "Code Duplication",
      fixable: false,
      estimatedTime: 20
    },
    {
      id: "issue-5",
      type: "error",
      severity: "high",
      file: "src/hooks/useAuth.ts",
      line: 34,
      column: 12,
      message: "Potential memory leak: useEffect missing dependency",
      rule: "react-hooks/exhaustive-deps",
      category: "React Hooks",
      fixable: true,
      estimatedTime: 5
    }
  ]);

  const [codeMetrics, setCodeMetrics] = useState<CodeMetrics[]>([
    {
      file: "src/components/Button.tsx",
      linesOfCode: 145,
      cyclomaticComplexity: 8,
      maintainabilityIndex: 78,
      technicalDebt: 2.5,
      duplicateLines: 0,
      testCoverage: 92,
      lastModified: new Date(),
      author: "John Doe"
    },
    {
      file: "src/utils/helpers.ts",
      linesOfCode: 320,
      cyclomaticComplexity: 15,
      maintainabilityIndex: 45,
      technicalDebt: 8.2,
      duplicateLines: 23,
      testCoverage: 67,
      lastModified: new Date(Date.now() - 86400000),
      author: "Jane Smith"
    },
    {
      file: "src/services/api.ts",
      linesOfCode: 280,
      cyclomaticComplexity: 12,
      maintainabilityIndex: 65,
      technicalDebt: 4.1,
      duplicateLines: 12,
      testCoverage: 84,
      lastModified: new Date(Date.now() - 3600000),
      author: "Bob Wilson"
    }
  ]);

  const [qualityGates, setQualityGates] = useState<QualityGate[]>([
    {
      id: "gate-1",
      name: "Code Coverage",
      metric: "coverage",
      operator: "gt",
      threshold: 80,
      status: "passed",
      actualValue: 85.4
    },
    {
      id: "gate-2",
      name: "Technical Debt",
      metric: "debt_ratio",
      operator: "lt",
      threshold: 5,
      status: "warning",
      actualValue: 4.9
    },
    {
      id: "gate-3",
      name: "Maintainability",
      metric: "maintainability",
      operator: "gt",
      threshold: 70,
      status: "failed",
      actualValue: 62.8
    },
    {
      id: "gate-4",
      name: "Complexity",
      metric: "complexity",
      operator: "lt",
      threshold: 10,
      status: "passed",
      actualValue: 8.2
    }
  ]);

  const [analysisRuns, setAnalysisRuns] = useState<AnalysisRun[]>([
    {
      id: "run-1",
      timestamp: new Date(),
      duration: 45.2,
      filesAnalyzed: 156,
      totalIssues: 23,
      errorCount: 2,
      warningCount: 8,
      qualityScore: 7.8,
      status: "completed"
    },
    {
      id: "run-2",
      timestamp: new Date(Date.now() - 3600000),
      duration: 42.8,
      filesAnalyzed: 154,
      totalIssues: 19,
      errorCount: 1,
      warningCount: 6,
      qualityScore: 8.2,
      status: "completed"
    }
  ]);

  const runAnalysis = async () => {
    setIsAnalyzing(true);
    
    // Simulate analysis process
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const newRun: AnalysisRun = {
      id: `run-${Date.now()}`,
      timestamp: new Date(),
      duration: Math.random() * 30 + 30,
      filesAnalyzed: Math.floor(Math.random() * 50 + 150),
      totalIssues: Math.floor(Math.random() * 20 + 15),
      errorCount: Math.floor(Math.random() * 3 + 1),
      warningCount: Math.floor(Math.random() * 10 + 5),
      qualityScore: Math.random() * 3 + 7,
      status: "completed"
    };
    
    setAnalysisRuns(prev => [newRun, ...prev]);
    setIsAnalyzing(false);
  };

  const getIssueIcon = (type: CodeIssue['type']) => {
    switch (type) {
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'info':
        return <CheckCircle2 className="h-4 w-4 text-blue-500" />;
      case 'suggestion':
        return <Zap className="h-4 w-4 text-purple-500" />;
    }
  };

  const getSeverityColor = (severity: CodeIssue['severity']) => {
    switch (severity) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-blue-500';
    }
  };

  const getQualityGateIcon = (status: QualityGate['status']) => {
    switch (status) {
      case 'passed':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
    }
  };

  const filteredIssues = codeIssues.filter(issue => {
    const matchesSearch = issue.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         issue.file.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSeverity = filterSeverity === 'all' || issue.severity === filterSeverity;
    const matchesType = filterType === 'all' || issue.type === filterType;
    
    return matchesSearch && matchesSeverity && matchesType;
  });

  const totalIssues = codeIssues.length;
  const errorCount = codeIssues.filter(i => i.type === 'error').length;
  const warningCount = codeIssues.filter(i => i.type === 'warning').length;
  const fixableCount = codeIssues.filter(i => i.fixable).length;

  const averageComplexity = codeMetrics.reduce((sum, m) => sum + m.cyclomaticComplexity, 0) / codeMetrics.length;
  const averageMaintainability = codeMetrics.reduce((sum, m) => sum + m.maintainabilityIndex, 0) / codeMetrics.length;
  const totalTechnicalDebt = codeMetrics.reduce((sum, m) => sum + m.technicalDebt, 0);
  const averageCoverage = codeMetrics.reduce((sum, m) => sum + m.testCoverage, 0) / codeMetrics.length;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-blue-500" />
            Code Analysis & Metrics
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-5 flex-shrink-0">
            <TabsTrigger value="issues" className="flex items-center gap-2">
              <Bug className="h-4 w-4" />
              Issues
            </TabsTrigger>
            <TabsTrigger value="metrics" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Metrics
            </TabsTrigger>
            <TabsTrigger value="quality-gates" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Quality Gates
            </TabsTrigger>
            <TabsTrigger value="trends" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Trends
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="issues" className="flex-1 overflow-hidden flex flex-col">
            <div className="flex items-center gap-4 mb-4 flex-shrink-0">
              <Button 
                onClick={runAnalysis} 
                disabled={isAnalyzing}
                className="flex items-center gap-2"
              >
                <RefreshCw className={`h-4 w-4 ${isAnalyzing ? 'animate-spin' : ''}`} />
                {isAnalyzing ? 'Analyzing...' : 'Run Analysis'}
              </Button>
              
              <Separator orientation="vertical" className="h-6" />
              
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search issues..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 w-64"
                  />
                </div>
                <Select value={filterSeverity} onValueChange={setFilterSeverity}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Severity</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="error">Errors</SelectItem>
                    <SelectItem value="warning">Warnings</SelectItem>
                    <SelectItem value="info">Info</SelectItem>
                    <SelectItem value="suggestion">Suggestions</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center gap-2 ml-auto">
                <Label className="text-sm">Auto-analysis</Label>
                <Switch checked={autoAnalysis} onCheckedChange={setAutoAnalysis} />
              </div>
            </div>

            <div className="grid grid-cols-4 gap-4 mb-4 flex-shrink-0">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Total Issues</p>
                      <p className="text-2xl font-bold">{totalIssues}</p>
                    </div>
                    <Bug className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-red-600">Errors</p>
                      <p className="text-2xl font-bold text-red-600">{errorCount}</p>
                    </div>
                    <XCircle className="h-8 w-8 text-red-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-yellow-600">Warnings</p>
                      <p className="text-2xl font-bold text-yellow-600">{warningCount}</p>
                    </div>
                    <AlertTriangle className="h-8 w-8 text-yellow-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-green-600">Auto-fixable</p>
                      <p className="text-2xl font-bold text-green-600">{fixableCount}</p>
                    </div>
                    <Zap className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <ScrollArea className="flex-1">
              <div className="space-y-3 pr-4">
                {filteredIssues.map((issue) => (
                  <Card key={issue.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3 flex-1">
                          {getIssueIcon(issue.type)}
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <p className="font-medium">{issue.message}</p>
                              <Badge 
                                variant="secondary" 
                                className={`${getSeverityColor(issue.severity)} text-white`}
                              >
                                {issue.severity}
                              </Badge>
                              {issue.fixable && (
                                <Badge variant="outline" className="text-green-600">
                                  Auto-fixable
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <span>{issue.file}:{issue.line}:{issue.column}</span>
                              <span>Rule: {issue.rule}</span>
                              <span>Category: {issue.category}</span>
                              <span>Est. fix time: {issue.estimatedTime}min</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Button size="sm" variant="outline">
                            View File
                          </Button>
                          {issue.fixable && (
                            <Button size="sm">
                              Quick Fix
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="metrics" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-4 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-blue-600">{averageComplexity.toFixed(1)}</p>
                    <p className="text-sm text-muted-foreground">Avg Complexity</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">{averageMaintainability.toFixed(1)}</p>
                    <p className="text-sm text-muted-foreground">Maintainability</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-red-600">{totalTechnicalDebt.toFixed(1)}h</p>
                    <p className="text-sm text-muted-foreground">Technical Debt</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-purple-600">{averageCoverage.toFixed(1)}%</p>
                    <p className="text-sm text-muted-foreground">Test Coverage</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <ScrollArea className="flex-1">
              <div className="space-y-4 pr-4">
                {codeMetrics.map((metrics, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base">{metrics.file}</CardTitle>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Users className="h-4 w-4" />
                          {metrics.author}
                          <Calendar className="h-4 w-4" />
                          {metrics.lastModified.toLocaleDateString()}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                        <div>
                          <p className="text-sm text-muted-foreground">Lines of Code</p>
                          <p className="text-lg font-semibold">{metrics.linesOfCode}</p>
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Complexity</p>
                          <p className="text-lg font-semibold">{metrics.cyclomaticComplexity}</p>
                          <Progress 
                            value={Math.min(metrics.cyclomaticComplexity * 5, 100)} 
                            className="h-2 mt-1"
                          />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Maintainability</p>
                          <p className="text-lg font-semibold">{metrics.maintainabilityIndex}</p>
                          <Progress 
                            value={metrics.maintainabilityIndex} 
                            className="h-2 mt-1"
                          />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">Test Coverage</p>
                          <p className="text-lg font-semibold">{metrics.testCoverage}%</p>
                          <Progress 
                            value={metrics.testCoverage} 
                            className="h-2 mt-1"
                          />
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between mt-4 pt-4 border-t">
                        <div className="flex items-center gap-4 text-sm">
                          <span>Technical Debt: {metrics.technicalDebt}h</span>
                          <span>Duplicate Lines: {metrics.duplicateLines}</span>
                        </div>
                        <Button size="sm" variant="outline">
                          <FileText className="h-4 w-4 mr-2" />
                          View Details
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="quality-gates" className="flex-1 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Quality Gates</h3>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Configure Gates
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
              {qualityGates.map((gate) => (
                <Card key={gate.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {getQualityGateIcon(gate.status)}
                        <h4 className="font-medium">{gate.name}</h4>
                      </div>
                      <Badge 
                        variant={gate.status === 'passed' ? 'default' : gate.status === 'warning' ? 'secondary' : 'destructive'}
                      >
                        {gate.status}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Threshold: {gate.operator} {gate.threshold}</span>
                        <span>Actual: {gate.actualValue}</span>
                      </div>
                      <Progress 
                        value={gate.status === 'passed' ? 100 : gate.status === 'warning' ? 75 : 25} 
                        className="h-2"
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Overall Quality Score</CardTitle>
                <CardDescription>
                  Based on all quality gates and code metrics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <div className="text-4xl font-bold text-green-600">8.2</div>
                  <div className="flex-1">
                    <Progress value={82} className="h-4" />
                    <p className="text-sm text-muted-foreground mt-1">
                      Good quality - Above average for your project type
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="trends" className="flex-1 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Analysis History</h3>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export Report
              </Button>
            </div>

            <ScrollArea className="flex-1">
              <div className="space-y-4 pr-4">
                {analysisRuns.map((run) => (
                  <Card key={run.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base">
                          Analysis - {run.timestamp.toLocaleString()}
                        </CardTitle>
                        <Badge variant={run.status === 'completed' ? 'default' : 'secondary'}>
                          {run.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Duration</p>
                          <p className="font-medium">{run.duration.toFixed(1)}s</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Files Analyzed</p>
                          <p className="font-medium">{run.filesAnalyzed}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Total Issues</p>
                          <p className="font-medium">{run.totalIssues}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Quality Score</p>
                          <p className="font-medium">{run.qualityScore.toFixed(1)}/10</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Errors/Warnings</p>
                          <p className="font-medium">{run.errorCount}/{run.warningCount}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="settings" className="flex-1 overflow-hidden">
            <ScrollArea className="flex-1">
              <div className="space-y-6 pr-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Analysis Configuration</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Auto-analysis on Save</Label>
                        <p className="text-sm text-muted-foreground">Run analysis when files are saved</p>
                      </div>
                      <Switch checked={autoAnalysis} onCheckedChange={setAutoAnalysis} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Real-time Issues</Label>
                        <p className="text-sm text-muted-foreground">Show issues while typing</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Rules Configuration</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Rule Severity</Label>
                      <Select defaultValue="recommended">
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="strict">Strict</SelectItem>
                          <SelectItem value="recommended">Recommended</SelectItem>
                          <SelectItem value="relaxed">Relaxed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}