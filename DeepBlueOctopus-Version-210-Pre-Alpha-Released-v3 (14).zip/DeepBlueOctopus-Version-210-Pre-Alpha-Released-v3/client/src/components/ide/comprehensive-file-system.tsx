import React, { useState, useCallback, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  FolderOpen, File, Upload, Download, Search, 
  Star, Trash2, Copy, Move, Archive, 
  FileText, Image, Video, Code2, Database,
  Filter, RefreshCw, Settings, Globe,
  HardDrive, Clock, Eye, Share2, Lock
} from "lucide-react";

interface ComprehensiveFileSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FileSystemItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  path: string;
  size: number;
  modified: Date;
  created: Date;
  permissions: 'read' | 'write' | 'execute';
  owner: string;
  tags: string[];
  starred: boolean;
  encrypted: boolean;
  shared: boolean;
  version: number;
  checksum: string;
  mimeType: string;
  encoding: string;
  language?: string;
  children?: FileSystemItem[];
}

interface FileOperation {
  id: string;
  type: 'copy' | 'move' | 'delete' | 'compress' | 'extract';
  status: 'pending' | 'running' | 'completed' | 'failed';
  progress: number;
  source: string;
  destination?: string;
  error?: string;
}

const SAMPLE_FILE_SYSTEM: FileSystemItem[] = [
  {
    id: '1',
    name: 'projects',
    type: 'folder',
    path: '/home/user/projects',
    size: 0,
    modified: new Date('2024-07-04T14:30:00'),
    created: new Date('2024-07-01T10:00:00'),
    permissions: 'write',
    owner: 'user',
    tags: ['work', 'development'],
    starred: true,
    encrypted: false,
    shared: false,
    version: 1,
    checksum: '',
    mimeType: 'inode/directory',
    encoding: 'utf-8',
    children: [
      {
        id: '2',
        name: 'deepblue-ide',
        type: 'folder',
        path: '/home/user/projects/deepblue-ide',
        size: 0,
        modified: new Date('2024-07-04T16:00:00'),
        created: new Date('2024-07-02T09:00:00'),
        permissions: 'write',
        owner: 'user',
        tags: ['ide', 'typescript', 'react'],
        starred: true,
        encrypted: false,
        shared: true,
        version: 5,
        checksum: '',
        mimeType: 'inode/directory',
        encoding: 'utf-8'
      }
    ]
  },
  {
    id: '3',
    name: 'main.tsx',
    type: 'file',
    path: '/home/user/projects/main.tsx',
    size: 2847,
    modified: new Date('2024-07-04T15:45:00'),
    created: new Date('2024-07-04T10:00:00'),
    permissions: 'write',
    owner: 'user',
    tags: ['typescript', 'react', 'entry-point'],
    starred: false,
    encrypted: false,
    shared: false,
    version: 3,
    checksum: 'sha256:a1b2c3d4e5f6',
    mimeType: 'text/typescript',
    encoding: 'utf-8',
    language: 'typescript'
  },
  {
    id: '4',
    name: 'config.json',
    type: 'file',
    path: '/home/user/projects/config.json',
    size: 1234,
    modified: new Date('2024-07-03T12:00:00'),
    created: new Date('2024-07-03T12:00:00'),
    permissions: 'read',
    owner: 'user',
    tags: ['configuration', 'json'],
    starred: false,
    encrypted: true,
    shared: false,
    version: 1,
    checksum: 'sha256:f6e5d4c3b2a1',
    mimeType: 'application/json',
    encoding: 'utf-8',
    language: 'json'
  }
];

export default function ComprehensiveFileSystem({ isOpen, onClose }: ComprehensiveFileSystemProps) {
  const [activeTab, setActiveTab] = useState('browser');
  const [fileSystem, setFileSystem] = useState<FileSystemItem[]>(SAMPLE_FILE_SYSTEM);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [operations, setOperations] = useState<FileOperation[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState<'name' | 'size' | 'modified' | 'type'>('name');
  const [filterBy, setFilterBy] = useState<'all' | 'files' | 'folders' | 'starred'>('all');
  const [showHidden, setShowHidden] = useState(false);
  const [viewMode, setViewMode] = useState<'list' | 'grid' | 'tree'>('list');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { toast } = useToast();
  const { addFile } = useIDEState();

  const getFileIcon = (item: FileSystemItem) => {
    if (item.type === 'folder') return <FolderOpen className="w-4 h-4 text-blue-500" />;
    if (item.mimeType.startsWith('image/')) return <Image className="w-4 h-4 text-green-500" />;
    if (item.mimeType.startsWith('video/')) return <Video className="w-4 h-4 text-purple-500" />;
    if (item.language) return <Code2 className="w-4 h-4 text-blue-600" />;
    if (item.mimeType.includes('json') || item.mimeType.includes('xml')) return <Database className="w-4 h-4 text-orange-500" />;
    return <FileText className="w-4 h-4 text-gray-500" />;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (date: Date): string => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    if (files.length === 0) return;

    files.forEach((file, index) => {
      const operationId = `upload-${Date.now()}-${index}`;
      const newOperation: FileOperation = {
        id: operationId,
        type: 'copy',
        status: 'running',
        progress: 0,
        source: file.name,
        destination: '/uploads/'
      };

      setOperations(prev => [...prev, newOperation]);

      // Simulate upload progress
      const interval = setInterval(() => {
        setOperations(prev => prev.map(op => {
          if (op.id === operationId) {
            const newProgress = Math.min(op.progress + Math.random() * 20, 100);
            if (newProgress >= 100) {
              clearInterval(interval);
              
              // Add to file system
              const newFile: FileSystemItem = {
                id: `file-${Date.now()}-${index}`,
                name: file.name,
                type: 'file',
                path: `/uploads/${file.name}`,
                size: file.size,
                modified: new Date(),
                created: new Date(),
                permissions: 'write',
                owner: 'user',
                tags: ['uploaded'],
                starred: false,
                encrypted: false,
                shared: false,
                version: 1,
                checksum: `sha256:${Math.random().toString(36)}`,
                mimeType: file.type,
                encoding: 'utf-8',
                language: file.name.split('.').pop()
              };

              setFileSystem(prev => [...prev, newFile]);
              return { ...op, progress: 100, status: 'completed' as const };
            }
            return { ...op, progress: newProgress };
          }
          return op;
        }));
      }, 100);
    });

    toast({
      title: "Upload Started",
      description: `Uploading ${files.length} file(s)`,
    });
  }, [toast]);

  const openInIDE = (item: FileSystemItem) => {
    if (item.type === 'folder') return;
    
    addFile({
      name: item.name,
      path: item.path,
      content: `// File loaded from comprehensive file system\n// Path: ${item.path}\n// Size: ${formatFileSize(item.size)}\n// Modified: ${formatDate(item.modified)}\n\nconsole.log('File opened in IDE: ${item.name}');`,
      language: item.language || 'text',
      isDirectory: false,
      projectId: 1
    });

    toast({
      title: "File Opened",
      description: `${item.name} opened in IDE`,
    });
  };

  const toggleStar = (itemId: string) => {
    setFileSystem(prev => prev.map(item => 
      item.id === itemId 
        ? { ...item, starred: !item.starred }
        : item
    ));
  };

  const deleteItems = (itemIds: string[]) => {
    setFileSystem(prev => prev.filter(item => !itemIds.includes(item.id)));
    setSelectedItems([]);
    toast({
      title: "Items Deleted",
      description: `${itemIds.length} item(s) deleted`,
    });
  };

  const copyItems = (itemIds: string[]) => {
    const items = fileSystem.filter(item => itemIds.includes(item.id));
    const copies = items.map(item => ({
      ...item,
      id: `${item.id}-copy-${Date.now()}`,
      name: `${item.name} (copy)`,
      path: `${item.path} (copy)`,
      created: new Date(),
      modified: new Date()
    }));
    
    setFileSystem(prev => [...prev, ...copies]);
    toast({
      title: "Items Copied",
      description: `${items.length} item(s) copied`,
    });
  };

  const filteredFileSystem = fileSystem.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesFilter = filterBy === 'all' || 
                         (filterBy === 'files' && item.type === 'file') ||
                         (filterBy === 'folders' && item.type === 'folder') ||
                         (filterBy === 'starred' && item.starred);
    
    const matchesHidden = showHidden || !item.name.startsWith('.');
    
    return matchesSearch && matchesFilter && matchesHidden;
  }).sort((a, b) => {
    switch (sortBy) {
      case 'name': return a.name.localeCompare(b.name);
      case 'size': return b.size - a.size;
      case 'modified': return b.modified.getTime() - a.modified.getTime();
      case 'type': return a.type.localeCompare(b.type);
      default: return 0;
    }
  });

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <HardDrive className="w-5 h-5" />
            Comprehensive File System
            <Badge variant="outline" className="ml-2">
              {filteredFileSystem.length} Items
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex flex-col gap-4 overflow-hidden">
          {/* Toolbar */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Input
                placeholder="Search files and folders..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64"
              />
              <select 
                value={filterBy}
                onChange={(e) => setFilterBy(e.target.value as any)}
                className="px-3 py-2 border rounded-md bg-background"
              >
                <option value="all">All Items</option>
                <option value="files">Files Only</option>
                <option value="folders">Folders Only</option>
                <option value="starred">Starred</option>
              </select>
              <select 
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-3 py-2 border rounded-md bg-background"
              >
                <option value="name">Sort by Name</option>
                <option value="size">Sort by Size</option>
                <option value="modified">Sort by Modified</option>
                <option value="type">Sort by Type</option>
              </select>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2">
                <Switch
                  checked={showHidden}
                  onCheckedChange={setShowHidden}
                />
                <span className="text-sm">Show Hidden</span>
              </div>
              <Button
                onClick={() => fileInputRef.current?.click()}
                size="sm"
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="browser">File Browser</TabsTrigger>
              <TabsTrigger value="operations">Operations</TabsTrigger>
              <TabsTrigger value="properties">Properties</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>
            
            <TabsContent value="browser" className="flex-1">
              {/* Action Bar */}
              {selectedItems.length > 0 && (
                <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-md mb-4">
                  <span className="text-sm font-medium">
                    {selectedItems.length} item(s) selected
                  </span>
                  <div className="flex gap-2 ml-auto">
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => copyItems(selectedItems)}
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copy
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => deleteItems(selectedItems)}
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </div>
              )}

              <ScrollArea className="flex-1">
                <div className="space-y-1">
                  {filteredFileSystem.map((item) => (
                    <Card 
                      key={item.id} 
                      className={`hover:shadow-sm transition-shadow cursor-pointer ${
                        selectedItems.includes(item.id) ? 'ring-2 ring-blue-500' : ''
                      }`}
                      onClick={() => {
                        if (selectedItems.includes(item.id)) {
                          setSelectedItems(prev => prev.filter(id => id !== item.id));
                        } else {
                          setSelectedItems(prev => [...prev, item.id]);
                        }
                      }}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3 flex-1">
                            {getFileIcon(item)}
                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <h4 className="font-medium">{item.name}</h4>
                                {item.starred && <Star className="w-4 h-4 text-yellow-500 fill-current" />}
                                {item.encrypted && <Lock className="w-4 h-4 text-red-500" />}
                                {item.shared && <Share2 className="w-4 h-4 text-blue-500" />}
                              </div>
                              <div className="flex items-center gap-2 text-sm text-gray-600">
                                <span>{item.path}</span>
                                <span>•</span>
                                <span>{formatFileSize(item.size)}</span>
                                <span>•</span>
                                <span>{formatDate(item.modified)}</span>
                                <span>•</span>
                                <Badge variant="outline" className="text-xs">
                                  v{item.version}
                                </Badge>
                              </div>
                              <div className="flex gap-1 mt-1">
                                {item.tags.map((tag, idx) => (
                                  <Badge key={idx} variant="secondary" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleStar(item.id);
                              }}
                            >
                              <Star className={`w-4 h-4 ${item.starred ? 'text-yellow-500 fill-current' : ''}`} />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={(e) => {
                                e.stopPropagation();
                                openInIDE(item);
                              }}
                              disabled={item.type === 'folder'}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="operations" className="flex-1">
              <ScrollArea className="flex-1">
                <div className="space-y-3">
                  {operations.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <Archive className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>No active operations</p>
                    </div>
                  ) : (
                    operations.map((operation) => (
                      <Card key={operation.id}>
                        <CardContent className="p-4">
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Badge variant="outline" className="capitalize">
                                  {operation.type}
                                </Badge>
                                <span className="text-sm font-medium">{operation.source}</span>
                                {operation.destination && (
                                  <>
                                    <span className="text-gray-400">→</span>
                                    <span className="text-sm">{operation.destination}</span>
                                  </>
                                )}
                              </div>
                              <Badge 
                                variant={operation.status === 'completed' ? 'default' : 'outline'}
                                className="capitalize"
                              >
                                {operation.status}
                              </Badge>
                            </div>
                            {operation.status === 'running' && (
                              <div className="space-y-1">
                                <div className="flex justify-between text-sm">
                                  <span>Progress</span>
                                  <span>{Math.round(operation.progress)}%</span>
                                </div>
                                <Progress value={operation.progress} className="w-full" />
                              </div>
                            )}
                            {operation.error && (
                              <div className="text-sm text-red-600 bg-red-50 p-2 rounded">
                                {operation.error}
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="properties" className="flex-1">
              {selectedItems.length === 1 ? (
                (() => {
                  const item = fileSystem.find(f => f.id === selectedItems[0]);
                  if (!item) return null;
                  return (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-sm">General Information</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <span className="font-medium">Name:</span>
                            <span>{item.name}</span>
                            <span className="font-medium">Type:</span>
                            <span className="capitalize">{item.type}</span>
                            <span className="font-medium">Size:</span>
                            <span>{formatFileSize(item.size)}</span>
                            <span className="font-medium">Owner:</span>
                            <span>{item.owner}</span>
                            <span className="font-medium">Permissions:</span>
                            <span className="capitalize">{item.permissions}</span>
                            <span className="font-medium">Encoding:</span>
                            <span>{item.encoding}</span>
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="text-sm">Dates & Version</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div className="grid grid-cols-2 gap-2 text-sm">
                            <span className="font-medium">Created:</span>
                            <span>{formatDate(item.created)}</span>
                            <span className="font-medium">Modified:</span>
                            <span>{formatDate(item.modified)}</span>
                            <span className="font-medium">Version:</span>
                            <span>v{item.version}</span>
                            <span className="font-medium">Checksum:</span>
                            <span className="font-mono text-xs">{item.checksum}</span>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  );
                })()
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Settings className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Select a single item to view properties</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="analytics" className="flex-1">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">File Types</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {Object.entries(
                        fileSystem.reduce((acc, item) => {
                          if (item.type === 'file') {
                            const ext = item.name.split('.').pop() || 'no extension';
                            acc[ext] = (acc[ext] || 0) + 1;
                          }
                          return acc;
                        }, {} as Record<string, number>)
                      ).map(([ext, count]) => (
                        <div key={ext} className="flex justify-between text-sm">
                          <span>.{ext}</span>
                          <Badge variant="outline">{count}</Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Storage Usage</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span>Total Files:</span>
                        <Badge>{fileSystem.filter(f => f.type === 'file').length}</Badge>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Total Folders:</span>
                        <Badge>{fileSystem.filter(f => f.type === 'folder').length}</Badge>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Total Size:</span>
                        <Badge>{formatFileSize(fileSystem.reduce((acc, f) => acc + f.size, 0))}</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Quick Stats</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span>Starred Items:</span>
                        <Badge className="bg-yellow-100 text-yellow-800">
                          {fileSystem.filter(f => f.starred).length}
                        </Badge>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Shared Items:</span>
                        <Badge className="bg-blue-100 text-blue-800">
                          {fileSystem.filter(f => f.shared).length}
                        </Badge>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Encrypted Items:</span>
                        <Badge className="bg-red-100 text-red-800">
                          {fileSystem.filter(f => f.encrypted).length}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="flex items-center justify-between pt-4 border-t">
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <HardDrive className="w-4 h-4" />
              <span>{filteredFileSystem.length} Items</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>Last Updated: {new Date().toLocaleTimeString()}</span>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            <Button>
              <Settings className="w-4 h-4 mr-2" />
              System Settings
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}