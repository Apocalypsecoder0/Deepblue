import { useState } from "react";
import { ChevronDown, ChevronRight, FilePlus, FolderPlus, RefreshCw, Circle, Folder, FolderOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useIDEState } from "@/hooks/use-ide-state";
import { getFileIcon } from "@/lib/file-icons";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import { SoundButton } from "@/components/ui/sound-system";
import { apiRequest } from "@/lib/queryClient";
import type { File } from "@shared/schema";

export default function Sidebar() {
  const { currentProject, openFile, selectedFileId, setSelectedFileId } = useIDEState();
  const [expandedFolders, setExpandedFolders] = useState<Set<number>>(new Set([1]));
  const [isCreatingFile, setIsCreatingFile] = useState(false);
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);
  const [newFileName, setNewFileName] = useState("");
  const [newFolderName, setNewFolderName] = useState("");
  const [creatingInFolder, setCreatingInFolder] = useState<number | null>(null);
  const queryClient = useQueryClient();

  const { data: files = [], refetch } = useQuery({
    queryKey: ["/api/files", currentProject?.id],
    enabled: !!currentProject?.id,
  });

  const createFileMutation = useMutation({
    mutationFn: async (fileData: any) => {
      return apiRequest("POST", "/api/files", fileData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
      setIsCreatingFile(false);
      setNewFileName("");
      setCreatingInFolder(null);
    },
  });

  const createFolderMutation = useMutation({
    mutationFn: async (folderData: any) => {
      return apiRequest("POST", "/api/files", folderData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
      setIsCreatingFolder(false);
      setNewFolderName("");
      setCreatingInFolder(null);
    },
  });

  const toggleFolder = (folderId: number) => {
    const newExpanded = new Set(expandedFolders);
    if (newExpanded.has(folderId)) {
      newExpanded.delete(folderId);
    } else {
      newExpanded.add(folderId);
    }
    setExpandedFolders(newExpanded);
  };

  const handleFileClick = (file: File) => {
    if (file.isDirectory) {
      toggleFolder(file.id);
    } else {
      setSelectedFileId(file.id);
      openFile(file);
    }
  };

  const handleCreateFile = (parentId: number | null = null) => {
    setIsCreatingFile(true);
    setCreatingInFolder(parentId);
    setNewFileName("");
  };

  const handleCreateFolder = (parentId: number | null = null) => {
    setIsCreatingFolder(true);
    setCreatingInFolder(parentId);
    setNewFolderName("");
  };

  const submitNewFile = () => {
    if (!newFileName.trim()) return;
    
    const extension = newFileName.split('.').pop()?.toLowerCase() || 'txt';
    const languageMap: Record<string, string> = {
      'js': 'javascript',
      'ts': 'typescript',
      'py': 'python',
      'java': 'java',
      'cpp': 'cpp',
      'c': 'c',
      'rs': 'rust',
      'go': 'go',
      'php': 'php',
      'rb': 'ruby',
      'css': 'css',
      'html': 'html',
      'json': 'json',
      'md': 'markdown',
      'txt': 'plaintext'
    };

    const fileData = {
      name: newFileName.trim(),
      path: creatingInFolder ? `/${Array.isArray(files) ? files.find((f: any) => f.id === creatingInFolder)?.path : ''}/${newFileName.trim()}` : `/${newFileName.trim()}`,
      content: '',
      language: languageMap[extension] || 'plaintext',
      projectId: currentProject?.id,
      isDirectory: false,
      parentId: creatingInFolder,
      size: 0,
      lastModified: new Date(),
      isReadonly: false,
      encoding: 'utf-8'
    };

    createFileMutation.mutate(fileData);
  };

  const submitNewFolder = () => {
    if (!newFolderName.trim()) return;
    
    const folderData = {
      name: newFolderName.trim(),
      path: creatingInFolder ? `/${Array.isArray(files) ? files.find((f: any) => f.id === creatingInFolder)?.path : ''}/${newFolderName.trim()}` : `/${newFolderName.trim()}`,
      content: '',
      language: 'plaintext',
      projectId: currentProject?.id,
      isDirectory: true,
      parentId: creatingInFolder,
      size: 0,
      lastModified: new Date(),
      isReadonly: false,
      encoding: 'utf-8'
    };

    createFolderMutation.mutate(folderData);
  };

  const renderFileTree = (parentId: number | null, level: number = 0): React.ReactNode => {
    if (!Array.isArray(files)) return null;
    
    const childFiles = files.filter((file: any) => file.parentId === parentId);
    
    return childFiles.map((file: any) => (
      <div key={file.id}>
        <div
          style={{ paddingLeft: `${level * 16}px` }}
          className={`flex items-center py-1 px-2 text-sm cursor-pointer file-tree-item rounded transition-colors hover:bg-[var(--ide-surface-secondary)] ${
            selectedFileId === file.id ? "bg-[var(--ide-accent)]/20 text-[var(--ide-accent)]" : "text-[var(--ide-text)]"
          }`}
          onClick={() => handleFileClick(file)}
        >
          {file.isDirectory ? (
            <div className="flex items-center gap-1">
              {expandedFolders.has(file.id) ? (
                <ChevronDown className="h-3 w-3 text-[var(--ide-text-secondary)]" />
              ) : (
                <ChevronRight className="h-3 w-3 text-[var(--ide-text-secondary)]" />
              )}
              {expandedFolders.has(file.id) ? (
                <FolderOpen className="h-4 w-4 text-[var(--ide-accent)]" />
              ) : (
                <Folder className="h-4 w-4 text-[var(--ide-accent)]" />
              )}
            </div>
          ) : (
            <div className="flex items-center gap-1">
              <div className="w-3" />
              {getFileIcon(file.name, file.isDirectory)}
            </div>
          )}
          
          <span className={`ml-2 ${file.isDirectory ? "font-medium" : ""}`}>{file.name}</span>
          
          {!file.isDirectory && (
            <Circle className="h-2 w-2 text-[var(--ide-warning)] ml-auto opacity-0" />
          )}
        </div>
        
        {file.isDirectory && expandedFolders.has(file.id) && (
          <div>
            {renderFileTree(file.id, level + 1)}
          </div>
        )}
      </div>
    ));
  };

  return (
    <div className="ide-sidebar w-60 border-r border-[var(--ide-border)] flex flex-col bg-[var(--ide-surface)]">
      {/* Explorer Header */}
      <div className="p-3 border-b border-[var(--ide-border)]">
        <div className="flex items-center justify-between">
          <h3 className="font-medium text-sm text-[var(--ide-text)]">EXPLORER</h3>
          <div className="flex space-x-1">
            <TooltipWrapper
              title="New File"
              content="Create a new file in the current directory with support for 25+ programming languages"
              type="tip"
            >
              <SoundButton
                variant="ghost"
                size="sm"
                onClick={() => handleCreateFile()}
                className="h-6 w-6 p-0"
              >
                <FilePlus className="h-3 w-3" />
              </SoundButton>
            </TooltipWrapper>
            
            <TooltipWrapper
              title="New Folder"
              content="Create a new folder to organize your project files"
              type="tip"
            >
              <SoundButton
                variant="ghost"
                size="sm"
                onClick={() => handleCreateFolder()}
                className="h-6 w-6 p-0"
              >
                <FolderPlus className="h-3 w-3" />
              </SoundButton>
            </TooltipWrapper>
            
            <TooltipWrapper
              title="Refresh"
              content="Refresh the file explorer to show latest changes"
              type="tip"
            >
              <SoundButton
                variant="ghost"
                size="sm"
                onClick={() => refetch()}
                className="h-6 w-6 p-0"
              >
                <RefreshCw className="h-3 w-3" />
              </SoundButton>
            </TooltipWrapper>
          </div>
        </div>
      </div>

      {/* File Tree */}
      <div className="flex-1 overflow-auto p-2">
        {currentProject ? (
          <div className="space-y-1">
            {/* Project Root */}
            <div className="text-xs font-medium text-[var(--ide-text-secondary)] mb-2 uppercase tracking-wide">
              {currentProject.name}
            </div>
            
            {/* File Creation Input */}
            {isCreatingFile && (
              <div className="flex items-center gap-2 p-2 bg-[var(--ide-surface-secondary)] rounded">
                <Input
                  value={newFileName}
                  onChange={(e) => setNewFileName(e.target.value)}
                  placeholder="filename.ext"
                  className="text-xs"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') submitNewFile();
                    if (e.key === 'Escape') {
                      setIsCreatingFile(false);
                      setNewFileName("");
                    }
                  }}
                  autoFocus
                />
              </div>
            )}
            
            {/* Folder Creation Input */}
            {isCreatingFolder && (
              <div className="flex items-center gap-2 p-2 bg-[var(--ide-surface-secondary)] rounded">
                <Input
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  placeholder="folder name"
                  className="text-xs"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') submitNewFolder();
                    if (e.key === 'Escape') {
                      setIsCreatingFolder(false);
                      setNewFolderName("");
                    }
                  }}
                  autoFocus
                />
              </div>
            )}
            
            {/* Render File Tree */}
            {renderFileTree(null)}
          </div>
        ) : (
          <div className="text-center text-[var(--ide-text-secondary)] py-8">
            <p className="text-sm">No project selected</p>
          </div>
        )}
      </div>
    </div>
  );
}