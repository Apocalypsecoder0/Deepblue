import React, { useState, useCallback, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { 
  Cpu, MemoryStick, Activity, AlertTriangle, TrendingUp,
  BarChart3, PieChart, Zap, Clock, Target, RefreshCw,
  Download, Bug, Search, Filter, Eye, Camera
} from "lucide-react";

interface MemoryAnalyzerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface MemorySnapshot {
  id: string;
  timestamp: Date;
  totalMemory: number;
  usedMemory: number;
  freeMemory: number;
  gcCollections: number;
  heapSize: number;
  allocatedObjects: number;
  leaks: MemoryLeak[];
}

interface MemoryLeak {
  id: string;
  type: string;
  size: number;
  location: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  stack: string[];
  recommendations: string[];
}

interface PerformanceMetric {
  id: string;
  name: string;
  value: number;
  unit: string;
  threshold: number;
  status: 'good' | 'warning' | 'critical';
  trend: 'up' | 'down' | 'stable';
}

export default function MemoryAnalyzer({ isOpen, onClose }: MemoryAnalyzerProps) {
  const [snapshots, setSnapshots] = useState<MemorySnapshot[]>([
    {
      id: '1',
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
      totalMemory: 8192,
      usedMemory: 5847,
      freeMemory: 2345,
      gcCollections: 12,
      heapSize: 4096,
      allocatedObjects: 15624,
      leaks: [
        {
          id: '1',
          type: 'Event Listener',
          size: 256,
          location: 'components/FileManager.tsx:45',
          description: 'Uncleaned event listeners causing memory accumulation',
          severity: 'medium',
          stack: ['FileManager.tsx:45', 'useEffect hook', 'addEventListener'],
          recommendations: [
            'Add cleanup function in useEffect return',
            'Use removeEventListener in component unmount'
          ]
        },
        {
          id: '2',
          type: 'DOM References',
          size: 512,
          location: 'components/CodeEditor.tsx:120',
          description: 'DOM node references not being cleared',
          severity: 'high',
          stack: ['CodeEditor.tsx:120', 'Monaco Editor instance', 'DOM manipulation'],
          recommendations: [
            'Dispose Monaco Editor instances properly',
            'Clear DOM references on unmount'
          ]
        }
      ]
    },
    {
      id: '2',
      timestamp: new Date(),
      totalMemory: 8192,
      usedMemory: 6234,
      freeMemory: 1958,
      gcCollections: 15,
      heapSize: 4352,
      allocatedObjects: 18901,
      leaks: []
    }
  ]);

  const [metrics, setMetrics] = useState<PerformanceMetric[]>([
    {
      id: '1',
      name: 'Memory Usage',
      value: 76,
      unit: '%',
      threshold: 80,
      status: 'warning',
      trend: 'up'
    },
    {
      id: '2',
      name: 'Heap Size',
      value: 4352,
      unit: 'MB',
      threshold: 5000,
      status: 'good',
      trend: 'stable'
    },
    {
      id: '3',
      name: 'GC Frequency',
      value: 15,
      unit: '/min',
      threshold: 20,
      status: 'good',
      trend: 'up'
    },
    {
      id: '4',
      name: 'Object Count',
      value: 18901,
      unit: 'objects',
      threshold: 25000,
      status: 'good',
      trend: 'up'
    }
  ]);

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedSnapshot, setSelectedSnapshot] = useState<MemorySnapshot>(snapshots[0]);
  const [autoRefresh, setAutoRefresh] = useState(false);

  const { toast } = useToast();

  const takeSnapshot = useCallback(async () => {
    setIsAnalyzing(true);
    
    // Simulate memory analysis
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const newSnapshot: MemorySnapshot = {
      id: Date.now().toString(),
      timestamp: new Date(),
      totalMemory: 8192,
      usedMemory: Math.floor(Math.random() * 3000) + 4000,
      freeMemory: 0,
      gcCollections: Math.floor(Math.random() * 10) + 10,
      heapSize: Math.floor(Math.random() * 1000) + 3500,
      allocatedObjects: Math.floor(Math.random() * 10000) + 15000,
      leaks: Math.random() > 0.7 ? [
        {
          id: Date.now().toString(),
          type: 'Closure',
          size: Math.floor(Math.random() * 500) + 100,
          location: `components/Component${Math.floor(Math.random() * 10)}.tsx:${Math.floor(Math.random() * 100) + 1}`,
          description: 'Potential memory leak detected',
          severity: Math.random() > 0.5 ? 'medium' : 'high',
          stack: ['Component.tsx', 'useEffect', 'closure'],
          recommendations: ['Review closure usage', 'Check dependency array']
        }
      ] : []
    };

    newSnapshot.freeMemory = newSnapshot.totalMemory - newSnapshot.usedMemory;
    
    setSnapshots(prev => [newSnapshot, ...prev.slice(0, 9)]);
    setSelectedSnapshot(newSnapshot);
    setIsAnalyzing(false);
    
    toast({
      title: "Snapshot completed",
      description: `Memory analysis completed. ${newSnapshot.leaks.length} issues found.`,
    });
  }, [toast]);

  const runAnalysis = useCallback(async () => {
    setIsAnalyzing(true);
    
    // Simulate comprehensive analysis
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Update metrics
    setMetrics(prev => prev.map(metric => ({
      ...metric,
      value: metric.name === 'Memory Usage' 
        ? Math.floor(Math.random() * 30) + 60
        : metric.value + (Math.random() - 0.5) * 100,
      status: Math.random() > 0.7 ? 'warning' : 'good',
      trend: Math.random() > 0.5 ? 'up' : Math.random() > 0.5 ? 'down' : 'stable'
    })));
    
    setIsAnalyzing(false);
    
    toast({
      title: "Analysis completed",
      description: "Memory and performance analysis finished",
    });
  }, [toast]);

  const exportReport = useCallback(() => {
    const report = {
      timestamp: new Date().toISOString(),
      snapshots: snapshots.slice(0, 5),
      metrics,
      summary: {
        totalLeaks: snapshots.reduce((sum, s) => sum + s.leaks.length, 0),
        criticalIssues: snapshots.reduce((sum, s) => sum + s.leaks.filter(l => l.severity === 'critical').length, 0),
        memoryTrend: 'increasing'
      }
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `memory-analysis-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Report exported",
      description: "Memory analysis report has been downloaded",
    });
  }, [snapshots, metrics, toast]);

  useEffect(() => {
    if (autoRefresh) {
      const interval = setInterval(takeSnapshot, 30000); // Every 30 seconds
      return () => clearInterval(interval);
    }
  }, [autoRefresh, takeSnapshot]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good': return 'text-green-600 bg-green-100';
      case 'warning': return 'text-yellow-600 bg-yellow-100';
      case 'critical': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'bg-blue-100 text-blue-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'critical': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-red-500" />;
      case 'down': return <TrendingUp className="w-4 h-4 text-green-500 rotate-180" />;
      default: return <Activity className="w-4 h-4 text-gray-500" />;
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MemoryStick className="w-5 h-5" />
            Memory & Performance Analyzer
            <Badge variant="outline">
              {selectedSnapshot.leaks.length} issues detected
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="overview" className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="memory">Memory Analysis</TabsTrigger>
            <TabsTrigger value="leaks">Memory Leaks</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="flex-1 flex flex-col space-y-4">
            {/* Control Panel */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Activity className="w-4 h-4" />
                    Memory Analysis Controls
                  </span>
                  <div className="flex gap-2">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={autoRefresh}
                        onChange={(e) => setAutoRefresh(e.target.checked)}
                        className="rounded"
                      />
                      <span className="text-sm">Auto-refresh</span>
                    </div>
                    <Button
                      onClick={takeSnapshot}
                      disabled={isAnalyzing}
                      variant="outline"
                    >
                      <Camera className="w-4 h-4 mr-2" />
                      Take Snapshot
                    </Button>
                    <Button
                      onClick={runAnalysis}
                      disabled={isAnalyzing}
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      {isAnalyzing ? 'Analyzing...' : 'Run Analysis'}
                    </Button>
                    <Button
                      onClick={exportReport}
                      variant="outline"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export Report
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
            </Card>

            {/* Key Metrics */}
            <div className="grid grid-cols-4 gap-4">
              {metrics.map((metric) => (
                <Card key={metric.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">{metric.name}</span>
                      {getTrendIcon(metric.trend)}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold">{metric.value}</span>
                      <span className="text-sm text-gray-500">{metric.unit}</span>
                    </div>
                    <div className={`text-xs px-2 py-1 rounded mt-2 ${getStatusColor(metric.status)}`}>
                      {metric.status.toUpperCase()}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Current Memory Status */}
            <Card>
              <CardHeader>
                <CardTitle>Current Memory Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Memory Usage</span>
                      <span>{selectedSnapshot.usedMemory} MB / {selectedSnapshot.totalMemory} MB</span>
                    </div>
                    <Progress 
                      value={(selectedSnapshot.usedMemory / selectedSnapshot.totalMemory) * 100} 
                      className="h-3"
                    />
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Heap Size</span>
                      <p className="font-medium">{selectedSnapshot.heapSize} MB</p>
                    </div>
                    <div>
                      <span className="text-gray-500">GC Collections</span>
                      <p className="font-medium">{selectedSnapshot.gcCollections}</p>
                    </div>
                    <div>
                      <span className="text-gray-500">Objects</span>
                      <p className="font-medium">{selectedSnapshot.allocatedObjects.toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Issues */}
            {selectedSnapshot.leaks.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-500" />
                    Recent Memory Issues
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {selectedSnapshot.leaks.slice(0, 3).map((leak) => (
                      <div key={leak.id} className="flex items-center justify-between p-3 border rounded">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{leak.type}</span>
                            <Badge className={getSeverityColor(leak.severity)}>
                              {leak.severity}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-500">{leak.location}</p>
                          <p className="text-sm">{leak.description}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{leak.size} KB</p>
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="memory" className="flex-1 flex flex-col space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {/* Memory Timeline */}
              <Card className="col-span-2">
                <CardHeader>
                  <CardTitle>Memory Usage Timeline</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-end justify-between gap-2">
                    {snapshots.slice(0, 10).reverse().map((snapshot, index) => {
                      const height = (snapshot.usedMemory / snapshot.totalMemory) * 100;
                      return (
                        <div key={snapshot.id} className="flex flex-col items-center">
                          <div 
                            className={`w-8 bg-blue-500 rounded-t ${
                              selectedSnapshot.id === snapshot.id ? 'bg-blue-700' : ''
                            }`}
                            style={{ height: `${height * 2}px` }}
                            onClick={() => setSelectedSnapshot(snapshot)}
                          />
                          <span className="text-xs mt-1">
                            {snapshot.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Snapshot Details */}
              <Card>
                <CardHeader>
                  <CardTitle>Snapshot Details</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <span className="text-sm text-gray-500">Timestamp</span>
                      <p className="font-medium">{selectedSnapshot.timestamp.toLocaleString()}</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Total Memory</span>
                      <p className="font-medium">{selectedSnapshot.totalMemory} MB</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Used Memory</span>
                      <p className="font-medium">{selectedSnapshot.usedMemory} MB</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Free Memory</span>
                      <p className="font-medium">{selectedSnapshot.freeMemory} MB</p>
                    </div>
                    <div>
                      <span className="text-sm text-gray-500">Heap Size</span>
                      <p className="font-medium">{selectedSnapshot.heapSize} MB</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Memory Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle>Memory Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Heap</span>
                        <span>{selectedSnapshot.heapSize} MB</span>
                      </div>
                      <Progress value={60} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Stack</span>
                        <span>128 MB</span>
                      </div>
                      <Progress value={15} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Other</span>
                        <span>256 MB</span>
                      </div>
                      <Progress value={25} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="leaks" className="flex-1 flex flex-col space-y-4">
            <Card className="flex-1">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bug className="w-4 h-4" />
                  Memory Leaks ({selectedSnapshot.leaks.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-4">
                    {selectedSnapshot.leaks.length > 0 ? (
                      selectedSnapshot.leaks.map((leak) => (
                        <Card key={leak.id}>
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between mb-3">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="font-medium">{leak.type}</span>
                                  <Badge className={getSeverityColor(leak.severity)}>
                                    {leak.severity}
                                  </Badge>
                                </div>
                                <p className="text-sm text-gray-500">{leak.location}</p>
                              </div>
                              <span className="font-bold text-red-600">{leak.size} KB</span>
                            </div>
                            
                            <p className="text-sm mb-3">{leak.description}</p>
                            
                            <div className="space-y-2">
                              <div>
                                <span className="text-sm font-medium">Stack Trace:</span>
                                <div className="bg-gray-100 dark:bg-gray-800 p-2 rounded mt-1">
                                  {leak.stack.map((trace, index) => (
                                    <div key={index} className="text-xs font-mono">
                                      {trace}
                                    </div>
                                  ))}
                                </div>
                              </div>
                              
                              <div>
                                <span className="text-sm font-medium">Recommendations:</span>
                                <ul className="list-disc list-inside mt-1 space-y-1">
                                  {leak.recommendations.map((rec, index) => (
                                    <li key={index} className="text-sm text-gray-600">{rec}</li>
                                  ))}
                                </ul>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))
                    ) : (
                      <div className="text-center py-12">
                        <Bug className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-lg font-medium mb-2">No Memory Leaks Detected</h3>
                        <p className="text-gray-500">Great! No memory leaks found in the current snapshot.</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="performance" className="flex-1 flex flex-col space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Performance Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {metrics.map((metric) => (
                      <div key={metric.id} className="flex items-center justify-between">
                        <div>
                          <span className="font-medium">{metric.name}</span>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-sm text-gray-500">
                              {metric.value} {metric.unit}
                            </span>
                            {getTrendIcon(metric.trend)}
                          </div>
                        </div>
                        <Badge className={getStatusColor(metric.status)}>
                          {metric.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Optimization Suggestions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded">
                      <h4 className="font-medium text-blue-800 dark:text-blue-200">Memory Usage</h4>
                      <p className="text-sm text-blue-600 dark:text-blue-300">
                        Consider implementing object pooling for frequently created objects
                      </p>
                    </div>
                    <div className="p-3 bg-yellow-50 dark:bg-yellow-950 rounded">
                      <h4 className="font-medium text-yellow-800 dark:text-yellow-200">GC Frequency</h4>
                      <p className="text-sm text-yellow-600 dark:text-yellow-300">
                        Reduce object allocations in performance-critical paths
                      </p>
                    </div>
                    <div className="p-3 bg-green-50 dark:bg-green-950 rounded">
                      <h4 className="font-medium text-green-800 dark:text-green-200">Overall Performance</h4>
                      <p className="text-sm text-green-600 dark:text-green-300">
                        Performance metrics are within acceptable ranges
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}