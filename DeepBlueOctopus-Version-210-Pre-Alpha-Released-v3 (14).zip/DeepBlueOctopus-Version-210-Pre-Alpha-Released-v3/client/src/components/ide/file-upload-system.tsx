import React, { useState, useRef, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useIDEState } from "@/hooks/use-ide-state";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Upload, File, Image, Video, Archive, 
  FileText, X, Check, AlertCircle, Folder,
  Download, Trash2
} from "lucide-react";

interface FileUploadSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface UploadFile {
  id: string;
  file: File;
  progress: number;
  status: 'pending' | 'uploading' | 'success' | 'error';
  error?: string;
}

export default function FileUploadSystem({ isOpen, onClose }: FileUploadSystemProps) {
  const [uploadFiles, setUploadFiles] = useState<UploadFile[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { currentProject } = useIDEState();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const uploadMutation = useMutation({
    mutationFn: async ({ fileData, fileId }: { fileData: any; fileId: string }) => {
      // Update progress
      setUploadFiles(prev => prev.map(f => 
        f.id === fileId ? { ...f, status: 'uploading', progress: 50 } : f
      ));

      const response = await apiRequest("POST", "/api/files", fileData);
      
      // Complete progress
      setUploadFiles(prev => prev.map(f => 
        f.id === fileId ? { ...f, status: 'success', progress: 100 } : f
      ));

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
      toast({
        title: "Upload successful",
        description: "Files uploaded successfully",
      });
    },
    onError: (error: any, variables) => {
      setUploadFiles(prev => prev.map(f => 
        f.id === variables.fileId ? { 
          ...f, 
          status: 'error', 
          error: error.message || 'Upload failed' 
        } : f
      ));
      toast({
        title: "Upload failed",
        description: "Failed to upload some files",
        variant: "destructive",
      });
    },
  });

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      handleFiles(files);
    }
  }, []);

  const handleFiles = useCallback((files: File[]) => {
    const newUploadFiles: UploadFile[] = files.map(file => ({
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      file,
      progress: 0,
      status: 'pending'
    }));

    setUploadFiles(prev => [...prev, ...newUploadFiles]);

    // Process each file
    newUploadFiles.forEach(uploadFile => {
      processFile(uploadFile);
    });
  }, [currentProject]);

  const processFile = async (uploadFile: UploadFile) => {
    try {
      const { file, id } = uploadFile;
      
      // Read file content
      const content = await readFileContent(file);
      
      // Determine language from file extension
      const extension = file.name.split('.').pop()?.toLowerCase();
      const languageMap: { [key: string]: string } = {
        js: "javascript",
        ts: "typescript",
        jsx: "javascript",
        tsx: "typescript",
        py: "python",
        html: "html",
        css: "css",
        scss: "scss",
        json: "json",
        md: "markdown",
        txt: "plaintext",
        xml: "xml",
        yaml: "yaml",
        yml: "yaml"
      };

      const fileData = {
        name: file.name,
        path: `/${file.name}`,
        content,
        language: languageMap[extension || ""] || "plaintext",
        projectId: currentProject?.id || 1,
        isDirectory: false,
        parentId: null,
        size: file.size,
        encoding: "utf-8"
      };

      uploadMutation.mutate({ fileData, fileId: id });

    } catch (error) {
      setUploadFiles(prev => prev.map(f => 
        f.id === uploadFile.id ? { 
          ...f, 
          status: 'error', 
          error: 'Failed to read file content' 
        } : f
      ));
    }
  };

  const readFileContent = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsText(file);
    });
  };

  const removeFile = useCallback((fileId: string) => {
    setUploadFiles(prev => prev.filter(f => f.id !== fileId));
  }, []);

  const clearAll = useCallback(() => {
    setUploadFiles([]);
  }, []);

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    
    if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(extension || '')) {
      return <Image className="w-4 h-4 text-blue-500" />;
    }
    if (['mp4', 'avi', 'mov', 'wmv', 'webm'].includes(extension || '')) {
      return <Video className="w-4 h-4 text-purple-500" />;
    }
    if (['zip', 'rar', '7z', 'tar', 'gz'].includes(extension || '')) {
      return <Archive className="w-4 h-4 text-orange-500" />;
    }
    return <FileText className="w-4 h-4 text-gray-500" />;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <Check className="w-4 h-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      case 'uploading':
        return <Upload className="w-4 h-4 text-blue-500 animate-pulse" />;
      default:
        return <File className="w-4 h-4 text-gray-500" />;
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            File Upload System
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex flex-col space-y-4">
          {/* Upload Area */}
          <Card
            className={`border-2 border-dashed transition-colors ${
              isDragOver ? 'border-blue-500 bg-blue-50 dark:bg-blue-950' : 'border-gray-300'
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <CardContent className="flex flex-col items-center justify-center py-8">
              <Upload className="w-12 h-12 text-gray-400 mb-4" />
              <p className="text-lg font-medium mb-2">Drop files here to upload</p>
              <p className="text-sm text-gray-500 mb-4">or click to select files</p>
              <Button
                onClick={() => fileInputRef.current?.click()}
                variant="outline"
              >
                <Folder className="w-4 h-4 mr-2" />
                Browse Files
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                onChange={handleFileSelect}
                className="hidden"
                accept=".js,.ts,.jsx,.tsx,.py,.html,.css,.scss,.json,.md,.txt,.xml,.yaml,.yml"
              />
            </CardContent>
          </Card>

          {/* Upload Queue */}
          {uploadFiles.length > 0 && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">Upload Queue ({uploadFiles.length})</CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={clearAll}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear All
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-64">
                  <div className="space-y-3">
                    {uploadFiles.map((uploadFile) => (
                      <div
                        key={uploadFile.id}
                        className="flex items-center gap-3 p-3 border rounded-lg"
                      >
                        <div className="flex items-center gap-2 min-w-0 flex-1">
                          {getFileIcon(uploadFile.file.name)}
                          <div className="min-w-0 flex-1">
                            <p className="font-medium truncate">{uploadFile.file.name}</p>
                            <p className="text-sm text-gray-500">
                              {formatFileSize(uploadFile.file.size)}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {getStatusIcon(uploadFile.status)}
                          
                          {uploadFile.status === 'uploading' && (
                            <div className="w-24">
                              <Progress value={uploadFile.progress} className="h-2" />
                            </div>
                          )}

                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeFile(uploadFile.id)}
                            disabled={uploadFile.status === 'uploading'}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          )}

          {/* Upload Statistics */}
          <div className="grid grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-gray-500">Total Files</p>
                <p className="text-2xl font-bold">{uploadFiles.length}</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-gray-500">Successful</p>
                <p className="text-2xl font-bold text-green-600">
                  {uploadFiles.filter(f => f.status === 'success').length}
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-sm text-gray-500">Failed</p>
                <p className="text-2xl font-bold text-red-600">
                  {uploadFiles.filter(f => f.status === 'error').length}
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}