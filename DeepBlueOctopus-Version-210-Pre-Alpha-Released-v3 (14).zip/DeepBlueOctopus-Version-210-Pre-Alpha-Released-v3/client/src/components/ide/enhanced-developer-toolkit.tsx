import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { 
  Code, Terminal, Bug, Wrench, Database, 
  Activity, BarChart3, Zap, Settings, 
  AlertTriangle, CheckCircle, Clock, 
  HardDrive, Cpu, Wifi, Shield,
  FileText, Search, PlayCircle, StopCircle
} from "lucide-react";

interface EnhancedDeveloperToolkitProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SystemMetric {
  name: string;
  value: number;
  unit: string;
  status: 'good' | 'warning' | 'critical';
  history: number[];
}

interface LogEntry {
  id: string;
  timestamp: Date;
  level: 'info' | 'warning' | 'error' | 'debug';
  message: string;
  source: string;
  details?: any;
}

interface PerformanceTest {
  id: string;
  name: string;
  type: 'speed' | 'memory' | 'network' | 'database';
  status: 'idle' | 'running' | 'completed' | 'failed';
  duration: number;
  result?: any;
}

const SYSTEM_METRICS: SystemMetric[] = [
  {
    name: 'CPU Usage',
    value: 45,
    unit: '%',
    status: 'good',
    history: [30, 35, 40, 45, 42, 38, 45]
  },
  {
    name: 'Memory Usage',
    value: 68,
    unit: '%',
    status: 'warning',
    history: [55, 60, 65, 68, 70, 67, 68]
  },
  {
    name: 'Disk I/O',
    value: 25,
    unit: 'MB/s',
    status: 'good',
    history: [20, 22, 25, 23, 28, 24, 25]
  },
  {
    name: 'Network',
    value: 89,
    unit: 'Mbps',
    status: 'good',
    history: [85, 87, 89, 91, 88, 86, 89]
  }
];

const SAMPLE_LOGS: LogEntry[] = [
  {
    id: '1',
    timestamp: new Date(),
    level: 'info',
    message: 'Application started successfully',
    source: 'main.tsx'
  },
  {
    id: '2',
    timestamp: new Date(Date.now() - 5000),
    level: 'warning',
    message: 'High memory usage detected',
    source: 'memory-monitor',
    details: { usage: '68%', threshold: '70%' }
  },
  {
    id: '3',
    timestamp: new Date(Date.now() - 10000),
    level: 'error',
    message: 'Failed to connect to database',
    source: 'db-connection',
    details: { host: 'localhost', port: 5432 }
  }
];

const PERFORMANCE_TESTS: PerformanceTest[] = [
  {
    id: 'speed-1',
    name: 'Component Render Speed',
    type: 'speed',
    status: 'completed',
    duration: 125,
    result: { renderTime: '12.5ms', components: 45 }
  },
  {
    id: 'memory-1',
    name: 'Memory Leak Detection',
    type: 'memory',
    status: 'running',
    duration: 0
  },
  {
    id: 'network-1',
    name: 'API Response Time',
    type: 'network',
    status: 'idle',
    duration: 0
  }
];

export default function EnhancedDeveloperToolkit({ isOpen, onClose }: EnhancedDeveloperToolkitProps) {
  const [activeTab, setActiveTab] = useState('monitor');
  const [metrics, setMetrics] = useState<SystemMetric[]>(SYSTEM_METRICS);
  const [logs, setLogs] = useState<LogEntry[]>(SAMPLE_LOGS);
  const [tests, setTests] = useState<PerformanceTest[]>(PERFORMANCE_TESTS);
  const [searchQuery, setSearchQuery] = useState("");
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [debugMode, setDebugMode] = useState(false);

  const { toast } = useToast();

  useEffect(() => {
    if (!isOpen || !autoRefresh) return;

    const interval = setInterval(() => {
      setMetrics(prev => prev.map(metric => ({
        ...metric,
        value: metric.value + (Math.random() - 0.5) * 10,
        history: [...metric.history.slice(1), metric.value]
      })));
    }, 2000);

    return () => clearInterval(interval);
  }, [isOpen, autoRefresh]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good': return 'text-green-500';
      case 'warning': return 'text-yellow-500';
      case 'critical': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'good': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'critical': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default: return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'error': return 'text-red-500';
      case 'warning': return 'text-yellow-500';
      case 'info': return 'text-blue-500';
      case 'debug': return 'text-gray-500';
      default: return 'text-gray-500';
    }
  };

  const runPerformanceTest = (testId: string) => {
    setTests(prev => prev.map(test => 
      test.id === testId 
        ? { ...test, status: 'running' as const, duration: 0 }
        : test
    ));

    const interval = setInterval(() => {
      setTests(prev => prev.map(test => {
        if (test.id === testId && test.status === 'running') {
          const newDuration = test.duration + 100;
          if (newDuration >= 3000) {
            clearInterval(interval);
            return {
              ...test,
              status: 'completed' as const,
              duration: newDuration,
              result: { performance: 'excellent', score: 95 }
            };
          }
          return { ...test, duration: newDuration };
        }
        return test;
      }));
    }, 100);
  };

  const clearLogs = () => {
    setLogs([]);
    toast({
      title: "Logs Cleared",
      description: "All system logs have been cleared",
    });
  };

  const exportLogs = () => {
    const logData = logs.map(log => ({
      timestamp: log.timestamp.toISOString(),
      level: log.level,
      message: log.message,
      source: log.source,
      details: log.details
    }));
    
    const blob = new Blob([JSON.stringify(logData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `system-logs-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Logs Exported",
      description: "System logs exported successfully",
    });
  };

  const filteredLogs = logs.filter(log => 
    log.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
    log.source.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[85vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wrench className="w-5 h-5" />
            Enhanced Developer Toolkit
            <Badge variant="outline" className="ml-2">
              Real-time Monitoring
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex flex-col gap-4 overflow-hidden">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Switch
                  checked={autoRefresh}
                  onCheckedChange={setAutoRefresh}
                />
                <span className="text-sm">Auto Refresh</span>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={debugMode}
                  onCheckedChange={setDebugMode}
                />
                <span className="text-sm">Debug Mode</span>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Activity className="w-4 h-4" />
              <span>Live Monitoring Active</span>
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="monitor">System Monitor</TabsTrigger>
              <TabsTrigger value="logs">Error Logs</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="database">Database Tools</TabsTrigger>
              <TabsTrigger value="security">Security Audit</TabsTrigger>
            </TabsList>
            
            <TabsContent value="monitor" className="flex-1 space-y-4">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {metrics.map((metric) => (
                  <Card key={metric.name}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          {metric.name === 'CPU Usage' && <Cpu className="w-4 h-4" />}
                          {metric.name === 'Memory Usage' && <HardDrive className="w-4 h-4" />}
                          {metric.name === 'Disk I/O' && <Database className="w-4 h-4" />}
                          {metric.name === 'Network' && <Wifi className="w-4 h-4" />}
                          <span className="text-sm font-medium">{metric.name}</span>
                        </div>
                        {getStatusIcon(metric.status)}
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-baseline gap-1">
                          <span className={`text-2xl font-bold ${getStatusColor(metric.status)}`}>
                            {Math.round(metric.value)}
                          </span>
                          <span className="text-sm text-gray-600">{metric.unit}</span>
                        </div>
                        <Progress 
                          value={metric.value} 
                          className="w-full h-2" 
                        />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">System Overview</CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Runtime Information</h4>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span>Uptime</span>
                        <Badge variant="outline">2h 15m</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Node.js Version</span>
                        <Badge variant="outline">v20.10.0</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Memory Heap</span>
                        <Badge variant="outline">45.2 MB</Badge>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Application Status</h4>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span>Active Components</span>
                        <Badge className="bg-green-100 text-green-800">147</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>API Endpoints</span>
                        <Badge className="bg-blue-100 text-blue-800">23</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Database Connections</span>
                        <Badge className="bg-purple-100 text-purple-800">3</Badge>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Quick Actions</h4>
                    <div className="space-y-2">
                      <Button size="sm" variant="outline" className="w-full">
                        <Zap className="w-3 h-3 mr-2" />
                        Force GC
                      </Button>
                      <Button size="sm" variant="outline" className="w-full">
                        <Activity className="w-3 h-3 mr-2" />
                        Memory Snapshot
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="logs" className="flex-1 space-y-4">
              <div className="flex items-center gap-3">
                <Input
                  placeholder="Search logs..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1"
                />
                <Button onClick={clearLogs} variant="outline">
                  Clear Logs
                </Button>
                <Button onClick={exportLogs}>
                  Export
                </Button>
              </div>

              <ScrollArea className="flex-1">
                <div className="space-y-2">
                  {filteredLogs.map((log) => (
                    <Card key={log.id} className="hover:shadow-sm transition-shadow">
                      <CardContent className="p-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge 
                                variant="outline" 
                                className={`text-xs ${getLevelColor(log.level)}`}
                              >
                                {log.level.toUpperCase()}
                              </Badge>
                              <span className="text-xs text-gray-600">
                                {log.timestamp.toLocaleTimeString()}
                              </span>
                              <Badge variant="secondary" className="text-xs">
                                {log.source}
                              </Badge>
                            </div>
                            <p className="text-sm">{log.message}</p>
                            {log.details && debugMode && (
                              <pre className="text-xs bg-gray-100 p-2 rounded mt-2 overflow-x-auto">
                                {JSON.stringify(log.details, null, 2)}
                              </pre>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="performance" className="flex-1 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Performance Tests</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {tests.map((test) => (
                      <div key={test.id} className="flex items-center justify-between p-3 border rounded">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                            {test.type === 'speed' && <Zap className="w-4 h-4 text-blue-600" />}
                            {test.type === 'memory' && <HardDrive className="w-4 h-4 text-blue-600" />}
                            {test.type === 'network' && <Wifi className="w-4 h-4 text-blue-600" />}
                            {test.type === 'database' && <Database className="w-4 h-4 text-blue-600" />}
                          </div>
                          <div>
                            <h4 className="text-sm font-medium">{test.name}</h4>
                            <div className="flex items-center gap-2">
                              <Badge 
                                variant={test.status === 'completed' ? 'default' : 'outline'}
                                className="text-xs"
                              >
                                {test.status}
                              </Badge>
                              {test.status === 'running' && (
                                <span className="text-xs text-gray-600">
                                  {(test.duration / 1000).toFixed(1)}s
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {test.status === 'idle' && (
                            <Button 
                              size="sm" 
                              onClick={() => runPerformanceTest(test.id)}
                            >
                              <PlayCircle className="w-4 h-4" />
                            </Button>
                          )}
                          {test.status === 'running' && (
                            <Button size="sm" variant="outline" disabled>
                              <StopCircle className="w-4 h-4" />
                            </Button>
                          )}
                          {test.status === 'completed' && test.result && (
                            <Badge className="bg-green-100 text-green-800">
                              Score: {test.result.score || 'Complete'}
                            </Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Performance Metrics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm">Bundle Size</span>
                        <Badge variant="outline">2.4 MB</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">First Paint</span>
                        <Badge className="bg-green-100 text-green-800">0.8s</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Time to Interactive</span>
                        <Badge className="bg-yellow-100 text-yellow-800">1.2s</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">Lighthouse Score</span>
                        <Badge className="bg-green-100 text-green-800">94/100</Badge>
                      </div>
                    </div>
                    
                    <Button className="w-full mt-4">
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Run Full Analysis
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="database" className="flex-1 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Database Status</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Connection Status</span>
                      <Badge className="bg-green-100 text-green-800">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Connected
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Active Connections</span>
                      <Badge variant="outline">3/10</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Query Performance</span>
                      <Badge className="bg-green-100 text-green-800">Excellent</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Database Size</span>
                      <Badge variant="outline">15.2 MB</Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Quick Tools</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button variant="outline" className="w-full">
                      <Database className="w-4 h-4 mr-2" />
                      Query Analyzer
                    </Button>
                    <Button variant="outline" className="w-full">
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Performance Monitor
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Shield className="w-4 h-4 mr-2" />
                      Backup Database
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Settings className="w-4 h-4 mr-2" />
                      Schema Migration
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="security" className="flex-1 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Security Status</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Security Score</span>
                      <Badge className="bg-green-100 text-green-800">A+</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Vulnerabilities</span>
                      <Badge className="bg-green-100 text-green-800">0 Critical</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Dependencies</span>
                      <Badge className="bg-yellow-100 text-yellow-800">2 Updates</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">SSL Certificate</span>
                      <Badge className="bg-green-100 text-green-800">Valid</Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Security Tools</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button variant="outline" className="w-full">
                      <Shield className="w-4 h-4 mr-2" />
                      Vulnerability Scan
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Search className="w-4 h-4 mr-2" />
                      Dependency Audit
                    </Button>
                    <Button variant="outline" className="w-full">
                      <FileText className="w-4 h-4 mr-2" />
                      Security Report
                    </Button>
                    <Button variant="outline" className="w-full">
                      <Settings className="w-4 h-4 mr-2" />
                      Security Settings
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="flex items-center justify-between pt-4 border-t">
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <Activity className="w-4 h-4" />
              <span>Real-time Monitoring</span>
            </div>
            <div className="flex items-center gap-1">
              <Shield className="w-4 h-4" />
              <span>Security Active</span>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            <Button>
              <Settings className="w-4 h-4 mr-2" />
              Advanced Settings
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}