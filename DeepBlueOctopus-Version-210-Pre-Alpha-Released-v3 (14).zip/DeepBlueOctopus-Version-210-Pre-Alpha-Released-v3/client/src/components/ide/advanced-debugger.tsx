import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { 
  Bug, 
  Play, 
  Pause, 
  Square, 
  SkipForward, 
  StepForward, 
  ArrowDownRight, 
  ArrowUpLeft,
  CircleDot,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle,
  Clock,
  Layers,
  Terminal,
  Trash2
} from 'lucide-react';
import { TooltipWrapper } from '@/components/ui/tooltip-system';
import { SoundButton } from '@/components/ui/sound-system';

interface Breakpoint {
  id: string;
  file: string;
  line: number;
  column?: number;
  condition?: string;
  hitCount: number;
  enabled: boolean;
  isConditional: boolean;
}

interface Variable {
  name: string;
  value: any;
  type: string;
  scope: 'local' | 'global' | 'closure';
  isComplex: boolean;
  children?: Variable[];
  memoryAddress?: string;
}

interface CallStackFrame {
  id: string;
  function: string;
  file: string;
  line: number;
  column: number;
  variables: Variable[];
}

interface Thread {
  id: string;
  name: string;
  status: 'running' | 'paused' | 'stopped' | 'waiting';
  currentFrame?: CallStackFrame;
  callStack: CallStackFrame[];
}

interface WatchExpression {
  id: string;
  expression: string;
  value: any;
  error?: string;
  type: string;
}

interface DebugSession {
  id: string;
  name: string;
  status: 'running' | 'paused' | 'stopped';
  threads: Thread[];
  mainThread: string;
  startTime: Date;
  language: string;
}

interface AdvancedDebuggerProps {
  isOpen: boolean;
  onClose: () => void;
  currentFile?: string;
  currentCode?: string;
  language?: string;
}

export default function AdvancedDebugger({ isOpen, onClose, currentFile, currentCode, language }: AdvancedDebuggerProps) {
  // All hooks must be called in the same order on every render
  const [session, setSession] = useState<DebugSession | null>(null);
  const [breakpoints, setBreakpoints] = useState<Breakpoint[]>([]);
  const [watchExpressions, setWatchExpressions] = useState<WatchExpression[]>([]);
  const [newWatchExpression, setNewWatchExpression] = useState('');
  const [selectedThread, setSelectedThread] = useState<string>('');
  const [selectedFrame, setSelectedFrame] = useState<string>('');
  const [isDebugging, setIsDebugging] = useState(false);
  const [initialized, setInitialized] = useState(false);
  const logRef = useRef<HTMLDivElement>(null);

  // Mock data for demonstration - ensure hooks are always called
  useEffect(() => {
    if (isOpen && !initialized) {
      initializeMockSession();
      setInitialized(true);
    }
  }, [isOpen, initialized]);

  const initializeMockSession = () => {
    const mockSession: DebugSession = {
      id: 'session-1',
      name: `Debug Session - ${currentFile || 'main.js'}`,
      status: 'stopped',
      mainThread: 'thread-main',
      startTime: new Date(),
      language: language || 'javascript',
      threads: [
        {
          id: 'thread-main',
          name: 'Main Thread',
          status: 'stopped',
          callStack: [
            {
              id: 'frame-1',
              function: 'processData',
              file: 'main.js',
              line: 42,
              column: 15,
              variables: [
                {
                  name: 'userData',
                  value: { id: 123, name: 'John Doe', email: 'john@example.com' },
                  type: 'object',
                  scope: 'local',
                  isComplex: true,
                  children: [
                    { name: 'id', value: 123, type: 'number', scope: 'local', isComplex: false },
                    { name: 'name', value: 'John Doe', type: 'string', scope: 'local', isComplex: false },
                    { name: 'email', value: 'john@example.com', type: 'string', scope: 'local', isComplex: false }
                  ]
                },
                {
                  name: 'result',
                  value: null,
                  type: 'null',
                  scope: 'local',
                  isComplex: false
                },
                {
                  name: 'counter',
                  value: 5,
                  type: 'number',
                  scope: 'local',
                  isComplex: false
                }
              ]
            },
            {
              id: 'frame-2',
              function: 'handleRequest',
              file: 'api.js',
              line: 28,
              column: 8,
              variables: [
                {
                  name: 'request',
                  value: { method: 'POST', url: '/api/users' },
                  type: 'object',
                  scope: 'local',
                  isComplex: true
                }
              ]
            }
          ]
        },
        {
          id: 'thread-worker',
          name: 'Worker Thread #1',
          status: 'waiting',
          callStack: []
        }
      ]
    };

    setSession(mockSession);
    setSelectedThread('thread-main');
    setSelectedFrame('frame-1');

    // Add mock breakpoints
    setBreakpoints([
      {
        id: 'bp-1',
        file: 'main.js',
        line: 42,
        enabled: true,
        hitCount: 3,
        isConditional: false
      },
      {
        id: 'bp-2',
        file: 'api.js',
        line: 15,
        enabled: true,
        hitCount: 0,
        condition: 'userId > 100',
        isConditional: true
      }
    ]);

    // Add mock watch expressions
    setWatchExpressions([
      {
        id: 'watch-1',
        expression: 'userData.id',
        value: 123,
        type: 'number'
      },
      {
        id: 'watch-2', 
        expression: 'counter * 2',
        value: 10,
        type: 'number'
      }
    ]);
  };

  const startDebugging = () => {
    setIsDebugging(true);
    if (session) {
      setSession({
        ...session,
        status: 'running',
        threads: session.threads.map(thread => ({
          ...thread,
          status: thread.id === session.mainThread ? 'running' : thread.status
        }))
      });
    }
  };

  const pauseDebugging = () => {
    if (session) {
      setSession({
        ...session,
        status: 'paused',
        threads: session.threads.map(thread => ({
          ...thread,
          status: thread.id === session.mainThread ? 'paused' : thread.status
        }))
      });
    }
  };

  const stopDebugging = () => {
    setIsDebugging(false);
    if (session) {
      setSession({
        ...session,
        status: 'stopped',
        threads: session.threads.map(thread => ({
          ...thread,
          status: 'stopped'
        }))
      });
    }
  };

  const stepOver = () => {
    // Simulate stepping over
    console.log('Step Over');
  };

  const stepInto = () => {
    // Simulate stepping into
    console.log('Step Into');
  };

  const stepOut = () => {
    // Simulate stepping out
    console.log('Step Out');
  };

  const toggleBreakpoint = (id: string) => {
    setBreakpoints(prev => 
      prev.map(bp => 
        bp.id === id ? { ...bp, enabled: !bp.enabled } : bp
      )
    );
  };

  const removeBreakpoint = (id: string) => {
    setBreakpoints(prev => prev.filter(bp => bp.id !== id));
  };

  const addWatchExpression = () => {
    if (!newWatchExpression.trim()) return;

    const newWatch: WatchExpression = {
      id: `watch-${Date.now()}`,
      expression: newWatchExpression,
      value: 'Evaluating...',
      type: 'pending'
    };

    setWatchExpressions(prev => [...prev, newWatch]);
    setNewWatchExpression('');

    // Simulate evaluation
    setTimeout(() => {
      setWatchExpressions(prev => 
        prev.map(watch => 
          watch.id === newWatch.id 
            ? { ...watch, value: Math.random() > 0.5 ? 42 : 'undefined', type: 'number' }
            : watch
        )
      );
    }, 1000);
  };

  const removeWatchExpression = (id: string) => {
    setWatchExpressions(prev => prev.filter(watch => watch.id !== id));
  };

  const getCurrentThread = () => {
    return session?.threads.find(thread => thread.id === selectedThread);
  };

  const getCurrentFrame = () => {
    const thread = getCurrentThread();
    return thread?.callStack.find(frame => frame.id === selectedFrame);
  };

  const renderVariable = (variable: Variable, depth = 0) => {
    const [isExpanded, setIsExpanded] = useState(false);

    return (
      <div key={variable.name} className="text-sm" style={{ marginLeft: depth * 16 }}>
        <div className="flex items-center gap-2 py-1 hover:bg-[var(--ide-hover)] px-2 rounded">
          {variable.isComplex && (
            <Button
              variant="ghost"
              size="sm"
              className="h-4 w-4 p-0"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              {isExpanded ? '▼' : '▶'}
            </Button>
          )}
          {!variable.isComplex && <div className="w-4" />}
          
          <span className="font-medium text-[var(--ide-text)]">{variable.name}:</span>
          <Badge variant="outline" className="text-xs">{variable.type}</Badge>
          <span className="text-[var(--ide-text-secondary)]">
            {variable.isComplex ? 
              `{${variable.children?.length || 0} properties}` : 
              JSON.stringify(variable.value)
            }
          </span>
          <Badge variant="secondary" className="text-xs">{variable.scope}</Badge>
        </div>
        
        {variable.isComplex && isExpanded && variable.children && (
          <div className="ml-4">
            {variable.children.map(child => renderVariable(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Bug className="h-5 w-5 text-[var(--ide-accent)]" />
            Advanced Debugger
            {session && (
              <Badge variant={session.status === 'running' ? 'default' : 'secondary'}>
                {session.status}
              </Badge>
            )}
          </DialogTitle>
          <DialogDescription>
            Professional debugging tools with breakpoints, variable inspection, and call stack analysis
          </DialogDescription>
        </DialogHeader>

        {/* Debug Controls */}
        <div className="flex items-center gap-2 p-2 border rounded-lg">
          <TooltipWrapper title="Start Debugging" content="Begin debugging the current session" type="feature">
            <SoundButton
              className="border border-gray-300 bg-white hover:bg-gray-50 px-3 py-1 text-sm"
              onClick={startDebugging}
              disabled={isDebugging}
            >
              <Play className="h-4 w-4" />
            </SoundButton>
          </TooltipWrapper>

          <TooltipWrapper title="Pause Debugging" content="Pause the currently running debug session" type="feature">
            <SoundButton
              className="border border-gray-300 bg-white hover:bg-gray-50 px-3 py-1 text-sm"
              onClick={pauseDebugging}
              disabled={!isDebugging || session?.status !== 'running'}
            >
              <Pause className="h-4 w-4" />
            </SoundButton>
          </TooltipWrapper>

          <TooltipWrapper title="Stop Debugging" content="Stop the debug session completely" type="feature">
            <SoundButton
              className="border border-gray-300 bg-white hover:bg-gray-50 px-3 py-1 text-sm"
              onClick={stopDebugging}
              disabled={!isDebugging}
            >
              <Square className="h-4 w-4" />
            </SoundButton>
          </TooltipWrapper>

          <Separator orientation="vertical" className="h-6" />

          <TooltipWrapper title="Step Over (F10)" content="Execute the next line of code" type="feature">
            <SoundButton
              className="border border-gray-300 bg-white hover:bg-gray-50 px-3 py-1 text-sm"
              onClick={stepOver}
              disabled={session?.status !== 'paused'}
            >
              <SkipForward className="h-4 w-4" />
            </SoundButton>
          </TooltipWrapper>

          <TooltipWrapper title="Step Into (F11)" content="Step into function calls" type="feature">
            <SoundButton
              className="border border-gray-300 bg-white hover:bg-gray-50 px-3 py-1 text-sm"
              onClick={stepInto}
              disabled={session?.status !== 'paused'}
            >
              <ArrowDownRight className="h-4 w-4" />
            </SoundButton>
          </TooltipWrapper>

          <TooltipWrapper title="Step Out (Shift+F11)" content="Step out of current function" type="feature">
            <SoundButton
              className="border border-gray-300 bg-white hover:bg-gray-50 px-3 py-1 text-sm"
              onClick={stepOut}
              disabled={session?.status !== 'paused'}
            >
              <ArrowUpLeft className="h-4 w-4" />
            </SoundButton>
          </TooltipWrapper>
        </div>

        <div className="flex-1 grid grid-cols-4 gap-4">
          {/* Left Panel - Threads & Call Stack */}
          <div className="space-y-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Layers className="h-4 w-4" />
                  Threads
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {session?.threads.map(thread => (
                  <div
                    key={thread.id}
                    className={`p-2 rounded cursor-pointer ${
                      selectedThread === thread.id ? 'bg-[var(--ide-accent)] text-white' : 'hover:bg-[var(--ide-hover)]'
                    }`}
                    onClick={() => setSelectedThread(thread.id)}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">{thread.name}</span>
                      <Badge variant={thread.status === 'running' ? 'default' : 'secondary'} className="text-xs">
                        {thread.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Call Stack</CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-48">
                  {getCurrentThread()?.callStack.map((frame, index) => (
                    <div
                      key={frame.id}
                      className={`p-2 rounded cursor-pointer mb-1 ${
                        selectedFrame === frame.id ? 'bg-[var(--ide-accent)] text-white' : 'hover:bg-[var(--ide-hover)]'
                      }`}
                      onClick={() => setSelectedFrame(frame.id)}
                    >
                      <div className="text-sm font-medium">{frame.function}</div>
                      <div className="text-xs opacity-75">
                        {frame.file}:{frame.line}:{frame.column}
                      </div>
                    </div>
                  ))}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Middle Panel - Variables & Watch */}
          <div className="col-span-2 space-y-4">
            <Tabs defaultValue="variables" className="h-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="variables">Variables</TabsTrigger>
                <TabsTrigger value="watch">Watch</TabsTrigger>
                <TabsTrigger value="console">Console</TabsTrigger>
              </TabsList>

              <TabsContent value="variables" className="flex-1">
                <Card className="h-96">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Eye className="h-4 w-4" />
                      Variables
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-80">
                      {getCurrentFrame()?.variables.map(variable => renderVariable(variable))}
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="watch" className="flex-1">
                <Card className="h-96">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Eye className="h-4 w-4" />
                      Watch Expressions
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add watch expression..."
                        value={newWatchExpression}
                        onChange={(e) => setNewWatchExpression(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && addWatchExpression()}
                        className="text-sm"
                      />
                      <Button size="sm" onClick={addWatchExpression}>Add</Button>
                    </div>
                    
                    <ScrollArea className="h-64">
                      {watchExpressions.map(watch => (
                        <div key={watch.id} className="flex items-center justify-between p-2 hover:bg-[var(--ide-hover)] rounded">
                          <div className="flex-1">
                            <div className="text-sm font-medium">{watch.expression}</div>
                            <div className="text-xs text-[var(--ide-text-secondary)]">
                              {JSON.stringify(watch.value)} <Badge variant="outline" className="text-xs ml-1">{watch.type}</Badge>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeWatchExpression(watch.id)}
                            className="h-6 w-6 p-0"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      ))}
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="console" className="flex-1">
                <Card className="h-96">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Terminal className="h-4 w-4" />
                      Debug Console
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-64 font-mono text-sm">
                      <div className="space-y-1">
                        <div className="text-[var(--ide-text-secondary)]">[14:32:15] Debug session started</div>
                        <div className="text-yellow-500">[14:32:16] Breakpoint hit at main.js:42</div>
                        <div className="text-[var(--ide-text-secondary)]">[14:32:17] userData = {"{"}id: 123, name: "John Doe"{"}"}</div>
                        <div className="text-blue-500">[14:32:18] Evaluating watch expressions...</div>
                        <div className="text-green-500">[14:32:19] Watch: userData.id = 123</div>
                      </div>
                    </ScrollArea>
                    <div className="mt-3 flex gap-2">
                      <Input placeholder="Evaluate expression..." className="text-sm" />
                      <Button size="sm">Eval</Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Right Panel - Breakpoints */}
          <div>
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <CircleDot className="h-4 w-4" />
                  Breakpoints
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-80">
                  {breakpoints.map(breakpoint => (
                    <div key={breakpoint.id} className="p-2 hover:bg-[var(--ide-hover)] rounded mb-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0"
                            onClick={() => toggleBreakpoint(breakpoint.id)}
                          >
                            {breakpoint.enabled ? (
                              <CircleDot className="h-4 w-4 text-red-500" />
                            ) : (
                              <CircleDot className="h-4 w-4 text-gray-400" />
                            )}
                          </Button>
                          <div>
                            <div className="text-sm font-medium">{breakpoint.file}:{breakpoint.line}</div>
                            {breakpoint.condition && (
                              <div className="text-xs text-[var(--ide-text-secondary)]">
                                Condition: {breakpoint.condition}
                              </div>
                            )}
                            <div className="text-xs text-[var(--ide-text-secondary)]">
                              Hits: {breakpoint.hitCount}
                            </div>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeBreakpoint(breakpoint.id)}
                          className="h-6 w-6 p-0"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}