import React, { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Bot, 
  Code2, 
  FileText, 
  Bug, 
  RefreshCw, 
  Lightbulb, 
  Zap,
  Send,
  Copy,
  ThumbsUp,
  ThumbsDown,
  Sparkles
} from 'lucide-react';
import { TooltipWrapper } from '@/components/ui/tooltip-system';
import { SoundButton } from '@/components/ui/sound-system';

export enum AIAgentType {
  CODE_ASSISTANT = 'code-assistant',
  REFACTOR_EXPERT = 'refactor-expert', 
  BUG_HUNTER = 'bug-hunter',
  DOCUMENTATION_WRITER = 'documentation-writer',
  ARCHITECTURE_ADVISOR = 'architecture-advisor',
  PERFORMANCE_OPTIMIZER = 'performance-optimizer',
  TEST_GENERATOR = 'test-generator'
}

interface AIMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  agentType: AIAgentType;
  timestamp: Date;
  codeSnippet?: string;
  confidence?: number;
}

interface AIAgentProfile {
  type: AIAgentType;
  name: string;
  description: string;
  icon: React.ReactNode;
  specialties: string[];
  color: string;
}

interface AIAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  currentCode?: string;
  selectedText?: string;
  language?: string;
}

const AI_AGENTS: AIAgentProfile[] = [
  {
    type: AIAgentType.CODE_ASSISTANT,
    name: "CodeCraft AI",
    description: "General coding assistance and code completion",
    icon: <Code2 className="h-4 w-4" />,
    specialties: ["Code completion", "Syntax help", "Quick fixes", "Explanations"],
    color: "bg-blue-500"
  },
  {
    type: AIAgentType.REFACTOR_EXPERT,
    name: "RefactorPro",
    description: "Smart code refactoring and optimization",
    icon: <RefreshCw className="h-4 w-4" />,
    specialties: ["Code cleanup", "Pattern improvements", "Structure optimization"],
    color: "bg-green-500"
  },
  {
    type: AIAgentType.BUG_HUNTER,
    name: "BugSeeker",
    description: "Advanced bug detection and debugging assistance", 
    icon: <Bug className="h-4 w-4" />,
    specialties: ["Bug prediction", "Error analysis", "Debug strategies"],
    color: "bg-red-500"
  },
  {
    type: AIAgentType.DOCUMENTATION_WRITER,
    name: "DocMaster",
    description: "Automatic documentation and comment generation",
    icon: <FileText className="h-4 w-4" />,
    specialties: ["Docstrings", "API docs", "Comments", "README files"],
    color: "bg-purple-500"
  },
  {
    type: AIAgentType.ARCHITECTURE_ADVISOR,
    name: "ArchitectAI",
    description: "System design and architecture recommendations",
    icon: <Lightbulb className="h-4 w-4" />,
    specialties: ["Design patterns", "System architecture", "Best practices"],
    color: "bg-yellow-500"
  },
  {
    type: AIAgentType.PERFORMANCE_OPTIMIZER,
    name: "SpeedBoost",
    description: "Performance analysis and optimization suggestions",
    icon: <Zap className="h-4 w-4" />,
    specialties: ["Performance profiling", "Optimization", "Memory management"],
    color: "bg-orange-500"
  },
  {
    type: AIAgentType.TEST_GENERATOR,
    name: "TestCraft",
    description: "Automated test generation and coverage analysis",
    icon: <Sparkles className="h-4 w-4" />,
    specialties: ["Unit tests", "Integration tests", "Test coverage", "Mocking"],
    color: "bg-indigo-500"
  }
];

export default function AIAssistant({ isOpen, onClose, currentCode, selectedText, language }: AIAssistantProps) {
  const [messages, setMessages] = useState<AIMessage[]>([]);
  const [input, setInput] = useState('');
  const [selectedAgent, setSelectedAgent] = useState<AIAgentType>(AIAgentType.CODE_ASSISTANT);
  const [isProcessing, setIsProcessing] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getCurrentAgent = () => AI_AGENTS.find(agent => agent.type === selectedAgent) || AI_AGENTS[0];

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMessage: AIMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      agentType: selectedAgent,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = input;
    setInput('');
    setIsProcessing(true);

    try {
      let response: any;
      
      // Determine the appropriate API call based on agent type
      const context = `Current code: ${currentCode || 'None'}\nSelected text: ${selectedText || 'None'}\nLanguage: ${language || 'Unknown'}`;
      
      switch (selectedAgent) {
        case AIAgentType.CODE_ASSISTANT:
        case AIAgentType.REFACTOR_EXPERT:
        case AIAgentType.PERFORMANCE_OPTIMIZER:
          if (currentCode) {
            const task = selectedAgent === AIAgentType.CODE_ASSISTANT ? 'explain' :
                         selectedAgent === AIAgentType.REFACTOR_EXPERT ? 'refactor' : 'optimize';
            
            response = await fetch('/api/openai/analyze-code', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                code: selectedText || currentCode,
                language: language || 'javascript',
                task,
                context: currentInput
              })
            });
          } else {
            response = await fetch('/api/openai/generate-code', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                prompt: currentInput,
                language: language || 'javascript',
                context,
                includeComments: true
              })
            });
          }
          break;
          
        case AIAgentType.BUG_HUNTER:
          if (currentCode) {
            response = await fetch('/api/openai/analyze-code', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                code: currentCode,
                language: language || 'javascript',
                task: 'debug',
                context: currentInput
              })
            });
          } else {
            response = await fetch('/api/openai/chat', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                message: `As a debugging expert: ${currentInput}`,
                context
              })
            });
          }
          break;
          
        case AIAgentType.DOCUMENTATION_WRITER:
          if (currentCode) {
            response = await fetch('/api/openai/analyze-code', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                code: currentCode,
                language: language || 'javascript',
                task: 'document',
                context: currentInput
              })
            });
          } else {
            response = await fetch('/api/openai/chat', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                message: `As a documentation expert: ${currentInput}`,
                context
              })
            });
          }
          break;
          
        case AIAgentType.TEST_GENERATOR:
          if (currentCode) {
            response = await fetch('/api/openai/analyze-code', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                code: currentCode,
                language: language || 'javascript',
                task: 'test',
                context: currentInput
              })
            });
          } else {
            response = await fetch('/api/openai/generate-code', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                prompt: `Generate unit tests for: ${currentInput}`,
                language: language || 'javascript',
                context,
                includeComments: true
              })
            });
          }
          break;
          
        default:
          response = await fetch('/api/openai/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              message: currentInput,
              context
            })
          });
      }

      if (!response.ok) {
        throw new Error(`API call failed: ${response.statusText}`);
      }

      const result = await response.json();
      
      const aiMessage: AIMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: result.content || 'I received your request but encountered an issue processing it.',
        agentType: selectedAgent,
        timestamp: new Date(),
        confidence: result.confidence || 0.85,
        codeSnippet: result.codeSnippet
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('AI Assistant error:', error);
      
      const errorMessage: AIMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: error instanceof Error ? 
          `I encountered an error: ${error.message}. Please check your OpenAI API configuration.` :
          'I encountered an unexpected error. Please try again.',
        agentType: selectedAgent,
        timestamp: new Date(),
        confidence: 0
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  };

  const generateCodeAssistantResponse = (query: string, code?: string, lang?: string): string => {
    if (query.toLowerCase().includes('function') || query.toLowerCase().includes('method')) {
      return `Here's a ${lang || 'JavaScript'} function that addresses your request:\n\n\`\`\`${lang || 'javascript'}\n// Generated function based on your description\nfunction processData(data) {\n  // Implementation here\n  return processedData;\n}\n\`\`\`\n\nThis function follows best practices for ${lang || 'JavaScript'} development.`;
    }
    return `I can help you with that ${lang || 'code'} question. Based on your current context, here are some suggestions:\n\n1. Consider using proper error handling\n2. Follow naming conventions\n3. Add appropriate comments\n\nWould you like me to provide a specific implementation?`;
  };

  const generateRefactorResponse = (query: string, selectedCode?: string): string => {
    return `I've analyzed your code and found several refactoring opportunities:\n\n**Suggested Improvements:**\n\n1. **Extract Method**: Break down large functions into smaller, focused methods\n2. **Remove Duplication**: Consolidate repeated code blocks\n3. **Improve Naming**: Use more descriptive variable and function names\n\n\`\`\`javascript\n// Refactored version\nfunction optimizedFunction(data) {\n  return processInChunks(data)\n    .map(transform)\n    .filter(isValid);\n}\n\`\`\`\n\nThis refactoring improves readability and maintainability by 45%.`;
  };

  const generateBugHunterResponse = (query: string, code?: string): string => {
    return `🐛 **Bug Analysis Complete**\n\nI've identified potential issues in your code:\n\n**High Priority:**\n- Potential null pointer exception on line 23\n- Memory leak in event listener (not properly removed)\n\n**Medium Priority:**\n- Async/await pattern could be improved\n- Missing error boundaries\n\n**Recommendations:**\n1. Add null checks before object access\n2. Implement proper cleanup in useEffect\n3. Add try-catch blocks for async operations\n\nWould you like me to show the corrected code?`;
  };

  const generateDocumentationResponse = (query: string, code?: string): string => {
    return `📖 **Documentation Generated**\n\n\`\`\`javascript\n/**\n * Processes user data and applies transformations\n * @param {Object} userData - The user data object\n * @param {string} userData.id - Unique user identifier\n * @param {string} userData.name - User display name\n * @returns {Promise<Object>} Processed user data\n * @throws {ValidationError} When user data is invalid\n * @example\n * const result = await processUserData({\n *   id: '123',\n *   name: 'John Doe'\n * });\n */\nasync function processUserData(userData) {\n  // Implementation\n}\n\`\`\`\n\nDocumentation follows JSDoc standards with examples and error descriptions.`;
  };

  const generateArchitectureResponse = (query: string): string => {
    return `🏗️ **Architecture Recommendations**\n\nBased on your project requirements:\n\n**Suggested Pattern: Model-View-Controller (MVC)**\n\n\`\`\`\n┌─────────────┐    ┌─────────────┐    ┌─────────────┐\n│    Model    │◄──►│ Controller  │◄──►│    View     │\n│ (Data Logic)│    │ (Business)  │    │ (UI Logic)  │\n└─────────────┘    └─────────────┘    └─────────────┘\n\`\`\`\n\n**Benefits:**\n- Clear separation of concerns\n- Improved testability\n- Better code maintainability\n- Scalable architecture\n\n**Implementation Strategy:**\n1. Start with data models\n2. Create service controllers\n3. Build UI components\n4. Add state management`;
  };

  const generatePerformanceResponse = (query: string, code?: string): string => {
    return `⚡ **Performance Analysis**\n\n**Current Metrics:**\n- Execution time: 245ms\n- Memory usage: 12.3MB\n- Bundle size: 2.1MB\n\n**Optimization Opportunities:**\n\n1. **Code Splitting** (-40% initial load)\n2. **Lazy Loading** (-60% memory)\n3. **Memoization** (-25% re-renders)\n\n\`\`\`javascript\n// Optimized version\nconst MemoizedComponent = React.memo(({ data }) => {\n  const processedData = useMemo(() => \n    heavyComputation(data), [data]\n  );\n  \n  return <div>{processedData}</div>;\n});\n\`\`\`\n\n**Expected Improvement:** 65% faster rendering`;
  };

  const generateTestResponse = (query: string, code?: string, lang?: string): string => {
    return `🧪 **Test Suite Generated**\n\n\`\`\`javascript\ndescribe('processUserData', () => {\n  it('should process valid user data', async () => {\n    const mockUser = { id: '123', name: 'John' };\n    const result = await processUserData(mockUser);\n    \n    expect(result).toBeDefined();\n    expect(result.id).toBe('123');\n  });\n  \n  it('should handle invalid data', async () => {\n    await expect(processUserData(null))\n      .rejects.toThrow('Invalid user data');\n  });\n  \n  it('should validate required fields', () => {\n    const invalidUser = { name: 'John' }; // missing id\n    expect(() => validateUser(invalidUser))\n      .toThrow('User ID is required');\n  });\n});\n\`\`\`\n\n**Coverage:** 95% | **Tests:** 12 | **Assertions:** 24`;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-[var(--ide-accent)]" />
            AI Programming Assistant
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="chat" className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="chat">AI Chat</TabsTrigger>
            <TabsTrigger value="agents">AI Agents</TabsTrigger>
            <TabsTrigger value="tools">AI Tools</TabsTrigger>
          </TabsList>

          <TabsContent value="chat" className="flex-1 flex flex-col">
            <div className="flex gap-4 mb-4">
              <Select value={selectedAgent} onValueChange={(value) => setSelectedAgent(value as AIAgentType)}>
                <SelectTrigger className="w-64">
                  <SelectValue placeholder="Select AI Agent" />
                </SelectTrigger>
                <SelectContent>
                  {AI_AGENTS.map(agent => (
                    <SelectItem key={agent.type} value={agent.type}>
                      <div className="flex items-center gap-2">
                        {agent.icon}
                        {agent.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Badge variant="outline" className={`${getCurrentAgent().color} text-white`}>
                {getCurrentAgent().name}
              </Badge>
            </div>

            <ScrollArea className="flex-1 border rounded-lg p-4 mb-4">
              <div className="space-y-4">
                {messages.map(message => (
                  <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] rounded-lg p-3 ${
                      message.type === 'user' 
                        ? 'bg-[var(--ide-accent)] text-white' 
                        : 'bg-[var(--ide-sidebar)] border'
                    }`}>
                      {message.type === 'assistant' && (
                        <div className="flex items-center gap-2 mb-2 text-sm text-[var(--ide-text-secondary)]">
                          {getCurrentAgent().icon}
                          {getCurrentAgent().name}
                          {message.confidence && (
                            <Badge variant="outline" className="text-xs">
                              {Math.round(message.confidence * 100)}% confident
                            </Badge>
                          )}
                        </div>
                      )}
                      <div className="whitespace-pre-wrap">{message.content}</div>
                      {message.type === 'assistant' && (
                        <div className="flex items-center gap-2 mt-2">
                          <TooltipWrapper title="Copy response" type="action">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => copyToClipboard(message.content)}
                              className="h-6 w-6 p-0"
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                          </TooltipWrapper>
                          <TooltipWrapper title="Good response" type="action">
                            <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                              <ThumbsUp className="h-3 w-3" />
                            </Button>
                          </TooltipWrapper>
                          <TooltipWrapper title="Poor response" type="action">
                            <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                              <ThumbsDown className="h-3 w-3" />
                            </Button>
                          </TooltipWrapper>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                {isProcessing && (
                  <div className="flex justify-start">
                    <div className="bg-[var(--ide-sidebar)] border rounded-lg p-3">
                      <div className="flex items-center gap-2 text-[var(--ide-text-secondary)]">
                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-[var(--ide-accent)] border-t-transparent"></div>
                        {getCurrentAgent().name} is thinking...
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            <div className="flex gap-2">
              <Textarea
                placeholder={`Ask ${getCurrentAgent().name} for help...`}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                className="min-h-[60px]"
              />
              <SoundButton
                onClick={handleSendMessage}
                disabled={!input.trim() || isProcessing}
                className="px-4"
              >
                <Send className="h-4 w-4" />
              </SoundButton>
            </div>
          </TabsContent>

          <TabsContent value="agents" className="flex-1">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {AI_AGENTS.map(agent => (
                <Card key={agent.type} className="cursor-pointer hover:bg-[var(--ide-hover)]" 
                      onClick={() => setSelectedAgent(agent.type)}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <div className={`p-2 rounded-lg ${agent.color} text-white`}>
                        {agent.icon}
                      </div>
                      {agent.name}
                    </CardTitle>
                    <CardDescription>{agent.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-1">
                      {agent.specialties.map(specialty => (
                        <Badge key={specialty} variant="secondary" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="tools" className="flex-1">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Code2 className="h-4 w-4" />
                    Function Generator
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-[var(--ide-text-secondary)] mb-3">
                    Generate complete functions from natural language descriptions.
                  </p>
                  <Button variant="outline" className="w-full">Launch Tool</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <RefreshCw className="h-4 w-4" />
                    Smart Refactor
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-[var(--ide-text-secondary)] mb-3">
                    Automatically refactor code for better performance and readability.
                  </p>
                  <Button variant="outline" className="w-full">Launch Tool</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bug className="h-4 w-4" />
                    Bug Predictor
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-[var(--ide-text-secondary)] mb-3">
                    Predict potential bugs before they happen.
                  </p>
                  <Button variant="outline" className="w-full">Launch Tool</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Doc Auto-writer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-[var(--ide-text-secondary)] mb-3">
                    Generate comprehensive documentation automatically.
                  </p>
                  <Button variant="outline" className="w-full">Launch Tool</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-4 w-4" />
                    Architecture Advisor
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-[var(--ide-text-secondary)] mb-3">
                    Get suggestions for better system architecture.
                  </p>
                  <Button variant="outline" className="w-full">Launch Tool</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-4 w-4" />
                    Performance Optimizer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-[var(--ide-text-secondary)] mb-3">
                    Analyze and optimize code performance automatically.
                  </p>
                  <Button variant="outline" className="w-full">Launch Tool</Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}