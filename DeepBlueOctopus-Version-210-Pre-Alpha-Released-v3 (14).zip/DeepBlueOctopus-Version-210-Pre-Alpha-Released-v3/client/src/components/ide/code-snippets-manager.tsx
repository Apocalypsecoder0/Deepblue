import React, { useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  Code2, Plus, Search, Edit, Trash2, Copy,
  Star, Download, Upload, Tag, Folder,
  PlayCircle, Eye, Settings, Filter
} from "lucide-react";

interface CodeSnippetsManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface CodeSnippet {
  id: string;
  name: string;
  description: string;
  language: string;
  code: string;
  tags: string[];
  category: string;
  isFavorite: boolean;
  createdAt: Date;
  updatedAt: Date;
  usage: number;
  shortcut?: string;
}

const LANGUAGES = [
  'javascript', 'typescript', 'python', 'java', 'cpp', 'c', 'csharp',
  'html', 'css', 'scss', 'json', 'xml', 'yaml', 'markdown',
  'sql', 'bash', 'powershell', 'php', 'ruby', 'go', 'rust'
];

const CATEGORIES = [
  'functions', 'classes', 'hooks', 'components', 'utilities',
  'algorithms', 'patterns', 'templates', 'boilerplate', 'examples'
];

export default function CodeSnippetsManager({ isOpen, onClose }: CodeSnippetsManagerProps) {
  const [snippets, setSnippets] = useState<CodeSnippet[]>([
    {
      id: '1',
      name: 'React Hook Form Setup',
      description: 'Complete setup for React Hook Form with validation',
      language: 'typescript',
      code: `import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

type FormData = z.infer<typeof schema>;

export default function MyForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const onSubmit = (data: FormData) => {
    console.log(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <input {...register('email')} />
      {errors.email && <span>{errors.email.message}</span>}
      
      <input {...register('password')} type="password" />
      {errors.password && <span>{errors.password.message}</span>}
      
      <button type="submit">Submit</button>
    </form>
  );
}`,
      tags: ['react', 'form', 'validation', 'typescript'],
      category: 'components',
      isFavorite: true,
      createdAt: new Date('2025-01-01'),
      updatedAt: new Date('2025-01-01'),
      usage: 15,
      shortcut: 'rhf'
    },
    {
      id: '2',
      name: 'API Request with Error Handling',
      description: 'Fetch API with comprehensive error handling',
      language: 'javascript',
      code: `async function apiRequest(url, options = {}) {
  try {
    const response = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      throw new Error(\`HTTP error! status: \${response.status}\`);
    }

    const data = await response.json();
    return { data, error: null };
  } catch (error) {
    console.error('API request failed:', error);
    return { data: null, error: error.message };
  }
}

// Usage
const { data, error } = await apiRequest('/api/users', {
  method: 'POST',
  body: JSON.stringify({ name: 'John' }),
});

if (error) {
  console.error('Request failed:', error);
} else {
  console.log('Success:', data);
}`,
      tags: ['api', 'fetch', 'error-handling', 'async'],
      category: 'utilities',
      isFavorite: false,
      createdAt: new Date('2025-01-01'),
      updatedAt: new Date('2025-01-01'),
      usage: 8,
      shortcut: 'api'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editingSnippet, setEditingSnippet] = useState<Partial<CodeSnippet>>({});

  const { toast } = useToast();

  const filteredSnippets = snippets.filter(snippet => {
    const matchesSearch = snippet.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         snippet.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         snippet.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesLanguage = selectedLanguage === 'all' || snippet.language === selectedLanguage;
    const matchesCategory = selectedCategory === 'all' || snippet.category === selectedCategory;
    const matchesFavorites = !showFavoritesOnly || snippet.isFavorite;

    return matchesSearch && matchesLanguage && matchesCategory && matchesFavorites;
  });

  const handleCreateSnippet = useCallback(() => {
    setEditingSnippet({
      name: '',
      description: '',
      language: 'javascript',
      code: '',
      tags: [],
      category: 'utilities',
      isFavorite: false
    });
    setIsEditing(true);
  }, []);

  const handleEditSnippet = useCallback((snippet: CodeSnippet) => {
    setEditingSnippet(snippet);
    setIsEditing(true);
  }, []);

  const handleSaveSnippet = useCallback(() => {
    if (!editingSnippet.name || !editingSnippet.code) {
      toast({
        title: "Validation error",
        description: "Name and code are required",
        variant: "destructive",
      });
      return;
    }

    const now = new Date();
    const snippet: CodeSnippet = {
      id: editingSnippet.id || Date.now().toString(),
      name: editingSnippet.name!,
      description: editingSnippet.description || '',
      language: editingSnippet.language || 'javascript',
      code: editingSnippet.code!,
      tags: editingSnippet.tags || [],
      category: editingSnippet.category || 'utilities',
      isFavorite: editingSnippet.isFavorite || false,
      createdAt: editingSnippet.createdAt || now,
      updatedAt: now,
      usage: editingSnippet.usage || 0,
      shortcut: editingSnippet.shortcut
    };

    if (editingSnippet.id) {
      setSnippets(prev => prev.map(s => s.id === snippet.id ? snippet : s));
      toast({
        title: "Snippet updated",
        description: "Code snippet has been updated successfully",
      });
    } else {
      setSnippets(prev => [...prev, snippet]);
      toast({
        title: "Snippet created",
        description: "New code snippet has been created successfully",
      });
    }

    setIsEditing(false);
    setEditingSnippet({});
  }, [editingSnippet, toast]);

  const handleDeleteSnippet = useCallback((id: string) => {
    setSnippets(prev => prev.filter(s => s.id !== id));
    toast({
      title: "Snippet deleted",
      description: "Code snippet has been deleted",
    });
  }, [toast]);

  const handleToggleFavorite = useCallback((id: string) => {
    setSnippets(prev => prev.map(s => 
      s.id === id ? { ...s, isFavorite: !s.isFavorite } : s
    ));
  }, []);

  const handleCopyCode = useCallback((code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setSnippets(prev => prev.map(s => 
      s.id === id ? { ...s, usage: s.usage + 1 } : s
    ));
    toast({
      title: "Code copied",
      description: "Snippet code copied to clipboard",
    });
  }, [toast]);

  const handleInsertSnippet = useCallback((snippet: CodeSnippet) => {
    // This would integrate with the code editor to insert the snippet
    setSnippets(prev => prev.map(s => 
      s.id === snippet.id ? { ...s, usage: s.usage + 1 } : s
    ));
    toast({
      title: "Snippet inserted",
      description: `Inserted "${snippet.name}" into editor`,
    });
  }, [toast]);

  const parseTagsInput = (tagsString: string): string[] => {
    return tagsString.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0);
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[85vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Code2 className="w-5 h-5" />
            Code Snippets Manager
            <Badge variant="outline">
              {filteredSnippets.length} snippets
            </Badge>
          </DialogTitle>
        </DialogHeader>

        {!isEditing ? (
          <Tabs defaultValue="browse" className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="browse">Browse Snippets</TabsTrigger>
              <TabsTrigger value="search">Advanced Search</TabsTrigger>
              <TabsTrigger value="manage">Manage</TabsTrigger>
            </TabsList>

            <TabsContent value="browse" className="flex-1 flex flex-col space-y-4">
              <div className="flex gap-4 items-center">
                <div className="flex-1">
                  <Input
                    placeholder="Search snippets..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Languages</SelectItem>
                    {LANGUAGES.map(lang => (
                      <SelectItem key={lang} value={lang}>{lang}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  variant={showFavoritesOnly ? "default" : "outline"}
                  onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
                >
                  <Star className="w-4 h-4 mr-2" />
                  Favorites
                </Button>
                <Button onClick={handleCreateSnippet}>
                  <Plus className="w-4 h-4 mr-2" />
                  New Snippet
                </Button>
              </div>

              <ScrollArea className="flex-1">
                <div className="grid gap-4">
                  {filteredSnippets.map((snippet) => (
                    <Card key={snippet.id} className="group">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <CardTitle className="flex items-center gap-2 text-lg">
                              {snippet.name}
                              {snippet.isFavorite && (
                                <Star className="w-4 h-4 text-yellow-500 fill-current" />
                              )}
                              <Badge variant="outline">{snippet.language}</Badge>
                              <Badge variant="secondary">{snippet.category}</Badge>
                            </CardTitle>
                            <p className="text-sm text-gray-500 mt-1">
                              {snippet.description}
                            </p>
                            <div className="flex items-center gap-2 mt-2">
                              {snippet.tags.map(tag => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleToggleFavorite(snippet.id)}
                            >
                              <Star className={`w-4 h-4 ${snippet.isFavorite ? 'text-yellow-500 fill-current' : ''}`} />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditSnippet(snippet)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteSnippet(snippet.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-3 mb-3">
                          <pre className="text-sm overflow-x-auto">
                            <code>{snippet.code.substring(0, 200)}...</code>
                          </pre>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4 text-sm text-gray-500">
                            <span>Used {snippet.usage} times</span>
                            {snippet.shortcut && (
                              <span>Shortcut: {snippet.shortcut}</span>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleCopyCode(snippet.code, snippet.id)}
                            >
                              <Copy className="w-4 h-4 mr-2" />
                              Copy
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => handleInsertSnippet(snippet)}
                            >
                              <PlayCircle className="w-4 h-4 mr-2" />
                              Insert
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="search" className="flex-1 flex flex-col space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Advanced Search & Filter</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium">Language</label>
                      <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Languages</SelectItem>
                          {LANGUAGES.map(lang => (
                            <SelectItem key={lang} value={lang}>{lang}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Category</label>
                      <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Categories</SelectItem>
                          {CATEGORIES.map(cat => (
                            <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={showFavoritesOnly}
                        onChange={(e) => setShowFavoritesOnly(e.target.checked)}
                      />
                      Show favorites only
                    </label>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="manage" className="flex-1 flex flex-col space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <Code2 className="w-8 h-8 mx-auto mb-2 text-blue-500" />
                    <p className="text-2xl font-bold">{snippets.length}</p>
                    <p className="text-sm text-gray-500">Total Snippets</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <Star className="w-8 h-8 mx-auto mb-2 text-yellow-500" />
                    <p className="text-2xl font-bold">{snippets.filter(s => s.isFavorite).length}</p>
                    <p className="text-sm text-gray-500">Favorites</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <PlayCircle className="w-8 h-8 mx-auto mb-2 text-green-500" />
                    <p className="text-2xl font-bold">{snippets.reduce((sum, s) => sum + s.usage, 0)}</p>
                    <p className="text-sm text-gray-500">Total Usage</p>
                  </CardContent>
                </Card>
              </div>

              <div className="flex gap-4">
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export Snippets
                </Button>
                <Button variant="outline">
                  <Upload className="w-4 h-4 mr-2" />
                  Import Snippets
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        ) : (
          <div className="flex-1 flex flex-col space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">
                {editingSnippet.id ? 'Edit Snippet' : 'Create New Snippet'}
              </h3>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSaveSnippet}>
                  Save Snippet
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Name *</label>
                <Input
                  value={editingSnippet.name || ''}
                  onChange={(e) => setEditingSnippet(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter snippet name"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Shortcut</label>
                <Input
                  value={editingSnippet.shortcut || ''}
                  onChange={(e) => setEditingSnippet(prev => ({ ...prev, shortcut: e.target.value }))}
                  placeholder="e.g., rhf, api"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium">Description</label>
              <Input
                value={editingSnippet.description || ''}
                onChange={(e) => setEditingSnippet(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Brief description of the snippet"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Language</label>
                <Select
                  value={editingSnippet.language || 'javascript'}
                  onValueChange={(value) => setEditingSnippet(prev => ({ ...prev, language: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {LANGUAGES.map(lang => (
                      <SelectItem key={lang} value={lang}>{lang}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium">Category</label>
                <Select
                  value={editingSnippet.category || 'utilities'}
                  onValueChange={(value) => setEditingSnippet(prev => ({ ...prev, category: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium">Tags (comma-separated)</label>
              <Input
                value={editingSnippet.tags?.join(', ') || ''}
                onChange={(e) => setEditingSnippet(prev => ({ 
                  ...prev, 
                  tags: parseTagsInput(e.target.value) 
                }))}
                placeholder="react, typescript, hooks"
              />
            </div>

            <div className="flex-1">
              <label className="text-sm font-medium">Code *</label>
              <Textarea
                value={editingSnippet.code || ''}
                onChange={(e) => setEditingSnippet(prev => ({ ...prev, code: e.target.value }))}
                placeholder="Enter your code snippet here..."
                className="h-64 font-mono"
              />
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={editingSnippet.isFavorite || false}
                onChange={(e) => setEditingSnippet(prev => ({ 
                  ...prev, 
                  isFavorite: e.target.checked 
                }))}
              />
              <label className="text-sm">Mark as favorite</label>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}