import React, { useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { 
  Terminal, Plus, Edit, Trash2, Key, Shield,
  Server, Globe, Clock, CheckCircle, XCircle,
  Settings, Upload, Download, Copy, Eye, EyeOff
} from "lucide-react";

interface SSHManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SSHConnection {
  id: string;
  name: string;
  host: string;
  port: number;
  username: string;
  authMethod: 'password' | 'key' | 'agent';
  password?: string;
  privateKey?: string;
  passphrase?: string;
  keyPath?: string;
  status: 'connected' | 'disconnected' | 'connecting' | 'error';
  lastConnected?: Date;
  description: string;
  environment: Record<string, string>;
  tunnels: SSHTunnel[];
  isFavorite: boolean;
}

interface SSHTunnel {
  id: string;
  localPort: number;
  remoteHost: string;
  remotePort: number;
  type: 'local' | 'remote' | 'dynamic';
  isActive: boolean;
}

export default function SSHManager({ isOpen, onClose }: SSHManagerProps) {
  const [connections, setConnections] = useState<SSHConnection[]>([
    {
      id: '1',
      name: 'Production Server',
      host: 'prod.example.com',
      port: 22,
      username: 'ubuntu',
      authMethod: 'key',
      keyPath: '~/.ssh/id_rsa',
      status: 'disconnected',
      lastConnected: new Date(Date.now() - 2 * 60 * 60 * 1000),
      description: 'Main production server for web application',
      environment: { NODE_ENV: 'production', PORT: '3000' },
      tunnels: [
        {
          id: '1',
          localPort: 8080,
          remoteHost: 'localhost',
          remotePort: 80,
          type: 'local',
          isActive: false
        }
      ],
      isFavorite: true
    },
    {
      id: '2',
      name: 'Development Server',
      host: '192.168.1.100',
      port: 22,
      username: 'developer',
      authMethod: 'password',
      status: 'connected',
      lastConnected: new Date(),
      description: 'Local development environment',
      environment: { NODE_ENV: 'development' },
      tunnels: [],
      isFavorite: false
    }
  ]);

  const [selectedConnection, setSelectedConnection] = useState<SSHConnection | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editingConnection, setEditingConnection] = useState<Partial<SSHConnection>>({});
  const [showPasswords, setShowPasswords] = useState(false);
  const [testResults, setTestResults] = useState<{ [id: string]: string }>({});

  const { toast } = useToast();

  const handleCreateConnection = useCallback(() => {
    setEditingConnection({
      name: '',
      host: '',
      port: 22,
      username: '',
      authMethod: 'password',
      description: '',
      environment: {},
      tunnels: [],
      isFavorite: false
    });
    setIsEditing(true);
  }, []);

  const handleEditConnection = useCallback((connection: SSHConnection) => {
    setEditingConnection(connection);
    setIsEditing(true);
  }, []);

  const handleSaveConnection = useCallback(() => {
    if (!editingConnection.name || !editingConnection.host || !editingConnection.username) {
      toast({
        title: "Validation error",
        description: "Name, host, and username are required",
        variant: "destructive",
      });
      return;
    }

    const connection: SSHConnection = {
      id: editingConnection.id || Date.now().toString(),
      name: editingConnection.name!,
      host: editingConnection.host!,
      port: editingConnection.port || 22,
      username: editingConnection.username!,
      authMethod: editingConnection.authMethod || 'password',
      password: editingConnection.password,
      privateKey: editingConnection.privateKey,
      passphrase: editingConnection.passphrase,
      keyPath: editingConnection.keyPath,
      status: 'disconnected',
      lastConnected: editingConnection.lastConnected,
      description: editingConnection.description || '',
      environment: editingConnection.environment || {},
      tunnels: editingConnection.tunnels || [],
      isFavorite: editingConnection.isFavorite || false
    };

    if (editingConnection.id) {
      setConnections(prev => prev.map(c => c.id === connection.id ? connection : c));
      toast({
        title: "Connection updated",
        description: "SSH connection has been updated",
      });
    } else {
      setConnections(prev => [...prev, connection]);
      toast({
        title: "Connection created",
        description: "New SSH connection has been created",
      });
    }

    setIsEditing(false);
    setEditingConnection({});
  }, [editingConnection, toast]);

  const handleDeleteConnection = useCallback((id: string) => {
    setConnections(prev => prev.filter(c => c.id !== id));
    toast({
      title: "Connection deleted",
      description: "SSH connection has been deleted",
    });
  }, [toast]);

  const handleConnect = useCallback(async (id: string) => {
    setConnections(prev => prev.map(c => 
      c.id === id ? { ...c, status: 'connecting' } : c
    ));

    // Simulate connection attempt
    await new Promise(resolve => setTimeout(resolve, 2000));

    const success = Math.random() > 0.3; // 70% success rate
    
    setConnections(prev => prev.map(c => 
      c.id === id ? { 
        ...c, 
        status: success ? 'connected' : 'error',
        lastConnected: success ? new Date() : c.lastConnected
      } : c
    ));

    toast({
      title: success ? "Connected" : "Connection failed",
      description: success ? "SSH connection established" : "Failed to establish SSH connection",
      variant: success ? "default" : "destructive",
    });
  }, [toast]);

  const handleDisconnect = useCallback((id: string) => {
    setConnections(prev => prev.map(c => 
      c.id === id ? { ...c, status: 'disconnected' } : c
    ));

    toast({
      title: "Disconnected",
      description: "SSH connection closed",
    });
  }, [toast]);

  const handleTestConnection = useCallback(async (id: string) => {
    const connection = connections.find(c => c.id === id);
    if (!connection) return;

    setTestResults(prev => ({ ...prev, [id]: 'testing' }));

    // Simulate connection test
    await new Promise(resolve => setTimeout(resolve, 3000));

    const success = Math.random() > 0.2; // 80% success rate
    const result = success ? 'success' : 'failed';
    
    setTestResults(prev => ({ ...prev, [id]: result }));

    toast({
      title: success ? "Test successful" : "Test failed",
      description: success 
        ? "SSH connection test completed successfully" 
        : "SSH connection test failed - check credentials",
      variant: success ? "default" : "destructive",
    });
  }, [connections, toast]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'connecting':
        return <Clock className="w-4 h-4 text-blue-500 animate-spin" />;
      case 'error':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <Server className="w-4 h-4 text-gray-500" />;
    }
  };

  const getTestResultIcon = (result: string) => {
    switch (result) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'testing':
        return <Clock className="w-4 h-4 text-blue-500 animate-spin" />;
      default:
        return null;
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Terminal className="w-5 h-5" />
            SSH Connection Manager
            <Badge variant="outline">
              {connections.filter(c => c.status === 'connected').length} connected
            </Badge>
          </DialogTitle>
        </DialogHeader>

        {!isEditing ? (
          <Tabs defaultValue="connections" className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="connections">Connections</TabsTrigger>
              <TabsTrigger value="tunnels">Tunnels</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="connections" className="flex-1 flex flex-col space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Button onClick={handleCreateConnection}>
                    <Plus className="w-4 h-4 mr-2" />
                    New Connection
                  </Button>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={showPasswords}
                      onChange={(e) => setShowPasswords(e.target.checked)}
                      className="rounded"
                    />
                    <span className="text-sm">Show passwords</span>
                  </div>
                </div>
                <div className="text-sm text-gray-500">
                  {connections.length} total connections
                </div>
              </div>

              <ScrollArea className="flex-1">
                <div className="space-y-3">
                  {connections.map((connection) => (
                    <Card 
                      key={connection.id} 
                      className={`group cursor-pointer transition-colors ${
                        selectedConnection?.id === connection.id 
                          ? 'border-blue-300 bg-blue-50 dark:bg-blue-950' 
                          : ''
                      }`}
                      onClick={() => setSelectedConnection(connection)}
                    >
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              {getStatusIcon(connection.status)}
                              <span className="font-medium">{connection.name}</span>
                              {connection.isFavorite && (
                                <span className="text-yellow-500">★</span>
                              )}
                              <Badge variant="outline">{connection.authMethod}</Badge>
                            </div>
                            <p className="text-sm text-gray-500">
                              {connection.username}@{connection.host}:{connection.port}
                            </p>
                            <p className="text-xs text-gray-400 mt-1">
                              {connection.description}
                            </p>
                            {connection.lastConnected && (
                              <p className="text-xs text-gray-400">
                                Last connected: {connection.lastConnected.toLocaleString()}
                              </p>
                            )}
                          </div>
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleTestConnection(connection.id);
                              }}
                            >
                              {testResults[connection.id] ? 
                                getTestResultIcon(testResults[connection.id]) : 
                                <Shield className="w-4 h-4" />
                              }
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleEditConnection(connection);
                              }}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteConnection(connection.id);
                              }}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-center justify-between">
                          <div className="text-sm text-gray-500">
                            {connection.tunnels.length} tunnels configured
                          </div>
                          <div className="flex gap-2">
                            {connection.status === 'connected' ? (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDisconnect(connection.id);
                                }}
                              >
                                Disconnect
                              </Button>
                            ) : (
                              <Button
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleConnect(connection.id);
                                }}
                                disabled={connection.status === 'connecting'}
                              >
                                {connection.status === 'connecting' ? 'Connecting...' : 'Connect'}
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="tunnels" className="flex-1 flex flex-col space-y-4">
              {selectedConnection ? (
                <Card>
                  <CardHeader>
                    <CardTitle>SSH Tunnels for {selectedConnection.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedConnection.tunnels.length > 0 ? (
                      <div className="space-y-3">
                        {selectedConnection.tunnels.map((tunnel) => (
                          <div key={tunnel.id} className="flex items-center justify-between p-3 border rounded">
                            <div>
                              <span className="font-medium">
                                Local:{tunnel.localPort} → {tunnel.remoteHost}:{tunnel.remotePort}
                              </span>
                              <Badge variant="outline" className="ml-2">{tunnel.type}</Badge>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant={tunnel.isActive ? "default" : "secondary"}>
                                {tunnel.isActive ? "Active" : "Inactive"}
                              </Badge>
                              <Button variant="outline" size="sm">
                                {tunnel.isActive ? "Stop" : "Start"}
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-center text-gray-500 py-8">
                        No tunnels configured for this connection
                      </p>
                    )}
                    <Button className="mt-4" variant="outline">
                      <Plus className="w-4 h-4 mr-2" />
                      Add Tunnel
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center h-64">
                    <Globe className="w-12 h-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium mb-2">No Connection Selected</h3>
                    <p className="text-gray-500">Select a connection to manage its tunnels</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="settings" className="flex-1 flex flex-col space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>SSH Client Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium">Default SSH Port</label>
                      <Input type="number" defaultValue="22" />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Connection Timeout (seconds)</label>
                      <Input type="number" defaultValue="10" />
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <span className="text-sm">Enable SSH agent forwarding</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <span className="text-sm">Use compression</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <input type="checkbox" className="rounded" />
                      <span className="text-sm">Keep alive connections</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <span className="text-sm">Verify host keys</span>
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Default SSH Key Path</label>
                    <Input defaultValue="~/.ssh/id_rsa" />
                  </div>

                  <div className="flex gap-4">
                    <Button variant="outline">
                      <Upload className="w-4 h-4 mr-2" />
                      Import Connections
                    </Button>
                    <Button variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Export Connections
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        ) : (
          <div className="flex-1 flex flex-col space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium">
                {editingConnection.id ? 'Edit Connection' : 'New SSH Connection'}
              </h3>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSaveConnection}>
                  Save Connection
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Connection Name *</label>
                  <Input
                    value={editingConnection.name || ''}
                    onChange={(e) => setEditingConnection(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="My Server"
                  />
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="col-span-2">
                    <label className="text-sm font-medium">Host *</label>
                    <Input
                      value={editingConnection.host || ''}
                      onChange={(e) => setEditingConnection(prev => ({ ...prev, host: e.target.value }))}
                      placeholder="server.example.com"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Port</label>
                    <Input
                      type="number"
                      value={editingConnection.port || 22}
                      onChange={(e) => setEditingConnection(prev => ({ ...prev, port: parseInt(e.target.value) }))}
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium">Username *</label>
                  <Input
                    value={editingConnection.username || ''}
                    onChange={(e) => setEditingConnection(prev => ({ ...prev, username: e.target.value }))}
                    placeholder="ubuntu"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">Authentication Method</label>
                  <select
                    value={editingConnection.authMethod || 'password'}
                    onChange={(e) => setEditingConnection(prev => ({ ...prev, authMethod: e.target.value as any }))}
                    className="w-full px-3 py-2 border rounded-md"
                  >
                    <option value="password">Password</option>
                    <option value="key">Private Key</option>
                    <option value="agent">SSH Agent</option>
                  </select>
                </div>

                {editingConnection.authMethod === 'password' && (
                  <div>
                    <label className="text-sm font-medium">Password</label>
                    <div className="relative">
                      <Input
                        type={showPasswords ? "text" : "password"}
                        value={editingConnection.password || ''}
                        onChange={(e) => setEditingConnection(prev => ({ ...prev, password: e.target.value }))}
                        placeholder="Password"
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setShowPasswords(!showPasswords)}
                        className="absolute right-2 top-1/2 transform -translate-y-1/2"
                      >
                        {showPasswords ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                )}

                {editingConnection.authMethod === 'key' && (
                  <div className="space-y-3">
                    <div>
                      <label className="text-sm font-medium">Private Key Path</label>
                      <Input
                        value={editingConnection.keyPath || ''}
                        onChange={(e) => setEditingConnection(prev => ({ ...prev, keyPath: e.target.value }))}
                        placeholder="~/.ssh/id_rsa"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Passphrase (if required)</label>
                      <Input
                        type="password"
                        value={editingConnection.passphrase || ''}
                        onChange={(e) => setEditingConnection(prev => ({ ...prev, passphrase: e.target.value }))}
                        placeholder="Key passphrase"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Description</label>
                  <Textarea
                    value={editingConnection.description || ''}
                    onChange={(e) => setEditingConnection(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Connection description"
                    rows={3}
                  />
                </div>

                <div>
                  <label className="text-sm font-medium">Environment Variables</label>
                  <Textarea
                    value={Object.entries(editingConnection.environment || {})
                      .map(([key, value]) => `${key}=${value}`)
                      .join('\n')}
                    onChange={(e) => {
                      const env: Record<string, string> = {};
                      e.target.value.split('\n').forEach(line => {
                        const [key, ...valueParts] = line.split('=');
                        if (key && valueParts.length > 0) {
                          env[key.trim()] = valueParts.join('=').trim();
                        }
                      });
                      setEditingConnection(prev => ({ ...prev, environment: env }));
                    }}
                    placeholder="NODE_ENV=production&#10;PORT=3000"
                    rows={4}
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={editingConnection.isFavorite || false}
                    onChange={(e) => setEditingConnection(prev => ({ ...prev, isFavorite: e.target.checked }))}
                    className="rounded"
                  />
                  <span className="text-sm">Mark as favorite</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}