import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  BookOpen,
  FileText,
  Code,
  Download,
  Upload,
  Settings,
  Eye,
  Save,
  Copy,
  Search,
  Plus,
  Minus,
  Edit,
  Trash2,
  Star,
  Tag,
  Clock,
  User,
  Globe,
  Terminal,
  Database,
  Layers,
  GitBranch
} from "lucide-react";

interface DocumentationGeneratorProps {
  isOpen: boolean;
  onClose: () => void;
}

interface DocTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  content: string;
  variables: string[];
}

interface APIEndpoint {
  method: string;
  path: string;
  description: string;
  parameters: any[];
  responses: any[];
}

export default function DocumentationGenerator({ isOpen, onClose }: DocumentationGeneratorProps) {
  const [activeTab, setActiveTab] = useState("generator");
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [projectName, setProjectName] = useState("DeepBlue IDE Project");
  const [projectDescription, setProjectDescription] = useState("A comprehensive web-based IDE with advanced features");
  const [generatedDoc, setGeneratedDoc] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  const docTemplates: DocTemplate[] = [
    {
      id: "readme",
      name: "README.md",
      description: "Complete project README with installation, usage, and contribution guidelines",
      category: "Project",
      content: `# {{PROJECT_NAME}}

{{PROJECT_DESCRIPTION}}

## Features

- **Multi-Language Support**: JavaScript, TypeScript, Python, Java, C++, Rust, Go, and more
- **Advanced IDE Features**: Monaco Editor, debugging, version control, extensions
- **Database Integration**: PostgreSQL with Drizzle ORM
- **Professional Tools**: Code formatting, linting, testing, deployment

## Installation

\`\`\`bash
git clone https://github.com/your-username/{{PROJECT_SLUG}}.git
cd {{PROJECT_SLUG}}
npm install
npm run dev
\`\`\`

## Usage

1. Start the development server: \`npm run dev\`
2. Open your browser to \`http://localhost:3000\`
3. Begin coding with the full-featured IDE

## API Documentation

### Authentication
- \`POST /api/auth/login\` - User login
- \`POST /api/auth/register\` - User registration
- \`DELETE /api/auth/logout\` - User logout

### Projects
- \`GET /api/projects\` - List user projects
- \`POST /api/projects\` - Create new project
- \`PUT /api/projects/:id\` - Update project
- \`DELETE /api/projects/:id\` - Delete project

### Files
- \`GET /api/files\` - List project files
- \`POST /api/files\` - Create new file
- \`PUT /api/files/:id\` - Update file content
- \`DELETE /api/files/:id\` - Delete file

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## License

MIT License - see LICENSE file for details.`,
      variables: ["PROJECT_NAME", "PROJECT_DESCRIPTION", "PROJECT_SLUG"]
    },
    {
      id: "api",
      name: "API Documentation",
      description: "Comprehensive API reference with endpoints, parameters, and examples",
      category: "API",
      content: `# {{PROJECT_NAME}} API Documentation

## Overview

{{PROJECT_DESCRIPTION}}

**Base URL**: \`https://api.{{PROJECT_SLUG}}.com\`
**Version**: 1.0.0
**Authentication**: Bearer Token

## Authentication

### Login
\`\`\`http
POST /api/auth/login
Content-Type: application/json

{
  "username": "user@example.com",
  "password": "password123"
}
\`\`\`

**Response:**
\`\`\`json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "username": "user@example.com",
    "firstName": "John",
    "lastName": "Doe"
  }
}
\`\`\`

## Projects API

### Get Projects
\`\`\`http
GET /api/projects
Authorization: Bearer {token}
\`\`\`

### Create Project
\`\`\`http
POST /api/projects
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "My New Project",
  "description": "Project description"
}
\`\`\`

## Files API

### Get Files
\`\`\`http
GET /api/files?projectId=1
Authorization: Bearer {token}
\`\`\`

### Create File
\`\`\`http
POST /api/files
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "main.js",
  "content": "console.log('Hello World');",
  "language": "javascript",
  "projectId": 1
}
\`\`\`

## Error Responses

All API endpoints return errors in the following format:

\`\`\`json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": ["Username is required", "Password must be at least 8 characters"]
  }
}
\`\`\`

## Rate Limiting

- **Free Tier**: 100 requests per hour
- **Pro Tier**: 1000 requests per hour

## SDKs and Libraries

- **JavaScript**: \`npm install {{PROJECT_SLUG}}-sdk\`
- **Python**: \`pip install {{PROJECT_SLUG}}-sdk\`
- **Go**: \`go get github.com/{{PROJECT_SLUG}}/go-sdk\``,
      variables: ["PROJECT_NAME", "PROJECT_DESCRIPTION", "PROJECT_SLUG"]
    },
    {
      id: "deployment",
      name: "Deployment Guide",
      description: "Step-by-step deployment instructions for various platforms",
      category: "DevOps",
      content: `# {{PROJECT_NAME}} Deployment Guide

## Overview

This guide covers deploying {{PROJECT_NAME}} to various platforms including Vercel, Netlify, AWS, and Docker.

## Prerequisites

- Node.js 18+ installed
- PostgreSQL database
- Environment variables configured

## Environment Variables

Create a \`.env\` file with the following variables:

\`\`\`bash
DATABASE_URL=postgresql://user:password@localhost:5432/database
JWT_SECRET=your-secret-key
NODE_ENV=production
CORS_ORIGIN=https://your-domain.com
\`\`\`

## Vercel Deployment

1. **Install Vercel CLI**:
   \`\`\`bash
   npm install -g vercel
   \`\`\`

2. **Deploy**:
   \`\`\`bash
   vercel --prod
   \`\`\`

3. **Configure Environment Variables**:
   - Go to Vercel dashboard
   - Add environment variables
   - Redeploy

## Netlify Deployment

1. **Build the project**:
   \`\`\`bash
   npm run build
   \`\`\`

2. **Deploy to Netlify**:
   \`\`\`bash
   npm install -g netlify-cli
   netlify deploy --prod --dir=dist
   \`\`\`

## AWS Deployment

### Using AWS Lambda + API Gateway

1. **Install Serverless Framework**:
   \`\`\`bash
   npm install -g serverless
   \`\`\`

2. **Configure serverless.yml**:
   \`\`\`yaml
   service: {{PROJECT_SLUG}}
   provider:
     name: aws
     runtime: nodejs18.x
     region: us-east-1
   functions:
     app:
       handler: server/lambda.handler
       events:
         - http:
             path: /{proxy+}
             method: ANY
   \`\`\`

3. **Deploy**:
   \`\`\`bash
   serverless deploy
   \`\`\`

## Docker Deployment

1. **Create Dockerfile**:
   \`\`\`dockerfile
   FROM node:18-alpine
   WORKDIR /app
   COPY package*.json ./
   RUN npm install
   COPY . .
   RUN npm run build
   EXPOSE 3000
   CMD ["npm", "start"]
   \`\`\`

2. **Build and run**:
   \`\`\`bash
   docker build -t {{PROJECT_SLUG}} .
   docker run -p 3000:3000 --env-file .env {{PROJECT_SLUG}}
   \`\`\`

## Database Migration

Before deploying, ensure your database is migrated:

\`\`\`bash
npm run db:push
\`\`\`

## Health Checks

Configure health check endpoints:

- \`GET /health\` - Basic health check
- \`GET /health/db\` - Database connectivity
- \`GET /health/detailed\` - Comprehensive system status

## Monitoring

Set up monitoring with:

- **Application**: New Relic, Datadog
- **Infrastructure**: AWS CloudWatch, Prometheus
- **Logs**: LogRocket, Sentry
- **Uptime**: Pingdom, UptimeRobot

## Backup Strategy

1. **Database Backups**: Daily automated backups
2. **File Storage**: Replicated across regions
3. **Configuration**: Version controlled in Git`,
      variables: ["PROJECT_NAME", "PROJECT_SLUG"]
    },
    {
      id: "contributing",
      name: "Contributing Guide",
      description: "Guidelines for contributors including code style and workflow",
      category: "Community",
      content: `# Contributing to {{PROJECT_NAME}}

Thank you for your interest in contributing to {{PROJECT_NAME}}! This guide will help you get started.

## Code of Conduct

Please read and follow our [Code of Conduct](CODE_OF_CONDUCT.md).

## Development Setup

1. **Fork and clone the repository**:
   \`\`\`bash
   git clone https://github.com/your-username/{{PROJECT_SLUG}}.git
   cd {{PROJECT_SLUG}}
   \`\`\`

2. **Install dependencies**:
   \`\`\`bash
   npm install
   \`\`\`

3. **Start development server**:
   \`\`\`bash
   npm run dev
   \`\`\`

## Code Style

We use ESLint and Prettier for code formatting:

\`\`\`bash
npm run lint        # Check for linting errors
npm run lint:fix    # Fix linting errors
npm run format      # Format code with Prettier
\`\`\`

### TypeScript Guidelines

- Use explicit types when helpful for clarity
- Prefer interfaces over type aliases for object shapes
- Use strict null checks
- Document complex types with JSDoc comments

### React Guidelines

- Use functional components with hooks
- Keep components small and focused
- Use proper prop typing with TypeScript
- Follow the single responsibility principle

### Database Guidelines

- Use Drizzle ORM for all database operations
- Write migrations for schema changes
- Include proper indexes for performance
- Use transactions for multi-table operations

## Testing

Run the test suite:

\`\`\`bash
npm test                # Run all tests
npm run test:watch     # Run tests in watch mode
npm run test:coverage  # Run tests with coverage
\`\`\`

### Writing Tests

- Write unit tests for utility functions
- Write integration tests for API endpoints
- Write component tests for React components
- Aim for 80%+ test coverage

## Submitting Changes

1. **Create a feature branch**:
   \`\`\`bash
   git checkout -b feature/your-feature-name
   \`\`\`

2. **Make your changes**:
   - Follow the code style guidelines
   - Add tests for new functionality
   - Update documentation as needed

3. **Commit your changes**:
   \`\`\`bash
   git commit -m "feat: add new feature description"
   \`\`\`

   We follow [Conventional Commits](https://conventionalcommits.org/):
   - \`feat:\` New features
   - \`fix:\` Bug fixes
   - \`docs:\` Documentation changes
   - \`style:\` Code style changes
   - \`refactor:\` Code refactoring
   - \`test:\` Test additions or changes
   - \`chore:\` Maintenance tasks

4. **Push and create a pull request**:
   \`\`\`bash
   git push origin feature/your-feature-name
   \`\`\`

## Pull Request Process

1. Ensure all tests pass
2. Update documentation if needed
3. Add a clear description of your changes
4. Link any related issues
5. Request review from maintainers

## Issue Reporting

When reporting bugs, please include:

- Steps to reproduce
- Expected behavior
- Actual behavior
- Browser/environment details
- Screenshots if applicable

## Feature Requests

For feature requests, please:

- Check if the feature already exists
- Describe the use case
- Explain why it would be valuable
- Consider implementation complexity

## Architecture Decisions

Major architectural changes should be discussed in issues before implementation.

## Security

Report security vulnerabilities privately to: security@{{PROJECT_SLUG}}.com`,
      variables: ["PROJECT_NAME", "PROJECT_SLUG"]
    }
  ];

  const apiEndpoints: APIEndpoint[] = [
    {
      method: "GET",
      path: "/api/projects",
      description: "Retrieve all projects for authenticated user",
      parameters: [
        { name: "limit", type: "query", required: false, description: "Number of projects to return" },
        { name: "offset", type: "query", required: false, description: "Number of projects to skip" }
      ],
      responses: [
        { code: 200, description: "Success", example: '{"projects": [...]}' },
        { code: 401, description: "Unauthorized" }
      ]
    },
    {
      method: "POST",
      path: "/api/projects",
      description: "Create a new project",
      parameters: [
        { name: "name", type: "body", required: true, description: "Project name" },
        { name: "description", type: "body", required: false, description: "Project description" }
      ],
      responses: [
        { code: 201, description: "Project created", example: '{"id": 1, "name": "...", "description": "..."}' },
        { code: 400, description: "Invalid input" }
      ]
    },
    {
      method: "GET",
      path: "/api/files",
      description: "Retrieve files for a project",
      parameters: [
        { name: "projectId", type: "query", required: true, description: "Project ID" },
        { name: "path", type: "query", required: false, description: "Filter by path" }
      ],
      responses: [
        { code: 200, description: "Success", example: '{"files": [...]}' },
        { code: 404, description: "Project not found" }
      ]
    }
  ];

  const handleGenerate = async () => {
    setIsGenerating(true);
    
    try {
      const template = docTemplates.find(t => t.id === selectedTemplate);
      if (!template) return;

      // Simulate generation process
      await new Promise(resolve => setTimeout(resolve, 1500));

      let content = template.content;
      
      // Replace variables
      content = content.replace(/\{\{PROJECT_NAME\}\}/g, projectName);
      content = content.replace(/\{\{PROJECT_DESCRIPTION\}\}/g, projectDescription);
      content = content.replace(/\{\{PROJECT_SLUG\}\}/g, projectName.toLowerCase().replace(/\s+/g, '-'));

      setGeneratedDoc(content);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedDoc);
  };

  const handleDownload = () => {
    const template = docTemplates.find(t => t.id === selectedTemplate);
    const filename = template?.name.includes('.') ? template.name : `${template?.name}.md`;
    
    const blob = new Blob([generatedDoc], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            Documentation Generator & Developer Docs
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="generator">Generator</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="api-docs">API Docs</TabsTrigger>
            <TabsTrigger value="guides">Dev Guides</TabsTrigger>
            <TabsTrigger value="examples">Examples</TabsTrigger>
          </TabsList>

          <TabsContent value="generator" className="flex-1">
            <div className="grid grid-cols-2 gap-4 h-full">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="h-4 w-4" />
                      Documentation Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Project Name</label>
                      <Input
                        value={projectName}
                        onChange={(e) => setProjectName(e.target.value)}
                        placeholder="Enter project name"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium">Project Description</label>
                      <Textarea
                        value={projectDescription}
                        onChange={(e) => setProjectDescription(e.target.value)}
                        placeholder="Enter project description"
                        rows={3}
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium">Documentation Template</label>
                      <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a template" />
                        </SelectTrigger>
                        <SelectContent>
                          {docTemplates.map((template) => (
                            <SelectItem key={template.id} value={template.id}>
                              {template.name} - {template.category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex gap-2">
                      <Button 
                        onClick={handleGenerate} 
                        disabled={!selectedTemplate || isGenerating}
                        className="flex items-center gap-2"
                      >
                        <FileText className="h-4 w-4" />
                        {isGenerating ? "Generating..." : "Generate Docs"}
                      </Button>
                      <Button variant="outline" disabled={!generatedDoc} onClick={handleCopy}>
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" disabled={!generatedDoc} onClick={handleDownload}>
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Template Preview</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedTemplate ? (
                      <div className="text-xs">
                        <div className="font-medium mb-1">
                          {docTemplates.find(t => t.id === selectedTemplate)?.name}
                        </div>
                        <div className="text-muted-foreground mb-2">
                          {docTemplates.find(t => t.id === selectedTemplate)?.description}
                        </div>
                        <div className="flex gap-1">
                          {docTemplates.find(t => t.id === selectedTemplate)?.variables.map(variable => (
                            <Badge key={variable} variant="secondary" className="text-xs">
                              {variable}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    ) : (
                      <div className="text-xs text-muted-foreground">
                        Select a template to see preview
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Eye className="h-4 w-4" />
                      Generated Documentation
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-96 w-full border rounded p-4">
                      {generatedDoc ? (
                        <pre className="text-xs whitespace-pre-wrap font-mono">
                          {generatedDoc}
                        </pre>
                      ) : (
                        <div className="text-sm text-muted-foreground text-center py-8">
                          Configure settings and click "Generate Docs" to create documentation
                        </div>
                      )}
                    </ScrollArea>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="templates" className="flex-1">
            <ScrollArea className="h-full">
              <div className="grid grid-cols-2 gap-4">
                {docTemplates.map((template) => (
                  <Card key={template.id} className="cursor-pointer hover:shadow-lg transition-all">
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <FileText className="h-6 w-6 text-blue-500" />
                        <Badge variant="secondary" className="text-xs">
                          {template.category}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <CardTitle className="text-sm mb-1">{template.name}</CardTitle>
                      <CardDescription className="text-xs mb-3">
                        {template.description}
                      </CardDescription>
                      <div className="flex gap-1 mb-3">
                        {template.variables.map(variable => (
                          <Badge key={variable} variant="outline" className="text-xs">
                            {variable}
                          </Badge>
                        ))}
                      </div>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="w-full"
                        onClick={() => {
                          setSelectedTemplate(template.id);
                          setActiveTab("generator");
                        }}
                      >
                        Use Template
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="api-docs" className="flex-1">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="h-4 w-4" />
                    API Endpoints Reference
                  </CardTitle>
                  <CardDescription>
                    Complete API documentation for all available endpoints
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-4">
                      {apiEndpoints.map((endpoint, index) => (
                        <div key={index} className="border rounded p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge 
                              variant={endpoint.method === 'GET' ? 'default' : 
                                      endpoint.method === 'POST' ? 'secondary' : 'destructive'}
                              className="text-xs"
                            >
                              {endpoint.method}
                            </Badge>
                            <code className="text-sm font-mono">{endpoint.path}</code>
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">
                            {endpoint.description}
                          </p>
                          
                          <div className="space-y-2">
                            <div>
                              <h5 className="text-xs font-semibold mb-1">Parameters</h5>
                              {endpoint.parameters.map((param, i) => (
                                <div key={i} className="text-xs p-2 bg-gray-50 dark:bg-gray-800 rounded">
                                  <span className="font-medium">{param.name}</span>
                                  <Badge variant="outline" className="text-xs ml-2">
                                    {param.type}
                                  </Badge>
                                  {param.required && (
                                    <Badge variant="destructive" className="text-xs ml-1">
                                      Required
                                    </Badge>
                                  )}
                                  <div className="text-muted-foreground mt-1">
                                    {param.description}
                                  </div>
                                </div>
                              ))}
                            </div>
                            
                            <div>
                              <h5 className="text-xs font-semibold mb-1">Responses</h5>
                              {endpoint.responses.map((response, i) => (
                                <div key={i} className="text-xs p-2 bg-gray-50 dark:bg-gray-800 rounded">
                                  <Badge variant="outline" className="text-xs">
                                    {response.code}
                                  </Badge>
                                  <span className="ml-2">{response.description}</span>
                                  {response.example && (
                                    <pre className="text-xs mt-1 p-2 bg-gray-100 dark:bg-gray-700 rounded">
                                      {response.example}
                                    </pre>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="guides" className="flex-1">
            <div className="grid grid-cols-3 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <Code className="h-4 w-4" />
                    Development Guides
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-2">
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">Setting Up Development Environment</div>
                        <div className="text-xs text-muted-foreground">Node.js, PostgreSQL, and IDE configuration</div>
                      </div>
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">Database Schema Design</div>
                        <div className="text-xs text-muted-foreground">Drizzle ORM setup and migrations</div>
                      </div>
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">API Development</div>
                        <div className="text-xs text-muted-foreground">Express.js routes and middleware</div>
                      </div>
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">Frontend Architecture</div>
                        <div className="text-xs text-muted-foreground">React components and state management</div>
                      </div>
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">Testing Strategy</div>
                        <div className="text-xs text-muted-foreground">Unit, integration, and E2E testing</div>
                      </div>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <Terminal className="h-4 w-4" />
                    DevOps & Deployment
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-2">
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">Docker Containerization</div>
                        <div className="text-xs text-muted-foreground">Multi-stage builds and optimization</div>
                      </div>
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">CI/CD Pipeline</div>
                        <div className="text-xs text-muted-foreground">GitHub Actions and automated testing</div>
                      </div>
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">Cloud Deployment</div>
                        <div className="text-xs text-muted-foreground">AWS, Vercel, and Netlify deployment</div>
                      </div>
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">Monitoring & Logging</div>
                        <div className="text-xs text-muted-foreground">Error tracking and performance monitoring</div>
                      </div>
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">Security Best Practices</div>
                        <div className="text-xs text-muted-foreground">Authentication, authorization, and data protection</div>
                      </div>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <Star className="h-4 w-4" />
                    Best Practices
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-2">
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">Code Quality Standards</div>
                        <div className="text-xs text-muted-foreground">ESLint, Prettier, and TypeScript conventions</div>
                      </div>
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">Performance Optimization</div>
                        <div className="text-xs text-muted-foreground">Bundle splitting and lazy loading</div>
                      </div>
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">Accessibility Guidelines</div>
                        <div className="text-xs text-muted-foreground">WCAG compliance and keyboard navigation</div>
                      </div>
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">Error Handling</div>
                        <div className="text-xs text-muted-foreground">Graceful degradation and user feedback</div>
                      </div>
                      <div className="p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                        <div className="text-sm font-medium">Database Optimization</div>
                        <div className="text-xs text-muted-foreground">Query optimization and indexing strategies</div>
                      </div>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="examples" className="flex-1">
            <div className="grid grid-cols-2 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Code className="h-4 w-4" />
                    Code Examples
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-4">
                      <div className="border rounded p-3">
                        <h4 className="text-sm font-medium mb-2">API Route Example</h4>
                        <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-2 rounded overflow-x-auto">
{`// server/routes/projects.ts
export async function getProjects(req: Request, res: Response) {
  try {
    const userId = req.session.userId;
    const projects = await storage.getProjectsByUser(userId);
    res.json(projects);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch projects' });
  }
}`}
                        </pre>
                      </div>

                      <div className="border rounded p-3">
                        <h4 className="text-sm font-medium mb-2">React Component Example</h4>
                        <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-2 rounded overflow-x-auto">
{`// components/ProjectCard.tsx
interface ProjectCardProps {
  project: Project;
  onEdit: (id: number) => void;
}

export function ProjectCard({ project, onEdit }: ProjectCardProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{project.name}</CardTitle>
        <CardDescription>{project.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <Button onClick={() => onEdit(project.id)}>
          Edit Project
        </Button>
      </CardContent>
    </Card>
  );
}`}
                        </pre>
                      </div>

                      <div className="border rounded p-3">
                        <h4 className="text-sm font-medium mb-2">Database Schema Example</h4>
                        <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-2 rounded overflow-x-auto">
{`// shared/schema.ts
export const projects = pgTable('projects', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  userId: integer('user_id').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow()
});`}
                        </pre>
                      </div>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-4 w-4" />
                    Configuration Examples
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-80">
                    <div className="space-y-4">
                      <div className="border rounded p-3">
                        <h4 className="text-sm font-medium mb-2">Environment Configuration</h4>
                        <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-2 rounded">
{`# .env.example
DATABASE_URL=postgresql://user:pass@localhost:5432/db
JWT_SECRET=your-secret-key
NODE_ENV=development
CORS_ORIGIN=http://localhost:3000
PORT=3000`}
                        </pre>
                      </div>

                      <div className="border rounded p-3">
                        <h4 className="text-sm font-medium mb-2">Package.json Scripts</h4>
                        <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-2 rounded">
{`{
  "scripts": {
    "dev": "concurrently \\"npm run dev:server\\" \\"npm run dev:client\\"",
    "dev:server": "tsx watch server/index.ts",
    "dev:client": "vite",
    "build": "npm run build:client && npm run build:server",
    "db:push": "drizzle-kit push:pg",
    "db:studio": "drizzle-kit studio"
  }
}`}
                        </pre>
                      </div>

                      <div className="border rounded p-3">
                        <h4 className="text-sm font-medium mb-2">TypeScript Configuration</h4>
                        <pre className="text-xs bg-gray-100 dark:bg-gray-800 p-2 rounded">
{`{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "strict": true,
    "skipLibCheck": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["./client/src/*"],
      "@shared/*": ["./shared/*"]
    }
  }
}`}
                        </pre>
                      </div>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}