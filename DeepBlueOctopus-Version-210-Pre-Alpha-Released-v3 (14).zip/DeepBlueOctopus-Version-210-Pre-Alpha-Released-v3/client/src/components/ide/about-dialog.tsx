import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import OctopusLogo from "@/components/ui/octopus-logo";
import { Github, Globe, Mail, Code, Database, Wrench, Palette } from "lucide-react";

interface AboutDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AboutDialog({ isOpen, onClose }: AboutDialogProps) {
  const [activeTab, setActiveTab] = useState("about");

  const languageSupport = [
    { name: "JavaScript", ext: ".js", compiler: "Node.js", version: "ES2023" },
    { name: "TypeScript", ext: ".ts", compiler: "TSC", version: "5.0+" },
    { name: "Python", ext: ".py", compiler: "Python", version: "3.11" },
    { name: "Java", ext: ".java", compiler: "OpenJDK", version: "17+" },
    { name: "C++", ext: ".cpp", compiler: "G++", version: "11+" },
    { name: "C", ext: ".c", compiler: "GCC", version: "11+" },
    { name: "C#", ext: ".cs", compiler: "Mono", version: "6.12+" },
    { name: "Rust", ext: ".rs", compiler: "Rustc", version: "1.70+" },
    { name: "Go", ext: ".go", compiler: "Go", version: "1.21+" },
    { name: "PHP", ext: ".php", compiler: "PHP", version: "8.2+" },
    { name: "Ruby", ext: ".rb", compiler: "Ruby", version: "3.2+" },
    { name: "Swift", ext: ".swift", compiler: "Swift", version: "5.8+" },
    { name: "Kotlin", ext: ".kt", compiler: "Kotlin", version: "1.9+" },
    { name: "Dart", ext: ".dart", compiler: "Dart", version: "3.0+" },
    { name: "Bash", ext: ".sh", compiler: "Bash", version: "5.1+" },
    { name: "PowerShell", ext: ".ps1", compiler: "PowerShell", version: "7.3+" },
    { name: "SQL", ext: ".sql", compiler: "PostgreSQL", version: "15+" },
    { name: "HTML", ext: ".html", compiler: "Browser", version: "HTML5" },
    { name: "CSS", ext: ".css", compiler: "Browser", version: "CSS3" },
    { name: "SCSS", ext: ".scss", compiler: "Sass", version: "1.62+" },
    { name: "JSON", ext: ".json", compiler: "Native", version: "RFC 7159" },
    { name: "XML", ext: ".xml", compiler: "Native", version: "1.0" },
    { name: "YAML", ext: ".yaml", compiler: "Native", version: "1.2" },
    { name: "Markdown", ext: ".md", compiler: "Marked", version: "5.0+" },
    { name: "TOML", ext: ".toml", compiler: "Native", version: "1.0" },
  ];

  const features = [
    { icon: <Code className="w-4 h-4" />, name: "Multi-Language Support", desc: "25+ programming languages with compilers" },
    { icon: <Database className="w-4 h-4" />, name: "PostgreSQL Database", desc: "Full database integration with Drizzle ORM" },
    { icon: <Wrench className="w-4 h-4" />, name: "VS Code Features", desc: "Command palette, debug console, extensions" },
    { icon: <Palette className="w-4 h-4" />, name: "Ocean Theme", desc: "Beautiful deep blue octopus design" },
  ];

  const systemInfo = {
    version: "2.1.0 Alpha",
    buildDate: "July 01, 2025",
    nodeVersion: "20.x",
    architecture: navigator.platform || "Unknown",
    userAgent: navigator.userAgent,
    screen: `${screen.width}x${screen.height}`,
    memory: (navigator as any).deviceMemory ? `${(navigator as any).deviceMemory}GB` : "Unknown",
  };

  const patchNotes = [
    {
      version: "2.1.0 Alpha",
      date: "July 01, 2025",
      changes: [
        "Cross-platform desktop application deployment (macOS, Windows, Linux, iOS, Android)",
        "Platform Support Manager with build configurations and analytics",
        "Enhanced menu system with comprehensive File, Edit, View, Run, Tools options",
        "Missing features audit with 150+ identified components for future development",
        "Game engine enhancements with BlueScript scripting language",
        "Comprehensive development tools integration and professional IDE capabilities",
        "Performance optimizations and UI/UX improvements",
        "Alpha release preparation with roadmap for 12-18 month development cycle",
      ]
    },
    {
      version: "1.5.0",
      date: "July 01, 2025",
      changes: [
        "Added stunning splash screen with animated octopus logo",
        "Implemented Deep Blue Octopus theme with ocean effects",
        "Integrated PostgreSQL database with Drizzle ORM",
        "Enhanced VS Code-like features and functionality",
        "Added 25+ programming language support with compilers",
        "Created comprehensive about dialog and system info",
      ]
    },
    {
      version: "1.4.0",
      date: "June 30, 2025",
      changes: [
        "Implemented debug console with breakpoint management",
        "Added source control panel with Git integration",
        "Created extensions marketplace with install/uninstall",
        "Enhanced command palette with full VS Code shortcuts",
        "Added comprehensive settings panel with categories",
      ]
    },
    {
      version: "1.3.0",
      date: "June 29, 2025",
      changes: [
        "Added Monaco Editor with syntax highlighting",
        "Implemented file tree with drag-and-drop support",
        "Created terminal panel with code execution",
        "Added status bar with real-time information",
        "Enhanced multi-tab editor functionality",
      ]
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <OctopusLogo size={32} animated={true} />
            About DeepBlue:Octopus IDE
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="about">About</TabsTrigger>
            <TabsTrigger value="languages">Languages</TabsTrigger>
            <TabsTrigger value="features">Features</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
            <TabsTrigger value="updates">Updates</TabsTrigger>
          </TabsList>

          <TabsContent value="about" className="space-y-4">
            <div className="text-center space-y-4">
              <OctopusLogo size={80} animated={true} />
              <div>
                <h2 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">
                  DeepBlue:Octopus IDE
                </h2>
                <p className="text-lg text-muted-foreground">Ocean-Powered Development Environment</p>
                <Badge variant="secondary" className="mt-2">Version {systemInfo.version}</Badge>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h3 className="font-semibold">Developer Information</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Code className="w-4 h-4" />
                    <span>Stephen Deline Jr.</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    <span>stephend8846@gmail.com</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Github className="w-4 h-4" />
                    <span>github.com/apocalypsecode0</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    <span>stephendelinejr.dev</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="font-semibold">Build Information</h3>
                <div className="space-y-2 text-sm">
                  <div>Build Date: {systemInfo.buildDate}</div>
                  <div>Node.js: {systemInfo.nodeVersion}</div>
                  <div>Architecture: {systemInfo.architecture}</div>
                  <div>Screen: {systemInfo.screen}</div>
                </div>
              </div>
            </div>

            <div className="text-center pt-4 border-t">
              <p className="text-sm text-muted-foreground">
                © 2025 Stephen Deline Jr. All rights reserved. 
                DeepBlue:Octopus Ide is a cross-platform desktop application for developers.
                <br />
                Built with React, TypeScript, and PostgreSQL
                <br />
                GitHub:  | Email: deepblueoctopus@deepblueide.dev
              </p>
            </div>
          </TabsContent>

          <TabsContent value="languages">
            <ScrollArea className="h-[400px]">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {languageSupport.map((lang, index) => (
                  <div key={index} className="p-3 border rounded-lg space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{lang.name}</span>
                      <Badge variant="outline" className="text-xs">{lang.ext}</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      <div>Compiler: {lang.compiler}</div>
                      <div>Version: {lang.version}</div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="features">
            <ScrollArea className="h-[400px]">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-start gap-3 p-4 border rounded-lg">
                    <div className="mt-1 text-blue-400">{feature.icon}</div>
                    <div>
                      <h4 className="font-medium">{feature.name}</h4>
                      <p className="text-sm text-muted-foreground">{feature.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="system">
            <ScrollArea className="h-[400px]">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <h3 className="font-semibold">System Information</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Version:</span>
                        <span>{systemInfo.version}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Build Date:</span>
                        <span>{systemInfo.buildDate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Platform:</span>
                        <span>{systemInfo.architecture}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Memory:</span>
                        <span>{systemInfo.memory}</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <h3 className="font-semibold">Runtime Information</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Node.js:</span>
                        <span>{systemInfo.nodeVersion}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Screen:</span>
                        <span>{systemInfo.screen}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="pt-4 border-t">
                  <h3 className="font-semibold mb-2">User Agent</h3>
                  <p className="text-xs text-muted-foreground break-all">{systemInfo.userAgent}</p>
                </div>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="updates">
            <ScrollArea className="h-[400px]">
              <div className="space-y-6">
                {patchNotes.map((release, index) => (
                  <div key={index} className="space-y-3">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">Version {release.version}</h3>
                      <Badge variant="outline">{release.date}</Badge>
                    </div>
                    <ul className="space-y-1 text-sm">
                      {release.changes.map((change, changeIndex) => (
                        <li key={changeIndex} className="flex items-start gap-2">
                          <span className="text-green-400 mt-1.5 w-1 h-1 rounded-full bg-current flex-shrink-0"></span>
                          <span>{change}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end pt-4 border-t">
          <Button onClick={onClose}>Close</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}