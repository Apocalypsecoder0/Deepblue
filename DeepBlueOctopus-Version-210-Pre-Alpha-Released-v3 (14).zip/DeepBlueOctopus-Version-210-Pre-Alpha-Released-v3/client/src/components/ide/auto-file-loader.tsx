import React, { useEffect } from 'react';
import { useIDEState } from '@/hooks/use-ide-state';
import type { File } from '@shared/schema';

interface AutoFileLoaderProps {
  onFileOpen?: (file: File) => void;
}

export function AutoFileLoader({ onFileOpen }: AutoFileLoaderProps = {}) {
  const { openTabs, files, openFile } = useIDEState();

  useEffect(() => {
    // Only auto-load if no tabs are open and files are available
    if (openTabs.length === 0 && files && files.length > 0) {
      // Priority: main.js, index.html, then first non-directory file
      const priorityFile = files.find((file: File) => file.name === 'main.js') ||
                          files.find((file: File) => file.name === 'index.html') ||
                          files.find((file: File) => !file.isDirectory);
      
      if (priorityFile) {
        console.log('Auto-loading file:', priorityFile.name);
        openFile(priorityFile);
      }
    }
  }, [openTabs.length, files, openFile]);

  // This component doesn't render anything visible
  return null;
}