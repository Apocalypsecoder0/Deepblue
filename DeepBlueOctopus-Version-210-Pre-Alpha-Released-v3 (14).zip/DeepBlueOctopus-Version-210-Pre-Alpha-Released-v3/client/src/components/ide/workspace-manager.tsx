import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { SoundButton } from "@/components/ui/sound-system";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import {
  FolderOpen,
  Settings,
  Save,
  Upload,
  Download,
  Trash2,
  Edit3,
  Copy,
  Clock,
  Users,
  FileText,
  Code,
  Image,
  Music,
  Video,
  Layers,
  Monitor,
  Palette,
  Zap,
  Globe,
  Lock,
  Unlock,
  Star,
  Archive
} from "lucide-react";

interface WorkspaceManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Workspace {
  id: string;
  name: string;
  description: string;
  type: 'web' | 'mobile' | 'desktop' | 'game' | 'ai' | 'data';
  status: 'active' | 'archived' | 'shared' | 'private';
  lastModified: Date;
  collaborators: string[];
  files: number;
  size: string;
  isStarred: boolean;
  tags: string[];
  settings: {
    autoSave: boolean;
    versionControl: boolean;
    realTimeSync: boolean;
    backupEnabled: boolean;
  };
}

interface WorkspaceTemplate {
  id: string;
  name: string;
  description: string;
  type: string;
  icon: React.ReactNode;
  technologies: string[];
  estimatedTime: string;
}

export default function WorkspaceManager({ isOpen, onClose }: WorkspaceManagerProps) {
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [selectedWorkspace, setSelectedWorkspace] = useState<Workspace | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newWorkspaceName, setNewWorkspaceName] = useState("");
  const [newWorkspaceType, setNewWorkspaceType] = useState<Workspace['type']>('web');
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<'all' | Workspace['type']>('all');

  const workspaceTemplates: WorkspaceTemplate[] = [
    {
      id: 'react-app',
      name: 'React Application',
      description: 'Modern React app with TypeScript and Vite',
      type: 'Web Frontend',
      icon: <Code className="h-6 w-6" />,
      technologies: ['React', 'TypeScript', 'Vite', 'Tailwind CSS'],
      estimatedTime: '5 min'
    },
    {
      id: 'node-api',
      name: 'Node.js API',
      description: 'RESTful API with Express and TypeScript',
      type: 'Backend',
      icon: <Globe className="h-6 w-6" />,
      technologies: ['Node.js', 'Express', 'TypeScript', 'PostgreSQL'],
      estimatedTime: '3 min'
    },
    {
      id: 'flutter-app',
      name: 'Flutter Mobile App',
      description: 'Cross-platform mobile application',
      type: 'Mobile',
      icon: <Monitor className="h-6 w-6" />,
      technologies: ['Flutter', 'Dart', 'Material Design'],
      estimatedTime: '7 min'
    },
    {
      id: 'game-2d',
      name: '2D Game Project',
      description: 'Interactive 2D game with physics',
      type: 'Game',
      icon: <Layers className="h-6 w-6" />,
      technologies: ['JavaScript', 'Canvas', 'Physics Engine'],
      estimatedTime: '10 min'
    },
    {
      id: 'ml-project',
      name: 'Machine Learning',
      description: 'AI/ML project with Python and TensorFlow',
      type: 'AI/ML',
      icon: <Zap className="h-6 w-6" />,
      technologies: ['Python', 'TensorFlow', 'Jupyter', 'NumPy'],
      estimatedTime: '8 min'
    },
    {
      id: 'data-viz',
      name: 'Data Visualization',
      description: 'Interactive data dashboard',
      type: 'Data Science',
      icon: <Palette className="h-6 w-6" />,
      technologies: ['D3.js', 'React', 'Python', 'Pandas'],
      estimatedTime: '6 min'
    }
  ];

  useEffect(() => {
    // Initialize with mock workspaces
    const mockWorkspaces: Workspace[] = [
      {
        id: '1',
        name: 'DeepBlue IDE',
        description: 'Main IDE development project',
        type: 'web',
        status: 'active',
        lastModified: new Date(),
        collaborators: ['John Doe', 'Jane Smith'],
        files: 247,
        size: '15.3 MB',
        isStarred: true,
        tags: ['IDE', 'TypeScript', 'React'],
        settings: {
          autoSave: true,
          versionControl: true,
          realTimeSync: true,
          backupEnabled: true
        }
      },
      {
        id: '2',
        name: 'Mobile Game Engine',
        description: '2D/3D game development framework',
        type: 'game',
        status: 'active',
        lastModified: new Date(Date.now() - 86400000),
        collaborators: ['Alice Johnson'],
        files: 89,
        size: '8.7 MB',
        isStarred: false,
        tags: ['Game', 'Engine', 'Physics'],
        settings: {
          autoSave: true,
          versionControl: true,
          realTimeSync: false,
          backupEnabled: true
        }
      },
      {
        id: '3',
        name: 'AI Assistant API',
        description: 'Backend API for AI-powered features',
        type: 'ai',
        status: 'shared',
        lastModified: new Date(Date.now() - 172800000),
        collaborators: ['Bob Wilson', 'Carol Brown', 'Dave Lee'],
        files: 156,
        size: '22.1 MB',
        isStarred: true,
        tags: ['AI', 'API', 'Machine Learning'],
        settings: {
          autoSave: true,
          versionControl: true,
          realTimeSync: true,
          backupEnabled: true
        }
      }
    ];
    setWorkspaces(mockWorkspaces);
  }, []);

  const filteredWorkspaces = workspaces.filter(workspace => {
    const matchesSearch = workspace.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         workspace.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         workspace.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesFilter = filterType === 'all' || workspace.type === filterType;
    
    return matchesSearch && matchesFilter;
  });

  const createWorkspace = () => {
    if (!newWorkspaceName.trim()) return;
    
    const newWorkspace: Workspace = {
      id: Date.now().toString(),
      name: newWorkspaceName,
      description: `New ${newWorkspaceType} workspace`,
      type: newWorkspaceType,
      status: 'active',
      lastModified: new Date(),
      collaborators: [],
      files: 0,
      size: '0 B',
      isStarred: false,
      tags: [newWorkspaceType],
      settings: {
        autoSave: true,
        versionControl: false,
        realTimeSync: false,
        backupEnabled: true
      }
    };
    
    setWorkspaces([newWorkspace, ...workspaces]);
    setNewWorkspaceName("");
    setShowCreateDialog(false);
  };

  const toggleStar = (workspaceId: string) => {
    setWorkspaces(workspaces.map(ws => 
      ws.id === workspaceId ? { ...ws, isStarred: !ws.isStarred } : ws
    ));
  };

  const getStatusColor = (status: Workspace['status']) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'archived': return 'bg-gray-500';
      case 'shared': return 'bg-blue-500';
      case 'private': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  const getTypeIcon = (type: Workspace['type']) => {
    switch (type) {
      case 'web': return <Globe className="h-4 w-4" />;
      case 'mobile': return <Monitor className="h-4 w-4" />;
      case 'desktop': return <Monitor className="h-4 w-4" />;
      case 'game': return <Layers className="h-4 w-4" />;
      case 'ai': return <Zap className="h-4 w-4" />;
      case 'data': return <Palette className="h-4 w-4" />;
      default: return <Code className="h-4 w-4" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh] bg-gradient-to-br from-blue-950 via-slate-900 to-blue-900 border-blue-700">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-blue-100 flex items-center gap-2">
            <FolderOpen className="h-6 w-6 text-blue-400" />
            Workspace Manager
          </DialogTitle>
        </DialogHeader>

        <div className="flex h-full gap-6">
          {/* Left Panel - Workspace List */}
          <div className="w-1/3 space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="Search workspaces..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-blue-900/30 border-blue-700 text-blue-100"
              />
              <TooltipWrapper title="Create New Workspace" type="info">
                <SoundButton
                  onClick={() => setShowCreateDialog(true)}
                  className="bg-blue-600 hover:bg-blue-500"
                >
                  <FolderOpen className="h-4 w-4" />
                </SoundButton>
              </TooltipWrapper>
            </div>

            <Tabs value={filterType} onValueChange={(value) => setFilterType(value as any)}>
              <TabsList className="grid grid-cols-4 bg-blue-900/30">
                <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
                <TabsTrigger value="web" className="text-xs">Web</TabsTrigger>
                <TabsTrigger value="game" className="text-xs">Game</TabsTrigger>
                <TabsTrigger value="ai" className="text-xs">AI</TabsTrigger>
              </TabsList>
            </Tabs>

            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="space-y-2">
                {filteredWorkspaces.map((workspace) => (
                  <Card
                    key={workspace.id}
                    className={`cursor-pointer transition-all duration-200 hover:scale-105 ${
                      selectedWorkspace?.id === workspace.id
                        ? 'bg-blue-800/50 border-blue-500'
                        : 'bg-blue-900/30 border-blue-700 hover:bg-blue-800/30'
                    }`}
                    onClick={() => setSelectedWorkspace(workspace)}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          {getTypeIcon(workspace.type)}
                          <div>
                            <CardTitle className="text-sm text-blue-100">{workspace.name}</CardTitle>
                            <CardDescription className="text-xs text-blue-300">
                              {workspace.description}
                            </CardDescription>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <SoundButton
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleStar(workspace.id);
                            }}
                          >
                            <Star className={`h-3 w-3 ${workspace.isStarred ? 'fill-yellow-400 text-yellow-400' : 'text-blue-300'}`} />
                          </SoundButton>
                          <div className={`w-2 h-2 rounded-full ${getStatusColor(workspace.status)}`} />
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex items-center justify-between text-xs text-blue-300">
                        <span>{workspace.files} files</span>
                        <span>{workspace.size}</span>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {workspace.tags.slice(0, 2).map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs bg-blue-700/50 text-blue-200">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </div>

          {/* Right Panel - Workspace Details */}
          <div className="flex-1">
            {selectedWorkspace ? (
              <Tabs defaultValue="overview" className="h-full">
                <TabsList className="grid grid-cols-4 bg-blue-900/30">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="settings">Settings</TabsTrigger>
                  <TabsTrigger value="collaboration">Team</TabsTrigger>
                  <TabsTrigger value="templates">Templates</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-4 mt-4">
                  <Card className="bg-blue-900/30 border-blue-700">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {getTypeIcon(selectedWorkspace.type)}
                          <div>
                            <CardTitle className="text-blue-100">{selectedWorkspace.name}</CardTitle>
                            <CardDescription className="text-blue-300">
                              {selectedWorkspace.description}
                            </CardDescription>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <TooltipWrapper title="Open Workspace" type="action">
                            <SoundButton className="bg-blue-600 hover:bg-blue-500">
                              <FolderOpen className="h-4 w-4" />
                            </SoundButton>
                          </TooltipWrapper>
                          <TooltipWrapper title="Edit Workspace" type="action">
                            <SoundButton variant="outline" className="border-blue-600 text-blue-300">
                              <Edit3 className="h-4 w-4" />
                            </SoundButton>
                          </TooltipWrapper>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-blue-200">Project Statistics</Label>
                          <div className="space-y-1 text-sm text-blue-300">
                            <div className="flex justify-between">
                              <span>Files:</span>
                              <span>{selectedWorkspace.files}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Size:</span>
                              <span>{selectedWorkspace.size}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Type:</span>
                              <span className="capitalize">{selectedWorkspace.type}</span>
                            </div>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-blue-200">Last Activity</Label>
                          <div className="space-y-1 text-sm text-blue-300">
                            <div className="flex items-center gap-2">
                              <Clock className="h-3 w-3" />
                              <span>{selectedWorkspace.lastModified.toLocaleDateString()}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Users className="h-3 w-3" />
                              <span>{selectedWorkspace.collaborators.length} collaborators</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <Separator className="bg-blue-700" />
                      
                      <div className="space-y-2">
                        <Label className="text-blue-200">Tags</Label>
                        <div className="flex flex-wrap gap-2">
                          {selectedWorkspace.tags.map((tag) => (
                            <Badge key={tag} className="bg-blue-700/50 text-blue-200">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="settings" className="space-y-4 mt-4">
                  <Card className="bg-blue-900/30 border-blue-700">
                    <CardHeader>
                      <CardTitle className="text-blue-100 flex items-center gap-2">
                        <Settings className="h-5 w-5" />
                        Workspace Settings
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <Label className="text-blue-200">Auto Save</Label>
                            <p className="text-sm text-blue-400">Automatically save changes</p>
                          </div>
                          <Switch checked={selectedWorkspace.settings.autoSave} />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <Label className="text-blue-200">Version Control</Label>
                            <p className="text-sm text-blue-400">Enable Git integration</p>
                          </div>
                          <Switch checked={selectedWorkspace.settings.versionControl} />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <Label className="text-blue-200">Real-time Sync</Label>
                            <p className="text-sm text-blue-400">Live collaboration features</p>
                          </div>
                          <Switch checked={selectedWorkspace.settings.realTimeSync} />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <Label className="text-blue-200">Backup Enabled</Label>
                            <p className="text-sm text-blue-400">Automatic backups</p>
                          </div>
                          <Switch checked={selectedWorkspace.settings.backupEnabled} />
                        </div>
                      </div>
                      
                      <Separator className="bg-blue-700" />
                      
                      <div className="flex gap-2">
                        <TooltipWrapper title="Export Workspace" type="action">
                          <SoundButton variant="outline" className="border-blue-600 text-blue-300">
                            <Download className="h-4 w-4 mr-2" />
                            Export
                          </SoundButton>
                        </TooltipWrapper>
                        <TooltipWrapper title="Archive Workspace" type="action">
                          <SoundButton variant="outline" className="border-yellow-600 text-yellow-300">
                            <Archive className="h-4 w-4 mr-2" />
                            Archive
                          </SoundButton>
                        </TooltipWrapper>
                        <TooltipWrapper title="Delete Workspace" type="warning">
                          <SoundButton variant="outline" className="border-red-600 text-red-300">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </SoundButton>
                        </TooltipWrapper>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="collaboration" className="space-y-4 mt-4">
                  <Card className="bg-blue-900/30 border-blue-700">
                    <CardHeader>
                      <CardTitle className="text-blue-100 flex items-center gap-2">
                        <Users className="h-5 w-5" />
                        Team Collaboration
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-3">
                        {selectedWorkspace.collaborators.map((collaborator, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-blue-800/30 rounded-lg">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-blue-100 text-sm font-semibold">
                                {collaborator.split(' ').map(n => n[0]).join('')}
                              </div>
                              <div>
                                <p className="text-blue-100 font-medium">{collaborator}</p>
                                <p className="text-blue-400 text-sm">Editor</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 bg-green-500 rounded-full" />
                              <span className="text-blue-300 text-sm">Online</span>
                            </div>
                          </div>
                        ))}
                      </div>
                      
                      <div className="flex gap-2">
                        <Input
                          placeholder="Enter email to invite..."
                          className="flex-1 bg-blue-900/30 border-blue-700 text-blue-100"
                        />
                        <SoundButton className="bg-blue-600 hover:bg-blue-500">
                          Invite
                        </SoundButton>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="templates" className="space-y-4 mt-4">
                  <div className="grid grid-cols-2 gap-4">
                    {workspaceTemplates.map((template) => (
                      <Card key={template.id} className="bg-blue-900/30 border-blue-700 hover:bg-blue-800/30 transition-colors cursor-pointer">
                        <CardHeader>
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-blue-700/50 rounded-lg text-blue-200">
                              {template.icon}
                            </div>
                            <div>
                              <CardTitle className="text-blue-100 text-sm">{template.name}</CardTitle>
                              <CardDescription className="text-blue-300 text-xs">
                                {template.description}
                              </CardDescription>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <div className="flex flex-wrap gap-1">
                              {template.technologies.slice(0, 3).map((tech) => (
                                <Badge key={tech} variant="secondary" className="text-xs bg-blue-700/50 text-blue-200">
                                  {tech}
                                </Badge>
                              ))}
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-blue-400 text-xs">Setup: {template.estimatedTime}</span>
                              <SoundButton size="sm" className="bg-blue-600 hover:bg-blue-500 text-xs">
                                Use Template
                              </SoundButton>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            ) : (
              <div className="flex items-center justify-center h-full">
                <div className="text-center text-blue-300">
                  <FolderOpen className="h-16 w-16 mx-auto mb-4 text-blue-500" />
                  <h3 className="text-xl font-semibold mb-2">Select a Workspace</h3>
                  <p>Choose a workspace from the list to view details and manage settings.</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Create Workspace Dialog */}
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogContent className="bg-blue-950 border-blue-700">
            <DialogHeader>
              <DialogTitle className="text-blue-100">Create New Workspace</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="workspace-name" className="text-blue-200">Workspace Name</Label>
                <Input
                  id="workspace-name"
                  value={newWorkspaceName}
                  onChange={(e) => setNewWorkspaceName(e.target.value)}
                  placeholder="Enter workspace name..."
                  className="bg-blue-900/30 border-blue-700 text-blue-100"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-blue-200">Workspace Type</Label>
                <div className="grid grid-cols-3 gap-2">
                  {(['web', 'mobile', 'desktop', 'game', 'ai', 'data'] as const).map((type) => (
                    <SoundButton
                      key={type}
                      variant={newWorkspaceType === type ? "default" : "outline"}
                      className={`text-xs capitalize ${
                        newWorkspaceType === type 
                          ? 'bg-blue-600 text-blue-100' 
                          : 'border-blue-600 text-blue-300 hover:bg-blue-800/30'
                      }`}
                      onClick={() => setNewWorkspaceType(type)}
                    >
                      {getTypeIcon(type)}
                      <span className="ml-1">{type}</span>
                    </SoundButton>
                  ))}
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <SoundButton variant="outline" onClick={() => setShowCreateDialog(false)}>
                  Cancel
                </SoundButton>
                <SoundButton onClick={createWorkspace} disabled={!newWorkspaceName.trim()}>
                  Create Workspace
                </SoundButton>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </DialogContent>
    </Dialog>
  );
}