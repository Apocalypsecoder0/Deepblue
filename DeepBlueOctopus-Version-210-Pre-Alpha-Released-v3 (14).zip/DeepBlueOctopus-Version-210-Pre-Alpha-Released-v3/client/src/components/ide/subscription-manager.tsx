import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Crown, Check, X, Zap, Star, Code, Database, Palette, Bot, Shield } from "lucide-react";

interface SubscriptionManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  period: 'month' | 'year';
  features: string[];
  limitations: string[];
  popular?: boolean;
  current?: boolean;
}

interface UsageStats {
  compilations: { used: number; limit: number };
  aiRequests: { used: number; limit: number };
  projects: { used: number; limit: number };
  storage: { used: number; limit: number };
}

export default function SubscriptionManager({ isOpen, onClose }: SubscriptionManagerProps) {
  const [activeTab, setActiveTab] = useState<'plans' | 'usage' | 'billing'>('plans');
  const [currentPlan, setCurrentPlan] = useState<'free' | 'gold' | 'platinum'>('free');
  const [isUpgrading, setIsUpgrading] = useState(false);

  const plans: SubscriptionPlan[] = [
    {
      id: 'free',
      name: 'DeepBlue Free',
      price: 0,
      period: 'month',
      current: currentPlan === 'free',
      features: [
        '3 Projects',
        '50 MB Storage',
        'Basic AI Assistant (25 requests/day)',
        'Core programming languages (5)',
        'Standard code editor',
        'Basic file explorer',
        'Terminal with basic execution',
        'Community support',
        'Basic themes (3)',
        'File operations (save, open)',
        'Basic syntax highlighting',
        'Standard debugging',
        'Core IDE functionality'
      ],
      limitations: [
        'Limited storage and projects',
        'Restricted AI features',
        'No advanced tools',
        'Basic support only',
        'Limited customization'
      ]
    },
    {
      id: 'gold',
      name: 'DeepBlue Gold',
      price: 19.99,
      period: 'month',
      popular: true,
      current: currentPlan === 'gold',
      features: [
        '25 Projects',
        '5 GB Storage',
        'Enhanced AI Assistant (500 requests/day)',
        'Extended programming languages (15)',
        'Multi-terminal support',
        'Advanced code editor with IntelliSense',
        'Version control (Git integration)',
        'Database tools',
        'Code analysis & linting',
        'Custom themes (20+)',
        'Advanced debugging',
        'File operations with cloud sync',
        'Basic game engine',
        'UML designer (basic)',
        'Mobile framework (basic)',
        'Performance monitoring',
        'Real-time collaboration',
        'Priority support',
        '~35% of professional tools'
      ],
      limitations: [
        'Limited advanced features',
        'Restricted enterprise tools',
        'No premium exports',
        'Standard support response'
      ]
    },
    {
      id: 'platinum',
      name: 'DeepBlue Platinum',
      price: 49.99,
      period: 'month',
      current: currentPlan === 'platinum',
      features: [
        'Unlimited Projects',
        '50 GB Storage',
        'Premium AI Assistant (Unlimited requests)',
        'All programming languages (25+)',
        'Advanced multi-terminal with system monitoring',
        'Professional code editor suite',
        'Complete version control & GitHub integration',
        'Advanced database management',
        'Full game engine with exports',
        'Complete UML & architecture tools',
        '2D/3D object studio',
        'Audio/video editing suite',
        'Mathematics library (full)',
        'All mobile frameworks',
        'Advanced performance analytics',
        'Enterprise security features',
        'Custom plugin development',
        'API access & webhooks',
        'Advanced collaboration tools',
        'AutoCAD blueprint system',
        'Server management console',
        'Advanced error logging & analytics',
        'Custom themes & unlimited customization',
        'Priority enterprise support',
        '100% of all professional tools',
        'Early access to new features',
        'White-label options'
      ],
      limitations: []
    }
  ];

  const usageStats: UsageStats = {
    compilations: { 
      used: 147, 
      limit: currentPlan === 'free' ? 200 : 
             currentPlan === 'gold' ? 2000 : Infinity 
    },
    aiRequests: { 
      used: 18, 
      limit: currentPlan === 'free' ? 25 : 
             currentPlan === 'gold' ? 500 : Infinity 
    },
    projects: { 
      used: 2, 
      limit: currentPlan === 'free' ? 3 : 
             currentPlan === 'gold' ? 25 : Infinity 
    },
    storage: { 
      used: 25, 
      limit: currentPlan === 'free' ? 50 : 
             currentPlan === 'gold' ? 5000 : 50000 
    }
  };

  const handleUpgrade = async (planId: string) => {
    if (planId === 'free') return;

    setIsUpgrading(true);
    
    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setCurrentPlan(planId as 'gold' | 'platinum');
    setIsUpgrading(false);
    
    const planName = planId === 'gold' ? 'DeepBlue Gold' : 'DeepBlue Platinum';
    alert(`Successfully upgraded to ${planName}!`);
  };

  const getUsagePercentage = (used: number, limit: number) => {
    if (limit === Infinity) return 0;
    return Math.min((used / limit) * 100, 100);
  };

  const getUsageColor = (percentage: number) => {
    if (percentage >= 90) return 'bg-red-500';
    if (percentage >= 70) return 'bg-yellow-500';
    return 'bg-[var(--bioluminescent)]';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[85vh] bg-[var(--ide-bg)] border-[var(--ide-border)]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-[var(--ide-text)]">
            <Crown className="w-5 h-5 text-yellow-500" />
            Subscription Management
          </DialogTitle>
          <DialogDescription className="text-[var(--ide-text-secondary)]">
            Manage your DeepBlue:Octopus subscription and usage
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)} className="h-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="plans" className="flex items-center gap-2">
              <Crown className="w-4 h-4" />
              Plans
            </TabsTrigger>
            <TabsTrigger value="usage" className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              Usage
            </TabsTrigger>
            <TabsTrigger value="billing" className="flex items-center gap-2">
              <Star className="w-4 h-4" />
              Billing
            </TabsTrigger>
          </TabsList>

          <TabsContent value="plans" className="h-full space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {plans.map((plan) => (
                <Card 
                  key={plan.id} 
                  className={`relative border-2 ${
                    plan.current 
                      ? 'border-[var(--bioluminescent)] bg-[var(--bioluminescent)]/5' 
                      : plan.popular 
                        ? 'border-yellow-500/50 bg-gradient-to-br from-yellow-500/5 to-orange-500/5'
                        : 'border-[var(--ide-border)]'
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black">
                        Most Popular
                      </Badge>
                    </div>
                  )}
                  
                  {plan.current && (
                    <div className="absolute -top-3 right-4">
                      <Badge className="bg-[var(--bioluminescent)]">
                        Current Plan
                      </Badge>
                    </div>
                  )}

                  <CardHeader className="text-center pb-4">
                    <CardTitle className="flex items-center justify-center gap-2 text-[var(--ide-text)]">
                      {plan.id === 'platinum' ? (
                        <Crown className="w-6 h-6 text-purple-500" />
                      ) : plan.id === 'gold' ? (
                        <Star className="w-6 h-6 text-yellow-500" />
                      ) : (
                        <Shield className="w-6 h-6 text-blue-500" />
                      )}
                      {plan.name}
                    </CardTitle>
                    <div className="space-y-2">
                      <div className="text-3xl font-bold text-[var(--ide-text)]">
                        ${plan.price}
                        <span className="text-lg font-normal text-[var(--ide-text-secondary)]">
                          /{plan.period}
                        </span>
                      </div>
                      {(plan.id === 'gold' || plan.id === 'platinum') && (
                        <p className="text-sm text-[var(--ide-text-secondary)]">
                          Billed monthly • Cancel anytime
                        </p>
                      )}
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <h4 className="font-medium text-[var(--ide-text)] flex items-center gap-2">
                        <Check className="w-4 h-4 text-green-500" />
                        Included Features
                      </h4>
                      <ul className="space-y-2">
                        {plan.features.map((feature, index) => (
                          <li key={index} className="flex items-center gap-2 text-sm text-[var(--ide-text-secondary)]">
                            <Check className="w-3 h-3 text-green-500 flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {plan.limitations.length > 0 && (
                      <div className="space-y-3">
                        <h4 className="font-medium text-[var(--ide-text)] flex items-center gap-2">
                          <X className="w-4 h-4 text-red-500" />
                          Limitations
                        </h4>
                        <ul className="space-y-2">
                          {plan.limitations.map((limitation, index) => (
                            <li key={index} className="flex items-center gap-2 text-sm text-[var(--ide-text-secondary)]">
                              <X className="w-3 h-3 text-red-500 flex-shrink-0" />
                              {limitation}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="pt-4">
                      {plan.current ? (
                        <Button disabled className="w-full">
                          Current Plan
                        </Button>
                      ) : plan.id === 'pro' ? (
                        <Button
                          onClick={() => handleUpgrade(plan.id)}
                          disabled={isUpgrading}
                          className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-medium"
                        >
                          {isUpgrading ? (
                            <>
                              <Zap className="w-4 h-4 mr-2 animate-spin" />
                              Processing...
                            </>
                          ) : (
                            <>
                              <Crown className="w-4 h-4 mr-2" />
                              Upgrade to Pro
                            </>
                          )}
                        </Button>
                      ) : (
                        <Button variant="outline" className="w-full">
                          Current Plan
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {currentPlan === 'free' && (
              <Alert>
                <Crown className="h-4 w-4" />
                <AlertDescription>
                  <strong>Upgrade to Pro</strong> to unlock advanced features like unlimited AI requests, 
                  game engine exports, advanced debugging, and professional development tools.
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>

          <TabsContent value="usage" className="h-full space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="border-[var(--ide-border)]">
                <CardHeader>
                  <CardTitle className="text-[var(--ide-text)] flex items-center gap-2">
                    <Code className="w-5 h-5" />
                    Compilations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-[var(--ide-text-secondary)]">This month</span>
                      <span className="text-[var(--ide-text)]">
                        {usageStats.compilations.used} / {
                          usageStats.compilations.limit === Infinity 
                            ? '∞' 
                            : usageStats.compilations.limit
                        }
                      </span>
                    </div>
                    <Progress 
                      value={getUsagePercentage(usageStats.compilations.used, usageStats.compilations.limit)}
                      className="h-2"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-[var(--ide-border)]">
                <CardHeader>
                  <CardTitle className="text-[var(--ide-text)] flex items-center gap-2">
                    <Bot className="w-5 h-5" />
                    AI Requests
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-[var(--ide-text-secondary)]">Today</span>
                      <span className="text-[var(--ide-text)]">
                        {usageStats.aiRequests.used} / {
                          usageStats.aiRequests.limit === Infinity 
                            ? '∞' 
                            : usageStats.aiRequests.limit
                        }
                      </span>
                    </div>
                    <Progress 
                      value={getUsagePercentage(usageStats.aiRequests.used, usageStats.aiRequests.limit)}
                      className="h-2"
                    />
                    {currentPlan === 'free' && usageStats.aiRequests.used >= 45 && (
                      <p className="text-xs text-yellow-600">
                        You're approaching your daily limit. Upgrade to Pro for unlimited requests.
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-[var(--ide-border)]">
                <CardHeader>
                  <CardTitle className="text-[var(--ide-text)] flex items-center gap-2">
                    <Palette className="w-5 h-5" />
                    Projects
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-[var(--ide-text-secondary)]">Active</span>
                      <span className="text-[var(--ide-text)]">
                        {usageStats.projects.used} / {
                          usageStats.projects.limit === Infinity 
                            ? '∞' 
                            : usageStats.projects.limit
                        }
                      </span>
                    </div>
                    <Progress 
                      value={getUsagePercentage(usageStats.projects.used, usageStats.projects.limit)}
                      className="h-2"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-[var(--ide-border)]">
                <CardHeader>
                  <CardTitle className="text-[var(--ide-text)] flex items-center gap-2">
                    <Database className="w-5 h-5" />
                    Storage
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-[var(--ide-text-secondary)]">Used</span>
                      <span className="text-[var(--ide-text)]">
                        {usageStats.storage.used} MB / {
                          usageStats.storage.limit === Infinity 
                            ? '∞' 
                            : `${usageStats.storage.limit} MB`
                        }
                      </span>
                    </div>
                    <Progress 
                      value={getUsagePercentage(usageStats.storage.used, usageStats.storage.limit)}
                      className="h-2"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {currentPlan === 'free' && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-[var(--ide-text)]">Usage Recommendations</h3>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <Alert>
                    <Zap className="h-4 w-4" />
                    <AlertDescription>
                      You're using {Math.round(getUsagePercentage(usageStats.aiRequests.used, usageStats.aiRequests.limit))}% 
                      of your daily AI requests. Consider upgrading for unlimited access.
                    </AlertDescription>
                  </Alert>
                  
                  <Alert>
                    <Database className="h-4 w-4" />
                    <AlertDescription>
                      You're using {Math.round(getUsagePercentage(usageStats.storage.used, usageStats.storage.limit))}% 
                      of your storage. Pro plan includes 100x more storage.
                    </AlertDescription>
                  </Alert>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="billing" className="h-full space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="border-[var(--ide-border)]">
                <CardHeader>
                  <CardTitle className="text-[var(--ide-text)]">Current Subscription</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[var(--ide-text-secondary)]">Plan:</span>
                    <div className="flex items-center gap-2">
                      {currentPlan === 'platinum' ? (
                        <>
                          <Crown className="w-4 h-4 text-purple-500" />
                          <span className="text-[var(--ide-text)]">DeepBlue Platinum</span>
                        </>
                      ) : currentPlan === 'gold' ? (
                        <>
                          <Star className="w-4 h-4 text-yellow-500" />
                          <span className="text-[var(--ide-text)]">DeepBlue Gold</span>
                        </>
                      ) : (
                        <>
                          <Shield className="w-4 h-4 text-blue-500" />
                          <span className="text-[var(--ide-text)]">DeepBlue Free</span>
                        </>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-[var(--ide-text-secondary)]">Price:</span>
                    <span className="text-[var(--ide-text)]">
                      ${currentPlan === 'platinum' ? '49.99' : currentPlan === 'gold' ? '19.99' : '0.00'}/month
                    </span>
                  </div>
                  
                  {(currentPlan === 'gold' || currentPlan === 'platinum') && (
                    <>
                      <div className="flex items-center justify-between">
                        <span className="text-[var(--ide-text-secondary)]">Next billing:</span>
                        <span className="text-[var(--ide-text)]">Jan 15, 2025</span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-[var(--ide-text-secondary)]">Payment method:</span>
                        <span className="text-[var(--ide-text)]">•••• 4242</span>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              <Card className="border-[var(--ide-border)]">
                <CardHeader>
                  <CardTitle className="text-[var(--ide-text)]">Billing History</CardTitle>
                </CardHeader>
                <CardContent>
                  {(currentPlan === 'gold' || currentPlan === 'platinum') ? (
                    <div className="space-y-3">
                      <div className="flex justify-between items-center py-2 border-b border-[var(--ide-border)]">
                        <div>
                          <p className="text-sm text-[var(--ide-text)]">
                            {currentPlan === 'platinum' ? 'DeepBlue Platinum' : 'DeepBlue Gold'}
                          </p>
                          <p className="text-xs text-[var(--ide-text-secondary)]">Dec 15, 2024</p>
                        </div>
                        <span className="text-[var(--ide-text)]">
                          ${currentPlan === 'platinum' ? '49.99' : '19.99'}
                        </span>
                      </div>
                      
                      <div className="flex justify-between items-center py-2 border-b border-[var(--ide-border)]">
                        <div>
                          <p className="text-sm text-[var(--ide-text)]">DeepBlue Pro</p>
                          <p className="text-xs text-[var(--ide-text-secondary)]">Nov 15, 2024</p>
                        </div>
                        <span className="text-[var(--ide-text)]">$9.99</span>
                      </div>
                    </div>
                  ) : (
                    <p className="text-[var(--ide-text-secondary)] text-center py-8">
                      No billing history available for free plan
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>

            {(currentPlan === 'gold' || currentPlan === 'platinum') && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-[var(--ide-text)]">Manage Subscription</h3>
                <div className="flex gap-4">
                  <Button variant="outline">
                    Update Payment Method
                  </Button>
                  <Button variant="outline">
                    Download Invoice
                  </Button>
                  <Button variant="destructive">
                    Cancel Subscription
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}