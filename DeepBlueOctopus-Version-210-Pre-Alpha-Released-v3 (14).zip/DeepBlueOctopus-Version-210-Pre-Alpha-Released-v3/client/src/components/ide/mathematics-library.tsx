import { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SoundButton } from "@/components/ui/sound-system";
import { TooltipWrapper } from "@/components/ui/tooltip-system";
import {
  Calculator,
  BookOpen,
  GraduationCap,
  TrendingUp,
  PieChart,
  Activity,
  Zap,
  Brain,
  Target,
  Lightbulb,
  Download,
  Upload,
  Save,
  Copy,
  Play,
  RotateCcw,
  Settings,
  Info,
  Code,
  FileText,
  ChevronRight,
  ChevronDown,
  Star,
  Clock,
  Award,
  Search,
  Filter,
  Cpu,
  Sigma,
  Infinity,
  BarChart3,
  Atom,
  Orbit,
  Waves,
  Zap as Lightning,
  Triangle,
  Circle,
  Square,
  Function,
  Binary,
  GitBranch,
  Layers,
  FlaskConical,
  Microscope,
  Telescope,
  Gauge,
  Radio,
  Magnet
} from "lucide-react";

interface MathematicsLibraryProps {
  isOpen: boolean;
  onClose: () => void;
}

interface MathematicalConcept {
  id: string;
  name: string;
  mathematician: string;
  level: 'elementary' | 'high_school' | 'college' | 'university';
  category: string;
  description: string;
  formula?: string;
  example: string;
  code: string;
  difficulty: 1 | 2 | 3 | 4 | 5;
  prerequisites: string[];
  applications: string[];
  visualization?: string;
  timeToLearn: string;
  interactiveDemo: boolean;
}

interface Mathematician {
  name: string;
  period: string;
  nationality: string;
  contributions: string[];
  biography: string;
  famousWorks: string[];
}

export default function MathematicsLibrary({ isOpen, onClose }: MathematicsLibraryProps) {
  const [activeLevel, setActiveLevel] = useState<MathematicalConcept['level']>('elementary');
  const [selectedConcept, setSelectedConcept] = useState<MathematicalConcept | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [expandedConcepts, setExpandedConcepts] = useState<Set<string>>(new Set());
  const [codeOutput, setCodeOutput] = useState<string>("");
  const [showMathematician, setShowMathematician] = useState<Mathematician | null>(null);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const mathematicalConcepts: MathematicalConcept[] = [
    // Algorithms and Logic
    {
      id: 'sorting-algorithms',
      name: 'Sorting Algorithms',
      mathematician: 'Various',
      level: 'university',
      category: 'Algorithms',
      description: 'Comprehensive collection of sorting algorithms including Bubble Sort, Quick Sort, Merge Sort, and Heap Sort with complexity analysis.',
      formula: 'Time Complexity: O(n²) to O(n log n), Space Complexity: O(1) to O(n)',
      example: 'Quick Sort: [64, 34, 25, 12] → [12, 25, 34, 64]',
      code: `def bubble_sort(arr):
    """Bubble Sort: O(n²) time, O(1) space"""
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
    return arr

def quick_sort(arr):
    """Quick Sort: O(n log n) average, O(n²) worst case"""
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quick_sort(left) + middle + quick_sort(right)

def merge_sort(arr):
    """Merge Sort: O(n log n) time, O(n) space"""
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    return merge(left, right)

def merge(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result

# Algorithm analysis
import time
import random

def algorithm_performance_test():
    data = [random.randint(1, 1000) for _ in range(100)]
    
    # Test Bubble Sort
    start = time.time()
    bubble_sorted = bubble_sort(data.copy())
    bubble_time = time.time() - start
    
    # Test Quick Sort
    start = time.time()
    quick_sorted = quick_sort(data.copy())
    quick_time = time.time() - start
    
    # Test Merge Sort
    start = time.time()
    merge_sorted = merge_sort(data.copy())
    merge_time = time.time() - start
    
    print(f"Bubble Sort: {bubble_time:.6f}s")
    print(f"Quick Sort: {quick_time:.6f}s")
    print(f"Merge Sort: {merge_time:.6f}s")

algorithm_performance_test()`,
      difficulty: 4,
      prerequisites: ['Programming fundamentals', 'Big O notation', 'Recursion'],
      applications: ['Database systems', 'Search engines', 'Data processing'],
      timeToLearn: '2-3 weeks',
      interactiveDemo: true
    },
    {
      id: 'graph-algorithms',
      name: 'Graph Algorithms',
      mathematician: 'Dijkstra, Floyd-Warshall',
      level: 'university',
      category: 'Algorithms',
      description: 'Essential graph algorithms including Breadth-First Search, Depth-First Search, Dijkstra\'s shortest path, and minimum spanning trees.',
      formula: 'Dijkstra: O((V + E) log V), BFS/DFS: O(V + E)',
      example: 'Find shortest path from A to D in weighted graph',
      code: `import heapq
from collections import defaultdict, deque

class Graph:
    def __init__(self):
        self.vertices = defaultdict(list)
        self.weights = {}
    
    def add_edge(self, u, v, weight=1):
        self.vertices[u].append(v)
        self.vertices[v].append(u)  # For undirected graph
        self.weights[(u, v)] = weight
        self.weights[(v, u)] = weight

def dijkstra(graph, start):
    """Dijkstra's shortest path algorithm"""
    distances = defaultdict(lambda: float('inf'))
    distances[start] = 0
    priority_queue = [(0, start)]
    visited = set()
    
    while priority_queue:
        current_distance, current = heapq.heappop(priority_queue)
        
        if current in visited:
            continue
        visited.add(current)
        
        for neighbor in graph.vertices[current]:
            weight = graph.weights.get((current, neighbor), 1)
            distance = current_distance + weight
            
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(priority_queue, (distance, neighbor))
    
    return dict(distances)

def bfs(graph, start, target=None):
    """Breadth-First Search"""
    visited = set()
    queue = deque([start])
    path = []
    
    while queue:
        vertex = queue.popleft()
        if vertex not in visited:
            visited.add(vertex)
            path.append(vertex)
            
            if vertex == target:
                return path
            
            for neighbor in graph.vertices[vertex]:
                if neighbor not in visited:
                    queue.append(neighbor)
    
    return path

def dfs(graph, start, visited=None, path=None):
    """Depth-First Search"""
    if visited is None:
        visited = set()
    if path is None:
        path = []
    
    visited.add(start)
    path.append(start)
    
    for neighbor in graph.vertices[start]:
        if neighbor not in visited:
            dfs(graph, neighbor, visited, path)
    
    return path

# Example usage
g = Graph()
g.add_edge('A', 'B', 4)
g.add_edge('A', 'C', 2)
g.add_edge('B', 'C', 1)
g.add_edge('B', 'D', 5)
g.add_edge('C', 'D', 8)

distances = dijkstra(g, 'A')
print("Shortest distances from A:", distances)

bfs_path = bfs(g, 'A', 'D')
print("BFS path from A to D:", bfs_path)`,
      difficulty: 5,
      prerequisites: ['Data structures', 'Graph theory', 'Dynamic programming'],
      applications: ['GPS navigation', 'Social networks', 'Network routing'],
      timeToLearn: '3-4 weeks',
      interactiveDemo: true
    },
    {
      id: 'logic-functions',
      name: 'Boolean Logic & Propositional Calculus',
      mathematician: 'George Boole',
      level: 'university',
      category: 'Logic',
      description: 'Boolean algebra, truth tables, logical operators, and propositional logic for computer science and mathematics.',
      formula: 'AND: p ∧ q, OR: p ∨ q, NOT: ¬p, IMPLIES: p → q, BICONDITIONAL: p ↔ q',
      example: '(p ∧ q) ∨ (¬p ∧ r) → s',
      code: `class LogicSystem:
    """Boolean Logic and Propositional Calculus System"""
    
    @staticmethod
    def AND(p, q):
        return p and q
    
    @staticmethod
    def OR(p, q):
        return p or q
    
    @staticmethod
    def NOT(p):
        return not p
    
    @staticmethod
    def IMPLIES(p, q):
        return (not p) or q
    
    @staticmethod
    def BICONDITIONAL(p, q):
        return (p and q) or ((not p) and (not q))
    
    @staticmethod
    def XOR(p, q):
        return (p and not q) or (not p and q)
    
    @staticmethod
    def NAND(p, q):
        return not (p and q)
    
    @staticmethod
    def NOR(p, q):
        return not (p or q)

def generate_truth_table(variables, expression_func):
    """Generate truth table for a logical expression"""
    n = len(variables)
    rows = 2 ** n
    
    print("Truth Table:")
    print("|".join(f" {var} " for var in variables) + "| Result |")
    print("-" * (4 * len(variables) + 9))
    
    for i in range(rows):
        values = []
        for j in range(n):
            values.append((i >> (n - 1 - j)) & 1 == 1)
        
        result = expression_func(*values)
        
        value_str = "|".join(f" {int(v)} " for v in values)
        print(f"{value_str}|   {int(result)}   |")

def satisfiability_solver(variables, clauses):
    """Simple SAT solver using brute force"""
    n = len(variables)
    
    for i in range(2 ** n):
        assignment = {}
        for j, var in enumerate(variables):
            assignment[var] = (i >> (n - 1 - j)) & 1 == 1
        
        if all(evaluate_clause(clause, assignment) for clause in clauses):
            return assignment
    
    return None  # UNSAT

def evaluate_clause(clause, assignment):
    """Evaluate a clause given variable assignment"""
    return any(assignment[abs(literal)] if literal > 0 
              else not assignment[abs(literal)] 
              for literal in clause)

# Example: De Morgan's Laws
def de_morgan_example():
    logic = LogicSystem()
    
    print("De Morgan's Laws Verification:")
    print("¬(p ∧ q) ≡ (¬p ∨ ¬q)")
    
    for p in [True, False]:
        for q in [True, False]:
            left = logic.NOT(logic.AND(p, q))
            right = logic.OR(logic.NOT(p), logic.NOT(q))
            print(f"p={p}, q={q}: {left} ≡ {right} → {left == right}")

# Propositional logic example
def complex_logic_example(p, q, r, s):
    logic = LogicSystem()
    # (p ∧ q) ∨ (¬p ∧ r) → s
    antecedent = logic.OR(
        logic.AND(p, q),
        logic.AND(logic.NOT(p), r)
    )
    return logic.IMPLIES(antecedent, s)

generate_truth_table(['p', 'q', 'r', 's'], complex_logic_example)
de_morgan_example()`,
      difficulty: 4,
      prerequisites: ['Discrete mathematics', 'Set theory', 'Basic programming'],
      applications: ['Computer circuits', 'Database queries', 'AI reasoning'],
      timeToLearn: '2-3 weeks',
      interactiveDemo: true
    },
    {
      id: 'physics-mechanics',
      name: 'Classical Mechanics & Physics Equations',
      mathematician: 'Newton, Galileo',
      level: 'university',
      category: 'Physics',
      description: 'Fundamental physics equations for motion, force, energy, and momentum with computational solutions.',
      formula: 'F = ma, E = ½mv², p = mv, s = ut + ½at²',
      example: 'Ball thrown upward: v₀ = 20 m/s, find maximum height',
      code: `import math
import numpy as np
import matplotlib.pyplot as plt

class PhysicsCalculator:
    """Classical Mechanics and Physics Equations"""
    
    def __init__(self):
        self.g = 9.81  # Gravity (m/s²)
        self.c = 299792458  # Speed of light (m/s)
    
    def kinematic_motion(self, u, a, t):
        """Kinematic equations of motion"""
        v = u + a * t  # Final velocity
        s = u * t + 0.5 * a * t**2  # Displacement
        v_squared = u**2 + 2 * a * s  # v² = u² + 2as
        
        return {
            'final_velocity': v,
            'displacement': s,
            'velocity_check': math.sqrt(v_squared) if v_squared >= 0 else None
        }
    
    def projectile_motion(self, v0, angle_deg, height=0):
        """Projectile motion calculations"""
        angle_rad = math.radians(angle_deg)
        v0x = v0 * math.cos(angle_rad)
        v0y = v0 * math.sin(angle_rad)
        
        # Time of flight
        discriminant = v0y**2 + 2 * self.g * height
        t_flight = (v0y + math.sqrt(discriminant)) / self.g
        
        # Maximum height
        h_max = height + (v0y**2) / (2 * self.g)
        
        # Range
        range_x = v0x * t_flight
        
        return {
            'time_of_flight': t_flight,
            'maximum_height': h_max,
            'range': range_x,
            'initial_velocity_x': v0x,
            'initial_velocity_y': v0y
        }
    
    def energy_calculations(self, mass, velocity, height):
        """Energy calculations: kinetic, potential, total"""
        kinetic_energy = 0.5 * mass * velocity**2
        potential_energy = mass * self.g * height
        total_energy = kinetic_energy + potential_energy
        
        return {
            'kinetic_energy': kinetic_energy,
            'potential_energy': potential_energy,
            'total_energy': total_energy
        }
    
    def circular_motion(self, radius, velocity=None, period=None, frequency=None):
        """Circular motion calculations"""
        if velocity:
            omega = velocity / radius
            period_calc = 2 * math.pi / omega
            centripetal_acc = velocity**2 / radius
        elif period:
            omega = 2 * math.pi / period
            velocity = omega * radius
            centripetal_acc = velocity**2 / radius
        elif frequency:
            omega = 2 * math.pi * frequency
            velocity = omega * radius
            centripetal_acc = velocity**2 / radius
        else:
            raise ValueError("Provide velocity, period, or frequency")
        
        return {
            'angular_velocity': omega,
            'linear_velocity': velocity,
            'period': period_calc if velocity else period,
            'frequency': omega / (2 * math.pi),
            'centripetal_acceleration': centripetal_acc
        }
    
    def wave_mechanics(self, frequency, wavelength=None, velocity=None):
        """Wave equation: v = fλ"""
        if wavelength and not velocity:
            velocity = frequency * wavelength
        elif velocity and not wavelength:
            wavelength = velocity / frequency
        elif not wavelength and not velocity:
            raise ValueError("Provide either wavelength or velocity")
        
        period = 1 / frequency
        angular_frequency = 2 * math.pi * frequency
        
        return {
            'velocity': velocity,
            'wavelength': wavelength,
            'period': period,
            'angular_frequency': angular_frequency
        }
    
    def electromagnetic_equations(self, electric_field=None, magnetic_field=None, 
                                charge=None, velocity=None):
        """Electromagnetic force calculations"""
        results = {}
        
        if electric_field and charge:
            electric_force = charge * electric_field
            results['electric_force'] = electric_force
        
        if magnetic_field and charge and velocity:
            magnetic_force = charge * velocity * magnetic_field  # Simplified for perpendicular B and v
            results['magnetic_force'] = magnetic_force
        
        if electric_field and magnetic_field:
            results['electromagnetic_wave_velocity'] = electric_field / magnetic_field
        
        return results
    
    def relativity_basics(self, velocity):
        """Special relativity calculations"""
        if velocity >= self.c:
            raise ValueError("Velocity must be less than speed of light")
        
        gamma = 1 / math.sqrt(1 - (velocity / self.c)**2)
        
        return {
            'lorentz_factor': gamma,
            'time_dilation_factor': gamma,
            'length_contraction_factor': 1 / gamma,
            'relativistic_momentum_factor': gamma
        }

# Example calculations
physics = PhysicsCalculator()

# Projectile motion example
projectile = physics.projectile_motion(v0=30, angle_deg=45, height=10)
print("Projectile Motion Results:")
for key, value in projectile.items():
    print(f"{key}: {value:.2f}")

# Energy conservation example
energy = physics.energy_calculations(mass=2, velocity=10, height=5)
print("\nEnergy Calculations:")
for key, value in energy.items():
    print(f"{key}: {value:.2f} J")

# Wave mechanics
wave = physics.wave_mechanics(frequency=440, velocity=343)  # Sound wave
print(f"\nSound wave at 440 Hz: wavelength = {wave['wavelength']:.3f} m")`,
      difficulty: 4,
      prerequisites: ['Calculus', 'Vector mathematics', 'Differential equations'],
      applications: ['Engineering design', 'Aerospace', 'Robotics', 'Game physics'],
      timeToLearn: '4-6 weeks',
      interactiveDemo: true
    },
    // Elementary Level
    {
      id: 'archimedes-area',
      name: 'Areas and Volume',
      mathematician: 'Archimedes',
      level: 'elementary',
      category: 'Geometry',
      description: 'Calculate areas of circles, rectangles, and volumes of cylinders and spheres using Archimedes\' methods.',
      formula: 'Circle Area: A = πr², Sphere Volume: V = (4/3)πr³',
      example: 'Circle with radius 5: Area = π × 5² = 25π ≈ 78.54',
      code: `def circle_area(radius):
    """Calculate the area of a circle using Archimedes' method"""
    import math
    return math.pi * radius ** 2

def sphere_volume(radius):
    """Calculate the volume of a sphere"""
    import math
    return (4/3) * math.pi * radius ** 3

def cylinder_volume(radius, height):
    """Calculate the volume of a cylinder"""
    import math
    return math.pi * radius ** 2 * height

# Example usage
r = 5
print(f"Circle area with radius {r}: {circle_area(r):.2f}")
print(f"Sphere volume with radius {r}: {sphere_volume(r):.2f}")`,
      difficulty: 2,
      prerequisites: ['Basic arithmetic', 'Understanding of π'],
      applications: ['Engineering design', 'Architecture', 'Manufacturing'],
      timeToLearn: '1-2 hours',
      interactiveDemo: true
    },
    {
      id: 'pythagoras-theorem',
      name: 'Pythagorean Theorem',
      mathematician: 'Pythagoras',
      level: 'elementary',
      category: 'Geometry',
      description: 'Find the length of the hypotenuse in right triangles using the famous theorem a² + b² = c².',
      formula: 'a² + b² = c²',
      example: 'Triangle with sides 3 and 4: c² = 3² + 4² = 9 + 16 = 25, so c = 5',
      code: `def pythagorean_theorem(a, b):
    """Calculate hypotenuse using Pythagorean theorem"""
    import math
    return math.sqrt(a**2 + b**2)

def is_right_triangle(a, b, c):
    """Check if three sides form a right triangle"""
    sides = sorted([a, b, c])
    return abs(sides[0]**2 + sides[1]**2 - sides[2]**2) < 0.001

# Example usage
a, b = 3, 4
c = pythagorean_theorem(a, b)
print(f"Triangle with sides {a} and {b} has hypotenuse {c}")
print(f"Is (3,4,5) a right triangle? {is_right_triangle(3, 4, 5)}")`,
      difficulty: 1,
      prerequisites: ['Basic arithmetic', 'Square roots'],
      applications: ['Construction', 'Navigation', 'Distance calculations'],
      timeToLearn: '30 minutes',
      interactiveDemo: true
    },
    {
      id: 'fibonacci-sequence',
      name: 'Fibonacci Sequence',
      mathematician: 'Fibonacci',
      level: 'elementary',
      category: 'Number Theory',
      description: 'Generate the famous sequence where each number is the sum of the two preceding ones.',
      formula: 'F(n) = F(n-1) + F(n-2), where F(0) = 0, F(1) = 1',
      example: '0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89...',
      code: `def fibonacci_recursive(n):
    """Calculate nth Fibonacci number recursively"""
    if n <= 1:
        return n
    return fibonacci_recursive(n-1) + fibonacci_recursive(n-2)

def fibonacci_iterative(n):
    """Calculate nth Fibonacci number iteratively (more efficient)"""
    if n <= 1:
        return n
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

def fibonacci_sequence(count):
    """Generate first 'count' Fibonacci numbers"""
    sequence = []
    for i in range(count):
        sequence.append(fibonacci_iterative(i))
    return sequence

# Example usage
print("First 10 Fibonacci numbers:", fibonacci_sequence(10))
print("20th Fibonacci number:", fibonacci_iterative(20))`,
      difficulty: 2,
      prerequisites: ['Basic arithmetic', 'Sequence understanding'],
      applications: ['Nature patterns', 'Art and design', 'Computer algorithms'],
      timeToLearn: '45 minutes',
      interactiveDemo: true
    },

    // High School Level
    {
      id: 'descartes-coordinates',
      name: 'Cartesian Coordinate System',
      mathematician: 'Descartes',
      level: 'high_school',
      category: 'Analytic Geometry',
      description: 'Plot points, find distances, and work with linear equations in the coordinate plane.',
      formula: 'Distance: d = √[(x₂-x₁)² + (y₂-y₁)²], Slope: m = (y₂-y₁)/(x₂-x₁)',
      example: 'Distance between (1,2) and (4,6): d = √[(4-1)² + (6-2)²] = √[9+16] = 5',
      code: `import math
import matplotlib.pyplot as plt

def distance_between_points(x1, y1, x2, y2):
    """Calculate distance between two points"""
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

def slope_between_points(x1, y1, x2, y2):
    """Calculate slope between two points"""
    if x2 - x1 == 0:
        return float('inf')  # Vertical line
    return (y2 - y1) / (x2 - x1)

def linear_equation(x1, y1, x2, y2):
    """Get linear equation in slope-intercept form y = mx + b"""
    m = slope_between_points(x1, y1, x2, y2)
    if m == float('inf'):
        return f"x = {x1}"  # Vertical line
    b = y1 - m * x1
    return f"y = {m:.2f}x + {b:.2f}"

def plot_points_and_line(points):
    """Plot points and connecting line"""
    x_coords = [p[0] for p in points]
    y_coords = [p[1] for p in points]
    
    plt.figure(figsize=(8, 6))
    plt.scatter(x_coords, y_coords, color='red', s=100)
    plt.plot(x_coords, y_coords, 'b-', alpha=0.7)
    plt.grid(True)
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.title('Cartesian Coordinate System')
    plt.show()

# Example usage
p1, p2 = (1, 2), (4, 6)
dist = distance_between_points(*p1, *p2)
slope = slope_between_points(*p1, *p2)
equation = linear_equation(*p1, *p2)
print(f"Distance: {dist}")
print(f"Slope: {slope}")
print(f"Equation: {equation}")`,
      difficulty: 3,
      prerequisites: ['Basic algebra', 'Geometry fundamentals'],
      applications: ['GPS navigation', 'Computer graphics', 'Engineering design'],
      timeToLearn: '2-3 hours',
      interactiveDemo: true
    },
    {
      id: 'euler-graph-theory',
      name: 'Graph Theory Basics',
      mathematician: 'Euler',
      level: 'high_school',
      category: 'Graph Theory',
      description: 'Explore Euler paths, circuits, and the famous Seven Bridges of Königsberg problem.',
      formula: 'Euler\'s formula: V - E + F = 2 (for connected planar graphs)',
      example: 'A cube has 8 vertices, 12 edges, 6 faces: 8 - 12 + 6 = 2 ✓',
      code: `class Graph:
    def __init__(self):
        self.vertices = {}
    
    def add_vertex(self, vertex):
        if vertex not in self.vertices:
            self.vertices[vertex] = []
    
    def add_edge(self, v1, v2):
        self.add_vertex(v1)
        self.add_vertex(v2)
        self.vertices[v1].append(v2)
        self.vertices[v2].append(v1)
    
    def degree(self, vertex):
        return len(self.vertices.get(vertex, []))
    
    def has_euler_path(self):
        """Check if graph has Euler path"""
        odd_degree_vertices = [v for v in self.vertices if self.degree(v) % 2 == 1]
        return len(odd_degree_vertices) in [0, 2]
    
    def has_euler_circuit(self):
        """Check if graph has Euler circuit"""
        odd_degree_vertices = [v for v in self.vertices if self.degree(v) % 2 == 1]
        return len(odd_degree_vertices) == 0

# Seven Bridges of Königsberg
konigsberg = Graph()
bridges = [('A', 'B'), ('A', 'B'), ('A', 'C'), ('A', 'C'), ('A', 'D'), ('B', 'D'), ('C', 'D')]
for bridge in bridges:
    konigsberg.add_edge(*bridge)

print("Königsberg bridges problem:")
print(f"Has Euler path: {konigsberg.has_euler_path()}")
print(f"Has Euler circuit: {konigsberg.has_euler_circuit()}")`,
      difficulty: 3,
      prerequisites: ['Basic logic', 'Set theory basics'],
      applications: ['Network analysis', 'Route optimization', 'Social networks'],
      timeToLearn: '3-4 hours',
      interactiveDemo: true
    },

    // College Level
    {
      id: 'newton-calculus',
      name: 'Calculus Fundamentals',
      mathematician: 'Newton',
      level: 'college',
      category: 'Calculus',
      description: 'Limits, derivatives, and basic integration using Newton\'s method of fluxions.',
      formula: 'Derivative: f\'(x) = lim(h→0) [f(x+h) - f(x)]/h',
      example: 'f(x) = x²: f\'(x) = 2x, f(x) = x³: f\'(x) = 3x²',
      code: `import numpy as np
import matplotlib.pyplot as plt

def numerical_derivative(f, x, h=1e-7):
    """Calculate numerical derivative using limit definition"""
    return (f(x + h) - f(x)) / h

def newton_method(f, df, x0, tolerance=1e-10, max_iterations=100):
    """Find root using Newton's method"""
    x = x0
    for i in range(max_iterations):
        fx = f(x)
        if abs(fx) < tolerance:
            return x, i
        dfx = df(x)
        if abs(dfx) < tolerance:
            raise ValueError("Derivative too small")
        x = x - fx / dfx
    raise ValueError("Max iterations reached")

def numerical_integral(f, a, b, n=1000):
    """Calculate definite integral using trapezoidal rule"""
    x = np.linspace(a, b, n+1)
    y = [f(xi) for xi in x]
    return (b - a) * (sum(y) - 0.5*y[0] - 0.5*y[-1]) / n

# Example functions
def f(x):
    return x**2 - 4  # Root at x = ±2

def df(x):
    return 2*x

def parabola(x):
    return x**2

# Find root of x² - 4 = 0
root, iterations = newton_method(f, df, 1.0)
print(f"Root found: {root:.6f} in {iterations} iterations")

# Calculate derivative of x² at x = 3
x_point = 3
derivative = numerical_derivative(parabola, x_point)
print(f"Derivative of x² at x={x_point}: {derivative:.6f}")

# Calculate integral of x² from 0 to 2
integral = numerical_integral(parabola, 0, 2)
print(f"Integral of x² from 0 to 2: {integral:.6f}")`,
      difficulty: 4,
      prerequisites: ['Algebra', 'Trigonometry', 'Functions'],
      applications: ['Physics', 'Engineering', 'Economics', 'Optimization'],
      timeToLearn: '6-8 hours',
      interactiveDemo: true
    },
    {
      id: 'fourier-analysis',
      name: 'Fourier Series',
      mathematician: 'Fourier',
      level: 'college',
      category: 'Analysis',
      description: 'Decompose periodic functions into sine and cosine components.',
      formula: 'f(x) = a₀/2 + Σ[aₙcos(nx) + bₙsin(nx)]',
      example: 'Square wave can be expressed as sum of odd harmonics',
      code: `import numpy as np
import matplotlib.pyplot as plt

def fourier_coefficients(f, period, n_terms):
    """Calculate Fourier coefficients for a periodic function"""
    L = period / 2
    
    def integrate(func, a, b, n_points=1000):
        x = np.linspace(a, b, n_points)
        y = [func(xi) for xi in x]
        return (b - a) * np.mean(y)
    
    # Calculate a₀
    a0 = (1/L) * integrate(f, -L, L)
    
    # Calculate aₙ and bₙ coefficients
    a_coeffs = []
    b_coeffs = []
    
    for n in range(1, n_terms + 1):
        an = (1/L) * integrate(lambda x: f(x) * np.cos(n*np.pi*x/L), -L, L)
        bn = (1/L) * integrate(lambda x: f(x) * np.sin(n*np.pi*x/L), -L, L)
        a_coeffs.append(an)
        b_coeffs.append(bn)
    
    return a0, a_coeffs, b_coeffs

def fourier_series(x, a0, a_coeffs, b_coeffs, period):
    """Reconstruct function from Fourier coefficients"""
    L = period / 2
    result = a0 / 2
    
    for n, (an, bn) in enumerate(zip(a_coeffs, b_coeffs), 1):
        result += an * np.cos(n * np.pi * x / L) + bn * np.sin(n * np.pi * x / L)
    
    return result

# Square wave function
def square_wave(x, period=2*np.pi):
    x_mod = x % period
    return 1 if x_mod < period/2 else -1

# Calculate Fourier series for square wave
period = 2*np.pi
n_terms = 10
x_vals = np.linspace(-2*np.pi, 2*np.pi, 1000)

# Get original function values
original = [square_wave(x, period) for x in x_vals]

# Calculate Fourier coefficients
a0, a_coeffs, b_coeffs = fourier_coefficients(lambda x: square_wave(x, period), period, n_terms)

# Reconstruct using Fourier series
reconstructed = [fourier_series(x, a0, a_coeffs, b_coeffs, period) for x in x_vals]

print(f"Fourier coefficients calculated for {n_terms} terms")
print(f"a₀ = {a0:.6f}")
print(f"First few b coefficients: {b_coeffs[:5]}")`,
      difficulty: 4,
      prerequisites: ['Calculus', 'Trigonometry', 'Integration'],
      applications: ['Signal processing', 'Audio compression', 'Heat conduction'],
      timeToLearn: '8-10 hours',
      interactiveDemo: true
    },

    // University Level
    {
      id: 'galois-group-theory',
      name: 'Group Theory Fundamentals',
      mathematician: 'Galois',
      level: 'university',
      category: 'Abstract Algebra',
      description: 'Explore mathematical groups, their properties, and Galois theory applications.',
      formula: 'Group axioms: Closure, Associativity, Identity, Inverse',
      example: 'Cyclic group Z₄ = {0, 1, 2, 3} under addition modulo 4',
      code: `class Group:
    def __init__(self, elements, operation):
        self.elements = set(elements)
        self.operation = operation
        self.identity = self._find_identity()
    
    def _find_identity(self):
        """Find the identity element"""
        for e in self.elements:
            if all(self.operation(e, x) == x and self.operation(x, e) == x 
                   for x in self.elements):
                return e
        return None
    
    def inverse(self, element):
        """Find inverse of an element"""
        for inv in self.elements:
            if (self.operation(element, inv) == self.identity and
                self.operation(inv, element) == self.identity):
                return inv
        return None
    
    def is_group(self):
        """Check if structure satisfies group axioms"""
        # Check closure
        for a in self.elements:
            for b in self.elements:
                if self.operation(a, b) not in self.elements:
                    return False, "Not closed"
        
        # Check associativity
        for a in self.elements:
            for b in self.elements:
                for c in self.elements:
                    if (self.operation(self.operation(a, b), c) != 
                        self.operation(a, self.operation(b, c))):
                        return False, "Not associative"
        
        # Check identity exists
        if self.identity is None:
            return False, "No identity element"
        
        # Check inverses exist
        for element in self.elements:
            if self.inverse(element) is None:
                return False, f"No inverse for {element}"
        
        return True, "Valid group"
    
    def cayley_table(self):
        """Generate Cayley table for the group"""
        elements = sorted(list(self.elements))
        print("Cayley Table:")
        print("  |", " ".join(f"{e:3}" for e in elements))
        print("--+" + "----" * len(elements))
        
        for a in elements:
            row = f"{a:2}|"
            for b in elements:
                result = self.operation(a, b)
                row += f"{result:4}"
            print(row)

# Example: Cyclic group Z₄ under addition mod 4
def add_mod_4(a, b):
    return (a + b) % 4

z4 = Group([0, 1, 2, 3], add_mod_4)
is_valid, message = z4.is_group()
print(f"Z₄ is a group: {is_valid} - {message}")
print(f"Identity element: {z4.identity}")
z4.cayley_table()

# Example: Klein four-group
def klein_operation(a, b):
    table = {
        ('e', 'e'): 'e', ('e', 'a'): 'a', ('e', 'b'): 'b', ('e', 'c'): 'c',
        ('a', 'e'): 'a', ('a', 'a'): 'e', ('a', 'b'): 'c', ('a', 'c'): 'b',
        ('b', 'e'): 'b', ('b', 'a'): 'c', ('b', 'b'): 'e', ('b', 'c'): 'a',
        ('c', 'e'): 'c', ('c', 'a'): 'b', ('c', 'b'): 'a', ('c', 'c'): 'e'
    }
    return table[(a, b)]

klein = Group(['e', 'a', 'b', 'c'], klein_operation)
print("\\nKlein Four-Group:")
klein.cayley_table()`,
      difficulty: 5,
      prerequisites: ['Abstract algebra', 'Set theory', 'Mathematical proofs'],
      applications: ['Cryptography', 'Crystallography', 'Quantum mechanics'],
      timeToLearn: '15-20 hours',
      interactiveDemo: true
    },
    {
      id: 'turing-computability',
      name: 'Computability Theory',
      mathematician: 'Turing',
      level: 'university',
      category: 'Logic & Computation',
      description: 'Turing machines, decidability, and the foundations of computer science.',
      formula: 'Halting Problem: There is no algorithm that can determine if an arbitrary program halts',
      example: 'Simple Turing machine that recognizes palindromes',
      code: `class TuringMachine:
    def __init__(self, states, alphabet, transitions, start_state, accept_states, reject_states):
        self.states = states
        self.alphabet = alphabet
        self.transitions = transitions  # {(state, symbol): (new_state, new_symbol, direction)}
        self.start_state = start_state
        self.accept_states = accept_states
        self.reject_states = reject_states
        
    def simulate(self, input_string, max_steps=1000):
        """Simulate the Turing machine on input string"""
        tape = list(input_string) + ['_'] * 100  # Add blank symbols
        head = 0
        state = self.start_state
        steps = 0
        
        history = []
        
        while steps < max_steps:
            if head < 0 or head >= len(tape):
                return "REJECT", "Head moved off tape", history
            
            current_symbol = tape[head]
            history.append((state, tape[:20], head))  # Save first 20 symbols
            
            if state in self.accept_states:
                return "ACCEPT", f"Accepted in {steps} steps", history
            
            if state in self.reject_states:
                return "REJECT", f"Rejected in {steps} steps", history
            
            # Look up transition
            if (state, current_symbol) not in self.transitions:
                return "REJECT", f"No transition for ({state}, {current_symbol})", history
            
            new_state, new_symbol, direction = self.transitions[(state, current_symbol)]
            
            # Apply transition
            tape[head] = new_symbol
            state = new_state
            
            if direction == 'R':
                head += 1
            elif direction == 'L':
                head -= 1
            
            steps += 1
        
        return "TIMEOUT", f"Exceeded {max_steps} steps", history

def create_palindrome_tm():
    """Create a Turing machine that recognizes palindromes over {0, 1}"""
    states = ['q0', 'q1', 'q2', 'q3', 'q4', 'q5', 'accept', 'reject']
    alphabet = ['0', '1', '_', 'X', 'Y']
    
    transitions = {
        # Mark first symbol and go to end
        ('q0', '0'): ('q1', 'X', 'R'),
        ('q0', '1'): ('q2', 'Y', 'R'),
        ('q0', '_'): ('accept', '_', 'R'),  # Empty string is palindrome
        
        # Looking for matching symbol at end (started with 0)
        ('q1', '0'): ('q1', '0', 'R'),
        ('q1', '1'): ('q1', '1', 'R'),
        ('q1', '_'): ('q3', '_', 'L'),
        
        # Looking for matching symbol at end (started with 1)  
        ('q2', '0'): ('q2', '0', 'R'),
        ('q2', '1'): ('q2', '1', 'R'),
        ('q2', '_'): ('q4', '_', 'L'),
        
        # Check if last symbol matches first (was 0)
        ('q3', '0'): ('q5', 'X', 'L'),
        ('q3', 'X'): ('q3', 'X', 'L'),
        ('q3', 'Y'): ('q3', 'Y', 'L'),
        ('q3', '1'): ('reject', '1', 'R'),
        
        # Check if last symbol matches first (was 1)
        ('q4', '1'): ('q5', 'Y', 'L'),
        ('q4', 'X'): ('q4', 'X', 'L'),
        ('q4', 'Y'): ('q4', 'Y', 'L'),
        ('q4', '0'): ('reject', '0', 'R'),
        
        # Go back to start
        ('q5', '0'): ('q5', '0', 'L'),
        ('q5', '1'): ('q5', '1', 'L'),
        ('q5', 'X'): ('q0', 'X', 'R'),
        ('q5', 'Y'): ('q0', 'Y', 'R'),
        ('q5', '_'): ('q0', '_', 'R'),
        
        # Accept when only X's and Y's remain
        ('q0', 'X'): ('q0', 'X', 'R'),
        ('q0', 'Y'): ('q0', 'Y', 'R'),
    }
    
    return TuringMachine(states, alphabet, transitions, 'q0', ['accept'], ['reject'])

# Test the palindrome Turing machine
tm = create_palindrome_tm()

test_strings = ['101', '1001', '110', '1111', '0110', '']
for s in test_strings:
    result, message, history = tm.simulate(s)
    print(f"Input '{s}': {result} - {message}")`,
      difficulty: 5,
      prerequisites: ['Formal languages', 'Automata theory', 'Computability'],
      applications: ['Compiler design', 'AI reasoning', 'Computational complexity'],
      timeToLearn: '6-8 weeks',
      interactiveDemo: true
    },

    // Advanced Mathematical Formulas and Equation Solvers
    {
      id: 'equation-solvers',
      name: 'Advanced Equation Solvers',
      mathematician: 'Newton, Gauss',
      level: 'university',
      category: 'Numerical Analysis',
      description: 'Comprehensive equation solving methods including linear systems, polynomial equations, differential equations, and optimization.',
      formula: 'Newton-Raphson: x_{n+1} = x_n - f(x_n)/f\'(x_n), Gaussian elimination, Runge-Kutta methods',
      example: 'Solve x³ - 2x - 5 = 0 using Newton-Raphson method',
      code: `import numpy as np
from scipy.optimize import fsolve, minimize, linprog
from scipy.integrate import odeint
import sympy as sp

class EquationSolver:
    """Advanced Mathematical Equation Solving Suite"""
    
    def __init__(self):
        self.tolerance = 1e-10
        self.max_iterations = 1000
    
    def newton_raphson(self, f, df, x0, tolerance=None, max_iter=None):
        """Newton-Raphson method for finding roots"""
        tol = tolerance or self.tolerance
        max_it = max_iter or self.max_iterations
        
        x = x0
        iterations = []
        
        for i in range(max_it):
            fx = f(x)
            dfx = df(x)
            
            if abs(dfx) < tol:
                return None, "Derivative too small", iterations
            
            x_new = x - fx / dfx
            iterations.append((i, x, fx, x_new))
            
            if abs(x_new - x) < tol:
                return x_new, f"Converged in {i+1} iterations", iterations
            
            x = x_new
        
        return x, "Max iterations reached", iterations
    
    def bisection_method(self, f, a, b, tolerance=None, max_iter=None):
        """Bisection method for root finding"""
        tol = tolerance or self.tolerance
        max_it = max_iter or self.max_iterations
        
        if f(a) * f(b) > 0:
            return None, "Function has same sign at endpoints", []
        
        iterations = []
        
        for i in range(max_it):
            c = (a + b) / 2
            fc = f(c)
            
            iterations.append((i, a, b, c, fc))
            
            if abs(fc) < tol or abs(b - a) < tol:
                return c, f"Converged in {i+1} iterations", iterations
            
            if f(a) * fc < 0:
                b = c
            else:
                a = c
        
        return (a + b) / 2, "Max iterations reached", iterations
    
    def gaussian_elimination(self, A, b):
        """Solve linear system Ax = b using Gaussian elimination"""
        n = len(A)
        # Create augmented matrix
        augmented = [row[:] + [b[i]] for i, row in enumerate(A)]
        
        # Forward elimination
        for i in range(n):
            # Find pivot
            max_row = i
            for k in range(i + 1, n):
                if abs(augmented[k][i]) > abs(augmented[max_row][i]):
                    max_row = k
            
            # Swap rows
            augmented[i], augmented[max_row] = augmented[max_row], augmented[i]
            
            # Make all rows below this one 0 in current column
            for k in range(i + 1, n):
                if augmented[i][i] == 0:
                    continue
                factor = augmented[k][i] / augmented[i][i]
                for j in range(i, n + 1):
                    augmented[k][j] -= factor * augmented[i][j]
        
        # Back substitution
        x = [0] * n
        for i in range(n - 1, -1, -1):
            x[i] = augmented[i][n]
            for j in range(i + 1, n):
                x[i] -= augmented[i][j] * x[j]
            x[i] /= augmented[i][i]
        
        return x
    
    def polynomial_solver(self, coefficients):
        """Solve polynomial equation using numpy roots"""
        roots = np.roots(coefficients)
        
        real_roots = []
        complex_roots = []
        
        for root in roots:
            if np.isreal(root):
                real_roots.append(float(root.real))
            else:
                complex_roots.append(complex(root))
        
        return {
            'real_roots': real_roots,
            'complex_roots': complex_roots,
            'all_roots': roots.tolist()
        }
    
    def differential_equation_solver(self, dydt, y0, t_span, method='RK45'):
        """Solve ODE dy/dt = f(t, y) with initial condition y(t0) = y0"""
        from scipy.integrate import solve_ivp
        
        sol = solve_ivp(dydt, t_span, [y0], method=method, dense_output=True)
        
        return {
            'solution': sol,
            'success': sol.success,
            'message': sol.message,
            't_values': sol.t,
            'y_values': sol.y[0]
        }
    
    def optimization_solver(self, objective, constraints=None, bounds=None, x0=None):
        """Solve optimization problems"""
        if x0 is None:
            x0 = [0.0]  # Default starting point
        
        result = minimize(objective, x0, bounds=bounds, constraints=constraints)
        
        return {
            'optimal_x': result.x,
            'optimal_value': result.fun,
            'success': result.success,
            'message': result.message,
            'iterations': result.nit if hasattr(result, 'nit') else None
        }
    
    def symbolic_solver(self, equation_str, variable='x'):
        """Solve equations symbolically using SymPy"""
        x = sp.Symbol(variable)
        equation = sp.sympify(equation_str)
        
        solutions = sp.solve(equation, x)
        
        return {
            'symbolic_solutions': [str(sol) for sol in solutions],
            'numerical_solutions': [float(sol.evalf()) for sol in solutions if sol.is_real],
            'equation': str(equation),
            'variable': variable
        }

# Example usage and demonstrations
solver = EquationSolver()

# 1. Newton-Raphson example: solve x³ - 2x - 5 = 0
def f(x):
    return x**3 - 2*x - 5

def df(x):
    return 3*x**2 - 2

root, message, iterations = solver.newton_raphson(f, df, 2.0)
print(f"Newton-Raphson solution: x = {root:.6f}")
print(f"Status: {message}")

# 2. Linear system solver
A = [[2, 1, -1], [-3, -1, 2], [-2, 1, 2]]
b = [8, -11, -3]
solution = solver.gaussian_elimination(A, b)
print(f"Linear system solution: {solution}")

# 3. Polynomial solver: x⁴ - 4x³ + 6x² - 4x + 1 = 0
coefficients = [1, -4, 6, -4, 1]
poly_solution = solver.polynomial_solver(coefficients)
print(f"Polynomial roots: {poly_solution['real_roots']}")

# 4. Differential equation: dy/dt = -2y, y(0) = 1
def dydt(t, y):
    return -2 * y

ode_solution = solver.differential_equation_solver(dydt, 1.0, [0, 2])
print(f"ODE solution at t=1: y = {ode_solution['solution'].sol(1)[0]:.6f}")

# 5. Optimization: minimize x² + y² subject to x + y = 1
def objective(x):
    return x[0]**2 + x[1]**2

constraints = {'type': 'eq', 'fun': lambda x: x[0] + x[1] - 1}
opt_result = solver.optimization_solver(objective, constraints=[constraints], x0=[0.5, 0.5])
print(f"Optimization result: x = {opt_result['optimal_x']}, min value = {opt_result['optimal_value']:.6f}")

# 6. Symbolic solver
symbolic_result = solver.symbolic_solver('x**2 - 4*x + 3')
print(f"Symbolic solutions: {symbolic_result['symbolic_solutions']}")`,
      difficulty: 5,
      prerequisites: ['Calculus', 'Linear algebra', 'Numerical methods'],
      applications: ['Engineering optimization', 'Physics simulations', 'Financial modeling'],
      timeToLearn: '4-6 weeks',
      interactiveDemo: true
    },

    {
      id: 'advanced-physics-formulas',
      name: 'Advanced Physics & Engineering Formulas',
      mathematician: 'Maxwell, Schrödinger, Einstein',
      level: 'university',
      category: 'Physics',
      description: 'Comprehensive collection of advanced physics formulas including electromagnetism, quantum mechanics, thermodynamics, and relativity.',
      formula: 'Maxwell\'s equations, Schrödinger equation, Einstein field equations, Navier-Stokes equations',
      example: 'Calculate electromagnetic field from current distribution',
      code: `import numpy as np
import scipy.constants as const
from scipy.special import sph_harm, factorial
import cmath

class AdvancedPhysics:
    """Advanced Physics Formula Calculator"""
    
    def __init__(self):
        # Physical constants
        self.c = const.c  # Speed of light
        self.h = const.h  # Planck constant
        self.hbar = const.hbar  # Reduced Planck constant
        self.e = const.e  # Elementary charge
        self.me = const.m_e  # Electron mass
        self.kb = const.k  # Boltzmann constant
        self.eps0 = const.epsilon_0  # Vacuum permittivity
        self.mu0 = const.mu_0  # Vacuum permeability
        self.G = const.G  # Gravitational constant
        self.sigma = const.Stefan_Boltzmann  # Stefan-Boltzmann constant
    
    def electromagnetic_wave(self, frequency, amplitude, phase=0):
        """Calculate electromagnetic wave properties"""
        omega = 2 * np.pi * frequency
        wavelength = self.c / frequency
        wave_number = 2 * np.pi / wavelength
        
        def electric_field(x, t):
            return amplitude * np.cos(wave_number * x - omega * t + phase)
        
        def magnetic_field(x, t):
            return (amplitude / self.c) * np.cos(wave_number * x - omega * t + phase)
        
        energy_density = self.eps0 * amplitude**2 / 2
        intensity = energy_density * self.c
        
        return {
            'frequency': frequency,
            'wavelength': wavelength,
            'wave_number': wave_number,
            'energy_density': energy_density,
            'intensity': intensity,
            'electric_field': electric_field,
            'magnetic_field': magnetic_field
        }
    
    def quantum_harmonic_oscillator(self, n, mass, omega):
        """Calculate quantum harmonic oscillator properties"""
        # Energy levels
        energy = self.hbar * omega * (n + 0.5)
        
        # Classical turning points
        x_max = np.sqrt(2 * energy / (mass * omega**2))
        
        # Zero-point energy
        zero_point = self.hbar * omega / 2
        
        # Normalization constant for wavefunction
        alpha = np.sqrt(mass * omega / self.hbar)
        
        def wavefunction(x):
            """Normalized wavefunction for nth state"""
            hermite_n = self._hermite_polynomial(n, alpha * x)
            normalization = (alpha / np.pi)**(1/4) / np.sqrt(2**n * factorial(n))
            exponential = np.exp(-alpha**2 * x**2 / 2)
            return normalization * hermite_n * exponential
        
        def probability_density(x):
            """Probability density |ψ(x)|²"""
            psi = wavefunction(x)
            return np.abs(psi)**2
        
        return {
            'energy': energy,
            'quantum_number': n,
            'classical_turning_point': x_max,
            'zero_point_energy': zero_point,
            'wavefunction': wavefunction,
            'probability_density': probability_density
        }
    
    def _hermite_polynomial(self, n, x):
        """Calculate Hermite polynomial H_n(x)"""
        if n == 0:
            return np.ones_like(x)
        elif n == 1:
            return 2 * x
        else:
            # Recursive relation: H_{n+1} = 2x*H_n - 2n*H_{n-1}
            H_prev_prev = np.ones_like(x)
            H_prev = 2 * x
            
            for i in range(2, n + 1):
                H_current = 2 * x * H_prev - 2 * (i - 1) * H_prev_prev
                H_prev_prev, H_prev = H_prev, H_current
            
            return H_prev
    
    def relativity_calculations(self, velocity, rest_mass=None):
        """Special and general relativity calculations"""
        if abs(velocity) >= self.c:
            raise ValueError("Velocity must be less than speed of light")
        
        # Lorentz factor
        gamma = 1 / np.sqrt(1 - (velocity / self.c)**2)
        
        results = {
            'lorentz_factor': gamma,
            'time_dilation': gamma,
            'length_contraction': 1 / gamma,
            'velocity': velocity,
            'beta': velocity / self.c
        }
        
        if rest_mass:
            # Relativistic mass
            relativistic_mass = gamma * rest_mass
            
            # Relativistic momentum
            momentum = gamma * rest_mass * velocity
            
            # Total energy
            total_energy = gamma * rest_mass * self.c**2
            
            # Kinetic energy
            kinetic_energy = (gamma - 1) * rest_mass * self.c**2
            
            results.update({
                'rest_mass': rest_mass,
                'relativistic_mass': relativistic_mass,
                'momentum': momentum,
                'total_energy': total_energy,
                'kinetic_energy': kinetic_energy,
                'rest_energy': rest_mass * self.c**2
            })
        
        return results
    
    def thermodynamics(self, temperature, volume=None, pressure=None, 
                      amount=None, process_type='isothermal'):
        """Thermodynamic calculations"""
        R = const.R  # Gas constant
        
        results = {'temperature': temperature, 'process_type': process_type}
        
        if amount and volume and pressure:
            # Ideal gas law check
            pv_nrt = (pressure * volume) / (amount * R * temperature)
            results['ideal_gas_law_check'] = pv_nrt
        
        # Maxwell-Boltzmann distribution
        def maxwell_boltzmann_speed(v, mass):
            """Speed distribution function"""
            factor = 4 * np.pi * (mass / (2 * np.pi * self.kb * temperature))**(3/2)
            exponential = np.exp(-mass * v**2 / (2 * self.kb * temperature))
            return factor * v**2 * exponential
        
        # Blackbody radiation
        def planck_function(wavelength):
            """Planck's blackbody radiation formula"""
            numerator = 2 * self.h * self.c**2 / wavelength**5
            denominator = np.exp(self.h * self.c / (wavelength * self.kb * temperature)) - 1
            return numerator / denominator
        
        # Stefan-Boltzmann law
        def blackbody_power():
            """Total power radiated by blackbody"""
            return self.sigma * temperature**4
        
        results.update({
            'maxwell_boltzmann_speed': maxwell_boltzmann_speed,
            'planck_function': planck_function,
            'blackbody_power': blackbody_power(),
            'thermal_energy_kt': self.kb * temperature
        })
        
        return results
    
    def fluid_dynamics(self, density, velocity, viscosity, characteristic_length):
        """Fluid dynamics calculations"""
        # Reynolds number
        reynolds = density * velocity * characteristic_length / viscosity
        
        # Dynamic pressure
        dynamic_pressure = 0.5 * density * velocity**2
        
        # Flow regime
        if reynolds < 2300:
            flow_regime = "Laminar"
        elif reynolds > 4000:
            flow_regime = "Turbulent"
        else:
            flow_regime = "Transitional"
        
        return {
            'reynolds_number': reynolds,
            'dynamic_pressure': dynamic_pressure,
            'flow_regime': flow_regime,
            'density': density,
            'velocity': velocity,
            'viscosity': viscosity,
            'characteristic_length': characteristic_length
        }

# Example calculations
physics = AdvancedPhysics()

# 1. Electromagnetic wave calculation
em_wave = physics.electromagnetic_wave(frequency=1e9, amplitude=1e3)  # 1 GHz, 1 kV/m
print(f"EM wave - Wavelength: {em_wave['wavelength']:.3f} m")
print(f"EM wave - Intensity: {em_wave['intensity']:.2e} W/m²")

# 2. Quantum harmonic oscillator
qho = physics.quantum_harmonic_oscillator(n=2, mass=1e-27, omega=1e14)
print(f"QHO - Energy level n=2: {qho['energy']:.2e} J")
print(f"QHO - Classical turning point: {qho['classical_turning_point']:.2e} m")

# 3. Relativity at 0.9c
rel = physics.relativity_calculations(0.9 * physics.c, rest_mass=1e-27)
print(f"Relativity - Lorentz factor: {rel['lorentz_factor']:.3f}")
print(f"Relativity - Kinetic energy: {rel['kinetic_energy']:.2e} J")

# 4. Thermodynamics at room temperature
thermo = physics.thermodynamics(temperature=298.15)  # 25°C
print(f"Thermodynamics - Thermal energy kT: {thermo['thermal_energy_kt']:.2e} J")
print(f"Thermodynamics - Blackbody power: {thermo['blackbody_power']:.2e} W/m²")

# 5. Fluid dynamics for water flow
fluid = physics.fluid_dynamics(density=1000, velocity=2, viscosity=1e-3, characteristic_length=0.1)
print(f"Fluid - Reynolds number: {fluid['reynolds_number']:.0f}")
print(f"Fluid - Flow regime: {fluid['flow_regime']}")`,
      difficulty: 5,
      prerequisites: ['Advanced calculus', 'Linear algebra', 'Differential equations', 'Complex analysis'],
      applications: ['Quantum computing', 'Aerospace engineering', 'Medical physics', 'Materials science'],
      timeToLearn: '8-12 weeks',
      interactiveDemo: true
    }
  ];

  const mathematicians: Record<string, Mathematician> = {
    'Archimedes': {
      name: 'Archimedes',
      period: '287-212 BCE',
      nationality: 'Greek',
      contributions: ['Archimedes\' Principle', 'Method of Exhaustion', 'Spiral of Archimedes'],
      biography: 'Ancient Greek mathematician, physicist, engineer, and inventor. Known for shouting "Eureka!" when discovering the principle of buoyancy.',
      famousWorks: ['On the Sphere and Cylinder', 'Measurement of a Circle', 'The Sand Reckoner']
    },
    'Pythagoras': {
      name: 'Pythagoras',
      period: '570-495 BCE',
      nationality: 'Greek',
      contributions: ['Pythagorean Theorem', 'Music of the Spheres', 'Number Theory'],
      biography: 'Ancient Greek philosopher and mathematician who founded the Pythagorean school. Believed "All is number."',
      famousWorks: ['Pythagorean Theorem', 'Theory of Proportions']
    },
    'Fibonacci': {
      name: 'Leonardo Fibonacci',
      period: '1170-1250',
      nationality: 'Italian',
      contributions: ['Fibonacci Sequence', 'Introduction of Arabic Numerals to Europe'],
      biography: 'Italian mathematician who introduced the Hindu-Arabic numeral system to Western Europe.',
      famousWorks: ['Liber Abaci', 'Practica Geometriae']
    },
    'Descartes': {
      name: 'René Descartes',
      period: '1596-1650',
      nationality: 'French',
      contributions: ['Cartesian Coordinates', 'Analytic Geometry', 'Cartesian Method'],
      biography: 'French philosopher and mathematician who connected algebra and geometry, creating analytic geometry.',
      famousWorks: ['Discourse on Method', 'La Géométrie', 'Meditations on First Philosophy']
    },
    'Euler': {
      name: 'Leonhard Euler',
      period: '1707-1783',
      nationality: 'Swiss',
      contributions: ['Graph Theory', 'Euler\'s Identity', 'Euler\'s Method'],
      biography: 'Swiss mathematician who made groundbreaking discoveries in multiple areas of mathematics and physics.',
      famousWorks: ['Introduction to Analysis of the Infinite', 'Elements of Algebra']
    },
    'Newton': {
      name: 'Isaac Newton',
      period: '1643-1727',
      nationality: 'English',
      contributions: ['Calculus', 'Laws of Motion', 'Universal Gravitation'],
      biography: 'English mathematician and physicist who developed calculus and laid the foundations of classical mechanics.',
      famousWorks: ['Principia Mathematica', 'Method of Fluxions']
    },
    'Fourier': {
      name: 'Joseph Fourier',
      period: '1768-1830',
      nationality: 'French',
      contributions: ['Fourier Series', 'Fourier Transform', 'Heat Equation'],
      biography: 'French mathematician and physicist who studied heat transfer and vibrations.',
      famousWorks: ['The Analytical Theory of Heat']
    },
    'Galois': {
      name: 'Évariste Galois',
      period: '1811-1832',
      nationality: 'French',
      contributions: ['Group Theory', 'Galois Theory', 'Field Theory'],
      biography: 'French mathematician who died in a duel at age 20, but left behind revolutionary work in algebra.',
      famousWorks: ['Theory of Algebraic Equations']
    },
    'Turing': {
      name: 'Alan Turing',
      period: '1912-1954',
      nationality: 'British',
      contributions: ['Turing Machine', 'Computability Theory', 'Artificial Intelligence'],
      biography: 'British mathematician and computer scientist who laid the theoretical foundations for computer science.',
      famousWorks: ['On Computable Numbers', 'Computing Machinery and Intelligence']
    }
  };

  const filteredConcepts = mathematicalConcepts.filter(concept => {
    const matchesLevel = concept.level === activeLevel;
    const matchesSearch = concept.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         concept.mathematician.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         concept.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'all' || concept.category === filterCategory;
    
    return matchesLevel && matchesSearch && matchesCategory;
  });

  const categories = Array.from(new Set(mathematicalConcepts.map(c => c.category)));

  const runCode = (code: string) => {
    try {
      // Simulate code execution (in a real implementation, this would use a Python interpreter)
      setCodeOutput("Code executed successfully! (In a real implementation, this would run the Python code)");
    } catch (error) {
      setCodeOutput(`Error: ${error}`);
    }
  };

  const toggleExpanded = (conceptId: string) => {
    const newExpanded = new Set(expandedConcepts);
    if (newExpanded.has(conceptId)) {
      newExpanded.delete(conceptId);
    } else {
      newExpanded.add(conceptId);
    }
    setExpandedConcepts(newExpanded);
  };

  const getLevelIcon = (level: MathematicalConcept['level']) => {
    switch (level) {
      case 'elementary': return <BookOpen className="h-4 w-4" />;
      case 'high_school': return <GraduationCap className="h-4 w-4" />;
      case 'college': return <TrendingUp className="h-4 w-4" />;
      case 'university': return <Brain className="h-4 w-4" />;
    }
  };

  const getLevelColor = (level: MathematicalConcept['level']) => {
    switch (level) {
      case 'elementary': return 'text-green-400';
      case 'high_school': return 'text-blue-400';
      case 'college': return 'text-purple-400';
      case 'university': return 'text-red-400';
    }
  };

  const getDifficultyStars = (difficulty: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-3 w-3 ${i < difficulty ? 'text-yellow-400 fill-yellow-400' : 'text-gray-600'}`}
      />
    ));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[98vw] h-[98vh] bg-gradient-to-br from-emerald-950 via-slate-900 to-emerald-900 border-emerald-700">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-emerald-100 flex items-center gap-2">
            <Calculator className="h-6 w-6 text-emerald-400" />
            Mathematics Library - From Elementary to University
          </DialogTitle>
        </DialogHeader>

        <div className="flex h-full gap-4">
          {/* Left Sidebar - Navigation & Search */}
          <div className="w-80 space-y-4">
            {/* Search */}
            <div className="space-y-2">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2 top-2 h-4 w-4 text-emerald-400" />
                  <Input
                    placeholder="Search concepts, mathematicians..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-8 bg-emerald-900/30 border-emerald-700 text-emerald-100"
                  />
                </div>
                <Select value={filterCategory} onValueChange={setFilterCategory}>
                  <SelectTrigger className="w-24 bg-emerald-900/30 border-emerald-700 text-emerald-100">
                    <Filter className="h-4 w-4" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Level Tabs */}
            <Tabs value={activeLevel} onValueChange={(value) => setActiveLevel(value as any)}>
              <TabsList className="grid grid-cols-2 bg-emerald-900/30">
                <TabsTrigger value="elementary" className="text-xs">Elementary</TabsTrigger>
                <TabsTrigger value="high_school" className="text-xs">High School</TabsTrigger>
              </TabsList>
              <TabsList className="grid grid-cols-2 bg-emerald-900/30 mt-1">
                <TabsTrigger value="college" className="text-xs">College</TabsTrigger>
                <TabsTrigger value="university" className="text-xs">University</TabsTrigger>
              </TabsList>
            </Tabs>

            {/* Concepts List */}
            <Card className="bg-emerald-900/30 border-emerald-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-emerald-100 text-sm flex items-center gap-2">
                  {getLevelIcon(activeLevel)}
                  {activeLevel.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())} Level
                  <Badge variant="secondary" className="bg-emerald-700/50 text-emerald-200">
                    {filteredConcepts.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[calc(100vh-300px)]">
                  <div className="space-y-2">
                    {filteredConcepts.map((concept) => (
                      <div
                        key={concept.id}
                        className={`p-3 rounded cursor-pointer transition-all duration-200 ${
                          selectedConcept?.id === concept.id
                            ? 'bg-emerald-700/50 border border-emerald-500'
                            : 'bg-emerald-800/30 hover:bg-emerald-700/30 border border-transparent'
                        }`}
                        onClick={() => setSelectedConcept(concept)}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="text-emerald-100 font-medium text-sm">{concept.name}</h4>
                            <p className="text-emerald-300 text-xs mt-1">by {concept.mathematician}</p>
                            <div className="flex items-center gap-2 mt-2">
                              <Badge className="text-xs bg-emerald-600/50 text-emerald-200">
                                {concept.category}
                              </Badge>
                              <div className="flex items-center gap-1">
                                {getDifficultyStars(concept.difficulty)}
                              </div>
                            </div>
                            <div className="flex items-center gap-2 mt-1 text-xs text-emerald-400">
                              <Clock className="h-3 w-3" />
                              <span>{concept.timeToLearn}</span>
                            </div>
                          </div>
                          <SoundButton
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleExpanded(concept.id);
                            }}
                          >
                            {expandedConcepts.has(concept.id) ? 
                              <ChevronDown className="h-4 w-4" /> : 
                              <ChevronRight className="h-4 w-4" />
                            }
                          </SoundButton>
                        </div>
                        
                        {expandedConcepts.has(concept.id) && (
                          <div className="mt-3 pt-3 border-t border-emerald-600/30">
                            <p className="text-emerald-200 text-xs mb-2">{concept.description}</p>
                            {concept.formula && (
                              <div className="bg-emerald-950/50 p-2 rounded text-xs">
                                <code className="text-emerald-300">{concept.formula}</code>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Center - Main Content */}
          <div className="flex-1 space-y-4">
            {selectedConcept ? (
              <>
                {/* Concept Header */}
                <Card className="bg-emerald-900/30 border-emerald-700">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-emerald-100 text-xl flex items-center gap-3">
                          {getLevelIcon(selectedConcept.level)}
                          <span className={getLevelColor(selectedConcept.level)}>
                            {selectedConcept.name}
                          </span>
                        </CardTitle>
                        <CardDescription className="text-emerald-300 mt-2">
                          Developed by {selectedConcept.mathematician} • {selectedConcept.category}
                        </CardDescription>
                        <div className="flex items-center gap-4 mt-3">
                          <div className="flex items-center gap-1">
                            <span className="text-emerald-200 text-sm">Difficulty:</span>
                            <div className="flex gap-1">
                              {getDifficultyStars(selectedConcept.difficulty)}
                            </div>
                          </div>
                          <div className="flex items-center gap-2 text-emerald-300 text-sm">
                            <Clock className="h-4 w-4" />
                            <span>{selectedConcept.timeToLearn}</span>
                          </div>
                          {selectedConcept.interactiveDemo && (
                            <Badge className="bg-blue-600/50 text-blue-200">
                              Interactive Demo
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <TooltipWrapper title="Mathematician Info" type="info" content="Learn about the mathematician">
                          <SoundButton
                            size="sm"
                            variant="outline"
                            className="border-emerald-600 text-emerald-300"
                            onClick={() => setShowMathematician(mathematicians[selectedConcept.mathematician])}
                          >
                            <Info className="h-4 w-4" />
                          </SoundButton>
                        </TooltipWrapper>
                        <TooltipWrapper title="Copy Code" type="action" content="Copy code to clipboard">
                          <SoundButton
                            size="sm"
                            variant="outline"
                            className="border-emerald-600 text-emerald-300"
                            onClick={() => navigator.clipboard.writeText(selectedConcept.code)}
                          >
                            <Copy className="h-4 w-4" />
                          </SoundButton>
                        </TooltipWrapper>
                        <TooltipWrapper title="Run Code" type="action" content="Execute the code">
                          <SoundButton
                            size="sm"
                            className="bg-emerald-600 hover:bg-emerald-500"
                            onClick={() => runCode(selectedConcept.code)}
                          >
                            <Play className="h-4 w-4" />
                          </SoundButton>
                        </TooltipWrapper>
                      </div>
                    </div>
                  </CardHeader>
                </Card>

                {/* Content Tabs */}
                <Tabs defaultValue="theory" className="flex-1">
                  <TabsList className="grid grid-cols-4 bg-emerald-900/30">
                    <TabsTrigger value="theory">Theory</TabsTrigger>
                    <TabsTrigger value="code">Code</TabsTrigger>
                    <TabsTrigger value="examples">Examples</TabsTrigger>
                    <TabsTrigger value="applications">Applications</TabsTrigger>
                  </TabsList>

                  <TabsContent value="theory" className="space-y-4">
                    <Card className="bg-emerald-900/30 border-emerald-700">
                      <CardContent className="p-6 space-y-4">
                        <div>
                          <h3 className="text-emerald-100 font-semibold mb-2">Description</h3>
                          <p className="text-emerald-200">{selectedConcept.description}</p>
                        </div>
                        
                        {selectedConcept.formula && (
                          <div>
                            <h3 className="text-emerald-100 font-semibold mb-2">Formula</h3>
                            <div className="bg-emerald-950/50 p-4 rounded border border-emerald-600/30">
                              <code className="text-emerald-300 text-lg">{selectedConcept.formula}</code>
                            </div>
                          </div>
                        )}
                        
                        <div>
                          <h3 className="text-emerald-100 font-semibold mb-2">Prerequisites</h3>
                          <div className="flex flex-wrap gap-2">
                            {selectedConcept.prerequisites.map((prereq, index) => (
                              <Badge key={index} className="bg-yellow-600/50 text-yellow-200">
                                {prereq}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="code" className="space-y-4">
                    <Card className="bg-emerald-900/30 border-emerald-700">
                      <CardHeader>
                        <CardTitle className="text-emerald-100 text-sm flex items-center gap-2">
                          <Code className="h-4 w-4" />
                          Python Implementation
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="bg-gray-900 p-4 rounded border border-emerald-600/30 overflow-auto">
                            <pre className="text-green-400 text-sm">
                              <code>{selectedConcept.code}</code>
                            </pre>
                          </div>
                          
                          {codeOutput && (
                            <div className="bg-emerald-950/50 p-4 rounded border border-emerald-600/30">
                              <h4 className="text-emerald-200 font-semibold mb-2">Output:</h4>
                              <pre className="text-emerald-300 text-sm">{codeOutput}</pre>
                            </div>
                          )}
                          
                          <div className="flex gap-2">
                            <SoundButton
                              className="bg-emerald-600 hover:bg-emerald-500"
                              onClick={() => runCode(selectedConcept.code)}
                            >
                              <Play className="h-4 w-4 mr-2" />
                              Run Code
                            </SoundButton>
                            <SoundButton
                              variant="outline"
                              className="border-emerald-600 text-emerald-300"
                              onClick={() => navigator.clipboard.writeText(selectedConcept.code)}
                            >
                              <Copy className="h-4 w-4 mr-2" />
                              Copy Code
                            </SoundButton>
                            <SoundButton
                              variant="outline"
                              className="border-emerald-600 text-emerald-300"
                              onClick={() => setCodeOutput("")}
                            >
                              <RotateCcw className="h-4 w-4 mr-2" />
                              Clear Output
                            </SoundButton>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="examples" className="space-y-4">
                    <Card className="bg-emerald-900/30 border-emerald-700">
                      <CardHeader>
                        <CardTitle className="text-emerald-100 text-sm">Example</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="bg-emerald-950/50 p-4 rounded border border-emerald-600/30">
                          <p className="text-emerald-200">{selectedConcept.example}</p>
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="applications" className="space-y-4">
                    <Card className="bg-emerald-900/30 border-emerald-700">
                      <CardHeader>
                        <CardTitle className="text-emerald-100 text-sm">Real-World Applications</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {selectedConcept.applications.map((application, index) => (
                            <div key={index} className="flex items-center gap-3 p-3 bg-emerald-800/30 rounded">
                              <Target className="h-5 w-5 text-emerald-400" />
                              <span className="text-emerald-200">{application}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </>
            ) : (
              <Card className="bg-emerald-900/30 border-emerald-700 h-full">
                <CardContent className="flex items-center justify-center h-full">
                  <div className="text-center text-emerald-300">
                    <Calculator className="h-16 w-16 mx-auto mb-4 text-emerald-500" />
                    <h3 className="text-xl font-semibold mb-2">Welcome to the Mathematics Library</h3>
                    <p className="mb-4">Select a mathematical concept from the sidebar to explore its theory, implementation, and applications.</p>
                    <div className="text-sm text-emerald-400">
                      <p>📚 {mathematicalConcepts.length} concepts available</p>
                      <p>👨‍🎓 From Elementary to University level</p>
                      <p>💻 Interactive code examples included</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Sidebar - Mathematician Info */}
          <div className="w-80">
            {showMathematician ? (
              <Card className="bg-emerald-900/30 border-emerald-700">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-emerald-100 text-lg flex items-center gap-2">
                      <Award className="h-5 w-5 text-emerald-400" />
                      {showMathematician.name}
                    </CardTitle>
                    <SoundButton
                      size="sm"
                      variant="ghost"
                      onClick={() => setShowMathematician(null)}
                    >
                      ×
                    </SoundButton>
                  </div>
                  <CardDescription className="text-emerald-300">
                    {showMathematician.period} • {showMathematician.nationality}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="text-emerald-200 font-semibold mb-2">Biography</h4>
                    <p className="text-emerald-300 text-sm">{showMathematician.biography}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-emerald-200 font-semibold mb-2">Major Contributions</h4>
                    <div className="space-y-1">
                      {showMathematician.contributions.map((contribution, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <Lightbulb className="h-3 w-3 text-yellow-400" />
                          <span className="text-emerald-300">{contribution}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-emerald-200 font-semibold mb-2">Famous Works</h4>
                    <div className="space-y-1">
                      {showMathematician.famousWorks.map((work, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <FileText className="h-3 w-3 text-blue-400" />
                          <span className="text-emerald-300">{work}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="bg-emerald-900/30 border-emerald-700">
                <CardHeader>
                  <CardTitle className="text-emerald-100 text-sm">Quick Stats</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-emerald-800/30 rounded">
                      <div className="text-2xl font-bold text-emerald-100">
                        {mathematicalConcepts.filter(c => c.level === 'elementary').length}
                      </div>
                      <div className="text-xs text-emerald-300">Elementary</div>
                    </div>
                    <div className="text-center p-3 bg-emerald-800/30 rounded">
                      <div className="text-2xl font-bold text-emerald-100">
                        {mathematicalConcepts.filter(c => c.level === 'high_school').length}
                      </div>
                      <div className="text-xs text-emerald-300">High School</div>
                    </div>
                    <div className="text-center p-3 bg-emerald-800/30 rounded">
                      <div className="text-2xl font-bold text-emerald-100">
                        {mathematicalConcepts.filter(c => c.level === 'college').length}
                      </div>
                      <div className="text-xs text-emerald-300">College</div>
                    </div>
                    <div className="text-center p-3 bg-emerald-800/30 rounded">
                      <div className="text-2xl font-bold text-emerald-100">
                        {mathematicalConcepts.filter(c => c.level === 'university').length}
                      </div>
                      <div className="text-xs text-emerald-300">University</div>
                    </div>
                  </div>
                  
                  <Separator className="bg-emerald-700" />
                  
                  <div className="space-y-2">
                    <h4 className="text-emerald-200 font-semibold text-sm">Categories</h4>
                    {categories.map((category) => (
                      <div key={category} className="flex items-center justify-between text-sm">
                        <span className="text-emerald-300">{category}</span>
                        <Badge className="bg-emerald-600/50 text-emerald-200">
                          {mathematicalConcepts.filter(c => c.category === category).length}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}