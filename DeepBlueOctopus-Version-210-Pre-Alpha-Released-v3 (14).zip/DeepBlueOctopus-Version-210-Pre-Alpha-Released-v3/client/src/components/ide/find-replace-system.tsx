import React, { useState, useCallback, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { useIDEState } from "@/hooks/use-ide-state";
import { useToast } from "@/hooks/use-toast";
import { 
  Search, Replace, ArrowRight, ArrowLeft,
  ArrowUp, ArrowDown, RotateCcw, Check,
  FileText, Folder, Eye, Settings,
  Hash, CaseSensitive, Circle, Regex,
  SkipForward, PlayCircle, Square
} from "lucide-react";

interface FindReplaceSystemProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SearchMatch {
  fileId: number;
  fileName: string;
  filePath: string;
  line: number;
  column: number;
  text: string;
  matchText: string;
  contextBefore: string;
  contextAfter: string;
}

interface SearchOptions {
  caseSensitive: boolean;
  wholeWord: boolean;
  useRegex: boolean;
  includeFiles: boolean;
  includeFolders: boolean;
  searchInComments: boolean;
  searchInStrings: boolean;
}

export default function FindReplaceSystem({ isOpen, onClose }: FindReplaceSystemProps) {
  const [searchText, setSearchText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [searchScope, setSearchScope] = useState<'current' | 'all' | 'selection'>('current');
  const [searchOptions, setSearchOptions] = useState<SearchOptions>({
    caseSensitive: false,
    wholeWord: false,
    useRegex: false,
    includeFiles: true,
    includeFolders: false,
    searchInComments: true,
    searchInStrings: true
  });
  
  const [searchResults, setSearchResults] = useState<SearchMatch[]>([]);
  const [currentMatchIndex, setCurrentMatchIndex] = useState(0);
  const [isSearching, setIsSearching] = useState(false);
  const [replaceCount, setReplaceCount] = useState(0);
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [replaceHistory, setReplaceHistory] = useState<string[]>([]);

  const { files, activeTab, updateFileContent } = useIDEState();
  const { toast } = useToast();
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isOpen]);

  const performSearch = useCallback(async () => {
    if (!searchText.trim()) {
      setSearchResults([]);
      return;
    }

    setIsSearching(true);
    const results: SearchMatch[] = [];

    try {
      const searchRegex = searchOptions.useRegex 
        ? new RegExp(searchText, searchOptions.caseSensitive ? 'g' : 'gi')
        : new RegExp(
            searchOptions.wholeWord 
              ? `\\b${searchText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`
              : searchText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'),
            searchOptions.caseSensitive ? 'g' : 'gi'
          );

      const filesToSearch = searchScope === 'current' 
        ? (activeTab ? [files.find(f => f.id === activeTab.id)].filter(Boolean) : [])
        : (files || []);

      for (const file of filesToSearch) {
        if (!file || (!searchOptions.includeFiles && !file.isDirectory)) continue;
        if (!searchOptions.includeFolders && file.isDirectory) continue;
        if (!file.content) continue;

        const lines = file.content.split('\n');
        lines.forEach((line: string, lineIndex: number) => {
          let match;
          while ((match = searchRegex.exec(line)) !== null) {
            const contextStart = Math.max(0, match.index - 20);
            const contextEnd = Math.min(line.length, match.index + match[0].length + 20);
            
            results.push({
              fileId: file.id,
              fileName: file.name,
              filePath: file.path,
              line: lineIndex + 1,
              column: match.index + 1,
              text: line,
              matchText: match[0],
              contextBefore: line.substring(contextStart, match.index),
              contextAfter: line.substring(match.index + match[0].length, contextEnd)
            });
          }
        });
      }

      setSearchResults(results);
      setCurrentMatchIndex(0);

      // Add to search history
      if (searchText && !searchHistory.includes(searchText)) {
        setSearchHistory(prev => [searchText, ...prev.slice(0, 9)]);
      }

      toast({
        title: "Search completed",
        description: `Found ${results.length} matches`,
      });

    } catch (error) {
      toast({
        title: "Search error",
        description: "Invalid search pattern",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  }, [searchText, searchOptions, searchScope, files, activeTab, toast, searchHistory]);

  const performReplace = useCallback(async (replaceAll: boolean = false) => {
    if (!searchText.trim() || searchResults.length === 0) return;

    const replacements = replaceAll ? searchResults : [searchResults[currentMatchIndex]];
    let totalReplacements = 0;

    try {
      const fileUpdates: { [fileId: number]: string } = {};

      // Group replacements by file
      const replacementsByFile: { [fileId: number]: SearchMatch[] } = {};
      replacements.forEach(match => {
        if (!replacementsByFile[match.fileId]) {
          replacementsByFile[match.fileId] = [];
        }
        replacementsByFile[match.fileId].push(match);
      });

      // Process each file
      for (const [fileIdStr, matches] of Object.entries(replacementsByFile)) {
        const fileId = parseInt(fileIdStr);
        const file = files?.find(f => f.id === fileId);
        if (!file) continue;

        let updatedContent = file.content;
        const lines = updatedContent.split('\n');

        // Sort matches by line and column (reverse order to maintain positions)
        matches.sort((a, b) => {
          if (a.line !== b.line) return b.line - a.line;
          return b.column - a.column;
        });

        matches.forEach(match => {
          const lineIndex = match.line - 1;
          if (lineIndex < lines.length) {
            const line = lines[lineIndex];
            const before = line.substring(0, match.column - 1);
            const after = line.substring(match.column - 1 + match.matchText.length);
            lines[lineIndex] = before + replaceText + after;
            totalReplacements++;
          }
        });

        updatedContent = lines.join('\n');
        updateFileContent(fileId, updatedContent);
      }

      setReplaceCount(prev => prev + totalReplacements);

      // Add to replace history
      if (replaceText && !replaceHistory.includes(replaceText)) {
        setReplaceHistory(prev => [replaceText, ...prev.slice(0, 9)]);
      }

      // Re-search to update results
      await performSearch();

      toast({
        title: "Replace completed",
        description: `Replaced ${totalReplacements} occurrence${totalReplacements !== 1 ? 's' : ''}`,
      });

    } catch (error) {
      toast({
        title: "Replace error",
        description: "Failed to perform replacement",
        variant: "destructive",
      });
    }
  }, [searchText, replaceText, searchResults, currentMatchIndex, files, updateFileContent, performSearch, replaceHistory, toast]);

  const navigateToMatch = useCallback((index: number) => {
    if (index >= 0 && index < searchResults.length) {
      setCurrentMatchIndex(index);
      const match = searchResults[index];
      // Here you would typically navigate to the file and line
      // This would integrate with the code editor to jump to the location
      toast({
        title: "Navigate to match",
        description: `${match.fileName}:${match.line}:${match.column}`,
      });
    }
  }, [searchResults, toast]);

  const nextMatch = useCallback(() => {
    navigateToMatch((currentMatchIndex + 1) % searchResults.length);
  }, [currentMatchIndex, searchResults.length, navigateToMatch]);

  const previousMatch = useCallback(() => {
    navigateToMatch((currentMatchIndex - 1 + searchResults.length) % searchResults.length);
  }, [currentMatchIndex, searchResults.length, navigateToMatch]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      if (e.shiftKey) {
        previousMatch();
      } else {
        nextMatch();
      }
    } else if (e.key === 'Escape') {
      onClose();
    }
  }, [nextMatch, previousMatch, onClose]);

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[85vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            Find & Replace
            {searchResults.length > 0 && (
              <Badge variant="outline">
                {searchResults.length} matches
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="search" className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="search">Search & Replace</TabsTrigger>
            <TabsTrigger value="results">Results</TabsTrigger>
            <TabsTrigger value="options">Options</TabsTrigger>
          </TabsList>

          <TabsContent value="search" className="flex-1 flex flex-col space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="w-4 h-4" />
                  Search & Replace
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <Input
                        ref={searchInputRef}
                        placeholder="Search for..."
                        value={searchText}
                        onChange={(e) => setSearchText(e.target.value)}
                        onKeyDown={handleKeyDown}
                        className="pr-12"
                      />
                    </div>
                    <Button
                      onClick={performSearch}
                      disabled={isSearching}
                      className="flex items-center gap-2"
                    >
                      <Search className="w-4 h-4" />
                      {isSearching ? 'Searching...' : 'Search'}
                    </Button>
                  </div>

                  <div className="flex gap-2">
                    <div className="flex-1">
                      <Input
                        placeholder="Replace with..."
                        value={replaceText}
                        onChange={(e) => setReplaceText(e.target.value)}
                        onKeyDown={handleKeyDown}
                      />
                    </div>
                    <Button
                      onClick={() => performReplace(false)}
                      disabled={searchResults.length === 0}
                      variant="outline"
                      className="flex items-center gap-2"
                    >
                      <Replace className="w-4 h-4" />
                      Replace
                    </Button>
                    <Button
                      onClick={() => performReplace(true)}
                      disabled={searchResults.length === 0}
                      variant="outline"
                      className="flex items-center gap-2"
                    >
                      <PlayCircle className="w-4 h-4" />
                      Replace All
                    </Button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Checkbox
                        checked={searchOptions.caseSensitive}
                        onCheckedChange={(checked) => 
                          setSearchOptions(prev => ({ ...prev, caseSensitive: !!checked }))
                        }
                      />
                      <CaseSensitive className="w-4 h-4" />
                      <span className="text-sm">Case sensitive</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        checked={searchOptions.wholeWord}
                        onCheckedChange={(checked) => 
                          setSearchOptions(prev => ({ ...prev, wholeWord: !!checked }))
                        }
                      />
                      <Circle className="w-4 h-4" />
                      <span className="text-sm">Whole word</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Checkbox
                        checked={searchOptions.useRegex}
                        onCheckedChange={(checked) => 
                          setSearchOptions(prev => ({ ...prev, useRegex: !!checked }))
                        }
                      />
                      <Regex className="w-4 h-4" />
                      <span className="text-sm">Regex</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <select
                      value={searchScope}
                      onChange={(e) => setSearchScope(e.target.value as any)}
                      className="px-3 py-2 border rounded-md text-sm"
                    >
                      <option value="current">Current File</option>
                      <option value="all">All Files</option>
                      <option value="selection">Selection</option>
                    </select>
                  </div>
                </div>

                {searchResults.length > 0 && (
                  <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <div className="flex items-center gap-2">
                      <span className="text-sm">
                        Match {currentMatchIndex + 1} of {searchResults.length}
                      </span>
                      {replaceCount > 0 && (
                        <Badge variant="secondary">
                          {replaceCount} replaced
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={previousMatch}
                        disabled={searchResults.length === 0}
                      >
                        <ArrowUp className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={nextMatch}
                        disabled={searchResults.length === 0}
                      >
                        <ArrowDown className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="results" className="flex-1 flex flex-col space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  Search Results ({searchResults.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-2">
                    {searchResults.length === 0 ? (
                      <p className="text-center text-gray-500 py-8">
                        No search results. Enter a search term and click Search.
                      </p>
                    ) : (
                      searchResults.map((match, index) => (
                        <div
                          key={`${match.fileId}-${match.line}-${match.column}`}
                          className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                            index === currentMatchIndex 
                              ? 'bg-blue-50 dark:bg-blue-950 border-blue-200' 
                              : 'hover:bg-gray-50 dark:hover:bg-gray-800'
                          }`}
                          onClick={() => navigateToMatch(index)}
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <FileText className="w-4 h-4 text-blue-500" />
                            <span className="font-medium">{match.fileName}</span>
                            <span className="text-sm text-gray-500">
                              {match.line}:{match.column}
                            </span>
                          </div>
                          <div className="text-sm font-mono bg-gray-100 dark:bg-gray-800 p-2 rounded">
                            <span className="text-gray-600">{match.contextBefore}</span>
                            <span className="bg-yellow-200 dark:bg-yellow-800 px-1 rounded">
                              {match.matchText}
                            </span>
                            <span className="text-gray-600">{match.contextAfter}</span>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{match.filePath}</p>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="options" className="flex-1 flex flex-col space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Search Options
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <h4 className="font-medium">File Types</h4>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={searchOptions.includeFiles}
                          onCheckedChange={(checked) => 
                            setSearchOptions(prev => ({ ...prev, includeFiles: !!checked }))
                          }
                        />
                        <span className="text-sm">Include files</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={searchOptions.includeFolders}
                          onCheckedChange={(checked) => 
                            setSearchOptions(prev => ({ ...prev, includeFolders: !!checked }))
                          }
                        />
                        <span className="text-sm">Include folders</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-medium">Content Types</h4>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={searchOptions.searchInComments}
                          onCheckedChange={(checked) => 
                            setSearchOptions(prev => ({ ...prev, searchInComments: !!checked }))
                          }
                        />
                        <span className="text-sm">Search in comments</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={searchOptions.searchInStrings}
                          onCheckedChange={(checked) => 
                            setSearchOptions(prev => ({ ...prev, searchInStrings: !!checked }))
                          }
                        />
                        <span className="text-sm">Search in strings</span>
                      </div>
                    </div>
                  </div>
                </div>

                {(searchHistory.length > 0 || replaceHistory.length > 0) && (
                  <div className="space-y-3">
                    <h4 className="font-medium">Recent Searches</h4>
                    <div className="grid grid-cols-2 gap-4">
                      {searchHistory.length > 0 && (
                        <div>
                          <p className="text-sm text-gray-500 mb-2">Search terms:</p>
                          <div className="space-y-1">
                            {searchHistory.slice(0, 5).map((term, index) => (
                              <Button
                                key={index}
                                variant="ghost"
                                size="sm"
                                onClick={() => setSearchText(term)}
                                className="justify-start h-8 px-2 text-sm"
                              >
                                {term}
                              </Button>
                            ))}
                          </div>
                        </div>
                      )}
                      {replaceHistory.length > 0 && (
                        <div>
                          <p className="text-sm text-gray-500 mb-2">Replace terms:</p>
                          <div className="space-y-1">
                            {replaceHistory.slice(0, 5).map((term, index) => (
                              <Button
                                key={index}
                                variant="ghost"
                                size="sm"
                                onClick={() => setReplaceText(term)}
                                className="justify-start h-8 px-2 text-sm"
                              >
                                {term}
                              </Button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}