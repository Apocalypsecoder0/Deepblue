import React, { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  Eye, Download, ExternalLink, Image, Video, FileText,
  Code, Archive, Music, File, X, ZoomIn, ZoomOut,
  RotateCcw, RotateCw, Maximize2, Minimize2
} from "lucide-react";

interface FilePreviewSystemProps {
  isOpen: boolean;
  onClose: () => void;
  fileId?: number;
}

interface PreviewFile {
  id: number;
  name: string;
  path: string;
  content: string;
  size: number;
  type: string;
  lastModified: Date;
}

export default function FilePreviewSystem({ isOpen, onClose, fileId }: FilePreviewSystemProps) {
  const [selectedFile, setSelectedFile] = useState<PreviewFile | null>(null);
  const [previewMode, setPreviewMode] = useState<'image' | 'video' | 'audio' | 'text' | 'code' | 'pdf'>('text');
  const [zoom, setZoom] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [autoSaveEnabled, setAutoSaveEnabled] = useState(true);
  const [autoSaveInterval, setAutoSaveInterval] = useState(5000); // 5 seconds
  const [lastAutoSave, setLastAutoSave] = useState<Date | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  
  const { files, updateFileContent, saveCurrentFile } = useIDEState();
  const autoSaveTimerRef = useRef<NodeJS.Timeout>();
  const contentRef = useRef<string>('');

  useEffect(() => {
    if (fileId && files) {
      const file = files.find(f => f.id === fileId);
      if (file) {
        setSelectedFile({
          id: file.id,
          name: file.name,
          path: file.path,
          content: file.content,
          size: file.size || 0,
          type: getFileType(file.name),
          lastModified: file.lastModified || new Date()
        });
        setPreviewMode(getPreviewMode(file.name));
        contentRef.current = file.content;
      }
    }
  }, [fileId, files]);

  // Auto-save functionality
  useEffect(() => {
    if (autoSaveEnabled && hasUnsavedChanges && selectedFile) {
      autoSaveTimerRef.current = setTimeout(() => {
        handleAutoSave();
      }, autoSaveInterval);

      return () => {
        if (autoSaveTimerRef.current) {
          clearTimeout(autoSaveTimerRef.current);
        }
      };
    }
  }, [autoSaveEnabled, hasUnsavedChanges, autoSaveInterval, selectedFile]);

  const handleAutoSave = () => {
    if (selectedFile && hasUnsavedChanges) {
      updateFileContent(selectedFile.id, contentRef.current);
      saveCurrentFile();
      setLastAutoSave(new Date());
      setHasUnsavedChanges(false);
    }
  };

  const handleContentChange = (newContent: string) => {
    contentRef.current = newContent;
    setHasUnsavedChanges(true);
    if (selectedFile) {
      setSelectedFile({
        ...selectedFile,
        content: newContent
      });
    }
  };

  const getFileType = (fileName: string): string => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    const typeMap: { [key: string]: string } = {
      // Images
      jpg: 'image', jpeg: 'image', png: 'image', gif: 'image', svg: 'image', webp: 'image', bmp: 'image',
      // Videos
      mp4: 'video', avi: 'video', mov: 'video', wmv: 'video', webm: 'video', mkv: 'video',
      // Audio
      mp3: 'audio', wav: 'audio', flac: 'audio', aac: 'audio', ogg: 'audio',
      // Documents
      pdf: 'pdf', doc: 'document', docx: 'document', ppt: 'presentation', pptx: 'presentation',
      // Code
      js: 'code', ts: 'code', jsx: 'code', tsx: 'code', py: 'code', html: 'code', css: 'code', scss: 'code',
      // Archives
      zip: 'archive', rar: 'archive', '7z': 'archive', tar: 'archive', gz: 'archive',
      // Text
      txt: 'text', md: 'text', json: 'text', xml: 'text', yaml: 'text', yml: 'text'
    };
    
    return typeMap[extension || ''] || 'text';
  };

  const getPreviewMode = (fileName: string): 'image' | 'video' | 'audio' | 'text' | 'code' | 'pdf' => {
    const fileType = getFileType(fileName);
    switch (fileType) {
      case 'image': return 'image';
      case 'video': return 'video';
      case 'audio': return 'audio';
      case 'code': return 'code';
      case 'pdf': return 'pdf';
      default: return 'text';
    }
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'image': return <Image className="w-5 h-5 text-blue-500" />;
      case 'video': return <Video className="w-5 h-5 text-purple-500" />;
      case 'audio': return <Music className="w-5 h-5 text-green-500" />;
      case 'code': return <Code className="w-5 h-5 text-orange-500" />;
      case 'archive': return <Archive className="w-5 h-5 text-red-500" />;
      case 'pdf': return <FileText className="w-5 h-5 text-red-600" />;
      default: return <File className="w-5 h-5 text-gray-500" />;
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDateTime = (date: Date): string => {
    return date.toLocaleString();
  };

  const handleZoomIn = () => setZoom(prev => Math.min(prev + 25, 300));
  const handleZoomOut = () => setZoom(prev => Math.max(prev - 25, 25));
  const handleRotate = () => setRotation(prev => (prev + 90) % 360);
  const handleResetView = () => {
    setZoom(100);
    setRotation(0);
  };

  const renderPreviewContent = () => {
    if (!selectedFile) return null;

    const commonControls = (
      <div className="flex items-center gap-2 mb-4">
        <Button variant="outline" size="sm" onClick={handleZoomOut}>
          <ZoomOut className="w-4 h-4" />
        </Button>
        <span className="text-sm font-medium">{zoom}%</span>
        <Button variant="outline" size="sm" onClick={handleZoomIn}>
          <ZoomIn className="w-4 h-4" />
        </Button>
        <Separator orientation="vertical" className="h-4" />
        <Button variant="outline" size="sm" onClick={handleRotate}>
          <RotateCw className="w-4 h-4" />
        </Button>
        <Button variant="outline" size="sm" onClick={handleResetView}>
          <RotateCcw className="w-4 h-4" />
        </Button>
        <Separator orientation="vertical" className="h-4" />
        <Button variant="outline" size="sm" onClick={() => setIsFullscreen(!isFullscreen)}>
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </Button>
      </div>
    );

    switch (previewMode) {
      case 'image':
        return (
          <div>
            {commonControls}
            <div className="flex justify-center">
              <img
                src={`data:image/jpeg;base64,${btoa(selectedFile.content)}`}
                alt={selectedFile.name}
                style={{
                  transform: `scale(${zoom / 100}) rotate(${rotation}deg)`,
                  maxWidth: '100%',
                  maxHeight: isFullscreen ? '80vh' : '400px'
                }}
                className="border rounded-lg"
              />
            </div>
          </div>
        );

      case 'video':
        return (
          <div>
            {commonControls}
            <video
              controls
              style={{ width: `${zoom}%`, maxHeight: isFullscreen ? '80vh' : '400px' }}
              className="mx-auto border rounded-lg"
            >
              <source src={`data:video/mp4;base64,${btoa(selectedFile.content)}`} />
              Your browser does not support the video tag.
            </video>
          </div>
        );

      case 'audio':
        return (
          <div>
            <div className="flex justify-center p-8">
              <div className="text-center">
                <Music className="w-16 h-16 mx-auto mb-4 text-green-500" />
                <h3 className="font-medium mb-4">{selectedFile.name}</h3>
                <audio controls className="mx-auto">
                  <source src={`data:audio/mpeg;base64,${btoa(selectedFile.content)}`} />
                  Your browser does not support the audio tag.
                </audio>
              </div>
            </div>
          </div>
        );

      case 'code':
      case 'text':
        return (
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Badge variant="outline">{selectedFile.name.split('.').pop()?.toUpperCase()}</Badge>
                <span className="text-sm text-gray-500">
                  {selectedFile.content.split('\n').length} lines
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => setZoom(prev => Math.max(prev - 10, 50))}>
                  <ZoomOut className="w-4 h-4" />
                </Button>
                <span className="text-sm">{zoom}%</span>
                <Button variant="outline" size="sm" onClick={() => setZoom(prev => Math.min(prev + 10, 200))}>
                  <ZoomIn className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <ScrollArea className={isFullscreen ? "h-[70vh]" : "h-96"}>
              <pre 
                className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg text-sm overflow-x-auto"
                style={{ fontSize: `${zoom}%` }}
              >
                <code>{selectedFile.content}</code>
              </pre>
            </ScrollArea>
          </div>
        );

      case 'pdf':
        return (
          <div className="text-center p-8">
            <FileText className="w-16 h-16 mx-auto mb-4 text-red-600" />
            <h3 className="font-medium mb-2">PDF Preview</h3>
            <p className="text-gray-500 mb-4">PDF preview not available in this version</p>
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Download to View
            </Button>
          </div>
        );

      default:
        return (
          <div className="text-center p-8">
            <File className="w-16 h-16 mx-auto mb-4 text-gray-500" />
            <h3 className="font-medium mb-2">Preview Not Available</h3>
            <p className="text-gray-500">This file type is not supported for preview</p>
          </div>
        );
    }
  };

  if (!isOpen || !selectedFile) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className={isFullscreen ? "max-w-[95vw] h-[95vh]" : "max-w-4xl h-[80vh]"}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5" />
            File Preview - {selectedFile.name}
            {hasUnsavedChanges && <Badge variant="destructive">Unsaved</Badge>}
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex flex-col space-y-4">
          {/* File Info */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {getFileIcon(selectedFile.type)}
                  <div>
                    <p className="font-medium">{selectedFile.name}</p>
                    <p className="text-sm text-gray-500">{selectedFile.path}</p>
                  </div>
                </div>
                <div className="text-right text-sm text-gray-500">
                  <p>Size: {formatFileSize(selectedFile.size)}</p>
                  <p>Modified: {formatDateTime(selectedFile.lastModified)}</p>
                  {lastAutoSave && (
                    <p className="text-green-600">
                      Auto-saved: {formatDateTime(lastAutoSave)}
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Auto-save Settings */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={autoSaveEnabled}
                      onChange={(e) => setAutoSaveEnabled(e.target.checked)}
                      className="rounded"
                    />
                    Auto-save enabled
                  </label>
                  {autoSaveEnabled && (
                    <select
                      value={autoSaveInterval}
                      onChange={(e) => setAutoSaveInterval(Number(e.target.value))}
                      className="px-2 py-1 border rounded text-sm"
                    >
                      <option value={3000}>3 seconds</option>
                      <option value={5000}>5 seconds</option>
                      <option value={10000}>10 seconds</option>
                      <option value={30000}>30 seconds</option>
                    </select>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleAutoSave()}
                    disabled={!hasUnsavedChanges}
                  >
                    Save Now
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Preview Content */}
          <Card className="flex-1">
            <CardContent className="p-4 h-full">
              <ScrollArea className="h-full">
                {renderPreviewContent()}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}