import React, { useState, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { 
  FileText, Save, Undo, Redo, Search, Replace, 
  Type, Palette, Zap, MousePointer, Grid3X3,
  Eye, EyeOff, Split, Maximize2, Settings,
  Bold, Italic, Underline, AlignLeft, AlignCenter,
  AlignRight, List, ListOrdered, Quote, Code,
  Link, Image, Table, Hash, Strikethrough
} from "lucide-react";

interface AdvancedTextEditorProps {
  isOpen: boolean;
  onClose: () => void;
}

interface EditorDocument {
  id: string;
  name: string;
  content: string;
  language: string;
  encoding: string;
  lineEndings: 'lf' | 'crlf' | 'cr';
  lastModified: Date;
  wordCount: number;
  charCount: number;
  selectedText: string;
  cursorPosition: { line: number; column: number };
}

interface EditorSettings {
  fontSize: number;
  fontFamily: string;
  theme: string;
  lineNumbers: boolean;
  wordWrap: boolean;
  autoIndent: boolean;
  tabSize: number;
  insertSpaces: boolean;
  minimap: boolean;
  bracketMatching: boolean;
  autoComplete: boolean;
  spellCheck: boolean;
  syntax: boolean;
  folding: boolean;
}

export default function AdvancedTextEditor({ isOpen, onClose }: AdvancedTextEditorProps) {
  const [activeTab, setActiveTab] = useState("editor");
  const [currentDoc, setCurrentDoc] = useState<EditorDocument>({
    id: "doc1",
    name: "document.txt",
    content: `Welcome to DeepBlue IDE Advanced Text Editor!

This is a comprehensive text editing environment with professional features:

## Features
- Multi-format support (Markdown, HTML, Plain Text, Rich Text)
- Advanced formatting tools and syntax highlighting
- Real-time collaboration and version control
- Plugin architecture and customizable interface
- Export capabilities and document templates

## Text Formatting
You can format text with **bold**, *italic*, ~~strikethrough~~, and [links](https://example.com).

### Code Blocks
\`\`\`javascript
function hello() {
    console.log("Hello from DeepBlue IDE!");
}
\`\`\`

### Lists
1. Numbered lists
2. With multiple items
   - Nested bullet points
   - Sub-items

### Tables
| Column 1 | Column 2 | Column 3 |
|----------|----------|----------|
| Data 1   | Data 2   | Data 3   |
| More     | Content  | Here     |

> Blockquotes for important information
> Multiple lines supported

---

Happy writing! 🚀`,
    language: "markdown",
    encoding: "utf-8",
    lineEndings: "lf",
    lastModified: new Date(),
    wordCount: 128,
    charCount: 856,
    selectedText: "",
    cursorPosition: { line: 1, column: 1 }
  });

  const [settings, setSettings] = useState<EditorSettings>({
    fontSize: 14,
    fontFamily: "JetBrains Mono",
    theme: "DeepBlue Dark",
    lineNumbers: true,
    wordWrap: true,
    autoIndent: true,
    tabSize: 4,
    insertSpaces: true,
    minimap: true,
    bracketMatching: true,
    autoComplete: true,
    spellCheck: true,
    syntax: true,
    folding: true
  });

  const [findReplace, setFindReplace] = useState({
    find: "",
    replace: "",
    caseSensitive: false,
    wholeWord: false,
    useRegex: false,
    findResults: 0,
    currentResult: 0
  });

  const [documents, setDocuments] = useState<EditorDocument[]>([
    currentDoc,
    {
      id: "doc2",
      name: "readme.md",
      content: "# Project Documentation\n\nThis is a sample markdown document.",
      language: "markdown",
      encoding: "utf-8",
      lineEndings: "lf",
      lastModified: new Date(Date.now() - 3600000),
      wordCount: 12,
      charCount: 67,
      selectedText: "",
      cursorPosition: { line: 1, column: 1 }
    }
  ]);

  const [recentFiles, setRecentFiles] = useState([
    { name: "project.md", path: "/docs/project.md", lastOpened: new Date() },
    { name: "config.json", path: "/config/config.json", lastOpened: new Date(Date.now() - 1800000) },
    { name: "styles.css", path: "/src/styles.css", lastOpened: new Date(Date.now() - 3600000) }
  ]);

  const textAreaRef = useRef<HTMLTextAreaElement>(null);

  const formatText = (format: string) => {
    const textarea = textAreaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = currentDoc.content.substring(start, end);
    let formattedText = selectedText;

    switch (format) {
      case 'bold':
        formattedText = `**${selectedText}**`;
        break;
      case 'italic':
        formattedText = `*${selectedText}*`;
        break;
      case 'strikethrough':
        formattedText = `~~${selectedText}~~`;
        break;
      case 'code':
        formattedText = `\`${selectedText}\``;
        break;
      case 'link':
        formattedText = `[${selectedText}](url)`;
        break;
      case 'quote':
        formattedText = `> ${selectedText}`;
        break;
      case 'h1':
        formattedText = `# ${selectedText}`;
        break;
      case 'h2':
        formattedText = `## ${selectedText}`;
        break;
      case 'h3':
        formattedText = `### ${selectedText}`;
        break;
      case 'list':
        formattedText = `- ${selectedText}`;
        break;
      case 'ordered-list':
        formattedText = `1. ${selectedText}`;
        break;
    }

    const newContent = 
      currentDoc.content.substring(0, start) + 
      formattedText + 
      currentDoc.content.substring(end);
    
    setCurrentDoc(prev => ({
      ...prev,
      content: newContent,
      wordCount: newContent.split(/\s+/).length,
      charCount: newContent.length,
      lastModified: new Date()
    }));
  };

  const insertTable = () => {
    const table = `
| Column 1 | Column 2 | Column 3 |
|----------|----------|----------|
| Data 1   | Data 2   | Data 3   |
| Data 4   | Data 5   | Data 6   |
`;
    
    const textarea = textAreaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const newContent = 
      currentDoc.content.substring(0, start) + 
      table + 
      currentDoc.content.substring(start);
    
    setCurrentDoc(prev => ({
      ...prev,
      content: newContent,
      lastModified: new Date()
    }));
  };

  const findInText = () => {
    if (!findReplace.find) return;
    
    const content = settings.caseSensitive ? currentDoc.content : currentDoc.content.toLowerCase();
    const searchTerm = settings.caseSensitive ? findReplace.find : findReplace.find.toLowerCase();
    
    const matches = content.split(searchTerm).length - 1;
    setFindReplace(prev => ({ ...prev, findResults: matches, currentResult: matches > 0 ? 1 : 0 }));
  };

  const replaceInText = () => {
    if (!findReplace.find) return;
    
    const flags = `g${findReplace.caseSensitive ? '' : 'i'}`;
    const regex = findReplace.useRegex 
      ? new RegExp(findReplace.find, flags)
      : new RegExp(findReplace.find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), flags);
    
    const newContent = currentDoc.content.replace(regex, findReplace.replace);
    
    setCurrentDoc(prev => ({
      ...prev,
      content: newContent,
      wordCount: newContent.split(/\s+/).length,
      charCount: newContent.length,
      lastModified: new Date()
    }));
  };

  const exportDocument = (format: string) => {
    const blob = new Blob([currentDoc.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentDoc.name.split('.')[0]}.${format}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const switchDocument = (docId: string) => {
    const doc = documents.find(d => d.id === docId);
    if (doc) setCurrentDoc(doc);
  };

  const createNewDocument = () => {
    const newDoc: EditorDocument = {
      id: `doc${Date.now()}`,
      name: "untitled.txt",
      content: "",
      language: "plaintext",
      encoding: "utf-8",
      lineEndings: "lf",
      lastModified: new Date(),
      wordCount: 0,
      charCount: 0,
      selectedText: "",
      cursorPosition: { line: 1, column: 1 }
    };
    
    setDocuments(prev => [...prev, newDoc]);
    setCurrentDoc(newDoc);
  };

  const themes = [
    "DeepBlue Dark", "DeepBlue Light", "Ocean Depths", "VS Code Dark",
    "Monokai", "Solarized Dark", "Solarized Light", "High Contrast"
  ];

  const languages = [
    "plaintext", "markdown", "html", "css", "javascript", "typescript",
    "python", "java", "cpp", "rust", "go", "json", "xml", "yaml"
  ];

  const fontFamilies = [
    "JetBrains Mono", "Fira Code", "Consolas", "Monaco", "SF Mono",
    "Source Code Pro", "Ubuntu Mono", "Roboto Mono", "Cascadia Code"
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-blue-500" />
            Advanced Text Editor - {currentDoc.name}
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <div className="flex items-center justify-between mb-4 flex-shrink-0">
            <TabsList className="grid grid-cols-5">
              <TabsTrigger value="editor">Editor</TabsTrigger>
              <TabsTrigger value="formatting">Format</TabsTrigger>
              <TabsTrigger value="find">Find/Replace</TabsTrigger>
              <TabsTrigger value="documents">Documents</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" onClick={createNewDocument}>
                <FileText className="h-4 w-4 mr-2" />
                New
              </Button>
              <Button size="sm" variant="outline">
                <Save className="h-4 w-4 mr-2" />
                Save
              </Button>
              <Button size="sm" variant="outline">
                <Undo className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="outline">
                <Redo className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <TabsContent value="editor" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 h-full">
              <div className="lg:col-span-3 flex flex-col">
                <div className="flex items-center gap-2 mb-2">
                  <Select value={currentDoc.language} onValueChange={(lang) => setCurrentDoc(prev => ({ ...prev, language: lang }))}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map(lang => (
                        <SelectItem key={lang} value={lang}>{lang}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Badge variant="outline">
                    {currentDoc.wordCount} words
                  </Badge>
                  <Badge variant="outline">
                    {currentDoc.charCount} chars
                  </Badge>
                  <Badge variant="outline">
                    Line {currentDoc.cursorPosition.line}
                  </Badge>
                </div>

                <Textarea
                  ref={textAreaRef}
                  value={currentDoc.content}
                  onChange={(e) => {
                    const newContent = e.target.value;
                    setCurrentDoc(prev => ({
                      ...prev,
                      content: newContent,
                      wordCount: newContent.trim() ? newContent.split(/\s+/).length : 0,
                      charCount: newContent.length,
                      lastModified: new Date()
                    }));
                  }}
                  className="flex-1 font-mono text-sm resize-none"
                  style={{ 
                    fontSize: `${settings.fontSize}px`,
                    fontFamily: settings.fontFamily,
                    lineHeight: '1.6'
                  }}
                  placeholder="Start typing your document..."
                />
              </div>

              <Card className="lg:col-span-1 flex flex-col">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Document Info</CardTitle>
                </CardHeader>
                <CardContent className="flex-1">
                  <div className="space-y-3 text-sm">
                    <div>
                      <Label className="text-xs text-muted-foreground">Name</Label>
                      <Input 
                        value={currentDoc.name}
                        onChange={(e) => setCurrentDoc(prev => ({ ...prev, name: e.target.value }))}
                        className="mt-1"
                      />
                    </div>
                    
                    <div>
                      <Label className="text-xs text-muted-foreground">Encoding</Label>
                      <p className="mt-1">{currentDoc.encoding}</p>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-muted-foreground">Line Endings</Label>
                      <p className="mt-1">{currentDoc.lineEndings.toUpperCase()}</p>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-muted-foreground">Last Modified</Label>
                      <p className="mt-1">{currentDoc.lastModified.toLocaleString()}</p>
                    </div>

                    <Separator />

                    <div>
                      <Label className="text-xs text-muted-foreground">Statistics</Label>
                      <div className="mt-1 space-y-1">
                        <p>Words: {currentDoc.wordCount}</p>
                        <p>Characters: {currentDoc.charCount}</p>
                        <p>Lines: {currentDoc.content.split('\n').length}</p>
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <Button size="sm" className="w-full" onClick={() => exportDocument('txt')}>
                        Export as TXT
                      </Button>
                      <Button size="sm" variant="outline" className="w-full" onClick={() => exportDocument('md')}>
                        Export as MD
                      </Button>
                      <Button size="sm" variant="outline" className="w-full" onClick={() => exportDocument('html')}>
                        Export as HTML
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="formatting" className="flex-1 overflow-hidden">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Text Formatting</CardTitle>
                  <CardDescription>Format selected text with these tools</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-4 lg:grid-cols-8 gap-2">
                    <Button size="sm" variant="outline" onClick={() => formatText('bold')}>
                      <Bold className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => formatText('italic')}>
                      <Italic className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => formatText('strikethrough')}>
                      <Strikethrough className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => formatText('code')}>
                      <Code className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => formatText('link')}>
                      <Link className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => formatText('quote')}>
                      <Quote className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => formatText('list')}>
                      <List className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => formatText('ordered-list')}>
                      <ListOrdered className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Headings & Structure</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
                    <Button size="sm" variant="outline" onClick={() => formatText('h1')}>
                      <Hash className="h-4 w-4 mr-2" />
                      H1
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => formatText('h2')}>
                      <Hash className="h-4 w-4 mr-2" />
                      H2
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => formatText('h3')}>
                      <Hash className="h-4 w-4 mr-2" />
                      H3
                    </Button>
                    <Button size="sm" variant="outline" onClick={insertTable}>
                      <Table className="h-4 w-4 mr-2" />
                      Table
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Document Templates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-2">
                    <Button size="sm" variant="outline" className="justify-start">
                      <FileText className="h-4 w-4 mr-2" />
                      Blog Post
                    </Button>
                    <Button size="sm" variant="outline" className="justify-start">
                      <FileText className="h-4 w-4 mr-2" />
                      Documentation
                    </Button>
                    <Button size="sm" variant="outline" className="justify-start">
                      <FileText className="h-4 w-4 mr-2" />
                      README
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="find" className="flex-1 overflow-hidden">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Find & Replace</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div>
                      <Label>Find</Label>
                      <div className="flex gap-2 mt-1">
                        <Input 
                          value={findReplace.find}
                          onChange={(e) => setFindReplace(prev => ({ ...prev, find: e.target.value }))}
                          placeholder="Search text..."
                        />
                        <Button size="sm" onClick={findInText}>
                          <Search className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div>
                      <Label>Replace</Label>
                      <div className="flex gap-2 mt-1">
                        <Input 
                          value={findReplace.replace}
                          onChange={(e) => setFindReplace(prev => ({ ...prev, replace: e.target.value }))}
                          placeholder="Replace with..."
                        />
                        <Button size="sm" onClick={replaceInText}>
                          <Replace className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch 
                        checked={findReplace.caseSensitive}
                        onCheckedChange={(checked) => setFindReplace(prev => ({ ...prev, caseSensitive: checked }))}
                      />
                      <Label>Case sensitive</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch 
                        checked={findReplace.wholeWord}
                        onCheckedChange={(checked) => setFindReplace(prev => ({ ...prev, wholeWord: checked }))}
                      />
                      <Label>Whole word</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch 
                        checked={findReplace.useRegex}
                        onCheckedChange={(checked) => setFindReplace(prev => ({ ...prev, useRegex: checked }))}
                      />
                      <Label>Regex</Label>
                    </div>
                  </div>

                  {findReplace.findResults > 0 && (
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary">
                        {findReplace.currentResult} of {findReplace.findResults} matches
                      </Badge>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="documents" className="flex-1 overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Open Documents</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-2">
                      {documents.map((doc) => (
                        <div 
                          key={doc.id}
                          className={`p-3 border rounded cursor-pointer transition-colors ${
                            doc.id === currentDoc.id ? 'bg-accent' : 'hover:bg-accent/50'
                          }`}
                          onClick={() => switchDocument(doc.id)}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{doc.name}</span>
                            <Badge variant="outline" className="text-xs">
                              {doc.language}
                            </Badge>
                          </div>
                          <div className="text-sm text-muted-foreground mt-1">
                            {doc.wordCount} words • {doc.charCount} chars
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Recent Files</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-2">
                      {recentFiles.map((file, index) => (
                        <div key={index} className="p-3 border rounded hover:bg-accent/50 cursor-pointer">
                          <div className="font-medium">{file.name}</div>
                          <div className="text-sm text-muted-foreground">{file.path}</div>
                          <div className="text-xs text-muted-foreground mt-1">
                            Last opened: {file.lastOpened.toLocaleString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="flex-1 overflow-hidden">
            <ScrollArea className="h-full">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Editor Appearance</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                      <div>
                        <Label>Font Family</Label>
                        <Select value={settings.fontFamily} onValueChange={(value) => setSettings(prev => ({ ...prev, fontFamily: value }))}>
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {fontFamilies.map(font => (
                              <SelectItem key={font} value={font}>{font}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label>Theme</Label>
                        <Select value={settings.theme} onValueChange={(value) => setSettings(prev => ({ ...prev, theme: value }))}>
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {themes.map(theme => (
                              <SelectItem key={theme} value={theme}>{theme}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label>Font Size: {settings.fontSize}px</Label>
                      <Slider
                        value={[settings.fontSize]}
                        onValueChange={([value]) => setSettings(prev => ({ ...prev, fontSize: value }))}
                        min={10}
                        max={24}
                        step={1}
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label>Tab Size: {settings.tabSize}</Label>
                      <Slider
                        value={[settings.tabSize]}
                        onValueChange={([value]) => setSettings(prev => ({ ...prev, tabSize: value }))}
                        min={2}
                        max={8}
                        step={1}
                        className="mt-2"
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Editor Features</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center justify-between">
                        <Label>Line Numbers</Label>
                        <Switch 
                          checked={settings.lineNumbers}
                          onCheckedChange={(checked) => setSettings(prev => ({ ...prev, lineNumbers: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Word Wrap</Label>
                        <Switch 
                          checked={settings.wordWrap}
                          onCheckedChange={(checked) => setSettings(prev => ({ ...prev, wordWrap: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Auto Indent</Label>
                        <Switch 
                          checked={settings.autoIndent}
                          onCheckedChange={(checked) => setSettings(prev => ({ ...prev, autoIndent: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Minimap</Label>
                        <Switch 
                          checked={settings.minimap}
                          onCheckedChange={(checked) => setSettings(prev => ({ ...prev, minimap: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Bracket Matching</Label>
                        <Switch 
                          checked={settings.bracketMatching}
                          onCheckedChange={(checked) => setSettings(prev => ({ ...prev, bracketMatching: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Auto Complete</Label>
                        <Switch 
                          checked={settings.autoComplete}
                          onCheckedChange={(checked) => setSettings(prev => ({ ...prev, autoComplete: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Spell Check</Label>
                        <Switch 
                          checked={settings.spellCheck}
                          onCheckedChange={(checked) => setSettings(prev => ({ ...prev, spellCheck: checked }))}
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <Label>Code Folding</Label>
                        <Switch 
                          checked={settings.folding}
                          onCheckedChange={(checked) => setSettings(prev => ({ ...prev, folding: checked }))}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}