import React, { useState, useCallback, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  Upload, Download, Copy, Move, Trash2, Archive, 
  FolderOpen, FileText, Image, Video, FileCheck,
  Cloud, Lock, Unlock, History, Search, Filter
} from "lucide-react";

interface AdvancedFileOperationsProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FileOperation {
  id: string;
  type: 'upload' | 'download' | 'copy' | 'move' | 'delete' | 'compress' | 'extract';
  files: string[];
  status: 'pending' | 'processing' | 'completed' | 'error';
  progress: number;
  startTime: Date;
  endTime?: Date;
  error?: string;
  size?: number;
}

interface CloudProvider {
  id: string;
  name: string;
  icon: string;
  connected: boolean;
  storageUsed: number;
  storageLimit: number;
}

export default function AdvancedFileOperations({ isOpen, onClose }: AdvancedFileOperationsProps) {
  const [operations, setOperations] = useState<FileOperation[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  
  const [cloudProviders] = useState<CloudProvider[]>([
    {
      id: 'google-drive',
      name: 'Google Drive',
      icon: '🔵',
      connected: true,
      storageUsed: 8.5,
      storageLimit: 15
    },
    {
      id: 'onedrive',
      name: 'OneDrive',
      icon: '🔷',
      connected: false,
      storageUsed: 0,
      storageLimit: 5
    },
    {
      id: 'dropbox',
      name: 'Dropbox',
      icon: '🟦',
      connected: true,
      storageUsed: 2.1,
      storageLimit: 2
    }
  ]);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const { files, createProject, addFile } = useIDEState();
  const { toast } = useToast();

  const handleDragAndDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const droppedFiles = Array.from(e.dataTransfer.files);
    
    if (droppedFiles.length > 0) {
      handleFileUpload(droppedFiles);
    }
  }, []);

  const handleFileUpload = useCallback(async (fileList: File[]) => {
    setIsUploading(true);
    setUploadProgress(0);

    const operation: FileOperation = {
      id: `upload-${Date.now()}`,
      type: 'upload',
      files: fileList.map(f => f.name),
      status: 'processing',
      progress: 0,
      startTime: new Date(),
      size: fileList.reduce((sum, f) => sum + f.size, 0)
    };

    setOperations(prev => [...prev, operation]);

    try {
      for (let i = 0; i < fileList.length; i++) {
        const file = fileList[i];
        const content = await file.text();
        
        // Simulate upload progress
        const progress = ((i + 1) / fileList.length) * 100;
        setUploadProgress(progress);
        
        setOperations(prev => prev.map(op => 
          op.id === operation.id ? { ...op, progress } : op
        ));

        // Add file to IDE
        await addFile({
          name: file.name,
          path: `/${file.name}`,
          content,
          language: getLanguageFromExtension(file.name),
          isDirectory: false,
          projectId: 1
        });

        // Simulate processing time
        await new Promise(resolve => setTimeout(resolve, 200));
      }

      setOperations(prev => prev.map(op => 
        op.id === operation.id ? { 
          ...op, 
          status: 'completed',
          progress: 100,
          endTime: new Date()
        } : op
      ));

      toast({
        title: "Upload completed",
        description: `${fileList.length} file(s) uploaded successfully`,
      });

    } catch (error) {
      setOperations(prev => prev.map(op => 
        op.id === operation.id ? { 
          ...op, 
          status: 'error',
          error: error instanceof Error ? error.message : 'Upload failed',
          endTime: new Date()
        } : op
      ));

      toast({
        title: "Upload failed",
        description: "Some files could not be uploaded",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  }, [addFile, toast]);

  const getLanguageFromExtension = (filename: string): string => {
    const ext = filename.split('.').pop()?.toLowerCase();
    const languageMap: Record<string, string> = {
      'js': 'javascript',
      'jsx': 'javascript',
      'ts': 'typescript',
      'tsx': 'typescript',
      'py': 'python',
      'java': 'java',
      'cpp': 'cpp',
      'c': 'c',
      'rs': 'rust',
      'go': 'go',
      'php': 'php',
      'rb': 'ruby',
      'html': 'html',
      'css': 'css',
      'scss': 'scss',
      'json': 'json',
      'xml': 'xml',
      'yaml': 'yaml',
      'yml': 'yaml',
      'md': 'markdown',
      'sql': 'sql',
      'sh': 'bash'
    };
    return languageMap[ext || ''] || 'text';
  };

  const handleBulkOperation = useCallback(async (
    operationType: 'copy' | 'move' | 'delete' | 'compress',
    selectedFiles: string[]
  ) => {
    const operation: FileOperation = {
      id: `${operationType}-${Date.now()}`,
      type: operationType,
      files: selectedFiles,
      status: 'processing',
      progress: 0,
      startTime: new Date()
    };

    setOperations(prev => [...prev, operation]);

    try {
      // Simulate operation processing
      for (let i = 0; i <= 100; i += 10) {
        await new Promise(resolve => setTimeout(resolve, 100));
        setOperations(prev => prev.map(op => 
          op.id === operation.id ? { ...op, progress: i } : op
        ));
      }

      setOperations(prev => prev.map(op => 
        op.id === operation.id ? { 
          ...op, 
          status: 'completed',
          progress: 100,
          endTime: new Date()
        } : op
      ));

      toast({
        title: `${operationType.charAt(0).toUpperCase() + operationType.slice(1)} completed`,
        description: `${selectedFiles.length} file(s) processed successfully`,
      });

      setSelectedFiles([]);

    } catch (error) {
      setOperations(prev => prev.map(op => 
        op.id === operation.id ? { 
          ...op, 
          status: 'error',
          error: error instanceof Error ? error.message : 'Operation failed',
          endTime: new Date()
        } : op
      ));

      toast({
        title: "Operation failed",
        description: "The operation could not be completed",
        variant: "destructive",
      });
    }
  }, [toast]);

  const handleFileExport = useCallback((format: 'zip' | 'tar' | 'tar.gz') => {
    const exportData = {
      format,
      files: files.map(file => ({
        name: file.name,
        path: file.path,
        content: file.content,
        language: file.language
      })),
      metadata: {
        exportedAt: new Date().toISOString(),
        projectName: 'DeepBlue IDE Project',
        version: '2.1.0'
      }
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { 
      type: 'application/json' 
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `project-export-${format}-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Project exported",
      description: `Project exported as ${format.toUpperCase()} format`,
    });
  }, [files, toast]);

  const connectCloudProvider = useCallback((providerId: string) => {
    // Simulate cloud connection
    toast({
      title: "Cloud connection",
      description: `Connecting to ${providerId}...`,
    });

    setTimeout(() => {
      toast({
        title: "Connected successfully",
        description: `${providerId} is now connected`,
      });
    }, 2000);
  }, [toast]);

  const getFileIcon = (filename: string) => {
    const ext = filename.split('.').pop()?.toLowerCase();
    
    if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'].includes(ext || '')) {
      return <Image className="w-4 h-4 text-blue-500" />;
    }
    if (['mp4', 'avi', 'mov', 'mkv', 'webm'].includes(ext || '')) {
      return <Video className="w-4 h-4 text-purple-500" />;
    }
    if (['zip', 'tar', 'gz', 'rar', '7z'].includes(ext || '')) {
      return <Archive className="w-4 h-4 text-orange-500" />;
    }
    
    return <FileText className="w-4 h-4 text-gray-500" />;
  };

  const getOperationIcon = (type: string) => {
    switch (type) {
      case 'upload': return <Upload className="w-4 h-4" />;
      case 'download': return <Download className="w-4 h-4" />;
      case 'copy': return <Copy className="w-4 h-4" />;
      case 'move': return <Move className="w-4 h-4" />;
      case 'delete': return <Trash2 className="w-4 h-4" />;
      case 'compress': return <Archive className="w-4 h-4" />;
      default: return <FileCheck className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-50 border-green-200';
      case 'processing': return 'text-blue-600 bg-blue-50 border-blue-200';
      case 'error': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FolderOpen className="w-5 h-5" />
            Advanced File Operations
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1">
          <Tabs defaultValue="upload">
            <TabsList>
              <TabsTrigger value="upload">Upload & Import</TabsTrigger>
              <TabsTrigger value="bulk">Bulk Operations</TabsTrigger>
              <TabsTrigger value="export">Export & Backup</TabsTrigger>
              <TabsTrigger value="cloud">Cloud Storage</TabsTrigger>
              <TabsTrigger value="history">Operation History</TabsTrigger>
            </TabsList>

            <TabsContent value="upload" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>File Upload</CardTitle>
                </CardHeader>
                <CardContent>
                  <div
                    className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors"
                    onDrop={handleDragAndDrop}
                    onDragOver={(e) => e.preventDefault()}
                    onDragEnter={(e) => e.preventDefault()}
                  >
                    <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                    <p className="text-lg font-medium mb-2">Drag and drop files here</p>
                    <p className="text-gray-500 mb-4">or click to browse</p>
                    <Button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploading}
                    >
                      {isUploading ? 'Uploading...' : 'Choose Files'}
                    </Button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      multiple
                      className="hidden"
                      onChange={(e) => {
                        const files = Array.from(e.target.files || []);
                        if (files.length > 0) {
                          handleFileUpload(files);
                        }
                      }}
                    />
                  </div>
                  
                  {isUploading && (
                    <div className="mt-4">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Uploading files...</span>
                        <span>{uploadProgress.toFixed(0)}%</span>
                      </div>
                      <Progress value={uploadProgress} className="h-2" />
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Import Project</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    <Button variant="outline" className="h-24 flex flex-col">
                      <Archive className="w-8 h-8 mb-2" />
                      ZIP Archive
                    </Button>
                    <Button variant="outline" className="h-24 flex flex-col">
                      <Archive className="w-8 h-8 mb-2" />
                      TAR Archive
                    </Button>
                    <Button variant="outline" className="h-24 flex flex-col">
                      <FolderOpen className="w-8 h-8 mb-2" />
                      Git Repository
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="bulk" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Bulk File Operations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <Search className="w-4 h-4" />
                        <Input
                          placeholder="Search files..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="w-64"
                        />
                      </div>
                      <select
                        value={filterType}
                        onChange={(e) => setFilterType(e.target.value)}
                        className="px-3 py-2 border rounded"
                      >
                        <option value="all">All Files</option>
                        <option value="javascript">JavaScript</option>
                        <option value="typescript">TypeScript</option>
                        <option value="python">Python</option>
                        <option value="images">Images</option>
                      </select>
                    </div>

                    <div className="border rounded">
                      <div className="max-h-64 overflow-y-auto">
                        {files.map((file) => (
                          <div
                            key={file.id}
                            className="flex items-center gap-3 p-3 border-b hover:bg-gray-50"
                          >
                            <Checkbox
                              checked={selectedFiles.includes(file.name)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setSelectedFiles(prev => [...prev, file.name]);
                                } else {
                                  setSelectedFiles(prev => prev.filter(f => f !== file.name));
                                }
                              }}
                            />
                            {getFileIcon(file.name)}
                            <div className="flex-1">
                              <div className="font-medium">{file.name}</div>
                              <div className="text-sm text-gray-500">{file.path}</div>
                            </div>
                            <Badge variant="outline">{file.language}</Badge>
                            <span className="text-xs text-gray-500">
                              {file.size || 0} bytes
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {selectedFiles.length > 0 && (
                      <div className="flex gap-2">
                        <Button
                          onClick={() => handleBulkOperation('copy', selectedFiles)}
                          variant="outline"
                        >
                          <Copy className="w-4 h-4 mr-2" />
                          Copy ({selectedFiles.length})
                        </Button>
                        <Button
                          onClick={() => handleBulkOperation('move', selectedFiles)}
                          variant="outline"
                        >
                          <Move className="w-4 h-4 mr-2" />
                          Move ({selectedFiles.length})
                        </Button>
                        <Button
                          onClick={() => handleBulkOperation('compress', selectedFiles)}
                          variant="outline"
                        >
                          <Archive className="w-4 h-4 mr-2" />
                          Compress ({selectedFiles.length})
                        </Button>
                        <Button
                          onClick={() => handleBulkOperation('delete', selectedFiles)}
                          variant="destructive"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete ({selectedFiles.length})
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="export" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Export Project</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4 mb-6">
                    <Button
                      onClick={() => handleFileExport('zip')}
                      variant="outline"
                      className="h-24 flex flex-col"
                    >
                      <Archive className="w-8 h-8 mb-2" />
                      ZIP Archive
                    </Button>
                    <Button
                      onClick={() => handleFileExport('tar')}
                      variant="outline"
                      className="h-24 flex flex-col"
                    >
                      <Archive className="w-8 h-8 mb-2" />
                      TAR Archive
                    </Button>
                    <Button
                      onClick={() => handleFileExport('tar.gz')}
                      variant="outline"
                      className="h-24 flex flex-col"
                    >
                      <Archive className="w-8 h-8 mb-2" />
                      TAR.GZ Archive
                    </Button>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-medium">Backup Options</h4>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="include-node-modules" />
                      <label htmlFor="include-node-modules">Include node_modules</label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="include-git" />
                      <label htmlFor="include-git">Include .git directory</label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="encrypt-backup" />
                      <label htmlFor="encrypt-backup">Encrypt backup</label>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="cloud" className="space-y-4">
              <div className="grid gap-4">
                {cloudProviders.map((provider) => (
                  <Card key={provider.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{provider.icon}</span>
                          <div>
                            <h4 className="font-medium">{provider.name}</h4>
                            <p className="text-sm text-gray-500">
                              {provider.storageUsed}GB / {provider.storageLimit}GB used
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {provider.connected ? (
                            <>
                              <Badge variant="default">Connected</Badge>
                              <Button size="sm" variant="outline">
                                <Cloud className="w-4 h-4 mr-2" />
                                Sync
                              </Button>
                            </>
                          ) : (
                            <Button
                              size="sm"
                              onClick={() => connectCloudProvider(provider.id)}
                            >
                              Connect
                            </Button>
                          )}
                        </div>
                      </div>
                      {provider.connected && (
                        <div className="mt-3">
                          <Progress 
                            value={(provider.storageUsed / provider.storageLimit) * 100} 
                            className="h-2"
                          />
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="history" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Operation History</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-3">
                      {operations.map((operation) => (
                        <div
                          key={operation.id}
                          className={`p-3 border rounded ${getStatusColor(operation.status)}`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              {getOperationIcon(operation.type)}
                              <span className="font-medium capitalize">
                                {operation.type}
                              </span>
                              <Badge variant="outline">
                                {operation.files.length} file(s)
                              </Badge>
                            </div>
                            <div className="text-sm text-gray-500">
                              {operation.startTime.toLocaleTimeString()}
                            </div>
                          </div>
                          
                          <div className="mt-2">
                            <div className="flex justify-between text-sm mb-1">
                              <span>Progress</span>
                              <span>{operation.progress}%</span>
                            </div>
                            <Progress value={operation.progress} className="h-1" />
                          </div>

                          {operation.error && (
                            <div className="mt-2 text-sm text-red-600">
                              Error: {operation.error}
                            </div>
                          )}

                          <div className="mt-2 text-xs text-gray-500">
                            Files: {operation.files.slice(0, 3).join(', ')}
                            {operation.files.length > 3 && ` +${operation.files.length - 3} more`}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}