import React, { useState, useCallback, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useIDEState } from "@/hooks/use-ide-state";
import { useToast } from "@/hooks/use-toast";
import { 
  Split, Columns, Rows, Monitor, Eye,
  FileText, Settings, RotateCcw, Maximize2,
  Minimize2, Move, Lock, Unlock
} from "lucide-react";

interface SplitScreenEditorProps {
  isOpen: boolean;
  onClose: () => void;
}

interface EditorPane {
  id: string;
  fileId: number | null;
  fileName: string;
  content: string;
  language: string;
  position: 'left' | 'right' | 'top' | 'bottom';
  isLocked: boolean;
  scrollPosition: number;
  cursorPosition: { line: number; column: number };
}

interface SplitLayout {
  id: string;
  name: string;
  type: 'horizontal' | 'vertical' | 'grid';
  panes: EditorPane[];
  isActive: boolean;
}

export default function SplitScreenEditor({ isOpen, onClose }: SplitScreenEditorProps) {
  const [splitLayouts, setSplitLayouts] = useState<SplitLayout[]>([
    {
      id: '1',
      name: 'Horizontal Split',
      type: 'horizontal',
      panes: [
        {
          id: 'left',
          fileId: 2,
          fileName: 'main.js',
          content: '',
          language: 'javascript',
          position: 'left',
          isLocked: false,
          scrollPosition: 0,
          cursorPosition: { line: 1, column: 1 }
        },
        {
          id: 'right',
          fileId: 3,
          fileName: 'styles.css',
          content: '',
          language: 'css',
          position: 'right',
          isLocked: false,
          scrollPosition: 0,
          cursorPosition: { line: 1, column: 1 }
        }
      ],
      isActive: true
    }
  ]);

  const [currentLayout, setCurrentLayout] = useState<SplitLayout>(splitLayouts[0]);
  const [syncScrolling, setSyncScrolling] = useState(false);
  const [syncCursor, setSyncCursor] = useState(false);
  const [showMinimaps, setShowMinimaps] = useState(true);
  const [splitRatio, setSplitRatio] = useState(50);

  const { files } = useIDEState();
  const { toast } = useToast();

  const handleCreateLayout = useCallback((type: 'horizontal' | 'vertical' | 'grid') => {
    const newLayout: SplitLayout = {
      id: Date.now().toString(),
      name: `${type} Split ${splitLayouts.length + 1}`,
      type,
      panes: type === 'grid' ? [
        {
          id: 'top-left',
          fileId: null,
          fileName: 'Select file...',
          content: '',
          language: 'plaintext',
          position: 'left',
          isLocked: false,
          scrollPosition: 0,
          cursorPosition: { line: 1, column: 1 }
        },
        {
          id: 'top-right',
          fileId: null,
          fileName: 'Select file...',
          content: '',
          language: 'plaintext',
          position: 'right',
          isLocked: false,
          scrollPosition: 0,
          cursorPosition: { line: 1, column: 1 }
        },
        {
          id: 'bottom-left',
          fileId: null,
          fileName: 'Select file...',
          content: '',
          language: 'plaintext',
          position: 'bottom',
          isLocked: false,
          scrollPosition: 0,
          cursorPosition: { line: 1, column: 1 }
        },
        {
          id: 'bottom-right',
          fileId: null,
          fileName: 'Select file...',
          content: '',
          language: 'plaintext',
          position: 'bottom',
          isLocked: false,
          scrollPosition: 0,
          cursorPosition: { line: 1, column: 1 }
        }
      ] : [
        {
          id: type === 'horizontal' ? 'left' : 'top',
          fileId: null,
          fileName: 'Select file...',
          content: '',
          language: 'plaintext',
          position: type === 'horizontal' ? 'left' : 'top',
          isLocked: false,
          scrollPosition: 0,
          cursorPosition: { line: 1, column: 1 }
        },
        {
          id: type === 'horizontal' ? 'right' : 'bottom',
          fileId: null,
          fileName: 'Select file...',
          content: '',
          language: 'plaintext',
          position: type === 'horizontal' ? 'right' : 'bottom',
          isLocked: false,
          scrollPosition: 0,
          cursorPosition: { line: 1, column: 1 }
        }
      ],
      isActive: false
    };

    setSplitLayouts(prev => [...prev, newLayout]);
    setCurrentLayout(newLayout);
    
    toast({
      title: "Layout created",
      description: `New ${type} split layout created`,
    });
  }, [splitLayouts, toast]);

  const handleDeleteLayout = useCallback((layoutId: string) => {
    setSplitLayouts(prev => {
      const filtered = prev.filter(l => l.id !== layoutId);
      if (currentLayout.id === layoutId && filtered.length > 0) {
        setCurrentLayout(filtered[0]);
      }
      return filtered;
    });
    
    toast({
      title: "Layout deleted",
      description: "Split layout has been deleted",
    });
  }, [currentLayout, toast]);

  const handleAssignFileToPane = useCallback((paneId: string, fileId: number) => {
    const file = files?.find(f => f.id === fileId);
    if (!file) return;

    setSplitLayouts(prev => prev.map(layout => 
      layout.id === currentLayout.id 
        ? {
            ...layout,
            panes: layout.panes.map(pane =>
              pane.id === paneId
                ? {
                    ...pane,
                    fileId,
                    fileName: file.name,
                    content: file.content,
                    language: file.language || 'plaintext'
                  }
                : pane
            )
          }
        : layout
    ));

    const updatedLayout = splitLayouts.find(l => l.id === currentLayout.id);
    if (updatedLayout) {
      setCurrentLayout({
        ...updatedLayout,
        panes: updatedLayout.panes.map(pane =>
          pane.id === paneId
            ? {
                ...pane,
                fileId,
                fileName: file.name,
                content: file.content,
                language: file.language || 'plaintext'
              }
            : pane
        )
      });
    }
  }, [currentLayout, files, splitLayouts]);

  const handleTogglePaneLock = useCallback((paneId: string) => {
    setSplitLayouts(prev => prev.map(layout => 
      layout.id === currentLayout.id 
        ? {
            ...layout,
            panes: layout.panes.map(pane =>
              pane.id === paneId ? { ...pane, isLocked: !pane.isLocked } : pane
            )
          }
        : layout
    ));

    const updatedLayout = splitLayouts.find(l => l.id === currentLayout.id);
    if (updatedLayout) {
      setCurrentLayout({
        ...updatedLayout,
        panes: updatedLayout.panes.map(pane =>
          pane.id === paneId ? { ...pane, isLocked: !pane.isLocked } : pane
        )
      });
    }
  }, [currentLayout, splitLayouts]);

  const renderEditorPane = (pane: EditorPane) => (
    <Card key={pane.id} className="h-full">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            <span className="font-medium text-sm">{pane.fileName}</span>
            <Badge variant="outline" className="text-xs">{pane.language}</Badge>
            {pane.isLocked && <Lock className="w-3 h-3 text-red-500" />}
          </div>
          <div className="flex items-center gap-1">
            <Select
              value={pane.fileId?.toString() || ''}
              onValueChange={(value) => handleAssignFileToPane(pane.id, parseInt(value))}
            >
              <SelectTrigger className="h-6 text-xs">
                <SelectValue placeholder="Select file" />
              </SelectTrigger>
              <SelectContent>
                {files?.filter(f => !f.isDirectory).map(file => (
                  <SelectItem key={file.id} value={file.id.toString()}>
                    {file.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleTogglePaneLock(pane.id)}
              className="h-6 w-6 p-0"
            >
              {pane.isLocked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-3 h-64">
        <div className="bg-gray-50 dark:bg-gray-900 rounded border h-full p-2 overflow-auto">
          <pre className="text-sm font-mono whitespace-pre-wrap">
            {pane.content || '// Select a file to edit...'}
          </pre>
        </div>
      </CardContent>
    </Card>
  );

  const renderSplitLayout = () => {
    const { type, panes } = currentLayout;
    
    if (type === 'horizontal') {
      return (
        <div className="flex h-96 gap-4">
          <div className="flex-1">
            {renderEditorPane(panes[0])}
          </div>
          <div className="w-1 bg-gray-300 cursor-col-resize" />
          <div className="flex-1">
            {renderEditorPane(panes[1])}
          </div>
        </div>
      );
    }
    
    if (type === 'vertical') {
      return (
        <div className="flex flex-col h-96 gap-4">
          <div className="flex-1">
            {renderEditorPane(panes[0])}
          </div>
          <div className="h-1 bg-gray-300 cursor-row-resize" />
          <div className="flex-1">
            {renderEditorPane(panes[1])}
          </div>
        </div>
      );
    }
    
    if (type === 'grid') {
      return (
        <div className="grid grid-cols-2 grid-rows-2 h-96 gap-2">
          {panes.map(pane => (
            <div key={pane.id}>
              {renderEditorPane(pane)}
            </div>
          ))}
        </div>
      );
    }
    
    return null;
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Split className="w-5 h-5" />
            Split-Screen Editor
            <Badge variant="outline">{currentLayout.name}</Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex flex-col space-y-4">
          {/* Layout Controls */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Layout Controls
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCreateLayout('horizontal')}
                    >
                      <Columns className="w-4 h-4 mr-2" />
                      Horizontal
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCreateLayout('vertical')}
                    >
                      <Rows className="w-4 h-4 mr-2" />
                      Vertical
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCreateLayout('grid')}
                    >
                      <Monitor className="w-4 h-4 mr-2" />
                      Grid (2x2)
                    </Button>
                  </div>
                  
                  <Select
                    value={currentLayout.id}
                    onValueChange={(value) => {
                      const layout = splitLayouts.find(l => l.id === value);
                      if (layout) setCurrentLayout(layout);
                    }}
                  >
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {splitLayouts.map(layout => (
                        <SelectItem key={layout.id} value={layout.id}>
                          {layout.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={syncScrolling}
                      onChange={(e) => setSyncScrolling(e.target.checked)}
                      className="rounded"
                    />
                    <span className="text-sm">Sync Scroll</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={syncCursor}
                      onChange={(e) => setSyncCursor(e.target.checked)}
                      className="rounded"
                    />
                    <span className="text-sm">Sync Cursor</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={showMinimaps}
                      onChange={(e) => setShowMinimaps(e.target.checked)}
                      className="rounded"
                    />
                    <span className="text-sm">Minimaps</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Split Editor */}
          <Card className="flex-1">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{currentLayout.name}</CardTitle>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">{currentLayout.type}</Badge>
                  <Badge variant="outline">{currentLayout.panes.length} panes</Badge>
                  {splitLayouts.length > 1 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteLayout(currentLayout.id)}
                    >
                      Delete Layout
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {renderSplitLayout()}
            </CardContent>
          </Card>

          {/* Pane Status */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Eye className="w-4 h-4" />
                Pane Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                {currentLayout.panes.map((pane, index) => (
                  <div key={pane.id} className="flex items-center justify-between p-2 border rounded">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">Pane {index + 1}</span>
                      <Badge variant="outline">{pane.position}</Badge>
                      {pane.isLocked && <Lock className="w-3 h-3 text-red-500" />}
                    </div>
                    <div className="text-sm text-gray-500">
                      {pane.fileName} ({pane.language})
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}