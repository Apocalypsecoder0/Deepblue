import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  Activity, 
  Cpu, 
  HardDrive, 
  MemoryStick, 
  Wifi, 
  Zap,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  Clock,
  Server,
  Monitor,
  RefreshCw,
  Download,
  Settings,
  BarChart3,
  PieChart,
  LineChart,
  Eye
} from "lucide-react";

interface PerformanceMonitorProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SystemMetrics {
  cpu: {
    usage: number;
    cores: number;
    temperature: number;
    frequency: number;
  };
  memory: {
    used: number;
    total: number;
    available: number;
    usage: number;
  };
  disk: {
    used: number;
    total: number;
    available: number;
    usage: number;
    readSpeed: number;
    writeSpeed: number;
  };
  network: {
    downloadSpeed: number;
    uploadSpeed: number;
    latency: number;
    packetsLost: number;
  };
  processes: Array<{
    name: string;
    pid: number;
    cpu: number;
    memory: number;
    status: 'running' | 'sleeping' | 'stopped';
  }>;
  timestamp: string;
}

interface PerformanceHistory {
  timestamp: string;
  cpu: number;
  memory: number;
  disk: number;
  network: number;
}

export default function PerformanceMonitor({ isOpen, onClose }: PerformanceMonitorProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('overview');
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);
  const [history, setHistory] = useState<PerformanceHistory[]>([]);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState(5000);
  const [alerts, setAlerts] = useState<Array<{
    id: string;
    type: 'warning' | 'error' | 'info';
    message: string;
    timestamp: string;
  }>>([]);

  useEffect(() => {
    if (isOpen) {
      loadMetrics();
      
      if (autoRefresh) {
        const interval = setInterval(loadMetrics, refreshInterval);
        return () => clearInterval(interval);
      }
    }
  }, [isOpen, autoRefresh, refreshInterval]);

  const loadMetrics = async () => {
    try {
      const response = await fetch('/api/system/metrics');
      const data = await response.json();
      setMetrics(data);
      
      // Add to history
      const historyPoint: PerformanceHistory = {
        timestamp: new Date().toISOString(),
        cpu: data.cpu.usage,
        memory: data.memory.usage,
        disk: data.disk.usage,
        network: data.network.downloadSpeed
      };
      
      setHistory(prev => [...prev.slice(-20), historyPoint]);
      
      // Check for alerts
      checkAlerts(data);
    } catch (error) {
      console.error('Failed to load metrics:', error);
      // Load sample metrics
      const sampleMetrics: SystemMetrics = {
        cpu: {
          usage: Math.random() * 100,
          cores: 8,
          temperature: 45 + Math.random() * 20,
          frequency: 2.4 + Math.random() * 1.6
        },
        memory: {
          used: 8.2,
          total: 16,
          available: 7.8,
          usage: 51.25
        },
        disk: {
          used: 120,
          total: 500,
          available: 380,
          usage: 24,
          readSpeed: 150 + Math.random() * 100,
          writeSpeed: 80 + Math.random() * 50
        },
        network: {
          downloadSpeed: 45.2 + Math.random() * 20,
          uploadSpeed: 12.8 + Math.random() * 10,
          latency: 15 + Math.random() * 10,
          packetsLost: Math.random() * 0.1
        },
        processes: [
          { name: 'DeepBlue IDE', pid: 1234, cpu: 15.2, memory: 256, status: 'running' },
          { name: 'Node.js', pid: 5678, cpu: 8.7, memory: 128, status: 'running' },
          { name: 'PostgreSQL', pid: 9012, cpu: 3.4, memory: 512, status: 'running' },
          { name: 'Chrome', pid: 3456, cpu: 12.1, memory: 1024, status: 'running' },
          { name: 'VSCode', pid: 7890, cpu: 5.3, memory: 186, status: 'sleeping' }
        ],
        timestamp: new Date().toISOString()
      };
      
      setMetrics(sampleMetrics);
    }
  };

  const checkAlerts = (data: SystemMetrics) => {
    const newAlerts = [];
    
    if (data.cpu.usage > 90) {
      newAlerts.push({
        id: `cpu-${Date.now()}`,
        type: 'error' as const,
        message: `High CPU usage detected: ${data.cpu.usage.toFixed(1)}%`,
        timestamp: new Date().toISOString()
      });
    }
    
    if (data.memory.usage > 85) {
      newAlerts.push({
        id: `memory-${Date.now()}`,
        type: 'warning' as const,
        message: `High memory usage: ${data.memory.usage.toFixed(1)}%`,
        timestamp: new Date().toISOString()
      });
    }
    
    if (data.disk.usage > 90) {
      newAlerts.push({
        id: `disk-${Date.now()}`,
        type: 'warning' as const,
        message: `Low disk space: ${data.disk.usage.toFixed(1)}% used`,
        timestamp: new Date().toISOString()
      });
    }
    
    if (newAlerts.length > 0) {
      setAlerts(prev => [...prev.slice(-10), ...newAlerts]);
    }
  };

  const formatBytes = (bytes: number) => {
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    if (bytes === 0) return '0 B';
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${sizes[i]}`;
  };

  const getStatusColor = (usage: number) => {
    if (usage > 90) return 'text-red-400';
    if (usage > 70) return 'text-yellow-400';
    return 'text-green-400';
  };

  const getProgressColor = (usage: number) => {
    if (usage > 90) return 'bg-red-600';
    if (usage > 70) return 'bg-yellow-600';
    return 'bg-green-600';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[95vh] bg-slate-900 border-slate-700">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            <Activity className="w-5 h-5" />
            Performance Monitor
            <div className="flex items-center gap-2 ml-auto">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setAutoRefresh(!autoRefresh)}
                className={autoRefresh ? 'bg-green-600' : ''}
              >
                <RefreshCw className={`w-4 h-4 ${autoRefresh ? 'animate-spin' : ''}`} />
                {autoRefresh ? 'Auto' : 'Manual'}
              </Button>
              <Button variant="outline" size="sm" onClick={loadMetrics}>
                <RefreshCw className="w-4 h-4" />
                Refresh
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-5 bg-slate-800">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="processes">Processes</TabsTrigger>
            <TabsTrigger value="network">Network</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="alerts">Alerts</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="flex-1">
            {metrics && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* CPU Card */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-sm">
                      <Cpu className="w-4 h-4 text-blue-400" />
                      CPU Usage
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-center">
                      <div className={`text-3xl font-bold ${getStatusColor(metrics.cpu.usage)}`}>
                        {metrics.cpu.usage.toFixed(1)}%
                      </div>
                      <Progress value={metrics.cpu.usage} className="h-2 mt-2" />
                    </div>
                    <div className="text-xs text-slate-400 space-y-1">
                      <div className="flex justify-between">
                        <span>Cores:</span>
                        <span>{metrics.cpu.cores}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Frequency:</span>
                        <span>{metrics.cpu.frequency.toFixed(1)} GHz</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Temperature:</span>
                        <span>{metrics.cpu.temperature.toFixed(1)}°C</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Memory Card */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-sm">
                      <MemoryStick className="w-4 h-4 text-green-400" />
                      Memory Usage
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-center">
                      <div className={`text-3xl font-bold ${getStatusColor(metrics.memory.usage)}`}>
                        {metrics.memory.usage.toFixed(1)}%
                      </div>
                      <Progress value={metrics.memory.usage} className="h-2 mt-2" />
                    </div>
                    <div className="text-xs text-slate-400 space-y-1">
                      <div className="flex justify-between">
                        <span>Used:</span>
                        <span>{metrics.memory.used.toFixed(1)} GB</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Total:</span>
                        <span>{metrics.memory.total} GB</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Available:</span>
                        <span>{metrics.memory.available.toFixed(1)} GB</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Disk Card */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-sm">
                      <HardDrive className="w-4 h-4 text-purple-400" />
                      Disk Usage
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-center">
                      <div className={`text-3xl font-bold ${getStatusColor(metrics.disk.usage)}`}>
                        {metrics.disk.usage.toFixed(1)}%
                      </div>
                      <Progress value={metrics.disk.usage} className="h-2 mt-2" />
                    </div>
                    <div className="text-xs text-slate-400 space-y-1">
                      <div className="flex justify-between">
                        <span>Used:</span>
                        <span>{metrics.disk.used} GB</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Total:</span>
                        <span>{metrics.disk.total} GB</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Read:</span>
                        <span>{metrics.disk.readSpeed.toFixed(1)} MB/s</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Write:</span>
                        <span>{metrics.disk.writeSpeed.toFixed(1)} MB/s</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Network Card */}
                <Card className="bg-slate-800 border-slate-700">
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-2 text-sm">
                      <Wifi className="w-4 h-4 text-orange-400" />
                      Network
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-center">
                      <div className="text-lg font-bold text-green-400">
                        {metrics.network.downloadSpeed.toFixed(1)} Mbps
                      </div>
                      <div className="text-sm text-slate-400">Download</div>
                    </div>
                    <div className="text-xs text-slate-400 space-y-1">
                      <div className="flex justify-between">
                        <span>Upload:</span>
                        <span>{metrics.network.uploadSpeed.toFixed(1)} Mbps</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Latency:</span>
                        <span>{metrics.network.latency.toFixed(1)}ms</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Packet Loss:</span>
                        <span>{(metrics.network.packetsLost * 100).toFixed(2)}%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="processes" className="flex-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">Running Processes</h3>
              <Badge className="bg-blue-600">
                {metrics?.processes.length || 0} processes
              </Badge>
            </div>

            <Card className="bg-slate-800 border-slate-700">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-slate-600">
                      <tr>
                        <th className="text-left p-4 text-white font-medium">Process</th>
                        <th className="text-left p-4 text-white font-medium">PID</th>
                        <th className="text-left p-4 text-white font-medium">CPU %</th>
                        <th className="text-left p-4 text-white font-medium">Memory</th>
                        <th className="text-left p-4 text-white font-medium">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {metrics?.processes.map((process) => (
                        <tr key={process.pid} className="border-b border-slate-700">
                          <td className="p-4 text-white font-medium">{process.name}</td>
                          <td className="p-4 text-slate-400">{process.pid}</td>
                          <td className="p-4">
                            <span className={getStatusColor(process.cpu)}>
                              {process.cpu.toFixed(1)}%
                            </span>
                          </td>
                          <td className="p-4 text-slate-300">{process.memory} MB</td>
                          <td className="p-4">
                            <Badge 
                              className={
                                process.status === 'running' ? 'bg-green-600' :
                                process.status === 'sleeping' ? 'bg-yellow-600' :
                                'bg-red-600'
                              }
                            >
                              {process.status}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="network" className="flex-1">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <TrendingUp className="w-4 h-4" />
                    Network Traffic
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-400">Download Speed</span>
                        <span className="text-green-400">{metrics?.network.downloadSpeed.toFixed(1)} Mbps</span>
                      </div>
                      <Progress value={(metrics?.network.downloadSpeed || 0) / 100 * 100} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-400">Upload Speed</span>
                        <span className="text-blue-400">{metrics?.network.uploadSpeed.toFixed(1)} Mbps</span>
                      </div>
                      <Progress value={(metrics?.network.uploadSpeed || 0) / 50 * 100} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Network Quality
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Latency</span>
                      <span className="text-white">{metrics?.network.latency.toFixed(1)}ms</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Packet Loss</span>
                      <span className={`${(metrics?.network.packetsLost || 0) > 0.01 ? 'text-red-400' : 'text-green-400'}`}>
                        {((metrics?.network.packetsLost || 0) * 100).toFixed(2)}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Connection Status</span>
                      <Badge className="bg-green-600">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Connected
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="history" className="flex-1">
            <Card className="bg-slate-800 border-slate-700 h-full">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <LineChart className="w-4 h-4" />
                  Performance History
                </CardTitle>
                <CardDescription>
                  System metrics over the last {history.length} measurements
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center">
                  <p className="text-slate-400">Performance chart would be displayed here</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="alerts" className="flex-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">System Alerts</h3>
              <Badge className="bg-red-600">
                {alerts.filter(a => a.type === 'error').length} errors
              </Badge>
            </div>

            <ScrollArea className="h-96">
              <div className="space-y-3">
                {alerts.length > 0 ? alerts.map((alert) => (
                  <Card key={alert.id} className="bg-slate-800 border-slate-700">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        {alert.type === 'error' && <AlertTriangle className="w-4 h-4 text-red-400" />}
                        {alert.type === 'warning' && <AlertTriangle className="w-4 h-4 text-yellow-400" />}
                        {alert.type === 'info' && <CheckCircle className="w-4 h-4 text-blue-400" />}
                        
                        <div className="flex-1">
                          <p className="text-white text-sm">{alert.message}</p>
                          <p className="text-xs text-slate-400 mt-1">
                            {new Date(alert.timestamp).toLocaleString()}
                          </p>
                        </div>
                        
                        <Badge className={
                          alert.type === 'error' ? 'bg-red-600' :
                          alert.type === 'warning' ? 'bg-yellow-600' :
                          'bg-blue-600'
                        }>
                          {alert.type}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                )) : (
                  <div className="flex items-center justify-center h-32">
                    <div className="text-center">
                      <CheckCircle className="w-8 h-8 text-green-400 mx-auto mb-2" />
                      <p className="text-slate-400">No alerts - System is running smoothly</p>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}