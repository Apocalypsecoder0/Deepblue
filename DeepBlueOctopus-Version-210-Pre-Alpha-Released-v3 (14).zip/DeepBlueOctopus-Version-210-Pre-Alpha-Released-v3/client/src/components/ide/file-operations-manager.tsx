import React, { useState, useRef, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Upload, Download, Copy, Move, Trash2, Archive, 
  FileImage, FileVideo, FileText, Eye, EyeOff,
  History, Lock, Unlock, CloudUpload, Folder,
  Search, Filter, MoreHorizontal, RefreshCw,
  CheckCircle2, AlertCircle, Clock, Zap,
  FileCode, Package, Image as ImageIcon
} from "lucide-react";

interface FileOperationsManagerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FileOperation {
  id: string;
  type: 'upload' | 'download' | 'copy' | 'move' | 'delete' | 'compress' | 'extract';
  files: string[];
  status: 'pending' | 'running' | 'completed' | 'failed';
  progress: number;
  timestamp: Date;
  destination?: string;
  size: number;
  error?: string;
}

interface FileTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  language: string;
  content: string;
  icon: string;
  size: number;
}

interface CloudProvider {
  id: string;
  name: string;
  icon: string;
  connected: boolean;
  storage: {
    used: number;
    total: number;
  };
}

export default function FileOperationsManager({ isOpen, onClose }: FileOperationsManagerProps) {
  const [activeTab, setActiveTab] = useState("operations");
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [isDragOver, setIsDragOver] = useState(false);
  const [autoSave, setAutoSave] = useState(true);
  const [encryptFiles, setEncryptFiles] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [operations, setOperations] = useState<FileOperation[]>([
    {
      id: "op-1",
      type: "upload",
      files: ["project-assets.zip", "components.tar.gz"],
      status: "completed",
      progress: 100,
      timestamp: new Date(Date.now() - 300000),
      size: 15.2,
    },
    {
      id: "op-2",
      type: "copy",
      files: ["src/components/", "src/utils/"],
      status: "running",
      progress: 65,
      timestamp: new Date(),
      destination: "backup/",
      size: 8.7,
    },
    {
      id: "op-3",
      type: "compress",
      files: ["dist/", "build/"],
      status: "pending",
      progress: 0,
      timestamp: new Date(),
      size: 45.3,
    }
  ]);

  const [templates, setTemplates] = useState<FileTemplate[]>([
    {
      id: "temp-1",
      name: "React Component",
      description: "Basic React functional component with TypeScript",
      category: "React",
      language: "typescript",
      content: `import React from 'react';\n\ninterface Props {\n  // Add your props here\n}\n\nexport default function Component({ }: Props) {\n  return (\n    <div>\n      {/* Your component content */}\n    </div>\n  );\n}`,
      icon: "⚛️",
      size: 0.25
    },
    {
      id: "temp-2",
      name: "Express API Route",
      description: "Express.js API route with error handling",
      category: "Node.js",
      language: "javascript",
      content: `const express = require('express');\nconst router = express.Router();\n\n// GET /api/resource\nrouter.get('/', async (req, res) => {\n  try {\n    // Your logic here\n    res.json({ success: true });\n  } catch (error) {\n    res.status(500).json({ error: error.message });\n  }\n});\n\nmodule.exports = router;`,
      icon: "🚀",
      size: 0.18
    },
    {
      id: "temp-3",
      name: "Python Class",
      description: "Python class template with docstrings",
      category: "Python",
      language: "python",
      content: `class ExampleClass:\n    """A simple example class.\n    \n    Attributes:\n        attribute (str): Description of attribute.\n    """\n    \n    def __init__(self, attribute: str):\n        """Initialize the class.\n        \n        Args:\n            attribute (str): Description of attribute.\n        """\n        self.attribute = attribute\n    \n    def method(self) -> str:\n        """Example method.\n        \n        Returns:\n            str: Description of return value.\n        """\n        return f"Hello, {self.attribute}!"`,
      icon: "🐍",
      size: 0.32
    }
  ]);

  const [cloudProviders, setCloudProviders] = useState<CloudProvider[]>([
    {
      id: "gdrive",
      name: "Google Drive",
      icon: "📁",
      connected: true,
      storage: { used: 8.5, total: 15 }
    },
    {
      id: "dropbox",
      name: "Dropbox",
      icon: "📦",
      connected: false,
      storage: { used: 0, total: 2 }
    },
    {
      id: "onedrive",
      name: "OneDrive",
      icon: "☁️",
      connected: true,
      storage: { used: 12.3, total: 100 }
    }
  ]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileUpload(files);
    }
  }, []);

  const handleFileUpload = (files: File[]) => {
    const newOperation: FileOperation = {
      id: `op-${Date.now()}`,
      type: "upload",
      files: files.map(f => f.name),
      status: "running",
      progress: 0,
      timestamp: new Date(),
      size: files.reduce((acc, f) => acc + (f.size / 1024 / 1024), 0)
    };

    setOperations(prev => [newOperation, ...prev]);

    // Simulate upload progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 20;
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        setOperations(prev => prev.map(op => 
          op.id === newOperation.id 
            ? { ...op, status: 'completed' as const, progress: 100 }
            : op
        ));
      } else {
        setOperations(prev => prev.map(op => 
          op.id === newOperation.id 
            ? { ...op, progress: Math.floor(progress) }
            : op
        ));
      }
    }, 200);
  };

  const handleBulkOperation = (operationType: FileOperation['type']) => {
    if (selectedFiles.length === 0) return;

    const newOperation: FileOperation = {
      id: `op-${Date.now()}`,
      type: operationType,
      files: [...selectedFiles],
      status: "pending",
      progress: 0,
      timestamp: new Date(),
      size: selectedFiles.length * 2.5 // Estimated size
    };

    setOperations(prev => [newOperation, ...prev]);
    setSelectedFiles([]);

    // Start operation after a delay
    setTimeout(() => {
      setOperations(prev => prev.map(op => 
        op.id === newOperation.id 
          ? { ...op, status: 'running' as const }
          : op
      ));

      // Simulate progress
      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress >= 100) {
          progress = 100;
          clearInterval(interval);
          setOperations(prev => prev.map(op => 
            op.id === newOperation.id 
              ? { ...op, status: 'completed' as const, progress: 100 }
              : op
          ));
        } else {
          setOperations(prev => prev.map(op => 
            op.id === newOperation.id 
              ? { ...op, progress: Math.floor(progress) }
              : op
          ));
        }
      }, 300);
    }, 1000);
  };

  const createFileFromTemplate = (template: FileTemplate) => {
    const fileName = `new-${template.name.toLowerCase().replace(/\s+/g, '-')}.${
      template.language === 'typescript' ? 'tsx' : 
      template.language === 'javascript' ? 'js' : 
      template.language === 'python' ? 'py' : 'txt'
    }`;

    // Simulate file creation
    console.log(`Creating file: ${fileName} from template: ${template.name}`);
  };

  const connectCloudProvider = (providerId: string) => {
    setCloudProviders(prev => prev.map(provider => 
      provider.id === providerId 
        ? { ...provider, connected: true }
        : provider
    ));
  };

  const getOperationIcon = (type: FileOperation['type']) => {
    switch (type) {
      case 'upload': return <Upload className="h-4 w-4" />;
      case 'download': return <Download className="h-4 w-4" />;
      case 'copy': return <Copy className="h-4 w-4" />;
      case 'move': return <Move className="h-4 w-4" />;
      case 'delete': return <Trash2 className="h-4 w-4" />;
      case 'compress': return <Archive className="h-4 w-4" />;
      case 'extract': return <Package className="h-4 w-4" />;
    }
  };

  const getStatusIcon = (status: FileOperation['status']) => {
    switch (status) {
      case 'completed': return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'failed': return <AlertCircle className="h-4 w-4 text-red-500" />;
      case 'running': return <RefreshCw className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'pending': return <Clock className="h-4 w-4 text-yellow-500" />;
    }
  };

  const mockFiles = [
    "src/components/Button.tsx",
    "src/utils/helpers.ts", 
    "public/images/logo.png",
    "docs/README.md",
    "package.json",
    "tsconfig.json",
    "src/styles/globals.css",
    "src/pages/index.tsx"
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Folder className="h-5 w-5 text-blue-500" />
            File Operations Manager
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-5 flex-shrink-0">
            <TabsTrigger value="operations" className="flex items-center gap-2">
              <RefreshCw className="h-4 w-4" />
              Operations
            </TabsTrigger>
            <TabsTrigger value="upload" className="flex items-center gap-2">
              <Upload className="h-4 w-4" />
              Upload
            </TabsTrigger>
            <TabsTrigger value="templates" className="flex items-center gap-2">
              <FileCode className="h-4 w-4" />
              Templates
            </TabsTrigger>
            <TabsTrigger value="cloud" className="flex items-center gap-2">
              <CloudUpload className="h-4 w-4" />
              Cloud Storage
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <MoreHorizontal className="h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="operations" className="flex-1 overflow-hidden flex flex-col">
            <div className="flex items-center gap-4 mb-4 flex-shrink-0">
              <div className="flex items-center gap-2">
                <Button 
                  onClick={() => handleBulkOperation('copy')}
                  disabled={selectedFiles.length === 0}
                  size="sm"
                  variant="outline"
                >
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Selected
                </Button>
                <Button 
                  onClick={() => handleBulkOperation('move')}
                  disabled={selectedFiles.length === 0}
                  size="sm"
                  variant="outline"
                >
                  <Move className="h-4 w-4 mr-2" />
                  Move Selected
                </Button>
                <Button 
                  onClick={() => handleBulkOperation('delete')}
                  disabled={selectedFiles.length === 0}
                  size="sm"
                  variant="destructive"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Selected
                </Button>
                <Button 
                  onClick={() => handleBulkOperation('compress')}
                  disabled={selectedFiles.length === 0}
                  size="sm"
                  variant="outline"
                >
                  <Archive className="h-4 w-4 mr-2" />
                  Compress
                </Button>
              </div>

              <Separator orientation="vertical" className="h-6" />

              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search files..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 w-64"
                />
              </div>

              <Badge variant="secondary">
                {selectedFiles.length} selected
              </Badge>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 flex-1 overflow-hidden">
              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <CardTitle className="text-base">File Selection</CardTitle>
                  <CardDescription>Select files for bulk operations</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden">
                  <ScrollArea className="h-full">
                    <div className="space-y-2">
                      {mockFiles.filter(file => 
                        file.toLowerCase().includes(searchQuery.toLowerCase())
                      ).map((file) => (
                        <div key={file} className="flex items-center space-x-2 p-2 rounded border hover:bg-accent">
                          <Checkbox
                            checked={selectedFiles.includes(file)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setSelectedFiles(prev => [...prev, file]);
                              } else {
                                setSelectedFiles(prev => prev.filter(f => f !== file));
                              }
                            }}
                          />
                          <FileText className="h-4 w-4 text-blue-500" />
                          <span className="text-sm">{file}</span>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card className="flex flex-col">
                <CardHeader className="flex-shrink-0">
                  <CardTitle className="text-base">Recent Operations</CardTitle>
                  <CardDescription>File operation history</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 overflow-hidden">
                  <ScrollArea className="h-full">
                    <div className="space-y-3">
                      {operations.map((operation) => (
                        <div key={operation.id} className="p-3 border rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {getOperationIcon(operation.type)}
                              <span className="font-medium capitalize">{operation.type}</span>
                              {getStatusIcon(operation.status)}
                            </div>
                            <span className="text-sm text-muted-foreground">
                              {operation.size.toFixed(1)} MB
                            </span>
                          </div>
                          
                          <div className="text-sm text-muted-foreground mb-2">
                            {operation.files.slice(0, 2).join(', ')}
                            {operation.files.length > 2 && ` +${operation.files.length - 2} more`}
                          </div>
                          
                          {operation.status === 'running' && (
                            <Progress value={operation.progress} className="h-2" />
                          )}
                          
                          <div className="flex justify-between items-center mt-2 text-xs text-muted-foreground">
                            <span>{operation.timestamp.toLocaleTimeString()}</span>
                            <span>{operation.progress}%</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="upload" className="flex-1 overflow-hidden">
            <div 
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                isDragOver ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' : 'border-gray-300'
              }`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            >
              <Upload className="h-12 w-12 mx-auto mb-4 text-gray-400" />
              <h3 className="text-lg font-semibold mb-2">Drop files here or click to upload</h3>
              <p className="text-muted-foreground mb-4">
                Support for multiple files, drag and drop, and bulk operations
              </p>
              <Button onClick={() => fileInputRef.current?.click()}>
                Choose Files
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                className="hidden"
                onChange={(e) => {
                  if (e.target.files) {
                    handleFileUpload(Array.from(e.target.files));
                  }
                }}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-6">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Upload Queue</p>
                      <p className="text-2xl font-bold">{operations.filter(op => op.type === 'upload' && op.status === 'pending').length}</p>
                    </div>
                    <Clock className="h-8 w-8 text-yellow-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Processing</p>
                      <p className="text-2xl font-bold">{operations.filter(op => op.status === 'running').length}</p>
                    </div>
                    <RefreshCw className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Completed</p>
                      <p className="text-2xl font-bold">{operations.filter(op => op.status === 'completed').length}</p>
                    </div>
                    <CheckCircle2 className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="templates" className="flex-1 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">File Templates</h3>
              <Button size="sm">
                <FileCode className="h-4 w-4 mr-2" />
                Create Template
              </Button>
            </div>

            <ScrollArea className="flex-1">
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                {templates.map((template) => (
                  <Card key={template.id} className="hover:shadow-md transition-shadow">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base flex items-center gap-2">
                          <span className="text-lg">{template.icon}</span>
                          {template.name}
                        </CardTitle>
                        <Badge variant="outline">{template.category}</Badge>
                      </div>
                      <CardDescription>{template.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-muted-foreground">
                          <span>{template.language}</span>
                          <span className="mx-2">•</span>
                          <span>{template.size} KB</span>
                        </div>
                        <Button 
                          size="sm" 
                          onClick={() => createFileFromTemplate(template)}
                        >
                          Use Template
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="cloud" className="flex-1 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">Cloud Storage Providers</h3>
              <Button size="sm">
                <CloudUpload className="h-4 w-4 mr-2" />
                Add Provider
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
              {cloudProviders.map((provider) => (
                <Card key={provider.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base flex items-center gap-2">
                        <span className="text-lg">{provider.icon}</span>
                        {provider.name}
                      </CardTitle>
                      <Badge variant={provider.connected ? "default" : "outline"}>
                        {provider.connected ? "Connected" : "Disconnected"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {provider.connected ? (
                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Storage Used</span>
                            <span>{provider.storage.used.toFixed(1)} GB / {provider.storage.total} GB</span>
                          </div>
                          <Progress value={(provider.storage.used / provider.storage.total) * 100} className="h-2" />
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" className="flex-1">
                            <Upload className="h-4 w-4 mr-2" />
                            Upload
                          </Button>
                          <Button size="sm" variant="outline" className="flex-1">
                            <Download className="h-4 w-4 mr-2" />
                            Sync
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <Button 
                        className="w-full" 
                        onClick={() => connectCloudProvider(provider.id)}
                      >
                        Connect
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="settings" className="flex-1 overflow-hidden">
            <ScrollArea className="flex-1">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>File Operations Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Auto-save Files</Label>
                        <p className="text-sm text-muted-foreground">Automatically save files after editing</p>
                      </div>
                      <Switch checked={autoSave} onCheckedChange={setAutoSave} />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Encrypt Sensitive Files</Label>
                        <p className="text-sm text-muted-foreground">Encrypt files containing sensitive data</p>
                      </div>
                      <Switch checked={encryptFiles} onCheckedChange={setEncryptFiles} />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Upload Preferences</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label>Default Upload Location</Label>
                      <Select defaultValue="workspace">
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="workspace">Current Workspace</SelectItem>
                          <SelectItem value="uploads">Uploads Folder</SelectItem>
                          <SelectItem value="temp">Temporary Folder</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label>Max File Size (MB)</Label>
                      <Input type="number" defaultValue="100" className="mt-1" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}