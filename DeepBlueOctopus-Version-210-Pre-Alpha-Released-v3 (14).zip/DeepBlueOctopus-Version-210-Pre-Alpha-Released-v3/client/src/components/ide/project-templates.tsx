import React, { useState, useCallback } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useIDEState } from "@/hooks/use-ide-state";
import { 
  FolderPlus, Code, Database, Globe, Smartphone,
  Play, Download, Upload, Star, Clock, Users,
  FileCode, Package, Settings, Zap
} from "lucide-react";

interface ProjectTemplatesProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ProjectTemplate {
  id: string;
  name: string;
  description: string;
  category: 'frontend' | 'backend' | 'fullstack' | 'mobile' | 'desktop' | 'game' | 'data' | 'ai';
  framework: string;
  language: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedTime: string;
  tags: string[];
  features: string[];
  fileStructure: FileTemplate[];
  dependencies: string[];
  scripts: Record<string, string>;
  environment: Record<string, string>;
  readme: string;
  isPopular: boolean;
  downloads: number;
  rating: number;
  author: string;
  version: string;
  lastUpdated: Date;
}

interface FileTemplate {
  path: string;
  content: string;
  language: string;
  isDirectory?: boolean;
}

export default function ProjectTemplates({ isOpen, onClose }: ProjectTemplatesProps) {
  const [projectTemplates] = useState<ProjectTemplate[]>([
    {
      id: 'react-typescript',
      name: 'React TypeScript Starter',
      description: 'Modern React application with TypeScript, Vite, and Tailwind CSS',
      category: 'frontend',
      framework: 'React',
      language: 'TypeScript',
      difficulty: 'intermediate',
      estimatedTime: '30 minutes',
      tags: ['react', 'typescript', 'vite', 'tailwind'],
      features: ['Hot reloading', 'TypeScript support', 'Tailwind CSS', 'ESLint', 'Prettier'],
      fileStructure: [
        {
          path: '/src',
          content: '',
          language: 'typescript',
          isDirectory: true
        },
        {
          path: '/src/App.tsx',
          content: `import React from 'react';
import './App.css';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="max-w-md mx-auto bg-white rounded-xl shadow-md p-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          Welcome to React + TypeScript
        </h1>
        <p className="text-gray-600">
          This is a modern React application with TypeScript and Tailwind CSS.
        </p>
      </div>
    </div>
  );
}

export default App;`,
          language: 'typescript'
        },
        {
          path: '/src/main.tsx',
          content: `import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.tsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)`,
          language: 'typescript'
        },
        {
          path: '/src/index.css',
          content: `@tailwind base;
@tailwind components;
@tailwind utilities;

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}`,
          language: 'css'
        }
      ],
      dependencies: ['react', 'react-dom', 'typescript', 'vite', 'tailwindcss'],
      scripts: {
        'dev': 'vite',
        'build': 'vite build',
        'preview': 'vite preview'
      },
      environment: {
        'NODE_ENV': 'development'
      },
      readme: `# React TypeScript Starter

A modern React application with TypeScript, Vite, and Tailwind CSS.

## Getting Started

1. Install dependencies: \`npm install\`
2. Start development server: \`npm run dev\`
3. Build for production: \`npm run build\`

## Features

- ⚡ Vite for fast development
- 🎨 Tailwind CSS for styling
- 📝 TypeScript for type safety
- 🔧 ESLint and Prettier for code quality`,
      isPopular: true,
      downloads: 15432,
      rating: 4.8,
      author: 'DeepBlue Team',
      version: '1.2.0',
      lastUpdated: new Date('2025-01-01')
    },
    {
      id: 'express-api',
      name: 'Express API Server',
      description: 'RESTful API server with Express, TypeScript, and PostgreSQL',
      category: 'backend',
      framework: 'Express',
      language: 'TypeScript',
      difficulty: 'intermediate',
      estimatedTime: '45 minutes',
      tags: ['express', 'api', 'postgresql', 'typescript'],
      features: ['REST API', 'PostgreSQL integration', 'Authentication', 'Rate limiting', 'Logging'],
      fileStructure: [
        {
          path: '/src',
          content: '',
          language: 'typescript',
          isDirectory: true
        },
        {
          path: '/src/index.ts',
          content: `import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { createServer } from 'http';

const app = express();
const server = createServer(app);

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

// Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

app.get('/api/users', (req, res) => {
  res.json([
    { id: 1, name: 'John Doe', email: 'john@example.com' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com' }
  ]);
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(\`Server running on port \${PORT}\`);
});`,
          language: 'typescript'
        },
        {
          path: '/src/routes/users.ts',
          content: `import { Router } from 'express';

const router = Router();

router.get('/', (req, res) => {
  res.json({ message: 'Users endpoint' });
});

router.post('/', (req, res) => {
  const { name, email } = req.body;
  res.json({ id: Date.now(), name, email });
});

export default router;`,
          language: 'typescript'
        }
      ],
      dependencies: ['express', 'cors', 'helmet', 'typescript', '@types/express'],
      scripts: {
        'dev': 'tsx watch src/index.ts',
        'build': 'tsc',
        'start': 'node dist/index.js'
      },
      environment: {
        'NODE_ENV': 'development',
        'PORT': '3000',
        'DATABASE_URL': 'postgresql://localhost:5432/myapp'
      },
      readme: `# Express API Server

RESTful API server with Express, TypeScript, and PostgreSQL.

## Getting Started

1. Install dependencies: \`npm install\`
2. Set up environment variables
3. Start development server: \`npm run dev\`

## API Endpoints

- \`GET /api/health\` - Health check
- \`GET /api/users\` - Get all users
- \`POST /api/users\` - Create user`,
      isPopular: true,
      downloads: 8921,
      rating: 4.6,
      author: 'DeepBlue Team',
      version: '1.1.0',
      lastUpdated: new Date('2024-12-15')
    },
    {
      id: 'nextjs-fullstack',
      name: 'Next.js Full-Stack App',
      description: 'Complete full-stack application with Next.js, Prisma, and Auth',
      category: 'fullstack',
      framework: 'Next.js',
      language: 'TypeScript',
      difficulty: 'advanced',
      estimatedTime: '2 hours',
      tags: ['nextjs', 'prisma', 'auth', 'fullstack'],
      features: ['Server-side rendering', 'Database ORM', 'Authentication', 'API routes', 'Deployment ready'],
      fileStructure: [
        {
          path: '/app',
          content: '',
          language: 'typescript',
          isDirectory: true
        },
        {
          path: '/app/page.tsx',
          content: `export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-24">
      <div className="z-10 max-w-5xl w-full items-center justify-between font-mono text-sm">
        <h1 className="text-4xl font-bold">Welcome to Next.js</h1>
        <p className="mt-4 text-xl">
          A full-stack application with authentication and database integration.
        </p>
      </div>
    </main>
  );
}`,
          language: 'typescript'
        },
        {
          path: '/app/api/auth/route.ts',
          content: `import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  const { email, password } = await request.json();
  
  // Add authentication logic here
  
  return NextResponse.json({ message: 'Authentication endpoint' });
}`,
          language: 'typescript'
        }
      ],
      dependencies: ['next', 'react', 'react-dom', 'prisma', '@prisma/client', 'next-auth'],
      scripts: {
        'dev': 'next dev',
        'build': 'next build',
        'start': 'next start'
      },
      environment: {
        'NEXTAUTH_SECRET': 'your-secret-here',
        'DATABASE_URL': 'postgresql://localhost:5432/nextapp'
      },
      readme: `# Next.js Full-Stack App

Complete full-stack application with Next.js, Prisma, and authentication.

## Features

- 🚀 Next.js 14 with App Router
- 🔐 NextAuth.js authentication
- 🗄️ Prisma ORM
- 💾 PostgreSQL database
- 🎨 Tailwind CSS styling`,
      isPopular: false,
      downloads: 3245,
      rating: 4.9,
      author: 'DeepBlue Team',
      version: '2.0.0',
      lastUpdated: new Date('2025-01-01')
    },
    {
      id: 'python-fastapi',
      name: 'FastAPI Python Backend',
      description: 'Modern Python API with FastAPI, SQLAlchemy, and async support',
      category: 'backend',
      framework: 'FastAPI',
      language: 'Python',
      difficulty: 'intermediate',
      estimatedTime: '1 hour',
      tags: ['python', 'fastapi', 'async', 'sqlalchemy'],
      features: ['Async support', 'Auto documentation', 'Type hints', 'Database ORM', 'Testing'],
      fileStructure: [
        {
          path: '/app',
          content: '',
          language: 'python',
          isDirectory: true
        },
        {
          path: '/app/main.py',
          content: `from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import uvicorn

app = FastAPI(title="FastAPI Backend", version="1.0.0")

class User(BaseModel):
    id: Optional[int] = None
    name: str
    email: str

users_db = [
    User(id=1, name="John Doe", email="john@example.com"),
    User(id=2, name="Jane Smith", email="jane@example.com")
]

@app.get("/")
async def root():
    return {"message": "Welcome to FastAPI"}

@app.get("/users", response_model=List[User])
async def get_users():
    return users_db

@app.post("/users", response_model=User)
async def create_user(user: User):
    user.id = len(users_db) + 1
    users_db.append(user)
    return user

@app.get("/users/{user_id}", response_model=User)
async def get_user(user_id: int):
    for user in users_db:
        if user.id == user_id:
            return user
    raise HTTPException(status_code=404, detail="User not found")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)`,
          language: 'python'
        },
        {
          path: '/requirements.txt',
          content: `fastapi==0.104.1
uvicorn[standard]==0.24.0
pydantic==2.5.0
sqlalchemy==2.0.23
python-multipart==0.0.6`,
          language: 'text'
        }
      ],
      dependencies: ['fastapi', 'uvicorn', 'pydantic', 'sqlalchemy'],
      scripts: {
        'dev': 'uvicorn app.main:app --reload',
        'start': 'uvicorn app.main:app --host 0.0.0.0 --port 8000'
      },
      environment: {
        'DATABASE_URL': 'sqlite:///./app.db'
      },
      readme: `# FastAPI Python Backend

Modern Python API with FastAPI, SQLAlchemy, and async support.

## Getting Started

1. Install dependencies: \`pip install -r requirements.txt\`
2. Start development server: \`uvicorn app.main:app --reload\`
3. Visit http://localhost:8000/docs for API documentation

## Features

- ⚡ FastAPI framework
- 📚 Automatic API documentation
- 🔄 Async/await support
- 🗄️ SQLAlchemy ORM
- ✅ Type hints throughout`,
      isPopular: true,
      downloads: 7834,
      rating: 4.7,
      author: 'DeepBlue Team',
      version: '1.3.0',
      lastUpdated: new Date('2024-12-20')
    }
  ]);

  const [selectedTemplate, setSelectedTemplate] = useState<ProjectTemplate | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'popular' | 'recent' | 'rating'>('popular');
  const [customTemplate, setCustomTemplate] = useState<Partial<ProjectTemplate>>({
    name: '',
    description: '',
    category: 'frontend',
    framework: '',
    language: '',
    difficulty: 'beginner'
  });

  const { createProject, addFile } = useIDEState();
  const { toast } = useToast();

  const filteredTemplates = projectTemplates
    .filter(template => {
      const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory;
      const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           template.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           template.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'popular':
          return b.downloads - a.downloads;
        case 'recent':
          return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
        case 'rating':
          return b.rating - a.rating;
        default:
          return 0;
      }
    });

  const handleCreateProject = useCallback(async (template: ProjectTemplate) => {
    try {
      // Create the project
      const projectId = await createProject(template.name, template.description);
      
      // Add all template files
      for (const fileTemplate of template.fileStructure) {
        await addFile({
          name: fileTemplate.path.split('/').pop() || 'file',
          path: fileTemplate.path,
          content: fileTemplate.content,
          language: fileTemplate.language,
          isDirectory: fileTemplate.isDirectory || false,
          projectId
        });
      }

      // Create package.json if dependencies exist
      if (template.dependencies.length > 0) {
        const packageJson = {
          name: template.name.toLowerCase().replace(/\s+/g, '-'),
          version: template.version,
          description: template.description,
          scripts: template.scripts,
          dependencies: template.dependencies.reduce((acc, dep) => {
            acc[dep] = 'latest';
            return acc;
          }, {} as Record<string, string>)
        };

        await addFile({
          name: 'package.json',
          path: '/package.json',
          content: JSON.stringify(packageJson, null, 2),
          language: 'json',
          isDirectory: false,
          projectId
        });
      }

      // Create README.md
      await addFile({
        name: 'README.md',
        path: '/README.md',
        content: template.readme,
        language: 'markdown',
        isDirectory: false,
        projectId
      });

      // Create .env file if environment variables exist
      if (Object.keys(template.environment).length > 0) {
        const envContent = Object.entries(template.environment)
          .map(([key, value]) => `${key}=${value}`)
          .join('\n');

        await addFile({
          name: '.env',
          path: '/.env',
          content: envContent,
          language: 'text',
          isDirectory: false,
          projectId
        });
      }

      toast({
        title: "Project created successfully",
        description: `${template.name} has been created with all template files`,
      });

      onClose();
    } catch (error) {
      toast({
        title: "Failed to create project",
        description: "An error occurred while creating the project",
        variant: "destructive",
      });
    }
  }, [createProject, addFile, toast, onClose]);

  const handleSaveCustomTemplate = useCallback(() => {
    if (!customTemplate.name || !customTemplate.description) {
      toast({
        title: "Missing information",
        description: "Please provide template name and description",
        variant: "destructive",
      });
      return;
    }

    // In a real implementation, this would save to a database
    toast({
      title: "Custom template saved",
      description: `${customTemplate.name} has been saved to your templates`,
    });

    // Reset form
    setCustomTemplate({
      name: '',
      description: '',
      category: 'frontend',
      framework: '',
      language: '',
      difficulty: 'beginner'
    });
  }, [customTemplate, toast]);

  const exportTemplate = useCallback((template: ProjectTemplate) => {
    const templateData = {
      template,
      exportedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(templateData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${template.name.toLowerCase().replace(/\s+/g, '-')}-template.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Template exported",
      description: "Template has been downloaded as JSON",
    });
  }, [toast]);

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FolderPlus className="w-5 h-5" />
            Project Templates
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 flex gap-6">
          {/* Sidebar */}
          <div className="w-80 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Filters</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Search</label>
                    <Input
                      placeholder="Search templates..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Category</label>
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        <SelectItem value="frontend">Frontend</SelectItem>
                        <SelectItem value="backend">Backend</SelectItem>
                        <SelectItem value="fullstack">Full-Stack</SelectItem>
                        <SelectItem value="mobile">Mobile</SelectItem>
                        <SelectItem value="desktop">Desktop</SelectItem>
                        <SelectItem value="game">Game</SelectItem>
                        <SelectItem value="data">Data Science</SelectItem>
                        <SelectItem value="ai">AI/ML</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Sort By</label>
                    <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="popular">Most Popular</SelectItem>
                        <SelectItem value="recent">Most Recent</SelectItem>
                        <SelectItem value="rating">Highest Rated</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {selectedTemplate && (
              <Card>
                <CardHeader>
                  <CardTitle>Template Details</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Framework</span>
                      <Badge variant="outline">{selectedTemplate.framework}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Language</span>
                      <Badge variant="outline">{selectedTemplate.language}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Difficulty</span>
                      <Badge 
                        variant={selectedTemplate.difficulty === 'beginner' ? 'secondary' : 
                                selectedTemplate.difficulty === 'intermediate' ? 'default' : 'destructive'}
                      >
                        {selectedTemplate.difficulty}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Est. Time</span>
                      <span className="text-sm text-gray-500">{selectedTemplate.estimatedTime}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Downloads</span>
                      <span className="text-sm text-gray-500">{selectedTemplate.downloads.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Rating</span>
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm">{selectedTemplate.rating}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 space-y-2">
                    <Button 
                      onClick={() => handleCreateProject(selectedTemplate)}
                      className="w-full"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Create Project
                    </Button>
                    <Button 
                      onClick={() => exportTemplate(selectedTemplate)}
                      variant="outline" 
                      className="w-full"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export Template
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Main Content */}
          <div className="flex-1">
            <Tabs defaultValue="browse">
              <TabsList>
                <TabsTrigger value="browse">Browse Templates</TabsTrigger>
                <TabsTrigger value="create">Create Template</TabsTrigger>
              </TabsList>

              <TabsContent value="browse" className="space-y-4">
                <div className="text-sm text-gray-500 mb-4">
                  {filteredTemplates.length} templates found
                </div>

                <ScrollArea className="h-[600px]">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {filteredTemplates.map((template) => (
                      <Card 
                        key={template.id}
                        className={`cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 ${
                          selectedTemplate?.id === template.id ? 'ring-2 ring-blue-500' : ''
                        }`}
                        onClick={() => setSelectedTemplate(template)}
                      >
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div>
                              <CardTitle className="flex items-center gap-2">
                                {template.isPopular && (
                                  <Star className="w-4 h-4 text-yellow-500" />
                                )}
                                {template.name}
                              </CardTitle>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline">{template.category}</Badge>
                                <Badge variant="secondary">{template.framework}</Badge>
                              </div>
                            </div>
                            <div className="text-right text-xs text-gray-500">
                              <div className="flex items-center gap-1">
                                <Star className="w-3 h-3" />
                                {template.rating}
                              </div>
                              <div>{template.downloads.toLocaleString()} downloads</div>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                            {template.description}
                          </p>
                          
                          <div className="space-y-2">
                            <div className="flex flex-wrap gap-1">
                              {template.tags.map((tag) => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                            
                            <div className="text-xs text-gray-500">
                              <div className="flex items-center gap-4">
                                <span className="flex items-center gap-1">
                                  <Clock className="w-3 h-3" />
                                  {template.estimatedTime}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Users className="w-3 h-3" />
                                  {template.author}
                                </span>
                              </div>
                            </div>
                          </div>

                          <div className="mt-3 space-y-1">
                            <div className="text-xs font-medium">Key Features:</div>
                            <div className="text-xs text-gray-600 dark:text-gray-300">
                              {template.features.slice(0, 3).join(', ')}
                              {template.features.length > 3 && '...'}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="create" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Create Custom Template</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium mb-2 block">Template Name</label>
                        <Input
                          value={customTemplate.name || ''}
                          onChange={(e) => setCustomTemplate(prev => ({ ...prev, name: e.target.value }))}
                          placeholder="My Custom Template"
                        />
                      </div>

                      <div>
                        <label className="text-sm font-medium mb-2 block">Framework</label>
                        <Input
                          value={customTemplate.framework || ''}
                          onChange={(e) => setCustomTemplate(prev => ({ ...prev, framework: e.target.value }))}
                          placeholder="React, Express, FastAPI..."
                        />
                      </div>

                      <div>
                        <label className="text-sm font-medium mb-2 block">Category</label>
                        <Select 
                          value={customTemplate.category || 'frontend'} 
                          onValueChange={(value: any) => setCustomTemplate(prev => ({ ...prev, category: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="frontend">Frontend</SelectItem>
                            <SelectItem value="backend">Backend</SelectItem>
                            <SelectItem value="fullstack">Full-Stack</SelectItem>
                            <SelectItem value="mobile">Mobile</SelectItem>
                            <SelectItem value="desktop">Desktop</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium mb-2 block">Language</label>
                        <Input
                          value={customTemplate.language || ''}
                          onChange={(e) => setCustomTemplate(prev => ({ ...prev, language: e.target.value }))}
                          placeholder="TypeScript, Python, Java..."
                        />
                      </div>

                      <div className="col-span-2">
                        <label className="text-sm font-medium mb-2 block">Description</label>
                        <Textarea
                          value={customTemplate.description || ''}
                          onChange={(e) => setCustomTemplate(prev => ({ ...prev, description: e.target.value }))}
                          placeholder="Describe your template..."
                          rows={3}
                        />
                      </div>

                      <div>
                        <label className="text-sm font-medium mb-2 block">Difficulty</label>
                        <Select 
                          value={customTemplate.difficulty || 'beginner'} 
                          onValueChange={(value: any) => setCustomTemplate(prev => ({ ...prev, difficulty: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="beginner">Beginner</SelectItem>
                            <SelectItem value="intermediate">Intermediate</SelectItem>
                            <SelectItem value="advanced">Advanced</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="mt-6 flex gap-2">
                      <Button onClick={handleSaveCustomTemplate}>
                        <Package className="w-4 h-4 mr-2" />
                        Save Template
                      </Button>
                      <Button variant="outline">
                        <Upload className="w-4 h-4 mr-2" />
                        Import Template
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Template Guidelines</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-sm space-y-2">
                      <div><strong>Name:</strong> Use clear, descriptive names</div>
                      <div><strong>Description:</strong> Explain what the template creates and its use case</div>
                      <div><strong>Structure:</strong> Include essential files and folders</div>
                      <div><strong>Dependencies:</strong> List all required packages</div>
                      <div><strong>Documentation:</strong> Provide clear setup instructions</div>
                      <div><strong>Examples:</strong> Include sample code and configurations</div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}